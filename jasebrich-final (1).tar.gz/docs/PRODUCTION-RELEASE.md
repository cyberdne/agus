# JASEB Production Release

## Runtime contract

- Node.js: `>=22.23.3` minimum for this release. Use the latest Node.js 22 LTS patch in the 22.x line for the current dependency set. Node.js 24 LTS should only be used after upgrading and runtime-testing the native `better-sqlite3` dependency.
- Start command: `node src/index.js`.
- The bot is a single direct process. It does not self-restart or spawn an internal supervisor.
- Use an external process manager for restart-on-failure in production (systemd, Docker, or another platform-native supervisor).

## Persistent state

Keep `data/` on a persistent volume. It contains the SQLite database and userbot session files. The release source package intentionally excludes runtime state from the distributable archive.

Userbot session storage remains plaintext `.txt` files by project design; protect the directory with filesystem permissions and server access controls. Do not move or encrypt session storage as part of this release.

## Environment

The existing `.env` file is preserved in the project exactly as requested. Do not commit or publicly distribute it.

## Deployment order

1. Back up the live `data/` directory.
2. Extract the release source over a staging directory.
3. Install dependencies once for the release (`npm ci` is preferred when the lockfile is authoritative). Do not run dependency installation on every process restart.
4. Verify syntax and run the available regression/contract suite.
5. Promote the release source. Keep the live `data/` directory persistent.
6. Start with `npm start`.
7. Verify `/start`, admin access, store/order flow, userbot activation/recovery, Auto Promosi start/stop, and restart recovery with controlled test accounts.

## Release gate

Do not mark a release production-ready unless all of these are known:

- source syntax passes;
- critical contract tests pass;
- dependency installation succeeds in the deployment environment;
- live Telegram smoke tests pass;
- restart recovery is verified;
- database backup/restore procedure is verified;
- logs contain no credentials or session strings;
- the release archive does not contain `data/`, SQLite database files, WAL/SHM files, or session files.

## Operational scaling

For a single-node deployment, the existing SQLite architecture is acceptable as the current persistence layer. When horizontal scaling becomes necessary, introduce shared coordination/storage (for example PostgreSQL plus a distributed limiter/queue) behind the existing repository/service boundaries instead of bypassing them from handlers.
