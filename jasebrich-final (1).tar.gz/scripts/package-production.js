#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const out = path.resolve(process.argv[2] || path.join(root, '..', 'jaseb-production-release.tar.gz'));
const parent = path.dirname(out);
fs.mkdirSync(parent, { recursive: true });

// Runtime state is deliberately excluded. The existing .env is preserved per
// project-owner instruction, so this archive must remain private.
const args = [
  '-czf', out,
  '--exclude=./node_modules',
  '--exclude=./data',
  '--exclude=./core.*',
  '--exclude=./*.log',
  '--exclude=./logs',
  '--exclude=./.git',
  '--exclude=./.jaseb-updates',
  '.',
];
const result = spawnSync('tar', args, { cwd: root, stdio: 'inherit' });
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status);

console.log(`Production package created: ${out}`);
