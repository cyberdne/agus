'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const assert = (cond, message) => {
  if (!cond) throw new Error(`FAIL: ${message}`);
  console.log(`PASS: ${message}`);
};

const store = read('src/handlers/store.handler.js');
const order = read('src/services/order.service.js');
const poolRepo = read('src/database/repositories/userbotPool.repository.js');
const poolHandler = read('src/handlers/admin/poolManagement.handler.js');
const poolKeyboard = read('src/keyboards/admin.keyboard.js');
const runtime = read('src/services/userbotRuntime.service.js');
const panel = read('src/handlers/panel.handler.js');
const poolConfig = read('src/services/poolPanelConfig.service.js');
const schema = read('src/database/schema.js');
const migrations = read('src/database/index.js');
const adminCallback = read('src/constants/admin.callback.js');
const transactionHandler = read('src/handlers/admin/transaction.handler.js');
const render = read('src/utils/render.js');
const index = read('src/index.js');
const gramjs = read('src/services/gramjs.service.js');
const config = read('src/config/index.js');
const userbot = read('src/services/userbot.service.js');

assert(order.includes('class JasebOutOfStockError'), 'Jaseb out-of-stock error exists at service boundary');
assert(order.includes('JasebOutOfStockError,\n  parseQtyStrict') || order.includes('JasebOutOfStockError,\n  parseQtyStrict'), 'Jaseb out-of-stock error is exported');
assert(order.includes('poolRepo.reserveForOrder(order.id, order.expires_at)'), 'new Jaseb orders reserve real pool stock atomically');
assert(poolRepo.includes("SET status = 'reserved'"), 'stock reservation uses database status transition');
assert(poolRepo.includes('releaseReservationsForClosedOrders();') && poolRepo.indexOf('releaseReservationsForClosedOrders();') < poolRepo.indexOf('SELECT COUNT(*)'), 'purchase inventory reconciles stale reservations before counting stock');
assert(poolRepo.includes("WHERE status = 'reserved' AND reservation_order_id = ?"), 'reservation is tied to canonical order id');
assert(poolRepo.includes("status IN ('available','disabled')") && poolRepo.includes('reservation_order_id IS NULL'), 'admin stock deletion is guarded against active/reserved/assigned rows');
assert(poolHandler.includes('poolDeleteConfirmCallback') && poolHandler.includes('poolDeleteCallback'), 'stock delete has explicit confirmation and execution handlers');
assert(poolKeyboard.includes('ADMIN_CALLBACK.POOL_VIEW(p.id)'), 'clicking stock item opens detail instead of deleting it');
assert(poolKeyboard.includes('ADMIN_CALLBACK.POOL_DEL_CONFIRM(id)'), 'delete action routes through confirmation callback');
assert(poolHandler.includes("row.status === 'available' || row.status === 'disabled'"), 'disabled/available stock deletion remains explicitly gated before delete');
assert(!poolKeyboard.includes('ADMIN_CALLBACK.POOL_DEL(p.id)'), 'stock list no longer routes item click directly to delete');
assert(poolConfig.includes('broadcast_text_entities'), 'pool panel stores Telegram text entities for formatting/custom emoji');
assert(schema.includes("broadcast_text_entities TEXT NOT NULL DEFAULT '[]'"), 'pool schema includes persisted message entities');
assert(migrations.includes('ALTER TABLE userbot_pool ADD COLUMN broadcast_text_entities TEXT NOT NULL DEFAULT'), 'existing databases receive additive pool message-entity migration');
assert(runtime.includes('deviceModel: config.telegramDeviceModel || \'JASEBRICH\''), 'GramJS runtime uses JASEBRICH device model');
assert(config.includes("telegramDeviceModel: process.env.TELEGRAM_DEVICE_MODEL || 'JASEBRICH'"), 'device model is centrally configurable with JASEBRICH default');
assert(store.includes('userbotService.getAvailableJasebStockCount()'), 'store catalog checks real Jaseb stock before rendering products');
assert(store.includes('JASEB_OUT_OF_STOCK'), 'store handles Jaseb stock race at order creation');
assert(userbot.includes('findReservedByOrder(order.id)'), 'Jaseb fulfillment prefers the reservation belonging to the order');
assert(panel.includes('checkAssetFeature(sel.asset, featureId, sel.kind)'), 'panel access is entitlement-gated for selected asset kind');
assert(index.includes("bot.hears('🧾 Transaksi', requireAdmin(transactionHomeCallback))"), 'Admin Panel exposes canonical transaction management');
assert((index.match(/bot\.hears\(MENU\.STORE, storeHandler\)/g) || []).length === 1, 'Store reply entry has exactly one handler registration');
assert((index.match(/bot\.action\(CALLBACK\.STORE_HOME, storeHomeCallback\)/g) || []).length === 1, 'Store inline-home callback has exactly one registration');
assert(index.includes('admintrx:approve:') && index.includes('admintrx:reject:'), 'transaction callbacks are registered');
assert(adminCallback.includes('TRANSACTIONS_HOME') && adminCallback.includes('TRANSACTION_APPROVE'), 'transaction callback constants exist');
assert(transactionHandler.includes('orderRepo.listForAdmin') && transactionHandler.includes('orderService.fulfillOrder'), 'Admin Transaksi reuses canonical order repository/service');
assert(transactionHandler.includes('payment_proof_file_id'), 'Admin Transaksi reads persisted real payment proof identifiers');
assert(transactionHandler.includes('updateTransactionNotification') && transactionHandler.includes("status: 'REJECTED'"), 'Admin transaction actions converge existing transaction-channel projection');
assert(transactionHandler.includes('requireAdmin') === false, 'transaction handlers are kept domain-neutral and protected at registration layer');
assert(render.includes('editMessageCaption') && render.includes('getEditMode'), 'message renderer distinguishes text vs caption media');
assert(render.includes('there is no text in the message to edit'), 'renderer explicitly handles the historical Telegram edit failure');
assert(store.includes("renderWithReplyKeyboard(ctx, content.text") && store.includes("null, 'store'"), 'store screen has a feature identity for duplicate-screen prevention');
assert(store.includes('runStoreActionIdempotently(ctx'), 'Store entry uses stable-update/source-message idempotency');
assert(panel.includes('panelMainKeyboard(active)'), 'userbot and Jaseb share one canonical main panel keyboard renderer');
assert(read('src/handlers/admin/panelUbot.handler.js').includes('const pool = poolRepo.listAll();'), 'Admin control-panel picker includes live Jaseb pool assets');

console.log('ALL JASEB-RICH PRODUCTION CONTRACT CHECKS PASS');
