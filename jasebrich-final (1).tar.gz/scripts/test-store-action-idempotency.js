'use strict';

const assert = require('assert');
const { createActionIdempotency } = require('../src/utils/actionIdempotency');

(async () => {
  const gate = createActionIdempotency({ ttlMs: 60_000, maxEntries: 100 });
  let executions = 0;

  const action = async () => {
    executions += 1;
    await new Promise((resolve) => setTimeout(resolve, 5));
    return { ok: true };
  };

  const [a, b] = await Promise.all([
    gate.run('telegram-update:100', action),
    gate.run('telegram-update:100', action),
  ]);
  assert.strictEqual(executions, 1, 'same update processed concurrently executes once');
  assert.deepStrictEqual(a, { ok: true });
  assert.deepStrictEqual(b, { ok: true });

  const c = await gate.run('telegram-update:100', action);
  assert.deepStrictEqual(c, { deduped: true }, 'same completed update is idempotent');
  assert.strictEqual(executions, 1, 'completed duplicate does not execute again');

  await gate.run('telegram-update:101', action);
  assert.strictEqual(executions, 2, 'different Telegram update executes normally');

  let failedExecutions = 0;
  const failing = async () => {
    failedExecutions += 1;
    throw new Error('expected test failure');
  };
  await assert.rejects(() => gate.run('telegram-update:102', failing), /expected test failure/);
  await assert.rejects(() => gate.run('telegram-update:102', failing), /expected test failure/);
  assert.strictEqual(failedExecutions, 2, 'failed action is not marked completed, allowing a real retry');

  console.log('STORE_ACTION_IDEMPOTENCY_PASS concurrent=1 completed-dedup=1 distinct-update=1 failure-retry=1');
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
