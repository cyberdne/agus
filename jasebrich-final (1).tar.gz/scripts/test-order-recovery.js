'use strict';
/**
 * End-to-end order recovery/claim tests against the real database,
 * repository, and order service. No mocks are used for DB/status/claim logic.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-order-recovery-'));
process.env.DB_PATH = path.join(tmpDir, 'recovery.sqlite');
process.env.BOT_TOKEN = 'test-token';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'test-hash';

const { initDatabase, getDb } = require('../src/database');
const orderRepo = require('../src/database/repositories/order.repository');
const orderService = require('../src/services/order.service');
const { CATEGORIES } = require('../src/services/product.service');

initDatabase();
const db = getDb();
const results = [];
const NOW = '2035-01-01T12:00:00.000Z';
const toIso = (secondsBefore) => new Date(Date.parse(NOW) - secondsBefore * 1000).toISOString();

async function test(name, fn) {
  try { await fn(); results.push(true); console.log(`PASS  ${name}`); }
  catch (e) { results.push(false); console.log(`FAIL  ${name}\n      ${(e && e.stack) || e}`); }
}

let nextUserId = 100;
let nextOrderId = 1000;
function makeUser(telegramId) {
  db.prepare('INSERT INTO users (id, telegram_id) VALUES (?, ?)').run(nextUserId++, telegramId);
  return telegramId;
}
function makeOrder(userId, status = 'paid', category = 'userbot') {
  const id = nextOrderId++;
  db.prepare(`
    INSERT INTO orders (id, user_id, category, product_name, qty, unit_price, total_price, duration_days, status, created_at, expires_at)
    VALUES (?, ?, ?, ?, 1, 1000, 1000, 30, ?, ?, ?)
  `).run(id, userId, category, 'Recovery Test', status, '2099-01-01 00:00:00', '2099-01-01 01:00:00');
  return id;
}
function setProcessingLease(id, { startedAt = null, heartbeatAt = null, claimToken = null, updatedAt = NOW } = {}) {
  db.prepare(`
    UPDATE orders
    SET status='processing', processing_started_at=?, processing_heartbeat_at=?, processing_claim_token=?, updated_at=?
    WHERE id=?
  `).run(startedAt, heartbeatAt, claimToken, updatedAt, id);
}

(async () => {
  const userA = makeUser(990001);
  const userB = makeUser(990002);
  const userC = makeUser(990003);
  const userD = makeUser(990004);
  const userE = makeUser(990005);
  const userF = makeUser(990006);
  const userG = makeUser(990007);
  const userH = makeUser(990008);
  const userI = makeUser(990009);
  const userJ = makeUser(990010);
  const userK = makeUser(990011);
  const userL = makeUser(990012);

  await test('A — fresh processing is not reclaimed', () => {
    const id = makeOrder(userA);
    const token = orderRepo.claimForProcessing(id);
    assert.equal(typeof token, 'string');
    // claimForProcessing stamps the REAL clock (datetime('now')), so the
    // recovery anchor must be the real clock too (default anchor), not NOW=2035.
    assert.equal(orderService.reclaimStaleProcessingOrders(), 0);
    assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(id).status, 'processing');
    orderRepo.releaseProcessingClaim(id, token, 'paid');
  });

  await test('B — 14:59 processing is not reclaimed', () => {
    const id = makeOrder(userB);
    setProcessingLease(id, { startedAt: toIso(14 * 60 + 59), heartbeatAt: toIso(14 * 60 + 59), claimToken: 'fresh-boundary' });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 0);
    assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(id).status, 'processing');
  });

  await test('C — exactly 15:00 boundary is not reclaimed because stale means strictly older than threshold', () => {
    const id = makeOrder(userC);
    setProcessingLease(id, { startedAt: toIso(15 * 60), heartbeatAt: toIso(15 * 60), claimToken: 'equal-boundary' });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 0);
    assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(id).status, 'processing');
  });

  await test('D — 15:01 stale processing is recovered', () => {
    const id = makeOrder(userD);
    setProcessingLease(id, { startedAt: toIso(15 * 60 + 1), heartbeatAt: toIso(15 * 60 + 1), claimToken: 'stale-boundary' });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 1);
    assert.deepEqual(db.prepare('SELECT status, processing_started_at, processing_heartbeat_at, processing_claim_token FROM orders WHERE id=?').get(id), {
      status: 'paid', processing_started_at: null, processing_heartbeat_at: null, processing_claim_token: null,
    });
  });

  await test('E — legacy processing row with NULL lease metadata falls back to stale updated_at', () => {
    const id = makeOrder(userE);
    const legacyUpdatedAt = toIso(16 * 60);
    setProcessingLease(id, { startedAt: null, heartbeatAt: null, claimToken: null, updatedAt: legacyUpdatedAt });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 1);
    assert.deepEqual(db.prepare('SELECT status, updated_at FROM orders WHERE id=?').get(id), { status: 'paid', updated_at: legacyUpdatedAt });
  });

  await test('F — current claim with fresh heartbeat is protected even when updated_at is old', () => {
    const id = makeOrder(userF);
    setProcessingLease(id, {
      startedAt: toIso(60 * 60),
      heartbeatAt: toIso(2 * 60),
      claimToken: 'live-claim',
      updatedAt: toIso(60 * 60),
    });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 0);
    assert.deepEqual({ ...db.prepare('SELECT status, processing_claim_token FROM orders WHERE id=?').get(id) }, { status: 'processing', processing_claim_token: 'live-claim' });
  });

  await test('G — heartbeat refresh prevents recovery, while a stopped heartbeat becomes recoverable', () => {
    const id = makeOrder(userG);
    const token = orderRepo.claimForProcessing(id);
    setProcessingLease(id, { startedAt: toIso(30 * 60), heartbeatAt: toIso(20 * 60), claimToken: token, updatedAt: toIso(20 * 60) });
    assert.equal(orderRepo.touchProcessing(id, token), true);
    // touchProcessing stamps the real clock -> evaluate recovery at the real clock.
    assert.equal(orderService.reclaimStaleProcessingOrders(), 0);

    setProcessingLease(id, { startedAt: toIso(30 * 60), heartbeatAt: toIso(16 * 60), claimToken: token, updatedAt: toIso(16 * 60) });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 1);
    assert.equal(orderRepo.touchProcessing(id, token), false);
  });

  await test('H — recovered order can be claimed again and old worker cannot finalize it', () => {
    const id = makeOrder(userH);
    setProcessingLease(id, { startedAt: toIso(16 * 60), heartbeatAt: toIso(16 * 60), claimToken: 'old-worker', updatedAt: toIso(16 * 60) });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 1);
    const newToken = orderRepo.claimForProcessing(id);
    assert.equal(typeof newToken, 'string');
    assert.notEqual(newToken, 'old-worker');
    assert.equal(orderRepo.setFulfillment(id, 777, 'old-worker'), false);
    assert.equal(orderRepo.setFulfillment(id, 777, newToken), true);
    assert.deepEqual(db.prepare('SELECT status, fulfillment_ref FROM orders WHERE id=?').get(id), { status: 'fulfilled', fulfillment_ref: 777 });
  });

  await test('I — repeated recovery is idempotent', () => {
    const id = makeOrder(userI);
    setProcessingLease(id, { startedAt: toIso(16 * 60), heartbeatAt: toIso(16 * 60), claimToken: 'repeat', updatedAt: toIso(16 * 60) });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 1);
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 0);
    assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(id).status, 'paid');
  });

  await test('J — two processing claims against the same order have exactly one winner', () => {
    const id = makeOrder(userJ);
    const first = orderRepo.claimForProcessing(id);
    const second = orderRepo.claimForProcessing(id);
    assert.equal(typeof first, 'string');
    assert.equal(second, null);
    assert.equal(db.prepare('SELECT status, processing_claim_token FROM orders WHERE id=?').get(id).processing_claim_token, first);
    orderRepo.releaseProcessingClaim(id, first, 'paid');
  });

  await test('K — ambiguous processing ownership is not guessed when claim token has no timestamps', () => {
    const id = makeOrder(userK);
    setProcessingLease(id, { startedAt: null, heartbeatAt: null, claimToken: 'unknown-worker', updatedAt: toIso(60 * 60) });
    assert.equal(orderService.reclaimStaleProcessingOrders(NOW), 0);
    assert.deepEqual(db.prepare('SELECT status, processing_claim_token, updated_at FROM orders WHERE id=?').get(id), {
      status: 'processing', processing_claim_token: 'unknown-worker', updated_at: toIso(60 * 60),
    });
  });

  await test('L — normal userbot fulfillment still reaches fulfilled and remains idempotent', async () => {
    const user = userL;
    const orderId = makeOrder(user, 'awaiting_confirmation', CATEGORIES.USERBOT);
    const result = await orderService.fulfillOrder({ getChat: async () => ({}) }, orderId);
    assert.equal(result.ok, true);
    assert.equal(result.type, 'userbot');
    assert.ok(result.pendingOwnedId > 0);
    assert.deepEqual(db.prepare('SELECT status, fulfillment_ref FROM orders WHERE id=?').get(orderId), { status: 'fulfilled', fulfillment_ref: result.pendingOwnedId });
    assert.deepEqual(db.prepare('SELECT order_id, status, user_id FROM userbots WHERE id=?').get(result.pendingOwnedId), { order_id: orderId, status: 'pending_otp', user_id: user });
    const duplicate = await orderService.fulfillOrder({ getChat: async () => ({}) }, orderId);
    assert.deepEqual({ ok: duplicate.ok, reason: duplicate.reason }, { ok: false, reason: 'already_fulfilled' });
  });

  const failed = results.filter((r) => !r).length;
  console.log(`\n${results.length - failed}/${results.length} passed`);
  process.exit(failed ? 1 : 0);
})();
