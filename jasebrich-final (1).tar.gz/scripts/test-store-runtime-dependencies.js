'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

const ROOT = path.resolve(__dirname, '..');
const storePath = path.join(ROOT, 'src/handlers/store.handler.js');
const storeSource = fs.readFileSync(storePath, 'utf8');

// Regression contract for the production incident:
// renderCategoryProducts() reaches the real Jaseb stock boundary. The handler
// must bind that dependency from the actual userbot service module; a missing
// lexical binding previously caused a ReferenceError only when Beli Jaseb was
// opened, even though static routing/price tests all passed.
assert.match(
  storeSource,
  /const userbotService = require\('\.\.\/services\/userbot\.service'\);/,
  'Store handler must import the real userbot service used by Jaseb stock routing'
);

const originalLoad = Module._load;
const calls = { render: [], listActive: [], stock: 0 };
let fakeStock = 1;

const markup = {
  keyboard(rows) {
    return { reply_markup: { keyboard: rows }, resize() { return this; } };
  },
  inlineKeyboard(rows) {
    return { reply_markup: { inline_keyboard: rows } };
  },
};

const fakeProductService = {
  CATEGORIES: { USERBOT: 'userbot', JASEB: 'jaseb', RENEWAL: 'renewal' },
  CATEGORY_LABEL: { userbot: '🤖 Beli Userbot', jaseb: '🔥 Beli Jaseb', renewal: '🔄 Perpanjang Langganan' },
  formatRupiah(value) { return `Rp ${value}`; },
  listActive(category) {
    calls.listActive.push(category);
    return [{ id: 10, name: category === 'jaseb' ? 'Jaseb 1 Bulan' : 'Userbot 1 Bulan', price: 10000, duration_days: 30, garansi: 0, category }];
  },
  resolvePurchaseProduct() { throw new Error('not exercised by this regression test'); },
};

const fakeOrderService = {
  QTY_MIN: 1,
  QTY_MAX: 24,
  InvalidQuantityError: class InvalidQuantityError extends Error {},
  parseQtyStrict() { return null; },
  validateQty() { return null; },
};

const fakeTemplate = () => ({
  getContent() { return { text: 'STORE_CONTENT', parse_mode: 'Markdown' }; },
});

const fakeCustomSubmenu = {
  defineSubmenu: () => ({}),
  defineTemplate: fakeTemplate,
  buildReplyOptions: () => ({}),
  buildCaptionOptions: () => ({}),
};

const fakeUserbotService = {
  getAvailableJasebStockCount() {
    calls.stock += 1;
    return fakeStock;
  },
};

Module._load = function patched(request, parent, isMain) {
  switch (request) {
    case 'telegraf': return { Markup: markup };
    case '../utils/buttons': return {
      replyButton: {
        success(label) { return { text: label }; },
        danger(label) { return { text: label }; },
      },
      button: {
        primary(label, callback) { return { text: label, callback_data: callback }; },
        success(label, callback) { return { text: label, callback_data: callback }; },
        danger(label, callback) { return { text: label, callback_data: callback }; },
      },
    };
    case '../state/buyerState': return { get() {}, set() {}, clear() {} };
    case '../database/repositories/order.repository': return {};
    case '../services/notification.service': return {};
    case '../utils/render': return {
      renderScreen: async (...args) => { calls.render.push(args); },
      renderWithReplyKeyboard: async (...args) => { calls.render.push(args); },
      isTextMessage: () => false,
    };
    case '../keyboards/inline.keyboard': return {
      storeCancelConfirmationKeyboard: () => ({}),
      storeProductListKeyboard: () => ({}),
      storeProductDetailKeyboard: () => ({}),
      storePolicyKeyboard: () => ({}),
      storePaymentKeyboard: () => ({}),
      storeCancelAllConfirmationKeyboard: () => ({}),
      storePendingOrderRecoveryKeyboard: () => ({}),
      storeCategoryBackKeyboard: () => ({}),
    };
    case '../keyboards/main.keyboard': return { storeKeyboard: {} };
    case '../services/custom-submenu.service': return fakeCustomSubmenu;
    case '../services/product.service': return fakeProductService;
    case '../services/order.service': return fakeOrderService;
    case '../services/payment.service': return {};
    case '../services/premiumEmojiConfig.service': return { configForGaransi: () => ({ icon: '📦', customEmojiId: null }) };
    case '../services/user.service': return {};
    case '../services/userbot.service': return fakeUserbotService;
    case '../utils/emojiMarkdown': return {
      escapeMdV2: (v) => String(v), boldMdV2: (v) => String(v), emojiMdV2: (v) => String(v && v.icon ? v.icon : '📦'),
    };
    case '../constants/menu': return {
      MENU: { PERPANJANG_LANGGANAN: '🔄 Perpanjang Langganan', BATAL: '❌ Batal' },
      CALLBACK: {
        STORE_HOME: 'store:home',
        STORE_CATEGORY: (category) => `store:cat:${category}`,
      },
    };
    case '../utils/placeholders': return { formatIndonesiaDate: (v) => String(v) };
    case '../services/renewalTarget.service': return { resolve: () => ({ status: 'none' }) };
    case '../services/subscription.service': return { isActiveNow: () => true };
    case '../utils/logger': return { debug() {}, info() {}, warn() {}, error() {} };
    case '../utils/actionIdempotency': return { createActionIdempotency: () => ({ run: (_key, fn) => fn() }) };
    default: return originalLoad.call(this, request, parent, isMain);
  }
};

async function main() {
  try {
    delete require.cache[storePath];
    const { renderCategoryProducts } = require(storePath);
    assert.equal(typeof renderCategoryProducts, 'function');

    const ctx = { from: { id: 123456 } };
    fakeStock = 1;
    await renderCategoryProducts(ctx, fakeProductService.CATEGORIES.JASEB);
    assert.equal(calls.stock, 1, 'Jaseb catalog must call the real userbot stock service exactly once');
    assert.deepEqual(calls.listActive, ['jaseb'], 'Jaseb catalog must query only the Jaseb product category');
    assert.equal(calls.render.length, 1, 'available Jaseb stock must render the catalog');

    calls.render.length = 0;
    calls.listActive.length = 0;
    fakeStock = 0;
    await renderCategoryProducts(ctx, fakeProductService.CATEGORIES.JASEB);
    assert.equal(calls.stock, 2, 'Jaseb stock boundary must be checked on every Jaseb catalog render');
    assert.deepEqual(calls.listActive, [], 'zero Jaseb stock must stop before querying/rendering products');
    assert.equal(calls.render.length, 1, 'zero Jaseb stock must render the existing empty-stock screen');

    console.log('STORE_RUNTIME_DEPENDENCY_PASS jaseb-stock-service-bound=1 stock-empty-path=1 category-isolated=1');
  } finally {
    Module._load = originalLoad;
    delete require.cache[storePath];
  }
}

main().catch((err) => {
  console.error(err && err.stack ? err.stack : err);
  process.exitCode = 1;
});
