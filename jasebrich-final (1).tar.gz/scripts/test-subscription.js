'use strict';
/**
 * Real integration tests for subscription enforcement + admin extension.
 *
 * What is REAL: SQLite (temp file, real schema + migrations), every service,
 * repository, handler, middleware-guard and the runtime manager.
 * What is substituted (transport boundary only — no network in CI):
 *   - GramJS TelegramClient  -> in-process FakeClient (records connect /
 *     disconnect / addEventHandler / removeEventHandler; can simulate a
 *     revoked session)
 *   - Telegram Bot API       -> recording fake `ctx.reply` / `telegram.sendMessage`
 * Run: node scripts/test-subscription.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-sub-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');

// ---- fake GramJS ------------------------------------------------------
const tg = require(path.join(root, 'node_modules/telegram'));
const fakes = { created: [], sessionInvalid: new Set() };
class FakeClient {
  constructor(session) { this.session = String(session.save ? session.save() : ''); this.handlers = []; this.connected = false; this.disconnects = 0; fakes.created.push(this); }
  async connect() { this.connected = true; }
  async disconnect() { this.connected = false; this.disconnects++; }
  addEventHandler(cb, ev) { this.handlers.push([ev, cb]); }
  removeEventHandler(cb, ev) { this.handlers = this.handlers.filter((h) => h[1] !== cb); }
  async invoke() {
    if (fakes.sessionInvalid.has(this.session)) { const e = new Error('401: AUTH_KEY_UNREGISTERED'); e.errorMessage = 'AUTH_KEY_UNREGISTERED'; throw e; }
    return {};
  }
}
Object.defineProperty(tg, 'TelegramClient', { value: FakeClient, configurable: true, writable: true });
const sess = require(path.join(root, 'node_modules/telegram/sessions'));
Object.defineProperty(sess, 'StringSession', { value: class { constructor(s) { this.s = s; } save() { return this.s; } }, configurable: true });

const { initDatabase, getDb } = require(path.join(root, 'src/database'));
initDatabase();
const db = getDb();
const S = (p) => require(path.join(root, 'src', p));
const subscription = S('services/subscription.service');
const lifecycle = S('services/userbotLifecycle.service');
const runtime = S('services/userbotRuntime.service');
const access = S('services/userbotAccess.service');
const ownedRepo = S('database/repositories/ownedUserbot.repository');
const orderService = S('services/order.service');
const DAY = 86400000;

const sent = [];
lifecycle.setTelegram({ sendMessage: async (id, text, o) => { sent.push({ id, text, o }); } });

let n = 0;
function mkUser(id) { db.prepare("INSERT OR IGNORE INTO users (telegram_id, username, first_name) VALUES (?,?,?)").run(id, `u${id}`, `U${id}`); }
function mkBot({ user = 100, expires, status = 'active', flags = 1, label = 'Userbot X', order = 1 } = {}) {
  mkUser(user);
  const r = db.prepare(`INSERT INTO userbots (user_id,label,status,session_string,telegram_userbot_id,auto_promosi,wtb_reply,pm_permit,expires_at,order_id,target,broadcast_text)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(user, label, status, `sess-${++n}`, 5000 + n, 0, flags, 0, expires, order, '@grup', 'PROMO TEXT');
  db.prepare('INSERT OR IGNORE INTO panel_groups (userbot_id,target,title) VALUES (?,?,?)').run(r.lastInsertRowid, '@grup', 'G');
  return ownedRepo.findById(r.lastInsertRowid);
}
const iso = (ms) => new Date(ms).toISOString();
const results = [];
async function test(name, fn) {
  try { await fn(); results.push([true, name]); console.log(`PASS  ${name}`); }
  catch (e) { results.push([false, name]); console.log(`FAIL  ${name}\n      ${e && e.stack || e}`); }
}
function fakeCtx(userId, data) {
  const replies = [];
  const ctx = {
    from: { id: userId, first_name: 'U', username: `u${userId}` }, chat: { id: userId, type: 'private' },
    updateType: data ? 'callback_query' : 'message', message: data ? undefined : { text: 'x', message_id: 1 },
    callbackQuery: data ? { data, message: { message_id: 5, chat: { id: userId } } } : undefined,
    telegram: { sendMessage: async (id, text, o) => { sent.push({ id, text, o }); } },
    replies,
    reply: async (text, o) => { replies.push({ text, o }); return { message_id: replies.length }; },
    editMessageText: async (text, o) => { replies.push({ text, o, edited: true }); },
    answerCbQuery: async () => true,
  };
  return ctx;
}
const buttonsOf = (o) => (o && o.reply_markup && o.reply_markup.inline_keyboard || []).flat();
const tick = () => new Promise((r) => setTimeout(r, 30));

(async () => {
  // ---------------------------------------------------------------- migration
  await test('Migration: legacy schema DB gains new columns/table without data loss', () => {
    const Database = require(path.join(root, 'node_modules/better-sqlite3'));
    const p = path.join(tmp, 'legacy.sqlite');
    const d = new Database(p);
    d.exec(`CREATE TABLE users (id INTEGER PRIMARY KEY, telegram_id INTEGER UNIQUE NOT NULL);
      CREATE TABLE userbots (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, label TEXT, status TEXT, session_string TEXT, expires_at TEXT);
      CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, status TEXT);
      INSERT INTO userbots (user_id,label,status,expires_at) VALUES (1,'old','active','2030-01-01T00:00:00.000Z');`);
    // Re-run the app's own migration statements against it.
    const src = fs.readFileSync(path.join(root, 'src/database/index.js'), 'utf8');
    const stmts = [...src.matchAll(/"(ALTER TABLE (?:userbots|orders) ADD COLUMN [^"]+)"/g)].map((m) => m[1]);
    for (const s of stmts) { try { d.exec(s); } catch (e) { if (!/duplicate column|no such table/.test(e.message)) throw e; } }
    const cols = d.prepare('PRAGMA table_info(userbots)').all().map((c) => c.name);
    for (const c of ['runtime_stop_reason', 'expired_at', 'sub_version', 'updated_at']) assert(cols.includes(c), c);
    assert(d.prepare('PRAGMA table_info(orders)').all().some((c) => c.name === 'target_userbot_id'));
    assert.equal(d.prepare('SELECT label FROM userbots').get().label, 'old');
    d.close();
  });

  // ---------------------------------------------------------------- pure math
  const NOW = Date.parse('2026-09-19T05:00:00.000Z');
  await test('G: active subscription +30d is added to CURRENT expiry (30 Sep -> 30 Oct)', () => {
    const c = subscription.computeExtension({ status: 'active', expires_at: '2026-09-30T00:00:00.000Z' }, 30, NOW);
    assert.equal(c.newExpiry, '2026-10-30T00:00:00.000Z'); assert.equal(c.base, 'current_expiry');
  });
  await test('H: expired (10 Sep) on 19 Sep +30d counts from NOW (-> 19 Oct), no double duration', () => {
    const c = subscription.computeExtension({ status: 'expired', expires_at: '2026-09-10T00:00:00.000Z' }, 30, NOW);
    assert.equal(c.newExpiry, '2026-10-19T05:00:00.000Z'); assert.equal(c.base, 'now');
  });
  await test('Boundary: now === expires_at is EXPIRED (deterministic); SQLite/ISO formats agree', () => {
    assert.equal(subscription.isExpiredAt('2026-09-19T05:00:00.000Z', NOW), true);
    assert.equal(subscription.isExpiredAt('2026-09-19T05:00:00.001Z', NOW), false);
    assert.equal(subscription.isExpiredAt('2026-09-19 05:00:00', NOW), true);
    assert.equal(subscription.isExpiredAt(null, NOW), false);
  });
  await test('Invalid durations rejected', () => {
    for (const d of [0, -1, 1.5, 'x', 99999]) assert.throws(() => subscription.computeExtension({ expires_at: null }, d), /Durasi/);
  });

  // ------------------------------------------------------- A/B/F access guard
  await test('A: active subscription -> control access granted', () => {
    const b = mkBot({ expires: iso(Date.now() + 5 * DAY) });
    assert.equal(access.checkUserbotControlAccess({ userbotId: b.id, actorId: 100 }).ok, true);
  });
  await test('B/F: expired by timestamp (status still "active", scheduler NOT run) is locked immediately', async () => {
    const b = mkBot({ expires: iso(Date.now() - 1000) });
    assert.equal(ownedRepo.findById(b.id).status, 'active');
    const r = access.checkUserbotControlAccess({ userbotId: b.id, actorId: 100 });
    assert.equal(r.ok, false); assert.equal(r.code, 'EXPIRED');
    await tick(); // lazy enforcement persisted the transition
    assert.equal(ownedRepo.findById(b.id).status, 'expired');
  });
  await test('P: user A cannot use userbot B (NOT_OWNER), even via callback id guessing', () => {
    const b = mkBot({ user: 101, expires: iso(Date.now() + DAY) });
    assert.equal(access.checkUserbotControlAccess({ userbotId: b.id, actorId: 100 }).code, 'NOT_OWNER');
    const e = mkBot({ user: 101, expires: iso(Date.now() - DAY) });
    assert.equal(access.checkUserbotControlAccess({ userbotId: e.id, actorId: 100 }).code, 'NOT_OWNER');
  });

  // ------------------------------------------------ B/C panel handlers (UI+old)
  const panel = S('handlers/panel.handler');
  const panelState = S('state/panelState');
  await test('B: Kontrol Panel entry with only-expired userbot -> renewal screen, no panel', async () => {
    mkUser(200);
    const b = mkBot({ user: 200, expires: iso(Date.now() - DAY) });
    const ctx = fakeCtx(200);
    await panel.panelHandler(ctx);
    const first = ctx.replies[0];
    assert.match(first.text, /Kadaluarsa/);
    assert(buttonsOf(first.o).some((x) => x.callback_data === `subscription:renew:${b.id}`));
    assert.equal(panelState.get(200), null);
  });
  await test('C: OLD panel state + old reply/inline buttons after expiry are rejected and redirected', async () => {
    const b = mkBot({ user: 201, expires: iso(Date.now() + 2000) });
    panelState.set(201, { kind: 'owned', id: b.id, step: null, screen: 'main', adminMode: false });
    // simulate time passing (expire in DB, no scheduler)
    db.prepare('UPDATE userbots SET expires_at=? WHERE id=?').run(iso(Date.now() - 1), b.id);
    const actions = [panel.startHandler, panel.baseReplyHandler, panel.groupHandler, panel.messageHandler, panel.pmPermitHandler,
      panel.autoReactEnableHandler, panel.groupDeleteAllConfirmCallback, panel.resetDataHandler, panel.transferHandler,
      panel.backupTokenHandler, panel.addGroupHandler, panel.extraHandler, panel.broadcastPmHandler];
    for (const h of actions) {
      panelState.set(201, { kind: 'owned', id: b.id, step: null, screen: 'main', adminMode: false });
      const ctx = h === panel.groupDeleteAllConfirmCallback ? fakeCtx(201, 'panelgrp:delallconfirm') : fakeCtx(201);
      const before = db.prepare('SELECT COUNT(*) c FROM panel_groups WHERE userbot_id=?').get(b.id).c;
      await h(ctx); await tick();
      assert(ctx.replies.some((r) => /Kadaluarsa/.test(r.text)), `handler ${h.name || ''} did not show renewal`);
      assert.equal(db.prepare('SELECT COUNT(*) c FROM panel_groups WHERE userbot_id=?').get(b.id).c, before, 'action must not run');
      assert.equal(ownedRepo.findById(b.id).auto_promosi, 0);
    }
  });
  await test('C2: wizard text step in progress when expiry hits is not executed', async () => {
    const b = mkBot({ user: 202, expires: iso(Date.now() - 5) });
    panelState.set(202, { kind: 'owned', id: b.id, step: 'await_add_reply_keyword', screen: 'reply', adminMode: false });
    const ctx = fakeCtx(202);
    await panel.handleStepInput(ctx, panelState.get(202), 'harga'); await tick();
    assert(ctx.replies.some((r) => /Kadaluarsa/.test(r.text)));
    assert.equal(db.prepare('SELECT COUNT(*) c FROM panel_wtb_replies WHERE userbot_id=?').get(b.id).c, 0);
  });
  await test('C3: forward-message interceptor path is guarded too', async () => {
    const b = mkBot({ user: 203, expires: iso(Date.now() - 5) });
    const st = { kind: 'owned', id: b.id, step: 'await_message_forward', adminMode: false };
    panelState.set(203, st);
    const ctx = fakeCtx(203);
    const asset = await panel.guardPanelState(ctx, st);
    assert.equal(asset, null); assert(ctx.replies.some((r) => /Kadaluarsa/.test(r.text)));
  });
  await test('O: multiple userbots: expiry of one does not affect the other; picker offered', async () => {
    const a = mkBot({ user: 204, expires: iso(Date.now() + 9 * DAY) });
    const e = mkBot({ user: 204, expires: iso(Date.now() - DAY), label: 'Kedua' });
    const ctx = fakeCtx(204);
    await panel.panelHandler(ctx);
    assert(/#\d+/.test(ctx.replies[0].text) && ctx.replies[0].text.includes(`#${e.id}`), 'picker mentions expired');
    assert.equal(access.checkUserbotControlAccess({ userbotId: a.id, actorId: 204 }).ok, true);
    assert.equal(access.checkUserbotControlAccess({ userbotId: e.id, actorId: 204 }).ok, false);
    // picking expired one goes to renewal screen
    const ctx2 = fakeCtx(204);
    await panel.selectAsset(ctx2, 'owned', e.id); await tick();
    assert(ctx2.replies.some((r) => /Kadaluarsa/.test(r.text)));
    // and the active one still opens
    const ctx3 = fakeCtx(204);
    await panel.selectAsset(ctx3, 'owned', a.id);
    assert(ctx3.replies.some((r) => /Panel Kontrol/.test(r.text)));
  });

  // ------------------------------------------------------- D/E/J/K runtime
  const bootFake = async (b) => { await runtime.syncAsset('owned', b.id); };
  await test('D/E: running userbot expires -> runtime stopped, listener removed, no duplicate stop; config retained', async () => {
    const before = fakes.created.length;
    const b = mkBot({ user: 300, expires: iso(Date.now() + 50 * DAY) });
    await bootFake(b);
    assert.equal(runtime.isRunning('owned', b.id), true);
    const c = fakes.created[before]; assert.equal(c.handlers.length, 1);
    db.prepare('UPDATE userbots SET expires_at=? WHERE id=?').run(iso(Date.now() - 1000), b.id);
    const r1 = await lifecycle.sweepExpiredOwned();
    const r2 = await lifecycle.sweepExpiredOwned();
    assert(r1.transitioned >= 1, 'this userbot transitioned (sweep is global: earlier tests left other lapsed rows)');
    assert.equal(r2.transitioned, 0, 'second sweep is a no-op (no duplicate stop / transition)');
    assert.equal(runtime.isRunning('owned', b.id), false);
    assert.equal(c.handlers.length, 0); assert.equal(c.disconnects, 1);
    const row = ownedRepo.findById(b.id);
    assert.equal(row.status, 'expired'); assert.equal(row.runtime_stop_reason, 'SUBSCRIPTION_EXPIRED');
    assert.equal(row.wtb_reply, 1); assert.equal(row.target, '@grup'); assert(row.session_string);
    assert.equal(db.prepare('SELECT COUNT(*) c FROM panel_groups WHERE userbot_id=?').get(b.id).c, 1);
    assert.equal(sent.filter((s) => s.id === 300 && /Kadaluarsa/.test(s.text)).length, 1, 'notified exactly once');
    assert.equal(db.prepare("SELECT COUNT(*) c FROM userbot_subscription_events WHERE userbot_id=? AND action='auto_expire'").get(b.id).c, 1);
  });
  await test('D2: exact-time expiry timer stops a running userbot WITHOUT any scheduler', async () => {
    const b = mkBot({ user: 301, expires: iso(Date.now() + 150) });
    await bootFake(b); assert.equal(runtime.isRunning('owned', b.id), true);
    await new Promise((r) => setTimeout(r, 450));
    assert.equal(runtime.isRunning('owned', b.id), false);
    assert.equal(ownedRepo.findById(b.id).status, 'expired');
  });
  await test('J/K: extend an expired userbot -> ACTIVE, runtime restored exactly once, config intact', async () => {
    const b = mkBot({ user: 302, expires: iso(Date.now() - 3 * DAY) });
    await lifecycle.expireAndStop(b.id);
    const created0 = fakes.created.length;
    const res = await lifecycle.extendAndReconcile({ userbotId: b.id, days: 30, operationId: 'op-J1', adminId: 900 });
    assert.equal(res.runtime.status, 'running');
    const row = ownedRepo.findById(b.id);
    assert.equal(row.status, 'active'); assert.equal(row.runtime_stop_reason, null);
    assert(Math.abs(Date.parse(row.expires_at) - (Date.now() + 30 * DAY)) < 5000);
    assert.equal(fakes.created.length, created0 + 1);
    const c = fakes.created[created0]; assert.equal(c.handlers.length, 1);
    await runtime.syncAsset('owned', b.id); await runtime.syncAsset('owned', b.id);
    assert.equal(fakes.created.length, created0 + 1, 'no second client'); assert.equal(c.handlers.length, 1, 'no second listener');
    assert.equal(row.target, '@grup'); assert.equal(row.wtb_reply, 1);
    assert.equal(access.checkUserbotControlAccess({ userbotId: b.id, actorId: 302 }).ok, true);
    await runtime.teardownAsset('owned', b.id);
  });
  await test('L: renewed but Telegram session revoked -> subscription ACTIVE, runtime stopped, SESSION_INVALID, user told to re-auth', async () => {
    const b = mkBot({ user: 303, expires: iso(Date.now() - DAY) });
    await lifecycle.expireAndStop(b.id);
    fakes.sessionInvalid.add(b.session_string);
    sent.length = 0;
    const res = await lifecycle.extendAndReconcile({ userbotId: b.id, days: 7, operationId: 'op-L1', adminId: 900 });
    assert.equal(res.runtime.status, 'session_invalid');
    const row = ownedRepo.findById(b.id);
    assert.equal(row.status, 'active'); assert.equal(row.runtime_stop_reason, 'SESSION_INVALID');
    assert.equal(subscription.getSubscriptionState(row), 'ACTIVE');
    assert.equal(runtime.isRunning('owned', b.id), false);
    assert(sent.some((s) => s.id === 303 && /Login ulang|login ulang/.test(s.text)));
    // control panel opens (subscription valid) and shows the re-auth hint
    panelState.set(303, { kind: 'owned', id: b.id, step: null, screen: 'main', adminMode: false });
    const ctx = fakeCtx(303); await panel.homePanelHandler(ctx);
    assert(ctx.replies.some((r) => /Sesi Telegram userbot ini tidak valid/.test(r.text)));
    // notified once only
    await lifecycle.handleSessionInvalid('owned', b.id);
    assert.equal(sent.filter((s) => s.id === 303 && /Sesi Userbot Tidak Valid/.test(s.text)).length, 1);
  });
  await test('N: restart recovery — expired-by-time row is NOT started; active row is restored', async () => {
    await runtime.shutdownAll();
    const dead = mkBot({ user: 304, expires: iso(Date.now() - 1000) });   // status still active, scheduler never ran
    const live = mkBot({ user: 305, expires: iso(Date.now() + 9 * DAY) });
    await runtime.bootstrapAll();
    assert.equal(runtime.isRunning('owned', dead.id), false);
    assert.equal(runtime.isRunning('owned', live.id), true);
    await runtime.shutdownAll();
  });

  // ------------------------------------------------ I/G/H idempotency + audit
  await test('G/H at service level via extend(): audit row has previous/new/admin/action', () => {
    const b = mkBot({ user: 400, expires: iso(Date.now() + 10 * DAY) });
    const before = b.expires_at;
    const r = subscription.extend({ userbotId: b.id, days: 30, operationId: 'op-G', adminId: 900 });
    assert.equal(Date.parse(r.row.expires_at), Date.parse(before) + 30 * DAY);
    const ev = r.event; assert.equal(ev.admin_id, 900); assert.equal(ev.owner_user_id, 400);
    assert.equal(ev.previous_expiry, before); assert.equal(ev.extension_days, 30); assert.equal(ev.action, 'admin_extend');
    assert(!JSON.stringify(ev).includes('sess-'), 'no credentials in audit');
  });
  await test('I: same operation id twice -> applied ONCE; different operation id -> applied again (intentional)', () => {
    const b = mkBot({ user: 401, expires: iso(Date.now() + 10 * DAY) });
    const t0 = Date.parse(b.expires_at);
    const a = subscription.extend({ userbotId: b.id, days: 30, operationId: 'op-I1', adminId: 900 });
    const dup = subscription.extend({ userbotId: b.id, days: 30, operationId: 'op-I1', adminId: 900 });
    assert.equal(a.duplicate, false); assert.equal(dup.duplicate, true);
    assert.equal(Date.parse(ownedRepo.findById(b.id).expires_at), t0 + 30 * DAY);
    subscription.extend({ userbotId: b.id, days: 30, operationId: 'op-I2', adminId: 900 });
    assert.equal(Date.parse(ownedRepo.findById(b.id).expires_at), t0 + 60 * DAY);
  });
  await test('Atomicity: failure inside the transaction rolls back expiry AND audit', () => {
    const b = mkBot({ user: 402, expires: iso(Date.now() + 10 * DAY) });
    const before = ownedRepo.findById(b.id);
    db.exec(`CREATE TRIGGER boom BEFORE UPDATE ON userbots WHEN NEW.id=${b.id} BEGIN SELECT RAISE(ABORT,'boom'); END`);
    assert.throws(() => subscription.extend({ userbotId: b.id, days: 30, operationId: 'op-ROLL', adminId: 900 }), /boom/);
    db.exec('DROP TRIGGER boom');
    const after = ownedRepo.findById(b.id);
    assert.equal(after.expires_at, before.expires_at); assert.equal(after.sub_version, before.sub_version);
    assert.equal(db.prepare("SELECT COUNT(*) c FROM userbot_subscription_events WHERE operation_id='op-ROLL'").get().c, 0);
  });
  await test('Revoked userbot cannot be extended back to life (SUSPENDED is not EXPIRED)', () => {
    const b = mkBot({ user: 403, expires: iso(Date.now() + DAY), status: 'revoked' });
    assert.throws(() => subscription.extend({ userbotId: b.id, days: 5, operationId: 'op-rev' }), /tidak dapat diperpanjang/);
    assert.equal(subscription.getSubscriptionState(b), 'SUSPENDED');
  });

  // ------------------------------------------------------------- M concurrency
  await test('M: expiry vs extension in BOTH orders converge on DB truth (no lost extension, runtime consistent)', async () => {
    for (const order of ['expire-first', 'extend-first', 'parallel']) {
      const b = mkBot({ user: 500, expires: iso(Date.now() + 50 * DAY) });
      await bootFake(b);
      db.prepare('UPDATE userbots SET expires_at=? WHERE id=?').run(iso(Date.now() - 500), b.id);
      const ex = () => lifecycle.expireAndStop(b.id, { notify: false });
      const ext = () => lifecycle.extendAndReconcile({ userbotId: b.id, days: 30, operationId: `op-M-${order}-${b.id}`, adminId: 900 });
      if (order === 'expire-first') { await ex(); await ext(); }
      else if (order === 'extend-first') { await ext(); await ex(); }
      else await Promise.all([ex(), ext()]);
      const row = ownedRepo.findById(b.id);
      assert.equal(row.status, 'active', order);
      assert(Date.parse(row.expires_at) > Date.now() + 29 * DAY, order);
      assert.equal(runtime.isRunning('owned', b.id), true, `runtime must be running after ${order}`);
      assert.equal(row.runtime_stop_reason, null, order);
      await runtime.teardownAsset('owned', b.id);
    }
  });
  await test('Scheduler: overlapping ticks are skipped', async () => {
    const realSet = global.setInterval; let fn = null; global.setInterval = (f) => { fn = f; return { unref() {} }; };
    let calls = 0; const orig = lifecycle.sweepExpiredOwned;
    lifecycle.sweepExpiredOwned = async () => { calls++; await new Promise((r) => setTimeout(r, 120)); return { transitioned: 0 }; };
    try {
      const { startScheduler } = S('scheduler');
      startScheduler({ sendMessage: async () => {} });   // first tick starts immediately
      await new Promise((r) => setTimeout(r, 10));
      await Promise.all([fn(), fn()]);                    // two more while first is running
      await new Promise((r) => setTimeout(r, 300));
      assert.equal(calls, 1, `expected 1 sweep, got ${calls}`);
      await fn(); assert.equal(calls, 2, 'next tick after completion runs');
    } finally { global.setInterval = realSet; lifecycle.sweepExpiredOwned = orig; }
  });
  await test('Scheduler leaves trial rows to the existing trial policy (no premature expired flag)', async () => {
    const t = mkBot({ user: 501, expires: iso(Date.now() - 1000), label: '🎁 Trial Userbot', order: null });
    await lifecycle.sweepExpiredOwned();
    assert.equal(ownedRepo.findById(t.id).status, 'active');
    assert.equal(access.checkUserbotControlAccess({ userbotId: t.id, actorId: 501 }).code, 'EXPIRED', 'but still locked immediately');
  });

  // ------------------------------------------------------ admin UI flow (real handlers)
  const subExt = S('handlers/admin/subscriptionExtend.handler');
  await test('Admin flow: list -> detail -> confirm -> go; double confirm = one extension; second intentional = another', async () => {
    mkUser(900);
    const b = mkBot({ user: 600, expires: iso(Date.parse('2026-09-10T00:00:00Z')) });   // long expired
    let ctx = fakeCtx(900, 'subext:list:e:0'); await subExt.subextListCallback(ctx);
    assert(buttonsOf(ctx.replies[0].o).some((x) => x.callback_data === `subext:sel:${b.id}`), 'userbot listed by stable id');
    ctx = fakeCtx(900, `subext:sel:${b.id}`); await subExt.subextSelectCallback(ctx);
    const durs = buttonsOf(ctx.replies[0].o).map((x) => x.callback_data);
    assert(durs.includes(`subext:pick:${b.id}:30`)); assert(durs.includes(`subext:custom:${b.id}`));
    assert.match(ctx.replies[0].text, /EXPIRED/);
    ctx = fakeCtx(900, `subext:pick:${b.id}:30`); await subExt.subextPickCallback(ctx);
    assert.match(ctx.replies[0].text, /Konfirmasi Perpanjangan/);
    const go = buttonsOf(ctx.replies[0].o).find((x) => /^subext:go:/.test(x.callback_data)).callback_data;
    const c1 = fakeCtx(900, go), c2 = fakeCtx(900, go);
    await Promise.all([subExt.subextGoCallback(c1), subExt.subextGoCallback(c2)]);
    const t1 = Date.parse(ownedRepo.findById(b.id).expires_at);
    assert(Math.abs(t1 - (Date.now() + 30 * DAY)) < 5000, 'expired -> from now, +30d once');
    const texts = [...c1.replies, ...c2.replies].map((r) => r.text).join('\n');
    assert(/berhasil diperpanjang/.test(texts), texts);
    const c3 = fakeCtx(900, go); await subExt.subextGoCallback(c3);   // late retry
    assert.match(c3.replies[0].text, /sudah diproses/);
    assert.equal(Date.parse(ownedRepo.findById(b.id).expires_at), t1);
    // deliberate second extension from a NEW confirmation screen
    ctx = fakeCtx(900, `subext:pick:${b.id}:30`); await subExt.subextPickCallback(ctx);
    const go2 = buttonsOf(ctx.replies[0].o).find((x) => /^subext:go:/.test(x.callback_data)).callback_data;
    assert.notEqual(go2, go);
    await subExt.subextGoCallback(fakeCtx(900, go2));
    assert.equal(Date.parse(ownedRepo.findById(b.id).expires_at), t1 + 30 * DAY, 'active -> added on top of current expiry');
    assert.equal(db.prepare("SELECT COUNT(*) c FROM userbot_subscription_events WHERE userbot_id=? AND action='admin_extend'").get(b.id).c, 2);
    assert(sent.some((s) => s.id === 600 && /diperpanjang/.test(s.text)), 'owner notified');
    // access restored immediately, no relogin
    assert.equal(access.checkUserbotControlAccess({ userbotId: b.id, actorId: 600 }).ok, true);
  });
  await test('Admin custom duration: text step validates and reaches confirmation', async () => {
    const b = mkBot({ user: 601, expires: iso(Date.now() + DAY) });
    const ctx = fakeCtx(900); ctx.message = { text: 'abc' };
    await subExt.handleSubextCustomText(ctx, { userbotId: b.id }); assert.match(ctx.replies[0].text, /Masukkan angka/);
    const c2 = fakeCtx(900); c2.message = { text: '45' };
    await subExt.handleSubextCustomText(c2, { userbotId: b.id }); assert.match(c2.replies[0].text, /\+45 Hari/);
  });
  await test('Durations come from existing Store packages when present (not hardcoded)', () => {
    assert.deepEqual(subscription.getExtensionOptions(), [7, 30, 90]);   // fallback (no packages)
    db.prepare("INSERT INTO products (category,name,price,duration_days,is_active) VALUES ('userbot','P14',1000,14,1),('userbot','P60',1000,60,1),('userbot','Off',1,3,0)").run();
    assert.deepEqual(subscription.getExtensionOptions(), [14, 60]);
  });

  // ------------------------------------------------ user renewal via order flow
  await test('Renewal order: expired userbot renewable; targets the CHOSEN userbot; double-confirm = one extension', async () => {
    mkUser(700);
    const a = mkBot({ user: 700, expires: iso(Date.now() - 2 * DAY), label: 'A' });
    const c = mkBot({ user: 700, expires: iso(Date.now() + 5 * DAY), label: 'C' });
    const cBefore = ownedRepo.findById(c.id).expires_at;
    const store = S('handlers/store.handler'); const rt = S('services/renewalTarget.service');
    assert.equal(rt.resolve(700).status, 'pick', 'multiple userbots -> asks, never guesses');
    // choose expired one through the real callback
    const sub = S('handlers/subscription.handler');
    const ctx = fakeCtx(700, `subscription:renew:${a.id}`); await sub.subscriptionRenewCallback(ctx);
    assert.equal(rt.resolve(700).asset.id, a.id);
    const product = { id: 1, category: 'userbot', name: 'P', price: 1000, duration_days: 30 };
    const order = orderService.createOrder({ userId: 700, product, qty: 1, category: 'renewal', targetUserbotId: a.id });
    // Real flow: buyer taps "Saya Sudah Bayar" (pending -> awaiting_confirmation); only then can admin confirm.
    orderService.markAwaitingConfirmation(order.id);
    const r1 = await orderService.fulfillOrder({ getChat: async () => ({}) }, order.id);
    const r2 = await orderService.fulfillOrder({ getChat: async () => ({}) }, order.id);
    assert.equal(r1.ok, true); assert.equal(r2.ok, false); assert.equal(r2.reason, 'already_fulfilled');
    const aRow = ownedRepo.findById(a.id);
    assert.equal(aRow.status, 'active'); assert(Math.abs(Date.parse(aRow.expires_at) - (Date.now() + 30 * DAY)) < 5000);
    assert.equal(ownedRepo.findById(c.id).expires_at, cBefore, 'other userbot untouched');
    // direct replay of the same order at service level is also a no-op
    const again = S('services/userbot.service').renewOwnedUserbot(orderService.findById(order.id));
    assert.equal(again.duplicate, true);
    // ambiguous without target -> refuse
    const o2 = orderService.createOrder({ userId: 700, product, qty: 1, category: 'renewal' });
    orderService.markAwaitingConfirmation(o2.id);
    assert.equal((await orderService.fulfillOrder({}, o2.id)).reason, 'ambiguous_target');
  });
  await test('subscription:renew for someone else\'s userbot is rejected', async () => {
    const other = mkBot({ user: 701, expires: iso(Date.now() - DAY) });
    mkUser(702);
    const ctx = fakeCtx(702, `subscription:renew:${other.id}`);
    await S('handlers/subscription.handler').subscriptionRenewCallback(ctx);
    assert(ctx.replies.some((r) => /bukan milik kamu/.test(r.text)));
    assert.equal(S('services/renewalTarget.service').resolve(702).status, 'none');
  });

  // ------------------------------------------------------------- Q custom emoji
  await test('Q: custom emoji on renewal/admin buttons never changes callback routing', async () => {
    const icons = S('services/buttonIconConfig.service');
    for (const label of ['Perpanjang Langganan', 'Konfirmasi', 'Custom', 'Batal']) { try { icons.setIcon(label, '🔥'); } catch (_) {} }
    const b = mkBot({ user: 800, expires: iso(Date.now() - DAY) });
    const notice = S('services/subscriptionNotice.service');
    const n = notice.buildExpiredNotice({ from: { id: 800 }, chat: { id: 800 } }, b);
    const btn = buttonsOf(n.options)[0];
    assert.equal(btn.callback_data, `subscription:renew:${b.id}`);
    const ctx = fakeCtx(900, `subext:pick:${b.id}:30`); await subExt.subextPickCallback(ctx);
    for (const x of buttonsOf(ctx.replies[0].o)) assert.match(x.callback_data, /^subext:(go:\d+:\d+:[0-9a-f]{8}|sel:\d+)$/);
    icons.reset();
  });
  await test('Access control: admin route guarded by requireAdmin', async () => {
    const { requireAdmin } = S('middlewares/admin.middleware');
    let ran = false; const h = requireAdmin(async () => { ran = true; });
    await h(fakeCtx(12345, 'subext:go:1:30:deadbeef')); assert.equal(ran, false);
    await h(fakeCtx(900, 'subext:go:1:30:deadbeef')); assert.equal(ran, true);
  });

  await runtime.shutdownAll();
  const failed = results.filter((r) => !r[0]);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
