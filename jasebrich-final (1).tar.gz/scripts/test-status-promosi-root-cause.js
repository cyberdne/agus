'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const index = read('src/index.js');
const panel = read('src/handlers/panel.handler.js');
const placeholdersSource = read('src/utils/placeholders.js');
const buttonSource = read('src/services/buttonIconConfig.service.js');

// The route remains registered for backwards compatibility/stale messages.
assert.match(index, /bot\.hears\(PANEL_FEATURE\.PROMOTION_STATUS/);
assert.match(index, /promotionStatusHandler/);

// The live handler is authoritative on the selected asset and runtime state.
assert.match(panel, /const promotionStatusHandler=safeHandler\(async ctx=>\{/);
assert.match(panel, /const s=selected\(ctx\);/);
assert.match(panel, /panelPromotionStatusSubmenu\.getContent\(ctxLike, base\)/);
assert.match(panel, /panelPlaceholderContext\(\{\.\.\.asset,__kind:kind\}\)/);
assert.ok(panel.includes('userbotRuntime.isAutoPromosiActive(kind,id)'));
assert.match(panel, /promotionRunningKeyboard\(kind,id\)/);
assert.match(panel, /renderWithReplyKeyboard\(ctx,content\.text/);
assert.match(panel, /startPromotionStatusWatcher\(ctx,kind,id,sent\.message_id,content\.text\)/);
assert.doesNotMatch(panel, /const promotionStatusInlineKeyboard\s*=/);

// All visible live-state fields are backed by the promotion runtime provider.
for (const token of [
  'status', 'total_groups', 'processed_groups', 'successful_groups',
  'failed_groups', 'blocked_groups', 'removed_groups', 'sent_count',
  'failed_count', 'current_round', 'progress', 'remaining_groups', 'round_pause_remaining',
  'started_at', 'last_activity', 'estimated_completion', 'remaining_time',
  'interval', 'runtime_status', 'package_name', 'phase', 'current_target', 'wait_reason', 'wait_remaining',
]) {
  assert.match(placeholdersSource, new RegExp(`\\b${token}:`), `missing placeholder provider for ${token}`);
}
assert.match(placeholdersSource, /hasOwnProperty\.call\(stats, 'promotionStatus'\)/);

// The new live placeholders are part of the canonical Status Promosi context.
assert.match(panel, /supportedPlaceholders: \[[^\]]*'phase'/);
assert.match(panel, /'current_target'/);
assert.match(panel, /'wait_reason'/);
assert.match(panel, /'wait_remaining'/);

for (const token of [
  'promotion.status', 'promotion.processedGroups', 'promotion.successfulGroups',
  'promotion.failedGroups', 'promotion.blockedGroups', 'promotion.removedGroups',
  'promotion.sentCount', 'promotion.failedCount', 'promotion.cycle',
  'promotion.progress', 'promotion.remainingGroups', 'promotion.startedAt',
  'promotion.lastActivity', 'promotion.etaSeconds', 'promotion.runtimeStatus',
  'promotion.phase', 'promotion.currentTarget', 'promotion.waitReason', 'promotion.waitRemainingSeconds',
]) {
  assert.ok(panel.includes(token), `panel placeholder mapping missing ${token}`);
}

function loadButtonIconConfigForUnitTest() {
  const originalLoad = Module._load;
  const settingsStore = new Map();
  Module._load = function(request, parent, isMain) {
    if (request === '../database/repositories/settings.repository') {
      return {
        get: (key) => settingsStore.get(key) ?? null,
        set: (key, value) => settingsStore.set(key, value),
      };
    }
    if (request === '../utils/emojiValidation') {
      return { validateSingleEmoji: (value) => ({ ok: true, value: String(value) }) };
    }
    return originalLoad.call(this, request, parent, isMain);
  };
  try {
    return require(path.join(root, 'src/services/buttonIconConfig.service.js'));
  } finally {
    Module._load = originalLoad;
  }
}

function loadPlaceholdersForUnitTest() {
  const originalLoad = Module._load;
  Module._load = function(request, parent, isMain) {
    if (request === './telegramFormatting') {
      return { normalizeTelegramEntities: (text, entities) => Array.isArray(entities) ? entities : [] };
    }
    return originalLoad.call(this, request, parent, isMain);
  };
  try {
    return require(path.join(root, 'src/utils/placeholders.js'));
  } finally {
    Module._load = originalLoad;
  }
}

const buttonIcons = loadButtonIconConfigForUnitTest();
buttonIcons.registerStaticLabels(['📊 Status Promosi', '🚀 Mulai Promosi', '⏹️ Stop Promosi']);
assert.equal(buttonIcons.resolveIncomingButtonLabel('status promosi'), '📊 Status Promosi');
assert.equal(buttonIcons.resolveIncomingButtonLabel('Status Promosi'), '📊 Status Promosi');
assert.equal(buttonIcons.resolveIncomingButtonLabel('unknown user text'), null);

const placeholders = loadPlaceholdersForUnitTest();
const ctx = { from: { id: 501, first_name: 'Tester' }, chat: { id: 501 }, message: { date: Math.floor(Date.now() / 1000) } };
const panelStats = {
  promotionStatus: 'AKTIF',
  totalGroups: 100,
  processedGroups: 37,
  successfulGroups: 30,
  failedGroups: 4,
  blockedGroups: 3,
  removedGroups: 1,
  sentCount: 30,
  failedCount: 4,
  currentRound: 2,
  progress: '37%',
  remainingGroups: 63,
  roundPauseRemaining: '00:00:00',
  startedAt: '01/10/2026, 23.45 WIB',
  lastActivity: '02/10/2026, 00.50 WIB',
  estimatedCompletion: '0j 12m 30d',
  remainingTime: 750,
  interval: '30–60 detik',
  runtimeStatus: 'CONNECTED',
  packageName: 'Special',
  phase: 'JEDA ANTAR GRUP',
  currentTarget: '@target',
  waitReason: 'Jeda antar grup',
  waitRemaining: '7 detik',
};
const template = '{status}|{progress}|{total_groups}|{processed_groups}|{successful_groups}|{failed_groups}|{blocked_groups}|{removed_groups}|{sent_count}|{failed_count}|{current_round}|{remaining_groups}|{round_pause_remaining}|{started_at}|{last_activity}|{estimated_completion}|{remaining_time}|{interval}|{runtime_status}|{package_name}|{phase}|{current_target}|{wait_reason}|{wait_remaining}';
const rendered = placeholders.applyPlaceholders(template, [], ctx, { panelStats });
assert.equal(rendered.text, 'AKTIF|37%|100|37|30|4|3|1|30|4|2|63|00:00:00|01/10/2026, 23.45 WIB|02/10/2026, 00.50 WIB|0j 12m 30d|750|30–60 detik|CONNECTED|Special|JEDA ANTAR GRUP|@target|Jeda antar grup|7 detik');
assert.doesNotMatch(rendered.text, /\{(?:status|progress|total_groups|processed_groups|successful_groups|failed_groups|blocked_groups|removed_groups|sent_count|failed_count|current_round|remaining_groups|round_pause_remaining|started_at|last_activity|estimated_completion|remaining_time|interval|runtime_status|package_name|phase|current_target|wait_reason|wait_remaining)\}/);

const unrelated = placeholders.applyPlaceholders('{status}', [], ctx, {});
assert.equal(unrelated.text, '{status}');

console.log('STATUS_PROMOSI_ROOT_CAUSE_OK');
