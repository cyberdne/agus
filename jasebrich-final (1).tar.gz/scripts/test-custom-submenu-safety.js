'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const handler = fs.readFileSync(path.join(root, 'src/handlers/admin/customSubmenu.handler.js'), 'utf8');
const middleware = fs.readFileSync(path.join(root, 'src/middlewares/customSubmenuText.middleware.js'), 'utf8');
const service = fs.readFileSync(path.join(root, 'src/services/custom-submenu.service.js'), 'utf8');

assert.match(handler, /typeof message\.text === 'string' \? message\.text : typeof message\.caption === 'string'/);
assert.match(handler, /isEntityTextInvalidError/);
assert.match(handler, /buildHtmlFallbackPayload/);
assert.match(handler, /retry exactly once/i);
assert.match(service, /normalizeTelegramEntities/);
assert.match(service, /SUPPORTED_ENTITY_TYPES/);
assert.match(middleware, /handleIncomingCustomText\(ctx, state\)/);
assert.match(handler, /logger\.debug\(\n\s*`Custom Submenu reference sent/);
assert.doesNotMatch(handler, /logger\.info\(\n\s*`Custom Submenu reference sent/);

console.log('CUSTOM_SUBMENU_SAFETY_STATIC_OK entity_fallback=1 invalid_input_guard=1 reference_log_quiet=1');
