'use strict';
/**
 * Backup Token + Cek Token — real integration tests.
 *
 * REAL: SQLite (temp files, real schema + migrations), every service,
 * repository and handler involved (token.handler, ubotFlow login wizard,
 * panel.handler steps, userbotAccess, subscription, scheduler-side sweeps).
 * Substituted at the transport boundary only (no network in CI), same
 * convention as the other scripts/test-*.js:
 *   - GramJS phone/OTP calls  -> in-process fakes returning a session
 *   - GramJS TelegramClient   -> FakeClient
 *   - Telegram Bot API        -> recording ctx / telegram stubs
 * Run: node scripts/test-backup-token.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-bt-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');

// Everything the app logs is captured (and searched for secrets at the end).
const logBuf = [];
for (const m of ['log', 'info', 'warn', 'error']) {
  console[m] = (...a) => { logBuf.push(a.map((x) => (typeof x === 'string' ? x : x && x.stack ? x.stack : JSON.stringify(x))).join(' ')); };
}
const out = (s) => process.stdout.write(`${s}\n`);

// ---- fake GramJS client (runtime) -----------------------------------------
const tg = require(path.join(root, 'node_modules/telegram'));
class FakeClient {
  constructor(session) { this.session = String(session.save ? session.save() : ''); this.handlers = []; }
  async connect() {}
  async disconnect() {}
  addEventHandler(cb, ev) { this.handlers.push([ev, cb]); }
  removeEventHandler(cb) { this.handlers = this.handlers.filter((h) => h[1] !== cb); }
  async invoke() { return {}; }
}
Object.defineProperty(tg, 'TelegramClient', { value: FakeClient, configurable: true, writable: true });
const sess = require(path.join(root, 'node_modules/telegram/sessions'));
Object.defineProperty(sess, 'StringSession', { value: class { constructor(s) { this.s = s; } save() { return this.s; } }, configurable: true });

const { initDatabase, getDb } = require(path.join(root, 'src/database'));
initDatabase();
const db = getDb();
const S = (p) => require(path.join(root, 'src', p));
const codec = S('utils/tokenCodec');
const bt = S('services/backupToken.service');
const subscription = S('services/subscription.service');
const userbotService = S('services/userbot.service');
const userService = S('services/user.service');
const ownedRepo = S('database/repositories/ownedUserbot.repository');
const poolRepo = S('database/repositories/userbotPool.repository');
const userRepo = S('database/repositories/user.repository');
const buyerState = S('state/buyerState');
const panelState = S('state/panelState');
const tokenClaimState = S('state/tokenClaimState');
const tokenHandler = S('handlers/token.handler');
const ubotFlow = S('handlers/ubotFlow.handler');
const panelHandler = S('handlers/panel.handler');
const gramjs = S('services/gramjs.service');
const { describeCheckResult, describeBackupStatus, newTokenNotice } = S('utils/tokenNotice');
const { extraKeyboard } = S('keyboards/panelControl.keyboard');
const { PANEL_FEATURE } = S('constants/menu');

// GramJS phone/OTP transport -> deterministic fakes.
let nextAccount = { sessionString: 'sess-NEW', telegramUserbotId: 5001, account: { firstName: 'Fake' } };
gramjs.startPhoneLogin = async () => ({});
gramjs.submitOtp = async () => nextAccount;
gramjs.submitPassword = async () => nextAccount;
gramjs.cancelLogin = () => {};

const MIN = 60 * 1000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;
const iso = (ms) => new Date(ms).toISOString();
const secrets = new Set(); // every plaintext token the tests ever see — must never leak

function remember(token) { secrets.add(token); secrets.add(codec.normalize(token)); return token; }

// ---- builders ---------------------------------------------------------------
let seq = 0;
function mkUser(id) {
  db.prepare('INSERT OR IGNORE INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(id, `u${id}`, `U${id}`);
}
function mkOrder(userId, { productId = null } = {}) {
  return db.prepare("INSERT INTO orders (user_id, product_id, category, product_name, qty, duration_days, status) VALUES (?,?,?,?,?,?, 'fulfilled')")
    .run(userId, productId, 'userbot', 'Paket X', 1, 30).lastInsertRowid;
}
/**
 * A real activated userbot with a real Backup Token, produced by the SAME code
 * path as production (ownedRepo.create -> userbotService.activateOwned).
 */
function mkBot({ user, kind = 'purchased', expiresInMs = 20 * DAY, tgId = 7000 + (++seq), session = `sess-${seq}`, label } = {}) {
  mkUser(user);
  let pending;
  if (kind === 'trial') {
    pending = userbotService.createTrialOwned({ userId: user, durationHours: 1 });
  } else {
    pending = ownedRepo.create({ userId: user, label: label || 'Userbot X', phone: null, orderId: mkOrder(user), expiresAt: null });
  }
  const row = userbotService.activateOwned(pending.id, {
    sessionString: session,
    telegramUserbotId: tgId,
    expiresAt: iso(Date.now() + expiresInMs),
    tokenPrefix: kind === 'trial' ? 'LIFE-UBOT' : 'JASEB',
  });
  assert.ok(row.token, 'activateOwned returns the plaintext once');
  remember(row.token);
  const { token, ...rest } = row;
  return { row: ownedRepo.findById(rest.id), token };
}
const setExpiry = (id, ms) => db.prepare('UPDATE userbots SET expires_at = ? WHERE id = ?').run(iso(ms), id);
const loseSession = (id) => db.prepare("UPDATE userbots SET runtime_stop_reason = 'SESSION_INVALID' WHERE id = ?").run(id);
const countBots = () => db.prepare('SELECT COUNT(*) c FROM userbots').get().c;
const countOrders = () => db.prepare('SELECT COUNT(*) c FROM orders').get().c;

function mkCtx(userId, text = 'x') {
  const replies = [];
  const sent = [];
  const deleted = [];
  return {
    from: { id: userId, first_name: 'U', username: `u${userId}` },
    chat: { id: userId, type: 'private' },
    updateType: 'message',
    message: { text, message_id: 1 },
    reply: async (t, o) => { replies.push({ text: t, o }); return { message_id: replies.length }; },
    deleteMessage: async () => { deleted.push(1); return true; },
    telegram: {
      sendMessage: async (id, t, o) => { sent.push({ id, text: t, o }); return { message_id: sent.length }; },
      deleteMessage: async (c, m) => { deleted.push(m); return true; },
      pinChatMessage: async () => true,
    },
    replies, sent, deleted,
    allText() { return [...replies, ...sent].map((r) => r.text).join('\n'); },
  };
}

/** Whole recovery through the real handlers: token prompt -> phone -> OTP -> finalize. */
async function recover(userId, token, { tgId, session = `recovered-${++seq}` } = {}) {
  const ctx = mkCtx(userId);
  tokenClaimState.set(userId, { step: 'await_token' });
  await tokenHandler.handleTokenInput(ctx, token);
  const st = buyerState.get(userId);
  const claimed = Boolean(st && st.flow === 'reauth');
  if (claimed) {
    const row = ownedRepo.findById(st.ownedId);
    nextAccount = { sessionString: session, telegramUserbotId: tgId ?? row.telegram_userbot_id, account: {} };
    await ubotFlow.handlePhoneInput(ctx, buyerState.get(userId), '+628123456789');
    await ubotFlow.handleOtpInput(ctx, buyerState.get(userId), '1 2 3 4 5');
  }
  return { ctx, claimed, state: st };
}

async function panelStep(userId, step, text, { id, adminMode } = {}) {
  const ctx = mkCtx(userId, text);
  panelState.set(userId, { kind: 'owned', id, step, screen: 'extra', adminMode: Boolean(adminMode) });
  await panelHandler.handleStepInput(ctx, panelState.get(userId), text);
  return ctx;
}

const results = [];
async function test(name, fn) {
  try { await fn(); results.push(true); out(`PASS  ${name}`); }
  catch (e) { results.push(false); out(`FAIL  ${name}\n      ${(e && e.stack) || e}`); }
}
const balanced = (s) => (s.match(/\*/g) || []).length % 2 === 0 && (s.match(/`/g) || []).length % 2 === 0;

(async () => {
  // =====================================================================
  // A. TOKEN CREATION
  // =====================================================================
  await test('A1 activation through the real wizard stores ONLY a hash; plaintext shown once', async () => {
    mkUser(101);
    const pending = ownedRepo.create({ userId: 101, label: 'Wizard Bot', phone: null, orderId: mkOrder(101), expiresAt: iso(Date.now() + 30 * DAY) });
    const ctx = mkCtx(101);
    nextAccount = { sessionString: 'wiz-sess', telegramUserbotId: 8101, account: { firstName: 'W' } };
    buyerState.set(101, { step: 'await_otp', ownedId: pending.id, phone: '+62811', flow: 'purchase' });
    await ubotFlow.handleOtpInput(ctx, buyerState.get(101), '1 2 3 4 5');
    const pinned = ctx.sent.find((s) => /Token Garansi/.test(s.text));
    assert.ok(pinned, 'activation receipt sent');
    const token = remember(/(JASEB-[A-Za-z0-9]+)/.exec(pinned.text)[1]);
    const row = ownedRepo.findById(pending.id);
    assert.equal(row.token, null, 'legacy plaintext column stays empty');
    assert.equal(row.token_hash, codec.hashInput(token));
    assert.equal(row.token_generation, 1);
    assert.equal(bt.checkToken({ actorId: 101, rawCode: token }).state, bt.STATE.VALID);
  });

  await test('A2 trial activation issues a LIFE-UBOT token with >=192 bits, bound to that trial', () => {
    const { row, token } = mkBot({ user: 102, kind: 'trial', expiresInMs: HOUR });
    assert.match(token, /^LIFE-UBOT : [0-9A-F]{48}$/);
    assert.equal(subscription.isTrial(row), true);
    const pub = bt.checkToken({ actorId: 102, rawCode: token });
    assert.equal(pub.state, bt.STATE.VALID);
    assert.equal(pub.trial, true);
  });

  await test('A3 generation: unique, >=192-bit, CSPRNG only (Math.random never used), no id/time derivation', () => {
    const realRandom = Math.random;
    Math.random = () => { throw new Error('Math.random must not be used for tokens'); };
    const seen = new Set();
    try {
      for (let i = 0; i < 3000; i++) {
        const t = codec.generate(i % 2 ? 'LIFE-UBOT' : 'JASEB');
        assert.ok(codec.normalize(t), 'own tokens always pass normalization');
        assert.ok(!seen.has(t)); seen.add(t);
        const body = t.replace(/^(JASEB-|LIFE-UBOT : )/, '');
        assert.ok(body.length >= 48, `body too short: ${body.length}`);
        assert.ok(!body.includes(String(Date.now()).slice(0, 8)));
      }
    } finally { Math.random = realRandom; }
    assert.equal(seen.size, 3000);
  });

  await test('A4 two userbots of one user get different tokens; each token maps to ITS userbot', () => {
    const a = mkBot({ user: 103, label: 'Alpha Bot' });
    const b = mkBot({ user: 103, label: 'Beta Bot' });
    assert.notEqual(a.token, b.token);
    assert.equal(bt.checkToken({ actorId: 103, rawCode: a.token }).label, 'Alpha Bot');
    assert.equal(bt.checkToken({ actorId: 103, rawCode: b.token }).label, 'Beta Bot');
  });

  await test('A5 the database itself refuses two userbots sharing one token hash', () => {
    const a = mkBot({ user: 104 });
    const b = mkBot({ user: 104 });
    assert.throws(() => db.prepare('UPDATE userbots SET token_hash = ? WHERE id = ?').run(a.row.token_hash, b.row.id), /UNIQUE/);
    assert.throws(() => db.prepare('INSERT INTO userbot_token_history (token_hash,userbot_id,generation,reason,retired_at) VALUES (?,?,?,?,?)')
      .run('h1', 1, 1, 'used', iso(Date.now())) && db.prepare('INSERT INTO userbot_token_history (token_hash,userbot_id,generation,reason,retired_at) VALUES (?,?,?,?,?)')
      .run('h1', 1, 1, 'used', iso(Date.now())), /UNIQUE/);
  });

  // =====================================================================
  // B. CEK TOKEN
  // =====================================================================
  await test('B1 valid token: VALID + owner-safe details, no ids/phone/session/order in the reply', () => {
    const { row, token } = mkBot({ user: 110, label: 'Cek Bot' });
    const pub = bt.checkToken({ actorId: 110, rawCode: token });
    assert.equal(pub.state, bt.STATE.VALID);
    assert.equal(pub.label, 'Cek Bot');
    assert.equal(pub.mode, bt.MODE.HEALTHY);
    const text = describeCheckResult(pub);
    assert.match(text, /TOKEN VALID/);
    for (const leak of [String(row.id) + ' ', String(row.telegram_userbot_id), row.session_string, String(row.order_id), token]) {
      assert.ok(!text.includes(`#${row.id}`) && !text.includes(leak.trim()) || leak.trim() === '' , `leaked ${leak}`);
    }
  });

  await test('B2 unknown / malformed tokens: INVALID and MALFORMED, never an exception', () => {
    const cases = [
      [codec.generate('JASEB'), bt.STATE.INVALID],
      ['', bt.STATE.MALFORMED], ['short', bt.STATE.MALFORMED], [null, bt.STATE.MALFORMED], [12345, bt.STATE.MALFORMED],
      ['A'.repeat(5000), bt.STATE.MALFORMED], [`JASEB-${'x'.repeat(40)}\u200b`, bt.STATE.MALFORMED],
      ["'; DROP TABLE userbots;--" + 'x'.repeat(20), bt.STATE.INVALID],
    ];
    for (const [input, expected] of cases) {
      bt.resetGuards();
      assert.equal(bt.checkToken({ actorId: 111, rawCode: input }).state, expected, `input ${String(input).slice(0, 20)}`);
    }
    assert.ok(db.prepare('SELECT COUNT(*) c FROM userbots').get().c > 0, 'table intact');
  });

  await test('B3 EXPIRED: purchased past expiry, trial past expiry (before AND after the sweep)', () => {
    bt.resetGuards();
    const p = mkBot({ user: 112, expiresInMs: 20 * DAY });
    setExpiry(p.row.id, Date.now() - 1000);
    assert.equal(bt.checkToken({ actorId: 112, rawCode: p.token }).state, bt.STATE.EXPIRED);

    const t = mkBot({ user: 113, kind: 'trial', expiresInMs: HOUR });
    setExpiry(t.row.id, Date.now() - 1000);
    const before = bt.checkToken({ actorId: 113, rawCode: t.token });
    assert.equal(before.state, bt.STATE.EXPIRED);
    assert.equal(before.trial, true);
    const swept = userbotService.sweepExpiredTrials();
    assert.ok(swept.some((x) => x.id === t.row.id), 'sweeper still deletes expired trials');
    assert.equal(ownedRepo.findById(t.row.id), undefined);
    const after = bt.checkToken({ actorId: 113, rawCode: t.token });
    assert.equal(after.state, bt.STATE.EXPIRED, 'a swept trial still says EXPIRED, not "unknown"');
    assert.equal(after.trial, true);
    assert.match(describeCheckResult(after), /trial sudah berakhir/);
  });

  await test('B4 ROTATED: regenerate retires the old token, new token is VALID', async () => {
    const { row, token } = mkBot({ user: 114 });
    const ctx = await panelStep(114, 'await_backup_token_regen', 'BUAT', { id: row.id });
    const fresh = remember(/`([^`]+)`/.exec(ctx.replies.map((r) => r.text).join('\n'))[1]);
    assert.notEqual(fresh, token);
    assert.equal(bt.checkToken({ actorId: 114, rawCode: token }).state, bt.STATE.ROTATED);
    assert.equal(bt.checkToken({ actorId: 114, rawCode: fresh }).state, bt.STATE.VALID);
    assert.equal(ownedRepo.findById(row.id).token_generation, row.token_generation + 1);
  });

  await test('B5 REVOKED: token of a userbot removed by admin reports REVOKED', () => {
    const { row, token } = mkBot({ user: 115 });
    userService.deleteUserCascade(115, 900);
    assert.equal(ownedRepo.findById(row.id), undefined);
    assert.equal(bt.checkToken({ actorId: 115, rawCode: token }).state, bt.STATE.REVOKED);
  });

  await test('B6 OWNERSHIP_MISMATCH internally, but the user-facing text equals an unknown token', () => {
    const { token } = mkBot({ user: 116 });
    mkUser(117);
    bt.resetGuards();
    const other = bt.checkToken({ actorId: 117, rawCode: token });
    assert.equal(other.state, bt.STATE.OWNERSHIP_MISMATCH);
    assert.deepEqual(Object.keys(other), ['state'], 'no label/expiry/ids for a non-owner');
    const unknown = bt.checkToken({ actorId: 117, rawCode: codec.generate('JASEB') });
    assert.equal(describeCheckResult(other), describeCheckResult(unknown));
  });

  await test('B7 brute-force guard: 8 failures lock that user only, and the window expires', () => {
    bt.resetGuards();
    const now = Date.now();
    for (let i = 0; i < bt.FAIL_LIMIT; i++) bt.checkToken({ actorId: 118, rawCode: codec.generate('JASEB'), nowMs: now + i });
    assert.equal(bt.checkToken({ actorId: 118, rawCode: codec.generate('JASEB'), nowMs: now + 100 }).state, bt.STATE.RATE_LIMITED);
    assert.equal(userbotService.claimToken(118, codec.generate('JASEB')).reason, 'rate_limited');
    assert.equal(bt.checkToken({ actorId: 119, rawCode: codec.generate('JASEB') }).state, bt.STATE.INVALID, 'other users unaffected');
    assert.equal(bt.checkToken({ actorId: 118, rawCode: codec.generate('JASEB'), nowMs: now + bt.FAIL_WINDOW_MS + 1000 }).state, bt.STATE.INVALID);
    bt.resetGuards();
  });

  await test('B8 Cek Token and Klaim Token agree on every state (one shared validation)', () => {
    bt.resetGuards();
    const healthy = mkBot({ user: 120 });
    const lost = mkBot({ user: 120 }); loseSession(lost.row.id);
    const expired = mkBot({ user: 120 }); setExpiry(expired.row.id, Date.now() - 5);
    const stranger = mkBot({ user: 121 });
    const rotatedBot = mkBot({ user: 120 });
    bt.regenerate({ actorId: 120, userbotId: rotatedBot.row.id });
    const cases = [
      [healthy.token, 120, bt.STATE.VALID, 'already_active'],
      [lost.token, 120, bt.STATE.VALID, null],
      [expired.token, 120, bt.STATE.EXPIRED, 'expired'],
      [stranger.token, 120, bt.STATE.OWNERSHIP_MISMATCH, 'not_owner'],
      [rotatedBot.token, 120, bt.STATE.ROTATED, 'rotated'],
    ];
    for (const [token, actor, state, claimReason] of cases) {
      assert.equal(bt.inspect({ actorId: actor, rawCode: token }).state, state);
      const claim = bt.claimOwned({ actorId: actor, rawCode: token });
      assert.equal(claim.handled, true);
      if (claimReason === null) assert.equal(claim.ok, true); else assert.equal(claim.reason, claimReason);
    }
    bt.resetGuards();
  });

  // =====================================================================
  // C. TRIAL — remaining time is preserved, never reset or extended
  // =====================================================================
  await test('C1 active trial, session lost: recovery restores the SAME userbot with the EXACT remaining time', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 130, kind: 'trial', expiresInMs: 10 * MIN, tgId: 9130 });
    mkUser(130);
    db.prepare("UPDATE users SET trial_claimed_at = '2026-01-01 00:00:00' WHERE telegram_id = 130").run();
    loseSession(row.id);
    const botsBefore = countBots(); const ordersBefore = countOrders();
    const claimedBefore = userRepo.hasClaimedTrial(130);

    const { claimed } = await recover(130, token, { session: 'trial-recovered' });
    assert.equal(claimed, true);

    const after = ownedRepo.findById(row.id);
    assert.equal(after.id, row.id, 'same userbot');
    assert.equal(after.expires_at, row.expires_at, 'expiry byte-identical: not reset to 1h, not extended');
    assert.ok(Date.parse(after.expires_at) - Date.now() <= 10 * MIN, 'remaining time did not grow');
    assert.ok(Date.parse(after.expires_at) - Date.now() > 8 * MIN, 'and is still ~10 minutes, not shrunk or reset');
    assert.equal(after.status, 'active');
    assert.equal(after.session_string, 'trial-recovered');
    assert.equal(after.runtime_stop_reason, null, 'SESSION_INVALID cleared');
    assert.equal(after.sub_version, row.sub_version, 'no subscription mutation');
    assert.equal(countBots(), botsBefore, 'no userbot created');
    assert.equal(countOrders(), ordersBefore, 'no order created');
    assert.equal(userRepo.hasClaimedTrial(130), claimedBefore, 'trial-claimed flag untouched');
    assert.equal(db.prepare("SELECT trial_claimed_at t FROM users WHERE telegram_id=130").get().t, '2026-01-01 00:00:00');
    assert.equal(after.token_generation, row.token_generation + 1, 'token consumed and replaced');
  });

  await test('C2 recovery consumes the token: old one ROTATED, replacement (LIFE-UBOT) VALID with the same expiry', async () => {
    const { row, token } = mkBot({ user: 131, kind: 'trial', expiresInMs: 30 * MIN });
    loseSession(row.id);
    const { ctx } = await recover(131, token);
    const notice = ctx.replies.map((r) => r.text).find((t) => /Token Backup Baru/.test(t));
    assert.ok(notice, 'owner receives the replacement once');
    const fresh = remember(/`([^`]+)`/.exec(notice)[1]);
    assert.match(fresh, /^LIFE-UBOT : /);
    assert.equal(bt.checkToken({ actorId: 131, rawCode: token }).state, bt.STATE.ROTATED);
    const pub = bt.checkToken({ actorId: 131, rawCode: fresh });
    assert.equal(pub.state, bt.STATE.VALID);
    assert.equal(pub.expiresAt, row.expires_at);
  });

  await test('C3 expired trial: claim refused; nothing created, revived or extended; trial cannot be re-claimed', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 132, kind: 'trial', expiresInMs: HOUR });
    db.prepare("UPDATE users SET trial_claimed_at = datetime('now') WHERE telegram_id = 132").run();
    loseSession(row.id);
    setExpiry(row.id, Date.now() - 1000);
    const snapshot = JSON.stringify(ownedRepo.findById(row.id));
    const botsBefore = countBots();
    const { claimed, ctx } = await recover(132, token);
    assert.equal(claimed, false);
    assert.match(ctx.allText(), /trial sudah berakhir/);
    assert.equal(JSON.stringify(ownedRepo.findById(row.id)), snapshot, 'row untouched');
    assert.equal(countBots(), botsBefore);
    assert.equal(userRepo.hasClaimedTrial(132), true, 'no fresh trial');
    assert.equal(buyerState.get(132), null, 'no login wizard was started');
  });

  await test('C4 exact boundary: valid at expires-1ms, EXPIRED at expires (deterministic clock)', () => {
    const { row, token } = mkBot({ user: 133, kind: 'trial', expiresInMs: HOUR });
    loseSession(row.id);
    const exp = Date.parse(row.expires_at);
    bt.resetGuards();
    assert.equal(bt.inspect({ actorId: 133, rawCode: token, nowMs: exp - 1 }).state, bt.STATE.VALID);
    assert.equal(bt.inspect({ actorId: 133, rawCode: token, nowMs: exp }).state, bt.STATE.EXPIRED);
    assert.equal(bt.claimOwned({ actorId: 133, rawCode: token, nowMs: exp }).reason, 'expired');
  });

  await test('C5 trial 01:00-02:00, logout 01:45, recovery 01:50 -> 10 minutes left, nothing extended (simulated clock)', () => {
    const t0 = Date.parse('2026-06-01T01:00:00.000Z');
    const { row, token } = mkBot({ user: 134, kind: 'trial', expiresInMs: HOUR });
    db.prepare('UPDATE userbots SET expires_at = ?, session_string = NULL, runtime_stop_reason = ? WHERE id = ?')
      .run(iso(t0 + HOUR), 'SESSION_INVALID', row.id);
    const claimAt = t0 + 50 * MIN;
    const claim = bt.claimOwned({ actorId: 134, rawCode: token, nowMs: claimAt });
    assert.equal(claim.ok, true);
    const done = bt.completeRecovery({ actorId: 134, userbotId: row.id, sessionString: 's', telegramUserbotId: row.telegram_userbot_id, nowMs: claimAt });
    assert.equal(done.ok, true);
    assert.equal(done.row.expires_at, iso(t0 + HOUR), 'still 02:00');
    assert.equal(Date.parse(done.row.expires_at) - claimAt, 10 * MIN, 'exactly 10 minutes remain');
  });

  await test('C6 trial expires WHILE the login wizard is open: completion is refused, session and token untouched', () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 135, kind: 'trial', expiresInMs: HOUR });
    loseSession(row.id);
    assert.equal(bt.claimOwned({ actorId: 135, rawCode: token }).ok, true);
    setExpiry(row.id, Date.now() - 1000);
    const before = ownedRepo.findById(row.id);
    const done = bt.completeRecovery({ actorId: 135, userbotId: row.id, sessionString: 'late', telegramUserbotId: row.telegram_userbot_id });
    assert.deepEqual(done, { ok: false, reason: 'expired' });
    const after = ownedRepo.findById(row.id);
    assert.equal(after.session_string, before.session_string);
    assert.equal(after.token_hash, before.token_hash);
    assert.equal(after.expires_at, before.expires_at);
  });

  // =====================================================================
  // D. PURCHASED
  // =====================================================================
  await test('D1 active purchased userbot: recovery keeps expiry/order/status exactly, adds no order', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 140, expiresInMs: 19 * DAY + 7 * MIN, tgId: 9140 });
    loseSession(row.id);
    const ordersBefore = countOrders(); const botsBefore = countBots();
    const { claimed } = await recover(140, token, { session: 'buy-recovered' });
    assert.equal(claimed, true);
    const after = ownedRepo.findById(row.id);
    assert.equal(after.expires_at, row.expires_at);
    assert.equal(after.order_id, row.order_id);
    assert.equal(after.status, 'active');
    assert.equal(after.session_string, 'buy-recovered');
    assert.equal(countOrders(), ordersBefore);
    assert.equal(countBots(), botsBefore);
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbot_subscription_events WHERE userbot_id = ?').get(row.id).c, 0, 'no subscription event => no extension');
  });

  await test('D2 expired purchased userbot: recovery refused, status/expiry untouched, no wizard', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 141, expiresInMs: DAY });
    loseSession(row.id);
    setExpiry(row.id, Date.now() - DAY);
    const snap = JSON.stringify(ownedRepo.findById(row.id));
    const { claimed, ctx } = await recover(141, token);
    assert.equal(claimed, false);
    assert.match(ctx.allText(), /Masa aktif userbot .* sudah berakhir/s);
    assert.equal(JSON.stringify(ownedRepo.findById(row.id)), snap);
    assert.equal(buyerState.get(141), null);
  });

  await test('D3 legacy/purchased whose product was deleted is NOT mistaken for a trial (product==null is not the signal)', () => {
    mkUser(142);
    const orderId = mkOrder(142, { productId: null }); // product gone
    const pending = ownedRepo.create({ userId: 142, label: 'Old Paket', phone: null, orderId, expiresAt: null });
    const act = userbotService.activateOwned(pending.id, { sessionString: 's', telegramUserbotId: 9142, expiresAt: iso(Date.now() + 5 * DAY), tokenPrefix: 'JASEB' });
    remember(act.token);
    const pub = bt.checkToken({ actorId: 142, rawCode: act.token });
    assert.equal(pub.trial, false);
    assert.match(describeCheckResult(pub), /Jenis: Berlangganan/);
    assert.equal(subscription.isTrial(ownedRepo.findById(pending.id)), false);
    const reg = bt.regenerate({ actorId: 142, userbotId: pending.id });
    assert.match(reg.token, /^JASEB-/, 'purchased-style token, not LIFE-UBOT');
    remember(reg.token);
  });

  await test('D4 renewal (subscription.extend) never touches the token; recovery afterwards keeps the extended expiry', async () => {
    const { row, token } = mkBot({ user: 143, expiresInMs: 3 * DAY });
    const ext = subscription.extend({ userbotId: row.id, days: 30, operationId: `t:${Date.now()}:143`, action: 'admin_extend', adminId: 900 });
    assert.equal(ext.duplicate, false);
    const mid = ownedRepo.findById(row.id);
    assert.equal(mid.token_hash, row.token_hash);
    assert.equal(mid.token_generation, row.token_generation);
    loseSession(row.id);
    await recover(143, token);
    assert.equal(ownedRepo.findById(row.id).expires_at, mid.expires_at, 'expiry = extended value, unchanged by recovery');
  });

  // =====================================================================
  // E. DUPLICATION / RACES / IDEMPOTENCY
  // =====================================================================
  await test('E1 claiming twice before finishing: same userbot, still exactly one row, one claim', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 150 });
    loseSession(row.id);
    const botsBefore = countBots();
    const c1 = bt.claimOwned({ actorId: 150, rawCode: token });
    const c2 = bt.claimOwned({ actorId: 150, rawCode: token });
    assert.equal(c1.userbotId, row.id); assert.equal(c2.userbotId, row.id);
    assert.equal(countBots(), botsBefore);
  });

  await test('E2 concurrent claims of one token (Promise.all): never more than one userbot / one rotation', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 151 });
    loseSession(row.id);
    const botsBefore = countBots();
    const claims = await Promise.all(Array.from({ length: 8 }, () => Promise.resolve().then(() => bt.claimOwned({ actorId: 151, rawCode: token }))));
    assert.ok(claims.every((c) => c.ok && c.userbotId === row.id));
    const dones = await Promise.all(Array.from({ length: 6 }, (_, i) => Promise.resolve().then(() =>
      bt.completeRecovery({ actorId: 151, userbotId: row.id, sessionString: `race-${i}`, telegramUserbotId: row.telegram_userbot_id }))));
    assert.ok(dones.every((d) => d.ok), 'every completion is safe');
    assert.equal(dones.filter((d) => d.newToken).length, 1, 'exactly ONE completion consumed the token / issued a replacement');
    const after = ownedRepo.findById(row.id);
    assert.equal(after.token_generation, row.token_generation + 1, 'exactly one rotation');
    assert.equal(countBots(), botsBefore, 'no duplicate owned userbot');
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbot_token_history WHERE userbot_id = ?').get(row.id).c, 1, 'exactly one retired credential');
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbots WHERE token_hash = ?').get(after.token_hash).c, 1, 'one active credential');
  });

  await test('E3 owner and a stranger claim the same token at the same time: only the owner proceeds', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 152 });
    mkUser(153);
    loseSession(row.id);
    const [owner, thief] = await Promise.all([
      Promise.resolve().then(() => bt.claimOwned({ actorId: 152, rawCode: token })),
      Promise.resolve().then(() => bt.claimOwned({ actorId: 153, rawCode: token })),
    ]);
    assert.equal(owner.ok, true);
    assert.equal(thief.ok, false); assert.equal(thief.reason, 'not_owner');
    const stolen = bt.completeRecovery({ actorId: 153, userbotId: row.id, sessionString: 'thief-sess', telegramUserbotId: row.telegram_userbot_id });
    assert.deepEqual(stolen, { ok: false, reason: 'not_owner' });
    assert.notEqual(ownedRepo.findById(row.id).session_string, 'thief-sess');
    bt.resetGuards();
  });

  await test('E4 a used token cannot be claimed again (double-click after success): safe, nothing new', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 154 });
    loseSession(row.id);
    await recover(154, token);
    const botsBefore = countBots();
    const gen = ownedRepo.findById(row.id).token_generation;
    const again = await recover(154, token);
    assert.equal(again.claimed, false);
    assert.match(again.ctx.allText(), /sudah tidak berlaku/);
    assert.equal(countBots(), botsBefore);
    assert.equal(ownedRepo.findById(row.id).token_generation, gen);
    tokenClaimState.clear(154);
  });

  await test('E5 a claim goes stale when the token is regenerated first (generation compare-and-swap)', () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 155 });
    loseSession(row.id);
    assert.equal(bt.claimOwned({ actorId: 155, rawCode: token }).ok, true);
    const reg = bt.regenerate({ actorId: 155, userbotId: row.id }); remember(reg.token);
    const done = bt.completeRecovery({ actorId: 155, userbotId: row.id, sessionString: 'stale', telegramUserbotId: row.telegram_userbot_id });
    assert.deepEqual(done, { ok: false, reason: 'rotated' });
    assert.notEqual(ownedRepo.findById(row.id).session_string, 'stale', 'session swap rolled back together with the failed rotation');
  });

  // =====================================================================
  // F. OWNERSHIP TRANSFER — atomic token rotation
  // =====================================================================
  await test('F1 transfer A -> B through the real panel step: old token dead for EVERYONE, B gets a new valid one', async () => {
    bt.resetGuards();
    const { row, token: tokenA } = mkBot({ user: 160, expiresInMs: 12 * DAY, tgId: 9160 });
    mkUser(161);
    const ctxA = await panelStep(160, 'await_transfer', '161', { id: row.id });
    const after = ownedRepo.findById(row.id);
    assert.equal(after.user_id, 161);
    assert.equal(after.expires_at, row.expires_at, 'new owner inherits the exact remaining period');
    assert.equal(after.session_string, row.session_string);
    assert.equal(after.token_generation, row.token_generation + 1);

    const toB = ctxA.sent.find((s) => s.id === 161);
    assert.ok(toB, 'new owner is notified');
    const tokenB = remember(/`([^`]+)`/.exec(toB.text)[1]);
    assert.ok(!ctxA.replies.map((r) => r.text).join('\n').includes(tokenB), 'the OLD owner never sees the new token');
    assert.ok(!ctxA.replies.map((r) => r.text).join('\n').includes(tokenA));

    bt.resetGuards();
    assert.equal(bt.checkToken({ actorId: 160, rawCode: tokenA }).state, bt.STATE.ROTATED, 'A: old token invalid');
    assert.equal(bt.checkToken({ actorId: 161, rawCode: tokenA }).state, bt.STATE.ROTATED, 'B: old token invalid too');
    assert.equal(bt.checkToken({ actorId: 161, rawCode: tokenB }).state, bt.STATE.VALID, 'B: new token valid');
    assert.equal(bt.checkToken({ actorId: 160, rawCode: tokenB }).state, bt.STATE.OWNERSHIP_MISMATCH, 'A cannot use B\'s token');
    loseSession(row.id);
    assert.equal((await recover(160, tokenA)).claimed, false, 'Owner A cannot recover');
    tokenClaimState.clear(160);
    assert.equal((await recover(161, tokenB, { tgId: 9160 })).claimed, true, 'Owner B can recover');
    assert.equal(ownedRepo.findById(row.id).user_id, 161);
  });

  await test('F2 transfer failure rolls EVERYTHING back (repository refuses the swap): owner, token and ledger unchanged', () => {
    const { row, token } = mkBot({ user: 162 });
    mkUser(163);
    const real = ownedRepo.transferOwner;
    ownedRepo.transferOwner = () => false;
    try {
      const res = bt.transferOwnership({ userbotId: row.id, fromUserId: 162, toUserId: 163 });
      assert.deepEqual(res, { ok: false, reason: 'conflict' });
    } finally { ownedRepo.transferOwner = real; }
    const after = ownedRepo.findById(row.id);
    assert.equal(after.user_id, 162);
    assert.equal(after.token_hash, row.token_hash);
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbot_token_history WHERE token_hash = ?').get(row.token_hash).c, 0, 'old token NOT retired by a transfer that did not happen');
    assert.equal(bt.checkToken({ actorId: 162, rawCode: token }).state, bt.STATE.VALID);
  });

  await test('F3 transfer failing mid-transaction (unknown target => FK error) leaves owner and token intact', () => {
    const { row, token } = mkBot({ user: 164 });
    assert.throws(() => bt.transferOwnership({ userbotId: row.id, fromUserId: 164, toUserId: 987654321 }), /FOREIGN KEY/);
    const after = ownedRepo.findById(row.id);
    assert.equal(after.user_id, 164);
    assert.equal(after.token_hash, row.token_hash);
    assert.equal(after.token_generation, row.token_generation);
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbot_token_history WHERE userbot_id = ?').get(row.id).c, 0);
    assert.equal(bt.checkToken({ actorId: 164, rawCode: token }).state, bt.STATE.VALID);
  });

  await test('F4 A starts a recovery, then transfers away: A can no longer finish it, B is unaffected', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 165 });
    mkUser(166);
    loseSession(row.id);
    assert.equal(bt.claimOwned({ actorId: 165, rawCode: token }).ok, true);
    const moved = bt.transferOwnership({ userbotId: row.id, fromUserId: 165, toUserId: 166 });
    assert.equal(moved.ok, true); remember(moved.token);
    const done = bt.completeRecovery({ actorId: 165, userbotId: row.id, sessionString: 'a-after-transfer', telegramUserbotId: row.telegram_userbot_id });
    assert.deepEqual(done, { ok: false, reason: 'not_owner' });
    assert.notEqual(ownedRepo.findById(row.id).session_string, 'a-after-transfer');
    assert.equal(bt.checkToken({ actorId: 166, rawCode: moved.token }).state, bt.STATE.VALID);
  });

  await test('F5 trial userbot transfers with a LIFE-UBOT token; expired/foreign/self transfers are refused server-side', () => {
    const t = mkBot({ user: 167, kind: 'trial', expiresInMs: 40 * MIN });
    mkUser(168);
    assert.deepEqual(bt.transferOwnership({ userbotId: t.row.id, fromUserId: 168, toUserId: 167 }), { ok: false, reason: 'not_owner' });
    assert.deepEqual(bt.transferOwnership({ userbotId: t.row.id, fromUserId: 167, toUserId: 167 }), { ok: false, reason: 'same_owner' });
    const ok = bt.transferOwnership({ userbotId: t.row.id, fromUserId: 167, toUserId: 168 });
    assert.equal(ok.ok, true); assert.match(remember(ok.token), /^LIFE-UBOT : /);
    assert.equal(ok.row.expires_at, t.row.expires_at);
    setExpiry(t.row.id, Date.now() - 1000);
    assert.deepEqual(bt.transferOwnership({ userbotId: t.row.id, fromUserId: 168, toUserId: 167 }), { ok: false, reason: 'not_active' });
  });

  // =====================================================================
  // G. SECURITY — forged state / callbacks / hostile input
  // =====================================================================
  await test('G1 forged panel state (non-owner pointing at someone else\'s userbot): every token action denied, nothing leaks or changes', async () => {
    const { row, token } = mkBot({ user: 170 });
    mkUser(171);
    const snap = JSON.stringify(ownedRepo.findById(row.id));
    for (const [step, text] of [['await_backup_token_regen', 'BUAT'], ['await_check_token', token], ['await_transfer', '171']]) {
      const ctx = await panelStep(171, step, text, { id: row.id });
      assert.ok(!ctx.allText().includes(token), `${step}: token leaked`);
      assert.match(ctx.allText(), /tidak ditemukan/);
    }
    const ctx2 = mkCtx(171);
    panelState.set(171, { kind: 'owned', id: row.id, step: null, screen: 'extra' });
    await panelHandler.backupTokenHandler(ctx2);
    await panelHandler.checkTokenHandler(ctx2);
    assert.match(ctx2.allText(), /tidak ditemukan/);
    assert.equal(JSON.stringify(ownedRepo.findById(row.id)), snap, 'row byte-identical');
  });

  await test('G2 forged adminMode by a non-admin does not bypass ownership', async () => {
    const { row } = mkBot({ user: 172 });
    mkUser(173);
    const ctx = await panelStep(173, 'await_backup_token_regen', 'BUAT', { id: row.id, adminMode: true });
    assert.match(ctx.allText(), /tidak ditemukan/);
    assert.equal(ownedRepo.findById(row.id).token_generation, row.token_generation);
  });

  await test('G3 forged inline callback panel:asset:owned:<foreign id> is refused', async () => {
    const { row } = mkBot({ user: 174 });
    mkUser(175);
    const ctx = mkCtx(175);
    ctx.callbackQuery = { data: `panel:asset:owned:${row.id}`, message: { message_id: 1, chat: { id: 175 } } };
    ctx.answerCbQuery = async () => true;
    await panelHandler.panelAssetInlineCallback(ctx);
    assert.match(ctx.allText(), /tidak ditemukan/);
    assert.equal(panelState.get(175), null, 'no panel session was opened');
  });

  await test('G4 claim screen: a foreign token and an unknown token get the SAME reply and keep the prompt open', async () => {
    bt.resetGuards();
    const { token } = mkBot({ user: 176 });
    mkUser(177);
    const foreign = mkCtx(177); tokenClaimState.set(177, { step: 'await_token' });
    await tokenHandler.handleTokenInput(foreign, token);
    const foreignState = tokenClaimState.get(177);
    const unknown = mkCtx(177); tokenClaimState.set(177, { step: 'await_token' });
    await tokenHandler.handleTokenInput(unknown, codec.generate('JASEB'));
    assert.equal(foreign.replies[0].text, unknown.replies[0].text);
    assert.ok(foreignState && foreignState.step === 'await_token', 'prompt stays open for the foreign case too');
    assert.ok(foreign.deleted.length > 0, 'the message containing the token is deleted from the chat');
    tokenClaimState.clear(177); bt.resetGuards();
  });

  await test('G5 pasted variants (backticks, spaces around ":", newline) resolve only for the owner', () => {
    bt.resetGuards();
    const { token } = mkBot({ user: 178, kind: 'trial', expiresInMs: HOUR });
    mkUser(179);
    for (const v of [token, `\`${token}\``, token.replace(' : ', ':'), `  ${token}\n`, token.replace(' : ', ' :  ')]) {
      assert.equal(bt.checkToken({ actorId: 178, rawCode: v }).state, bt.STATE.VALID, JSON.stringify(v));
      assert.equal(bt.checkToken({ actorId: 179, rawCode: v }).state, bt.STATE.OWNERSHIP_MISMATCH);
    }
    assert.equal(bt.checkToken({ actorId: 178, rawCode: token.toLowerCase() }).state, bt.STATE.INVALID, 'tokens are case sensitive');
    bt.resetGuards();
  });

  await test('G6 regenerate needs the exact word BUAT; anything else changes nothing; expired userbots cannot mint tokens', async () => {
    const { row, token } = mkBot({ user: 180 });
    const ctx = await panelStep(180, 'await_backup_token_regen', 'ya', { id: row.id });
    assert.match(ctx.allText(), /dibatalkan/);
    assert.equal(ownedRepo.findById(row.id).token_hash, row.token_hash);
    assert.equal(bt.checkToken({ actorId: 180, rawCode: token }).state, bt.STATE.VALID);
    setExpiry(row.id, Date.now() - 1000);
    assert.deepEqual(bt.regenerate({ actorId: 180, userbotId: row.id }), { ok: false, reason: 'expired' });
    assert.deepEqual(bt.regenerate({ actorId: 999, userbotId: row.id }), { ok: false, reason: 'not_owner' });
  });

  await test('G7 the Backup Token screen never prints the token (hash-only storage) and explains regeneration', async () => {
    const { row, token } = mkBot({ user: 181 });
    const ctx = mkCtx(181);
    panelState.set(181, { kind: 'owned', id: row.id, step: null, screen: 'extra' });
    await panelHandler.backupTokenHandler(ctx);
    const text = ctx.allText();
    assert.ok(!text.includes(token));
    assert.match(text, /Backup Token/); assert.match(text, /BUAT/);
    assert.equal(panelState.get(181).step, 'await_backup_token_regen');
  });

  await test('G8 Cek Token through the real panel step: valid/rotated/foreign texts, token message deleted, no leak', async () => {
    bt.resetGuards();
    const a = mkBot({ user: 182, label: 'Panel Cek' });
    const ctx = await panelStep(182, 'await_check_token', a.token, { id: a.row.id });
    assert.match(ctx.allText(), /TOKEN VALID/); assert.match(ctx.allText(), /Panel Cek/);
    assert.ok(ctx.deleted.length > 0);
    assert.ok(!ctx.allText().includes(a.token));
    const stranger = mkBot({ user: 183 });
    const ctx2 = await panelStep(182, 'await_check_token', stranger.token, { id: a.row.id });
    assert.match(ctx2.allText(), /TOKEN TIDAK VALID/);
    bt.resetGuards();
  });

  await test('G9 every user-visible renderer is valid Telegram Markdown (balanced) and custom-emoji-safe (no callback payloads)', () => {
    const states = [
      { state: bt.STATE.VALID, label: 'Bot', trial: true, expiresAt: iso(Date.now() + HOUR), mode: bt.MODE.HEALTHY },
      { state: bt.STATE.VALID, label: 'Bot', trial: false, expiresAt: null, mode: bt.MODE.RECOVER_SESSION },
      { state: bt.STATE.VALID, label: 'Bot', trial: false, expiresAt: iso(Date.now() + DAY), mode: bt.MODE.REACTIVATE },
      { state: bt.STATE.EXPIRED, trial: true }, { state: bt.STATE.EXPIRED, trial: false }, { state: bt.STATE.ROTATED },
      { state: bt.STATE.REVOKED }, { state: bt.STATE.NOT_RECOVERABLE }, { state: bt.STATE.RATE_LIMITED },
      { state: bt.STATE.INVALID }, { state: bt.STATE.MALFORMED }, { state: bt.STATE.OWNERSHIP_MISMATCH },
    ];
    for (const s of states) assert.ok(balanced(describeCheckResult(s)), `unbalanced: ${s.state}`);
    assert.ok(balanced(describeBackupStatus('Bot', { hasToken: true, rotatedAt: iso(Date.now()), trial: false, expiresAt: iso(Date.now() + DAY) })));
    assert.ok(balanced(describeBackupStatus('Bot', { hasToken: false, trial: true, expiresAt: null })));
    assert.ok(balanced(newTokenNotice(codec.generate('LIFE-UBOT'))));
    // The panel buttons keep their labels/routing: the two token buttons are still on the Extra screen.
    const labels = JSON.stringify(extraKeyboard(false));
    assert.ok(labels.includes(PANEL_FEATURE.BACKUP_TOKEN) && labels.includes(PANEL_FEATURE.CHECK_TOKEN) && labels.includes(PANEL_FEATURE.TRANSFER_UBOT));
  });

  // =====================================================================
  // H. REGRESSION — existing behaviour that must not change
  // =====================================================================
  await test('H1 plain re-auth (Buat Userbot after SESSION_INVALID) still works and does NOT touch the token', async () => {
    const { row, token } = mkBot({ user: 190, tgId: 9190 });
    loseSession(row.id);
    const ctx = mkCtx(190);
    nextAccount = { sessionString: 'plain-reauth', telegramUserbotId: 9190, account: {} };
    await ubotFlow.beginPhoneStep(ctx.telegram, 190, row.id, 'reauth');
    await ubotFlow.handlePhoneInput(ctx, buyerState.get(190), '+628111');
    await ubotFlow.handleOtpInput(ctx, buyerState.get(190), '1 2 3 4 5');
    const after = ownedRepo.findById(row.id);
    assert.equal(after.session_string, 'plain-reauth');
    assert.equal(after.token_hash, row.token_hash, 'token unchanged');
    assert.equal(after.token_generation, row.token_generation);
    assert.equal(bt.checkToken({ actorId: 190, rawCode: token }).state, bt.STATE.VALID);
  });

  await test('H2 re-auth with a DIFFERENT Telegram account is still refused (same-account rule), session and token unchanged', async () => {
    const { row, token } = mkBot({ user: 191, tgId: 9191 });
    loseSession(row.id);
    bt.resetGuards();
    const { claimed, ctx } = await recover(191, token, { tgId: 424242, session: 'wrong-account' });
    assert.equal(claimed, true);
    assert.match(ctx.allText(), /akun Telegram yang kamu login berbeda/i);
    const after = ownedRepo.findById(row.id);
    assert.notEqual(after.session_string, 'wrong-account');
    assert.equal(after.token_hash, row.token_hash, 'token not consumed by a failed recovery');
    assert.equal(bt.checkToken({ actorId: 191, rawCode: token }).state, bt.STATE.VALID);
  });

  await test('H3 admin-revoked userbot + its token (Garansi Akses): reactivated within the period, expiry unchanged, token replaced', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 192, expiresInMs: 9 * DAY });
    ownedRepo.revoke(row.id);
    const ctx = mkCtx(192); tokenClaimState.set(192, { step: 'await_token' });
    await tokenHandler.handleTokenInput(ctx, token);
    const after = ownedRepo.findById(row.id);
    assert.equal(after.status, 'active');
    assert.equal(after.expires_at, row.expires_at);
    assert.match(ctx.allText(), /Garansi berhasil diaktifkan kembali/);
    const fresh = remember(/`([^`]+)`/.exec(ctx.replies.map((r) => r.text).find((t) => /Token Backup Baru/.test(t)))[1]);
    assert.equal(bt.checkToken({ actorId: 192, rawCode: token }).state, bt.STATE.ROTATED);
    assert.equal(bt.checkToken({ actorId: 192, rawCode: fresh }).state, bt.STATE.VALID);
  });

  await test('H4 admin-revoked userbot whose period is over stays revoked (token cannot revive it)', async () => {
    bt.resetGuards();
    const { row, token } = mkBot({ user: 193, expiresInMs: DAY });
    ownedRepo.revoke(row.id); setExpiry(row.id, Date.now() - 1000);
    const ctx = mkCtx(193); tokenClaimState.set(193, { step: 'await_token' });
    await tokenHandler.handleTokenInput(ctx, token);
    assert.equal(ownedRepo.findById(row.id).status, 'revoked');
    assert.match(ctx.allText(), /sudah berakhir/);
  });

  await test('H5 leased-pool token flow (plaintext, unchanged): lessee reactivates, others get the generic reply', () => {
    bt.resetGuards();
    mkUser(194); mkUser(195);
    const pool = poolRepo.create({ label: 'Jaseb Pool', phone: null, sessionString: 'pool-s' });
    const tokenP = userbotService.generateToken('JASEB');
    poolRepo.assign(pool.id, { userId: 194, orderId: null, expiresAt: iso(Date.now() + DAY), token: tokenP });
    poolRepo.disable(pool.id);
    assert.equal(userbotService.claimToken(195, tokenP).reason, 'not_owner');
    const ok = userbotService.claimToken(194, tokenP);
    assert.deepEqual([ok.ok, ok.kind, ok.label], [true, 'pool', 'Jaseb Pool']);
    assert.equal(poolRepo.findById(pool.id).status, 'assigned');
    assert.equal(userbotService.claimToken(194, tokenP).reason, 'already_active');
    bt.resetGuards();
  });

  await test('H5b expired disabled leased-pool token cannot reactivate the pool asset', () => {
    bt.resetGuards();
    mkUser(197);
    const pool = poolRepo.create({ label: 'Expired Pool', phone: null, sessionString: 'pool-expired' });
    const tokenP = userbotService.generateToken('JASEB');
    poolRepo.assign(pool.id, { userId: 197, orderId: null, expiresAt: iso(Date.now() - 1000), token: tokenP });
    poolRepo.disable(pool.id);
    const result = userbotService.claimToken(197, tokenP);
    assert.equal(result.reason, 'expired');
    assert.equal(poolRepo.findById(pool.id).status, 'disabled');
    bt.resetGuards();
  });

  await test('H6 admin user deletion still cascades and now retires tokens; trial sweep still deletes expired trials', () => {
    const a = mkBot({ user: 196 });
    userService.deleteUserCascade(196, 900);
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbots WHERE user_id = 196').get().c, 0);
    assert.equal(userRepo.findByTelegramId(196), undefined);
    assert.equal(db.prepare('SELECT reason FROM userbot_token_history WHERE token_hash = ?').get(codec.hashInput(a.token)).reason, 'revoked');
  });

  // =====================================================================
  // I. DATABASE INTEGRITY / MIGRATION
  // =====================================================================
  const runNode = (code, dbPath) => {
    const r = spawnSync(process.execPath, ['-e', code], {
      env: { ...process.env, DB_PATH: dbPath, ROOT: root }, cwd: path.dirname(dbPath), encoding: 'utf8', timeout: 60000,
    });
    if (r.status !== 0) throw new Error(`subprocess failed: ${r.stderr || r.stdout}`);
    const line = r.stdout.split('\n').reverse().find((l) => l.startsWith('@@'));
    return line ? JSON.parse(line.slice(2)) : null;
  };
  const initScript = (extra = '') => `
    process.env.BOT_TOKEN='t';
    const { initDatabase, getDb } = require(process.env.ROOT + '/src/database');
    const codec = require(process.env.ROOT + '/src/utils/tokenCodec');
    const bt = require(process.env.ROOT + '/src/services/backupToken.service');
    initDatabase(); const db = getDb();
    const report = { fk: db.pragma('foreign_key_check'), integrity: db.pragma('integrity_check', { simple: true }) };
    ${extra}
    console.log('@@' + JSON.stringify(report));`;

  function buildLegacyDb(file) {
    const Database = require(path.join(root, 'node_modules/better-sqlite3'));
    const { SCHEMA } = require(path.join(root, 'src/database/schema'));
    const d = new Database(file);
    d.pragma('foreign_keys = ON');
    d.exec(SCHEMA);
    // Turn it back into the pre-feature shape: no token_hash & friends, no ledger.
    d.exec('DROP INDEX IF EXISTS idx_userbots_token_hash; DROP INDEX IF EXISTS idx_userbot_token_history_userbot; DROP TABLE userbot_token_history;');
    for (const c of ['token_hash', 'token_generation', 'token_rotated_at']) d.exec(`ALTER TABLE userbots DROP COLUMN ${c}`);
    for (const id of [301, 302, 303, 304]) d.prepare('INSERT INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(id, `l${id}`, `L${id}`);
    const ins = d.prepare(`INSERT INTO userbots (user_id,label,status,session_string,telegram_userbot_id,expires_at,order_id,token,phone)
      VALUES (?,?,?,?,?,?,?,?,?)`);
    const future = new Date(Date.now() + 10 * DAY).toISOString();
    const soon = new Date(Date.now() + 20 * MIN).toISOString();
    const past = new Date(Date.now() - DAY).toISOString();
    d.prepare("INSERT INTO orders (user_id,category,product_name,qty,duration_days,status) VALUES (301,'userbot','P',1,30,'fulfilled')").run();
    const rows = {
      purchased: ins.run(301, 'Legacy Purchased', 'active', 'sess-a', 1111, future, 1, 'JASEB-legacyPurchasedTokenValue0123456789ABCDEFghijkl', '+62811').lastInsertRowid,
      trial: ins.run(302, '🎁 Trial Userbot', 'active', 'sess-b', 2222, soon, null, 'LIFE-UBOT : 0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF', null).lastInsertRowid,
      expired: ins.run(303, 'Legacy Expired', 'active', 'sess-c', 3333, past, 1, 'JASEB-legacyExpiredTokenValue0123456789ABCDEFghijklmnop', null).lastInsertRowid,
      revoked: ins.run(304, 'Legacy Revoked', 'revoked', 'sess-d', 4444, future, 1, 'JASEB-legacyRevokedTokenValue0123456789ABCDEFghijklmnop1', null).lastInsertRowid,
      noToken: ins.run(301, 'Legacy NoToken', 'active', 'sess-e', 5555, future, 1, null, null).lastInsertRowid,
      dupA: ins.run(304, 'Dup A', 'active', 'sess-f', 6666, future, 1, 'JASEB-duplicatedTokenValueXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', null).lastInsertRowid,
      dupB: ins.run(304, 'Dup B', 'active', 'sess-g', 7777, future, 1, 'JASEB-duplicatedTokenValueXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'.slice(0, 57) , null).lastInsertRowid,
    };
    // Make dupB a real duplicate of dupA (same plaintext).
    d.prepare('UPDATE userbots SET token = (SELECT token FROM userbots WHERE id = ?) WHERE id = ?').run(rows.dupA, rows.dupB);
    d.close();
    return rows;
  }
  const LEGACY = {
    purchased: 'JASEB-legacyPurchasedTokenValue0123456789ABCDEFghijkl',
    trial: 'LIFE-UBOT : 0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF',
    expired: 'JASEB-legacyExpiredTokenValue0123456789ABCDEFghijklmnop',
    revoked: 'JASEB-legacyRevokedTokenValue0123456789ABCDEFghijklmnop1',
  };

  await test('I1 legacy DB (plaintext tokens, no new columns): migrates in place, tokens keep working, plaintext cleared, data intact, FK/integrity clean', () => {
    const file = path.join(tmp, 'legacy1.sqlite');
    const rows = buildLegacyDb(file);
    const rep = runNode(initScript(`
      report.rows = db.prepare('SELECT id,user_id,label,status,session_string,telegram_userbot_id,expires_at,order_id,token,token_hash,token_generation FROM userbots ORDER BY id').all();
      report.orders = db.prepare('SELECT COUNT(*) c FROM orders').get().c;
      report.idx = db.prepare("SELECT name FROM sqlite_master WHERE name='idx_userbots_token_hash'").all().length;
      report.ledger = db.prepare("SELECT name FROM sqlite_master WHERE name='userbot_token_history'").all().length;
      report.checks = {
        purchased: bt.checkToken({ actorId: 301, rawCode: ${JSON.stringify(LEGACY.purchased)} }),
        trial: bt.checkToken({ actorId: 302, rawCode: ${JSON.stringify(LEGACY.trial)} }),
        expired: bt.checkToken({ actorId: 303, rawCode: ${JSON.stringify(LEGACY.expired)} }),
        revokedMode: bt.inspect({ actorId: 304, rawCode: ${JSON.stringify(LEGACY.revoked)} }).mode,
        stranger: bt.checkToken({ actorId: 302, rawCode: ${JSON.stringify(LEGACY.purchased)} }).state,
      };`), file);
    assert.deepEqual(rep.fk, []); assert.equal(rep.integrity, 'ok');
    assert.equal(rep.rows.length, 7, 'no userbot lost');
    assert.equal(rep.orders, 1);
    assert.ok(rep.rows.every((r) => r.token === null), 'no plaintext left at rest');
    const byId = Object.fromEntries(rep.rows.map((r) => [r.id, r]));
    assert.equal(byId[rows.purchased].token_hash, codec.hashStored(LEGACY.purchased));
    assert.equal(byId[rows.purchased].user_id, 301); assert.equal(byId[rows.purchased].session_string, 'sess-a');
    assert.equal(byId[rows.trial].label, '🎁 Trial Userbot');
    assert.equal(byId[rows.noToken].token_hash, null, 'rows that never had a token stay token-less');
    assert.equal(rep.idx, 1); assert.equal(rep.ledger, 1);
    assert.equal(rep.checks.purchased.state, 'VALID');
    assert.equal(rep.checks.trial.state, 'VALID'); assert.equal(rep.checks.trial.trial, true, 'legacy trial still recognised as trial');
    assert.equal(rep.checks.expired.state, 'EXPIRED');
    assert.equal(rep.checks.revokedMode, 'reactivate', 'legacy Garansi Akses path preserved');
    assert.equal(rep.checks.stranger, 'OWNERSHIP_MISMATCH');
    const dupes = [byId[rows.dupA], byId[rows.dupB]];
    assert.equal(dupes.filter((r) => r.token_hash).length, 1, 'duplicate plaintext never yields two active credentials');
    // Expiry / ownership / status of every legacy row is exactly what it was.
    assert.equal(byId[rows.expired].status, 'active'); assert.equal(byId[rows.revoked].status, 'revoked');
  });

  await test('I2 migration + backfill are idempotent: re-running changes nothing and keeps tokens valid', () => {
    const file = path.join(tmp, 'legacy1.sqlite');
    const snap = (extra) => runNode(initScript(`report.all = db.prepare('SELECT * FROM userbots ORDER BY id').all(); report.hist = db.prepare('SELECT * FROM userbot_token_history').all(); ${extra || ''}`), file);
    const first = snap(); const second = snap(); const third = snap(`report.v = bt.checkToken({ actorId: 301, rawCode: ${JSON.stringify(LEGACY.purchased)} }).state`);
    assert.deepEqual(second.all, first.all);
    assert.deepEqual(third.all, first.all);
    assert.deepEqual(third.hist, first.hist);
    assert.equal(third.v, 'VALID');
    assert.deepEqual(third.fk, []);
  });

  await test('I3 fresh database has the final schema and constraints; empty DB starts clean', () => {
    const file = path.join(tmp, 'fresh.sqlite');
    const rep = runNode(initScript(`
      report.cols = db.pragma('table_info(userbots)').filter((c) => /^token/.test(c.name)).map((c) => c.name);
      report.uniq = db.prepare("SELECT sql FROM sqlite_master WHERE name='idx_userbots_token_hash'").get().sql;
      report.histUniq = db.pragma('index_list(userbot_token_history)').filter((i) => i.unique).length;`), file);
    assert.deepEqual(rep.cols.sort(), ['token', 'token_generation', 'token_hash', 'token_rotated_at']);
    assert.match(rep.uniq, /UNIQUE INDEX .* WHERE token_hash IS NOT NULL/);
    assert.ok(rep.histUniq >= 1);
    assert.deepEqual(rep.fk, []);
  });

  await test('I4 the live test database (activations, trials expired+swept, transfers, deletions, recoveries) passes integrity + FK checks and re-opens cleanly', () => {
    assert.deepEqual(db.pragma('foreign_key_check'), []);
    assert.equal(db.pragma('integrity_check', { simple: true }), 'ok');
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbots WHERE token_hash IS NOT NULL').get().c,
      db.prepare('SELECT COUNT(DISTINCT token_hash) c FROM userbots WHERE token_hash IS NOT NULL').get().c, 'every active credential unique');
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbots WHERE token IS NOT NULL').get().c, 0, 'no plaintext ever written');
    // no retired hash is simultaneously active
    assert.equal(db.prepare('SELECT COUNT(*) c FROM userbots u JOIN userbot_token_history h ON h.token_hash = u.token_hash').get().c, 0);
    db.pragma('wal_checkpoint(TRUNCATE)');
    const copy = path.join(tmp, 'reopen.sqlite');
    fs.copyFileSync(process.env.DB_PATH, copy);
    const rep = runNode(initScript(`report.n = db.prepare('SELECT COUNT(*) c FROM userbots').get().c;`), copy);
    assert.deepEqual(rep.fk, []); assert.equal(rep.integrity, 'ok');
    assert.equal(rep.n, countBots());
  });

  // =====================================================================
  // J. SECRET HYGIENE (runs last: sees everything the suite did)
  // =====================================================================
  await test('J1 no plaintext token ever reached the application log', () => {
    const log = logBuf.join('\n');
    assert.ok(secrets.size > 20, 'sanity: many tokens were exercised');
    for (const s of secrets) assert.ok(!log.includes(s), `token leaked to log: ${s.slice(0, 12)}...`);
  });

  await test('J2 no plaintext token exists anywhere in the database dump (all tables)', () => {
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map((t) => t.name);
    let dump = '';
    for (const t of tables) dump += JSON.stringify(db.prepare(`SELECT * FROM "${t}"`).all());
    for (const s of secrets) assert.ok(!dump.includes(s), `token stored in plaintext: ${s.slice(0, 12)}...`);
  });

  const failed = results.filter((r) => !r).length;
  out(`\n${results.length - failed}/${results.length} passed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { out(`FATAL ${e && e.stack || e}`); process.exit(2); });
