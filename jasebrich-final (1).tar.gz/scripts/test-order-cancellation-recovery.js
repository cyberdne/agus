'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');

try { require.resolve('better-sqlite3'); } catch (_) {
  console.error('BLOCKED  ORDER_CANCELLATION_REAL_DB — better-sqlite3 is not installed in this environment');
  process.exit(2);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-order-cancel-'));
process.env.DB_PATH = path.join(tmp, 'cancel.sqlite');
process.env.BOT_TOKEN = 'test-token';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'test-hash';

const { initDatabase, getDb } = require('../src/database');
const orderRepo = require('../src/database/repositories/order.repository');
const orderService = require('../src/services/order.service');
const productService = require('../src/services/product.service');

initDatabase();
const db = getDb();
const USER_A = 80101;
const USER_B = 80102;
for (const id of [USER_A, USER_B]) db.prepare('INSERT INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(id, `u${id}`, `U${id}`);
const product = productService.create({ category: 'userbot', name: 'Cancel Test', description: 'test', price: 5000, durationDays: 30, garansi: false });

function createPending(userId, id) {
  db.prepare(`INSERT INTO orders (id,user_id,product_id,category,product_name,qty,unit_price,total_price,duration_days,status,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, userId, product.id, 'userbot', 'Cancel Test', 1, 5000, 5000, 30, 'pending', '2099-01-01 00:00:00', '2099-01-01 01:00:00');
  return id;
}

(async () => {
  const one = createPending(USER_A, 9001);
  assert.equal(orderRepo.findOpenByUser(USER_A).id, one);
  const wrongOwner = orderService.cancelOwnOrder({ orderId: one, userId: USER_B });
  assert.deepEqual({ ok: wrongOwner.ok, reason: wrongOwner.reason }, { ok: false, reason: 'not_owner' });
  assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(one).status, 'pending');

  const cancelled = orderService.cancelOwnOrder({ orderId: one, userId: USER_A });
  assert.equal(cancelled.ok, true);
  assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(one).status, 'cancelled');
  assert.equal(orderRepo.findOpenByUser(USER_A), null);

  const secondProduct = productService.create({ category: 'userbot', name: 'Cancel Test 2', description: 'test', price: 6000, durationDays: 30, garansi: false });
  const fresh = orderService.createOrder({ userId: USER_A, product: secondProduct, qty: 1 });
  assert.equal(fresh.status, 'pending');
  assert.equal(fresh.total_price, 6000);
  assert.equal(fresh.product_name, 'Cancel Test 2');

  // Product changes apply to NEW orders only. Existing order snapshots remain
  // the invoice/order contract captured at creation time.
  productService.update(secondProduct.id, { price: 7000 });
  const existingSnapshot = orderRepo.findById(fresh.id);
  assert.equal(existingSnapshot.unit_price, 6000);
  assert.equal(existingSnapshot.total_price, 6000);
  assert.equal(existingSnapshot.product_name, 'Cancel Test 2');
  assert.equal(orderService.cancelOwnOrder({ orderId: fresh.id, userId: USER_A }).ok, true);
  const repriced = orderService.createOrder({ userId: USER_A, product: secondProduct, qty: 1 });
  assert.equal(repriced.unit_price, 7000);
  assert.equal(repriced.total_price, 7000);
  assert.equal(orderService.cancelOwnOrder({ orderId: repriced.id, userId: USER_A }).ok, true);

  // Retiring a product keeps the FK reference intact so entitlement resolution
  // remains possible while the storefront stops offering it.
  const deletedProduct = productService.create({ category: 'userbot', name: 'Deleted Product', description: 'snapshot', price: 8000, durationDays: 60, garansi: false });
  const legacy = orderService.createOrder({ userId: USER_A, product: deletedProduct, qty: 2 });
  productService.remove(deletedProduct.id);
  const preserved = orderRepo.findById(legacy.id);
  assert.equal(preserved.product_id, deletedProduct.id);
  assert.equal(productService.getById(deletedProduct.id).is_active, 0);
  assert.equal(preserved.product_name, 'Deleted Product');
  assert.equal(preserved.unit_price, 8000);
  assert.equal(preserved.total_price, 16000);
  assert.equal(preserved.duration_days, 120);
  assert.equal(orderService.cancelOwnOrder({ orderId: legacy.id, userId: USER_A }).ok, true);

  createPending(USER_B, 9003);
  createPending(USER_B, 9005);
  const claimed = orderService.cancelAllOwnPendingOrders({ userId: USER_B });
  assert.equal(claimed.cancelledCount, 2);
  assert.equal(db.prepare('SELECT COUNT(*) AS c FROM orders WHERE user_id=? AND status IN (\'pending\',\'awaiting_confirmation\')').get(USER_B).c, 0);
  assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(9003).status, 'cancelled');
  assert.equal(db.prepare('SELECT status FROM orders WHERE id=?').get(9005).status, 'cancelled');
  const twice = orderService.cancelAllOwnPendingOrders({ userId: USER_B });
  assert.equal(twice.cancelledCount, 0);
  for (const status of ['cancelled', 'rejected', 'paid', 'processing', 'fulfilled']) {
    db.prepare('UPDATE orders SET status=? WHERE id=?').run(status, 9003);
    assert.equal(orderRepo.findOpenOrdersByUser(USER_B).length, 0);
  }

  createPending(USER_B, 9004);
  db.prepare('UPDATE orders SET status=? WHERE id=?').run('awaiting_confirmation', 9004);
  const proofOrder = orderRepo.findById(9004);
  const noCancel = orderService.cancelOwnOrder({ orderId: 9004, userId: USER_B });
  assert.equal(noCancel.ok, false);
  assert.equal(noCancel.reason, 'invalid_status');
  assert.equal(orderRepo.findById(9004).status, 'awaiting_confirmation');
  assert.equal(proofOrder.user_id, USER_B);

  const cancelledBeforeProof = createPending(USER_A, 9010);
  const cancelFirst = orderService.cancelOwnOrder({ orderId: cancelledBeforeProof, userId: USER_A });
  assert.equal(cancelFirst.ok, true);
  const proofAfterCancel = orderService.requestPaymentProof({ orderId: cancelledBeforeProof, userId: USER_A });
  assert.equal(proofAfterCancel.ok, false);
  assert.equal(proofAfterCancel.reason, 'invalid_status');
  assert.equal(orderRepo.findById(cancelledBeforeProof).status, 'cancelled');

  console.log('PASS  buyer cancellation ownership/state CAS');
  console.log('PASS  cancelled order no longer blocks new order');
  console.log('PASS  bulk legacy pending recovery is idempotent');
  console.log('PASS  awaiting_confirmation is not buyer-cancellable');
})();
