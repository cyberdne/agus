'use strict';

const assert = require('assert');
const { renderWithReplyKeyboard } = require('../src/utils/render');
const screenState = require('../src/state/screenState');

function makeCtx() {
  const calls = { reply: 0, edit: 0 };
  const ctx = {
    chat: { id: 987654, type: 'private' },
    callbackQuery: null,
    telegram: {
      async editMessageText(chatId, messageId, inlineMessageId, text, options) {
        calls.edit++;
        calls.lastEdit = { chatId, messageId, text, options };
        return true;
      },
    },
    async reply(text, options) {
      calls.reply++;
      calls.lastReply = { text, options };
      return { message_id: calls.reply };
    },
  };
  return { ctx, calls };
}

(async () => {
  screenState.clear(987654);
  const { ctx, calls } = makeCtx();
  const keyboard = { reply_markup: { keyboard: [['🛒 Store']] } };

  const first = await renderWithReplyKeyboard(ctx, 'Menu Store', keyboard, null, 'store');
  assert.strictEqual(first.message_id, 1);
  assert.strictEqual(calls.reply, 1);
  assert.strictEqual(calls.edit, 0);

  const second = await renderWithReplyKeyboard(ctx, 'Menu Store terbaru', keyboard, null, 'store');
  assert.strictEqual(second.message_id, 1);
  assert.strictEqual(second.reused, true);
  assert.strictEqual(calls.reply, 1, 'repeated Store entry must not send a duplicate screen');
  assert.strictEqual(calls.edit, 1, 'repeated Store entry must edit the existing bot screen');
  assert.ok(!Object.prototype.hasOwnProperty.call(calls.lastEdit.options, 'reply_markup'), 'reply keyboard is not passed to editMessageText');

  // Telegram edit failure must fall back to exactly one new render.
  ctx.telegram.editMessageText = async () => { throw { description: 'Bad Request: message to edit not found' }; };
  const third = await renderWithReplyKeyboard(ctx, 'Menu Store setelah stale', keyboard, null, 'store');
  assert.strictEqual(third.message_id, 2);
  assert.strictEqual(calls.reply, 2, 'stale tracked screen must create one replacement, not loop');
  assert.strictEqual(calls.edit, 1);

  screenState.clear(987654);
  console.log('STORE_RENDER_DEDUP_OK repeated_entry=1 stale_fallback=1');
})().catch((err) => {
  console.error(err);
  process.exit(1);
});

const fs = require('fs');
const storeSource = fs.readFileSync(require('path').join(__dirname, '..', 'src/handlers/store.handler.js'), 'utf8');
assert.ok(/const sourceMessage = ctx && ctx\.callbackQuery && ctx\.callbackQuery\.message;/.test(storeSource));
assert.ok(/await ctx\.telegram\.deleteMessage\(ctx\.chat\.id, sourceMessage\.message_id\)/.test(storeSource));
console.log('STORE_CALLBACK_SOURCE_DEDUP_STATIC_OK callback_source_cleanup=1');
