'use strict';
/**
 * Boots the REAL src/index.js (real middleware chain, real bot.hears/bot.action
 * routing, real DB) with only the Telegram HTTP transport stubbed, then feeds
 * real-shaped updates through bot.handleUpdate().
 * Run: node scripts/test-subscription-bot.js
 */
const fs = require('fs'), os = require('os'), path = require('path');
const assert = require('node:assert/strict');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-bot-'));
Object.assign(process.env, { DB_PATH: path.join(tmp, 'b.sqlite'), BOT_TOKEN: '123:abc', ADMIN_IDS: '900', TELEGRAM_API_ID: '', TELEGRAM_API_HASH: '' });
process.chdir(tmp);
const root = path.resolve(__dirname, '..');
const { Telegraf } = require(path.join(root, 'node_modules/telegraf'));
let bot = null;
Telegraf.prototype.launch = function () { bot = this; return Promise.resolve(); };
const realExit = process.exit.bind(process);
process.exit = (c) => { if (c) throw new Error('process.exit(' + c + ')'); };  // index.js must not kill the test on config errors
process.once = () => process;
require(path.join(root, 'src/index.js'));

const calls = [];
let uid = 1;
const db = require(path.join(root, 'src/database')).getDb();
const owned = require(path.join(root, 'src/database/repositories/ownedUserbot.repository'));
function setup() {
  bot.botInfo = { id: 1, is_bot: true, username: 'b', first_name: 'b' };
  // Telegraf builds a fresh Telegram per update, so stub the transport on the prototype.
  require(path.join(root, 'node_modules/telegraf')).Telegram.prototype.callApi = async (method, payload) => { calls.push({ method, payload }); return method === 'sendMessage' ? { message_id: ++uid, chat: { id: payload.chat_id } } : true; };
}
const msg = (from, text) => ({ update_id: ++uid, message: { message_id: uid, date: Math.floor(Date.now() / 1000), chat: { id: from, type: 'private' }, from: { id: from, is_bot: false, first_name: 'U' + from, username: 'u' + from }, text } });
const cb = (from, data) => ({ update_id: ++uid, callback_query: { id: String(uid), from: { id: from, is_bot: false, first_name: 'U' + from }, chat_instance: 'x', data, message: { message_id: 50, date: 1, chat: { id: from, type: 'private' }, text: 'old' } } });
const texts = () => calls.filter((c) => /sendMessage|editMessageText/.test(c.method)).map((c) => c.payload.text || '').join('\n---\n');
const cbData = () => calls.flatMap((c) => (c.payload && c.payload.reply_markup && c.payload.reply_markup.inline_keyboard || []).flat()).map((b) => b.callback_data);
let pass = 0; async function t(name, fn) { calls.length = 0; try { await fn(); pass++; console.log('PASS  ' + name); } catch (e) { console.log('FAIL  ' + name + '\n      ' + (e.stack || e)); process.exitCode = 1; } }

(async () => {
  await new Promise((r) => setTimeout(r, 50)); setup();
  db.prepare("INSERT INTO users (telegram_id,username,first_name,join_gate_verified) VALUES (900,'adm','Adm',1),(100,'own',100,1),(101,'act',101,1)").run();
  const mk = (u, exp) => db.prepare("INSERT INTO userbots (user_id,label,status,session_string,expires_at,order_id,wtb_reply) VALUES (?,?,?,?,?,?,0)").run(u, 'Ubot', 'active', 's', exp, 1).lastInsertRowid;
  const expId = mk(100, new Date(Date.now() - 86400000).toISOString());   // status 'active' in DB, but past expiry
  const actId = mk(101, new Date(Date.now() + 86400000 * 5).toISOString());

  await t('Expired owner taps 🎛️ Kontrol Panel -> renewal screen with stable callback, no panel', async () => {
    await bot.handleUpdate(msg(100, '🎛️ Kontrol Panel'));
    assert.match(texts(), /Kadaluarsa/); assert.doesNotMatch(texts(), /Panel Kontrol Auto Promosi/);
    assert(cbData().includes(`subscription:renew:${expId}`));
  });
  await t('Old reply-keyboard button "🚀 Mulai Promosi" after expiry is not executed', async () => {
    await bot.handleUpdate(msg(100, '🚀 Mulai Promosi'));
    assert.doesNotMatch(texts(), /Promosi otomatis diaktifkan/);
    assert.equal(owned.findById(expId).auto_promosi, 0);
  });
  await t('Old inline button (panelgrp:delall) after expiry is rejected', async () => {
    await bot.handleUpdate(cb(100, 'panelgrp:delall'));
    assert.doesNotMatch(texts(), /Apakah yakin ingin menghapus SEMUA/);
  });
  await t('subscription:renew:<id> routes into the existing Store renewal flow', async () => {
    await bot.handleUpdate(cb(100, `subscription:renew:${expId}`));
    assert.match(texts(), /Perpanjang Langganan|Belum ada paket/);
  });
  await t('Active owner still opens the control panel', async () => {
    await bot.handleUpdate(msg(101, '🎛️ Kontrol Panel'));
    assert.match(texts(), /Panel Kontrol Auto Promosi/);
  });
  await t('Non-owner cannot renew someone else\'s userbot via callback', async () => {
    await bot.handleUpdate(cb(101, `subscription:renew:${expId}`));
    assert.match(texts(), /bukan milik kamu/);
  });
  await t('Admin: Settings -> "⏳ Perpanjang Userbot" reply button lists userbots', async () => {
    await bot.handleUpdate(msg(900, '⚙️ Settings'));
    const kb = calls.find((c) => c.payload.reply_markup && c.payload.reply_markup.keyboard);
    assert(JSON.stringify(kb.payload.reply_markup.keyboard).includes('Perpanjang Userbot'), 'button present in Settings');
    calls.length = 0;
    await bot.handleUpdate(msg(900, '⏳ Perpanjang Userbot'));
    assert(cbData().includes(`subext:sel:${expId}`)); assert(cbData().includes(`subext:sel:${actId}`));
  });
  await t('Admin: pick -> confirm -> go through real router extends once; user regains access', async () => {
    await bot.handleUpdate(cb(900, `subext:pick:${expId}:30`));
    const go = cbData().find((d) => /^subext:go:/.test(d)); assert(go);
    calls.length = 0;
    await bot.handleUpdate(cb(900, go)); await bot.handleUpdate(cb(900, go));
    const exp = Date.parse(owned.findById(expId).expires_at);
    assert(Math.abs(exp - (Date.now() + 30 * 86400000)) < 5000);
    calls.length = 0;
    await bot.handleUpdate(msg(100, '🎛️ Kontrol Panel'));
    assert.match(texts(), /Panel Kontrol Auto Promosi/);
  });
  await t('Non-admin cannot reach subext:go (requireAdmin)', async () => {
    const before = owned.findById(actId).expires_at;
    await bot.handleUpdate(cb(101, `subext:go:${actId}:30:deadbeef`));
    assert.equal(owned.findById(actId).expires_at, before);
  });
  console.log(`\n${pass} passed`); realExit(process.exitCode || 0);
})().catch((e) => { console.error(e); realExit(2); });
