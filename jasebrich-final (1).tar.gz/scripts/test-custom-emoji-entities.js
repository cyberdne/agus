'use strict';
/**
 * Real integration tests for the outgoing-message custom-emoji /
 * formatting-preservation fix.
 *
 * What is REAL: SQLite (temp file, real schema + migrations),
 * panelConfig.service, userbotRuntime.service (botEntitiesToGramJs,
 * sendConfiguredMessage, the WTB Base Reply send path), and the real
 * `telegram` (GramJS) Api.* entity classes.
 * What is substituted (transport boundary only — no real network):
 *   - GramJS TelegramClient -> in-process FakeClient that records every
 *     sendMessage/sendFile call instead of hitting Telegram.
 *   - The incoming NewMessage event -> a fake `message` object whose
 *     `.reply()` records its argument, exactly like FakeClient.sendMessage.
 *
 * Run: node scripts/test-custom-emoji-entities.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-emoji-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');

// ---- fake GramJS transport (Api.* entity classes are the REAL ones) ------
const tg = require(path.join(root, 'node_modules/telegram'));
const sentCalls = [];
class FakeClient {
  constructor(session) { this.session = String(session.save ? session.save() : ''); this.connected = false; }
  async connect() { this.connected = true; }
  async disconnect() { this.connected = false; }
  async getInputEntity(t) { return t; }
  async sendMessage(target, opts) { sentCalls.push({ kind: 'sendMessage', target, opts }); return { id: sentCalls.length }; }
  async sendFile(target, opts) { sentCalls.push({ kind: 'sendFile', target, opts }); return { id: sentCalls.length }; }
}
Object.defineProperty(tg, 'TelegramClient', { value: FakeClient, configurable: true, writable: true });
const sess = require(path.join(root, 'node_modules/telegram/sessions'));
Object.defineProperty(sess, 'StringSession', { value: class { constructor(s) { this.s = s; } save() { return this.s; } }, configurable: true });

const { initDatabase, getDb } = require(path.join(root, 'src/database'));
initDatabase();
const db = getDb();
const S = (p) => require(path.join(root, 'src', p));
const panelConfig = S('services/panelConfig.service');
const runtime = S('services/userbotRuntime.service');
const ownedRepo = S('database/repositories/ownedUserbot.repository');
const { Api } = require(path.join(root, 'node_modules/telegram/tl'));

let n = 0;
function mkUser(id) { db.prepare("INSERT OR IGNORE INTO users (telegram_id, username, first_name) VALUES (?,?,?)").run(id, `u${id}`, `U${id}`); }
function mkBot() {
  mkUser(100);
  const r = db.prepare(`INSERT INTO userbots (user_id,label,status,session_string,telegram_userbot_id,auto_promosi,wtb_reply,pm_permit,expires_at,order_id,target,broadcast_text)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(100, 'Userbot X', 'active', `sess-${++n}`, 5000 + n, 1, 1, 0, iso(Date.now() + 86400000), 1, '@grup', null);
  return ownedRepo.findById(r.lastInsertRowid);
}
const iso = (ms) => new Date(ms).toISOString();

const results = [];
async function test(name, fn) {
  try { await fn(); results.push([true, name]); console.log(`PASS  ${name}`); }
  catch (e) { results.push([false, name]); console.log(`FAIL  ${name}\n      ${e && e.stack || e}`); }
}

// Bot-API-shaped entities, exactly like ctx.message.entities from Telegram.
function botEntities() {
  const text = 'Halo *User* 👋 dunia';
  // "👋" is configured as a premium/custom emoji; "*User*" carries bold.
  const boldStart = text.indexOf('User');
  const emojiStart = text.indexOf('👋');
  return {
    text,
    entities: [
      { type: 'bold', offset: boldStart, length: 'User'.length },
      { type: 'custom_emoji', offset: emojiStart, length: 2, custom_emoji_id: '5432101234567890' },
    ],
  };
}

function findEntity(list, ctor) { return list.find((e) => e instanceof ctor); }

(async () => {
  const asset = mkBot();
  // GramJS is loaded lazily by the runtime (loadGramJs via configured()); any
  // real runtime entry point triggers it. Sync of a non-existent asset is a
  // no-op teardown, but it runs the real configured() -> loadGramJs() path.
  await runtime.syncAsset('owned', 0);

  await test('sendConfiguredMessage: custom emoji becomes MessageEntityCustomEmoji, bold survives', async () => {
    const { text, entities } = botEntities();
    panelConfig.setTextMessage(asset.id, text, entities);
    const client = new FakeClient({ save: () => asset.session_string });
    sentCalls.length = 0;
    await runtime.sendConfiguredMessage(client, '@grup', ownedRepo.findById(asset.id));
    assert.equal(sentCalls.length, 1);
    const { opts } = sentCalls[0];
    assert.equal(opts.message, text); // text content byte-identical
    const fe = opts.formattingEntities;
    assert.ok(Array.isArray(fe) && fe.length === 2, 'both entities must be forwarded');
    const bold = findEntity(fe, Api.MessageEntityBold);
    const emoji = findEntity(fe, Api.MessageEntityCustomEmoji);
    assert.ok(bold, 'bold entity must be preserved');
    assert.ok(emoji, 'custom emoji entity must be a real MessageEntityCustomEmoji');
    assert.equal(String(emoji.documentId), '5432101234567890');
    assert.equal(emoji.offset, text.indexOf('👋'));
    assert.equal(emoji.length, 2); // UTF-16 length of a surrogate-pair emoji
  });

  await test('sendConfiguredMessage: media caption keeps entities via formattingEntities', async () => {
    const { text, entities } = botEntities();
    const mediaPath = path.join(tmp, 'x.jpg');
    fs.writeFileSync(mediaPath, Buffer.from([0xff, 0xd8, 0xff]));
    panelConfig.setMediaMessage(asset.id, mediaPath, 'photo', text, entities, 'x.jpg');
    const client = new FakeClient({ save: () => asset.session_string });
    sentCalls.length = 0;
    await runtime.sendConfiguredMessage(client, '@grup', ownedRepo.findById(asset.id));
    assert.equal(sentCalls[0].kind, 'sendFile');
    const fe = sentCalls[0].opts.formattingEntities;
    assert.ok(findEntity(fe, Api.MessageEntityCustomEmoji), 'caption custom emoji preserved');
    assert.ok(findEntity(fe, Api.MessageEntityBold), 'caption bold preserved');
    assert.equal(sentCalls[0].opts.caption, text);
  });

  await test('Global quick text (await_global_text path): entities are stored, not dropped', async () => {
    const { text, entities } = botEntities();
    // Exercises the exact call the panel.handler "await_global_text" step
    // now makes: panelConfig.setTextMessage(id, text, entities).
    panelConfig.setTextMessage(asset.id, text, entities);
    const stored = panelConfig.getMessage(asset.id);
    const parsed = JSON.parse(stored.entities);
    assert.equal(parsed.length, 2);
    assert.ok(parsed.some((e) => e.type === 'custom_emoji' && e.custom_emoji_id === '5432101234567890'));
    assert.ok(parsed.some((e) => e.type === 'bold'));
  });

  await test('WTB Base Reply: addReply persists entities and the send path forwards MessageEntityCustomEmoji', async () => {
    const { text, entities } = botEntities();
    const row = panelConfig.addReply(asset.id, 'promo', text, entities);
    assert.ok(row.entities && JSON.parse(row.entities).length === 2);

    const listed = panelConfig.listReplies(asset.id).find((r) => r.id === row.id);
    const replyEntities = runtime.botEntitiesToGramJs(JSON.parse(listed.entities));
    assert.ok(findEntity(replyEntities, Api.MessageEntityCustomEmoji), 'WTB reply must carry a real custom emoji entity');
    assert.ok(findEntity(replyEntities, Api.MessageEntityBold), 'WTB reply must keep bold formatting');

    // Simulate the actual send call shape used in attach()'s handler after the fix.
    const fakeMessage = { reply: async (o) => { sentCalls.push({ kind: 'wtbReply', opts: o }); } };
    await fakeMessage.reply({ message: listed.response, formattingEntities: replyEntities });
    const last = sentCalls[sentCalls.length - 1];
    assert.equal(last.opts.message, text);
    assert.ok(findEntity(last.opts.formattingEntities, Api.MessageEntityCustomEmoji));
  });

  await test('Plain Unicode emoji (not configured as custom) stays plain — no false-positive entity', async () => {
    const text = 'Halo 😀 semuanya';
    panelConfig.setTextMessage(asset.id, text, []); // admin never marked 😀 as custom emoji
    const client = new FakeClient({ save: () => asset.session_string });
    sentCalls.length = 0;
    await runtime.sendConfiguredMessage(client, '@grup', ownedRepo.findById(asset.id));
    const { opts } = sentCalls[0];
    assert.equal(opts.message, text);
    assert.equal(opts.formattingEntities, undefined);
  });

  await test('Multiple custom emoji + one plain Unicode emoji in one message', async () => {
    const text = '🔥 Halo 👋 Selamat 🎉 datang ❤️';
    const idx = (ch) => text.indexOf(ch);
    const entities = [
      { type: 'custom_emoji', offset: idx('🔥'), length: 2, custom_emoji_id: '111' },
      { type: 'custom_emoji', offset: idx('👋'), length: 2, custom_emoji_id: '222' },
      { type: 'custom_emoji', offset: idx('🎉'), length: 2, custom_emoji_id: '333' },
      // ❤️ deliberately has NO entity — it must remain plain Unicode.
    ];
    panelConfig.setTextMessage(asset.id, text, entities);
    const client = new FakeClient({ save: () => asset.session_string });
    sentCalls.length = 0;
    await runtime.sendConfiguredMessage(client, '@grup', ownedRepo.findById(asset.id));
    const fe = sentCalls[0].opts.formattingEntities;
    assert.equal(fe.length, 3);
    const ids = fe.map((e) => String(e.documentId)).sort();
    assert.deepEqual(ids, ['111', '222', '333']);
    assert.equal(sentCalls[0].opts.message, text); // ❤️ still present as plain text
  });

  await test('Reply target (topicId) still passed through alongside entities', async () => {
    const { text, entities } = botEntities();
    panelConfig.setTextMessage(asset.id, text, entities);
    const client = new FakeClient({ save: () => asset.session_string });
    sentCalls.length = 0;
    await runtime.sendConfiguredMessage(client, '@grup', ownedRepo.findById(asset.id), 42);
    assert.equal(sentCalls[0].opts.replyTo, 42);
    assert.ok(findEntity(sentCalls[0].opts.formattingEntities, Api.MessageEntityCustomEmoji));
  });

  await test('Forward messages are untouched by the entity-merge logic', async () => {
    panelConfig.setForwardMessage(asset.id, '-100123', 555);
    const stored = panelConfig.getMessage(asset.id);
    assert.equal(stored.kind, 'forward');
    assert.equal(stored.entities, '[]'); // forwards never go through entity synthesis
  });

  console.log(`\n${results.filter((r) => r[0]).length}/${results.length} passed`);
  if (results.some((r) => !r[0])) process.exit(1);
})();
