'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const panel = read('src/handlers/panel.handler.js');
const runtime = read('src/services/userbotRuntime.service.js');
const reminder = read('src/services/subscriptionReminder.service.js');
const reminderRepo = read('src/database/repositories/subscriptionReminder.repository.js');
const lifecycle = read('src/services/userbotLifecycle.service.js');
const scheduler = read('src/scheduler.js');
const subscription = read('src/services/subscription.service.js');
const job = read('src/database/repositories/userbotRuntimeJob.repository.js');

// Realtime promotion status: authoritative runtime-job data, one watcher per
// user, throttled/coalesced, and no placeholder-only UI state.
assert.match(runtime, /function getPromotionStatus\(kind,id\)/);
assert.match(runtime, /runtimeJobRepo\.find\(kind,id\)/);
assert.match(runtime, /job\?\.processed_targets/);
assert.match(runtime, /job\?\.successful_targets/);
assert.match(runtime, /job\?\.failed_targets/);
assert.match(runtime, /job\?\.blocked_targets/);
assert.match(runtime, /job\?\.removed_targets/);
assert.match(runtime, /else if \(job\?\.status === 'failed'\) status = 'GAGAL'/);
assert.match(runtime, /else if \(job\?\.status === 'cancelled'\) status = 'BERHENTI'/);
assert.match(runtime, /status = 'SELESAI'/);
assert.match(panel, /const PROMOTION_STATUS_REFRESH_MS = 8000/);
assert.match(panel, /const promotionStatusWatchers = new Map\(\)/);
assert.match(panel, /stopPromotionStatusWatcher\(ctx\.from\.id\)/);
assert.ok(panel.includes('tracked.feature!==PROMOTION_STATUS_SCREEN') || panel.includes('tracked.feature !== PROMOTION_STATUS_SCREEN'));
assert.match(panel, /ctx\.telegram\.editMessageText\(uid,tracked\.messageId/);
assert.ok(panel.includes('content.text!==watcher.lastText') || panel.includes('content.text !== watcher.lastText'));
assert.match(panel, /PROMOTION_STATUS_SCREEN/);

// Start/Stop stays in the promotion submenu. Stop must not render the old
// confirmation text as the main output.
assert.match(panel, /makeScreen\(ctx,'promotion_status'\)/);
assert.ok(panel.includes('userbotRuntime.isAutoPromosiActive(kind,id)') || panel.includes('userbotRuntime.isAutoPromosiActive(panelKind(ctx),assetId)'));
const startBlock = panel.slice(panel.indexOf('const startHandler='), panel.indexOf('const promotionStatusHandler='));
assert.doesNotMatch(startBlock, /showMainPanel\(ctx, panelContent\(panelTpl\.promoStopped/);
assert.match(startBlock, /renderWithReplyKeyboard\(ctx,statusContent\.text/);
assert.match(startBlock, /promotionRunningKeyboard\(\)/);
assert.doesNotMatch(startBlock, /promotionStatusInlineKeyboard\(/);

// Managed connection reuse: no cold-path disconnect after every panel action;
// authorization proof is cached per managed asset and lifecycle is keyed per asset.
assert.match(runtime, /const SESSION_AUTH_CACHE_MS = 60 \* 1000/);
assert.match(runtime, /function assertSessionAuthorizedCached\(record/);
assert.match(runtime, /function ensureManagedClientLocked\(kind, id, asset\)/);
assert.match(runtime, /return await withAssetLock\(k, async \(\) =>/);
assert.match(runtime, /await assertSessionAuthorizedCached\(record, asset\.telegram_userbot_id\)/);
assert.match(runtime, /clients\.get\(keyFor\(kind,id\)\)/);
const withClient = runtime.slice(runtime.indexOf('async function withClient'), runtime.indexOf('/** Verify a stored MTProto session', runtime.indexOf('async function withClient')));
assert.doesNotMatch(withClient, /finally \{ try\{await c\.disconnect\(\)/);
assert.match(runtime, /if\(!live\|\|!asset\.session_string\|\|\(!any && !managedClientExists\)\)/);
assert.match(runtime, /only explicit lifecycle teardown, expiry, invalid-session handling, or/);

// Concurrency remains per asset, never a global mutex/queue.
assert.match(runtime, /const assetLocks = new Map\(\)/);
assert.match(runtime, /function withAssetLock\(key, fn\)/);
assert.match(runtime, /keyFor\(kind,id\)/);
assert.doesNotMatch(runtime, /const globalLock/);
assert.doesNotMatch(runtime, /GLOBAL_MUTEX/);

// Subscription expiry/extension are authoritative and CAS/transaction based.
assert.match(subscription, /db\.transaction\(\(\) =>/);
assert.match(subscription, /sub_version = sub_version \+ 1/);
assert.match(subscription, /WHERE id = \? AND sub_version = \?/);
assert.match(subscription, /status = 'expired'/);
assert.match(subscription, /isExpiredAt\(row\.expires_at, nowMs\)/);

// Durable near-expiry + expired reminder delivery, retry cap, and per-row
// isolation. A single bad subscriber cannot terminate the scheduler sweep.
assert.match(reminderRepo, /event_type = 'expiry'/);
assert.match(reminderRepo, /function listPendingExpiry/);
assert.match(reminderRepo, /function markExhausted/);
assert.match(reminder, /const MAX_AUTOMATIC_ATTEMPTS_PER_EVENT = 3/);
assert.match(reminder, /function classifyReminderDeliveryError/);
assert.match(reminder, /async function ensureExpiredReminderEvent/);
assert.match(reminder, /async function sendExpiredReminder/);
assert.match(reminder, /async function sweepExpiredReminders/);
assert.match(reminder, /catch \(err\) \{\n      \/\/ One malformed row\/template/);
assert.match(lifecycle, /ensureExpiredReminderEvent\(result\.row\)/);
assert.match(lifecycle, /sendExpiredReminder\(telegramRef, result\.row, eventKey\)/);
assert.doesNotMatch(lifecycle, /Fallback expiry notice/);
assert.match(scheduler, /sweepAutomaticReminders\(telegram\)/);
assert.match(scheduler, /sweepExpiredReminders\(telegram\)/);

// Promotion runtime counters are persisted by the existing job repository,
// not fabricated by the UI layer.
assert.match(job, /processed_targets = processed_targets \+ 1/);
assert.match(job, /successful_targets = successful_targets \+ \?/);
assert.match(job, /failed_targets = failed_targets \+ \?/);
assert.match(job, /blocked_targets = blocked_targets \+ \?/);
assert.match(job, /removed_targets = removed_targets \+ \?/);
assert.match(job, /last_activity_at/);

console.log('REALTIME_CONNECTION_SUBSCRIPTION_HARDENING_CONTRACT_OK');
