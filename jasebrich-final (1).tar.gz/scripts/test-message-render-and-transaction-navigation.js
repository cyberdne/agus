'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const render = require(path.join(root, 'src/utils/render.js'));
const store = fs.readFileSync(path.join(root, 'src/handlers/store.handler.js'), 'utf8');
const nav = fs.readFileSync(path.join(root, 'src/middlewares/navigationCancellation.middleware.js'), 'utf8');
const keyboard = fs.readFileSync(path.join(root, 'src/keyboards/inline.keyboard.js'), 'utf8');

async function run() {
  const calls = [];

  const textCtx = {
    chat: { id: 1 },
    callbackQuery: { data: 'store:test', message: { message_id: 10, text: 'old' } },
    async editMessageText(text) { calls.push(['text', text]); },
    async reply() { throw new Error('text callback must not reply'); },
  };
  await render.renderScreen(textCtx, 'new text', {}, 'store');
  assert.deepEqual(calls.shift(), ['text', 'new text']);

  const photoCtx = {
    chat: { id: 2 },
    callbackQuery: {
      data: 'store:test',
      message: { message_id: 20, photo: [{ file_id: 'x' }], caption: 'old caption' },
    },
    async editMessageText() { throw new Error('editMessageText must never be used for photo callbacks'); },
    async editMessageCaption(text) { calls.push(['caption', text]); },
    async reply() { throw new Error('photo callback should edit its caption'); },
  };
  await render.renderScreen(photoCtx, 'new caption', {}, 'store');
  assert.deepEqual(calls.shift(), ['caption', 'new caption']);

  let unsupportedReplies = 0;
  const unsupportedCtx = {
    chat: { id: 3 },
    callbackQuery: {
      data: 'store:test',
      message: { message_id: 30, sticker: { file_id: 's' } },
    },
    async editMessageText() { throw new Error('unsupported callback must not call editMessageText'); },
    async reply(text) { unsupportedReplies += 1; return { message_id: 31, text }; },
  };
  await render.renderScreen(unsupportedCtx, 'replacement', {}, 'store');
  assert.equal(unsupportedReplies, 1);

  assert.match(store, /replyButton\.danger\('❌ Batal'\)/);
  assert.doesNotMatch(store, /replyButton\.danger\('🔙 Kembali'\)/);
  assert.doesNotMatch(store, /async function returnToPaymentFromPaymentProof/);
  assert.doesNotMatch(nav, /returnToPaymentFromPaymentProof/);
  assert.match(nav, /buyer\.step === 'await_payment_proof'[\s\S]*?text === MENU\.BATAL/);
  const proofBlock = nav.match(/buyer && buyer\.step === 'await_payment_proof'[\s\S]*?\n    }/s)?.[0] || '';
  assert.doesNotMatch(proofBlock, /text === MENU\.KEMBALI/);
  assert.doesNotMatch(keyboard, /Tidak \/ Kembali/);

  console.log('PASS  text callback uses editMessageText');
  console.log('PASS  photo callback uses editMessageCaption and never editMessageText');
  console.log('PASS  unsupported callback message falls back to a fresh screen');
  console.log('PASS  payment-proof reply keyboard exposes only Batal');
  console.log('PASS  payment-proof Kembali transition is removed');
  console.log('PASS  transactional confirmation/recovery no longer labels navigation as Kembali');
}

run().catch((err) => {
  console.error('FAIL ', err && err.stack || err);
  process.exit(1);
});
