'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const store = read('src/handlers/store.handler.js');
const render = read('src/utils/render.js');

function blockBetween(source, startText, endText) {
  const start = source.indexOf(startText);
  assert.notStrictEqual(start, -1, `missing block start: ${startText}`);
  const end = source.indexOf(endText, start);
  assert.notStrictEqual(end, -1, `missing block end: ${endText}`);
  return source.slice(start, end);
}

const recoveryBlock = blockBetween(
  store,
  'async function renderPendingOrderRecovery(ctx, orders = null)',
  'async function renderPendingOrderRecoveryOrStore(ctx, orders = null)'
);
const recoveryOrStoreBlock = blockBetween(
  store,
  'async function renderPendingOrderRecoveryOrStore(ctx, orders = null)',
  'const storeHandler = safeHandler'
);
const storeHandlerBlock = blockBetween(
  store,
  'const storeHandler = safeHandler',
  '// "Kembali" from the S&K screen'
);

assert(!/renderStoreScreen\(ctx\)/.test(recoveryBlock),
  'empty recovery path has no hidden Store render side effect');
assert(/if \(!openOrders\.length\) return false;/.test(recoveryBlock),
  'recovery renderer returns false without rendering when there is nothing to recover');
assert(/if \(await renderPendingOrderRecovery\(ctx, orders\)\) return true;/.test(recoveryOrStoreBlock),
  'recovery-or-store helper makes exactly one explicit render decision');
assert(/await renderStoreScreen\(ctx\);/.test(recoveryOrStoreBlock),
  'recovery-or-store helper owns the single empty-recovery Store render');
assert((storeHandlerBlock.match(/renderPendingOrderRecoveryOrStore\(ctx\)/g) || []).length === 1,
  'Store entry handler has exactly one recovery-or-store render decision');
assert(!/renderPendingOrderRecovery\(ctx\)\s*;[\s\S]*renderStoreScreen\(ctx\)/.test(storeHandlerBlock),
  'Store entry handler cannot render Store twice through the old hidden fallback');

// Runtime regression for the renderer itself: concurrent callers must be
// covered by a deterministic single-screen strategy. This verifies the
// existing screen-state contract remains present; the root-cause fix above
// removes the internal second render that previously made one Store handler
// invoke the Store renderer twice.
assert(/renderWithReplyKeyboard/.test(render), 'reply-keyboard renderer exists');
assert(/screenState\.set\(chatId, sent\.message_id, featureName\)/.test(render),
  'Store screen render records the canonical screen identity');
assert(/createActionIdempotency/.test(store),
  'Store entry has stable-event idempotency protection against duplicate update execution');
assert(/runStoreActionIdempotently\(ctx/.test(store),
  'Store reply/callback entry points run through the idempotency boundary');

console.log('STORE_OPEN_DEDUP_ROOT_CAUSE_PASS hidden_render_removed=1 single_store_entry_decision=1');
