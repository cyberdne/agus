'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const src = path.join(root, 'src');
const files = [];
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const st = fs.statSync(full);
    if (st.isDirectory()) walk(full);
    else if (full.endsWith('.js')) files.push(full);
  }
}
walk(src);

const publicFiles = files.filter((f) => !f.includes(`${path.sep}handlers${path.sep}admin${path.sep}`));
const defs = [];
for (const file of publicFiles) {
  const text = fs.readFileSync(file, 'utf8');
  const re = /define(?:Template|Submenu)\(\s*(['"])([^'"]+)\1/g;
  let m;
  while ((m = re.exec(text))) defs.push({ id: m[2], file: path.relative(root, file) });
}

const seen = new Map();
for (const d of defs) {
  assert(!seen.has(d.id), `duplicate template/submenu id: ${d.id} (${seen.get(d.id)} and ${d.file})`);
  seen.set(d.id, d.file);
}
assert(defs.length >= 190, `expected broad customization inventory, found only ${defs.length} entries`);

const registry = fs.readFileSync(path.join(src, 'constants', 'submenu.registry.js'), 'utf8');
assert.match(registry, /scope:\s*'USER'/);
assert.match(registry, /defaultValue:\s*null/);
assert.match(registry, /defaultMaxLengthForMessageType/);
assert.doesNotMatch(registry, /maxLength:\s*null/);
assert.match(registry, /requestedMax == null[\s\S]*defaultMaxLengthForMessageType/);

const service = fs.readFileSync(path.join(src, 'services', 'custom-submenu.service.js'), 'utf8');
assert.match(service, /meta\.scope !== 'USER' \|\| meta\.editable === false/);
assert.match(service, /entry\.messageType === 'callback_alert'/);
assert.match(service, /resolveMaxLength/);
assert.match(service, /Metadata template tidak valid/);
assert.match(service, /getTemplateReference/);
assert.match(service, /activeContent/);
assert.match(service, /escapeReferencePlaceholderTokens/);
assert.doesNotMatch(service, /\beval\s*\(/);
assert.doesNotMatch(service, /new\s+Function\s*\(/);
assert.doesNotMatch(service, /dynamic\s+require/i);

const customHandler = fs.readFileSync(path.join(src, 'handlers', 'admin', 'customSubmenu.handler.js'), 'utf8');
assert.doesNotMatch(customHandler, /Template Reference/);
assert.doesNotMatch(customHandler, /sendTemplateReference/);
assert.match(customHandler, /sendActiveTemplateContent/);

const placeholders = fs.readFileSync(path.join(src, 'utils', 'placeholders.js'), 'utf8');
const baseMatch = placeholders.match(/const BASE_PLACEHOLDERS = new Set\(\[([^\]]+)\]\)/s);
assert(baseMatch, 'BASE_PLACEHOLDERS registry missing');
const base = new Set([...baseMatch[1].matchAll(/['"]([A-Za-z0-9_]+)['"]/g)].map((x) => x[1]));
const allTokens = new Set();
function extractCallArgs(text, openIndex) {
  let depth = 1;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = openIndex + 1; i < text.length; i += 1) {
    const ch = text[i];
    const next = text[i + 1];
    if (lineComment) { if (ch === '\n') lineComment = false; continue; }
    if (blockComment) { if (ch === '*' && next === '/') { blockComment = false; i += 1; } continue; }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (ch === '\\') { escaped = true; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '/' && next === '/') { lineComment = true; i += 1; continue; }
    if (ch === '/' && next === '*') { blockComment = true; i += 1; continue; }
    if (ch === '\'' || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === '(') depth += 1;
    else if (ch === ')') { depth -= 1; if (depth === 0) return text.slice(openIndex + 1, i); }
  }
  throw new Error('unclosed defineTemplate/defineSubmenu call');
}
for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  const re = /define(?:Template|Submenu)\s*\(/g;
  let m;
  while ((m = re.exec(text))) {
    const args = extractCallArgs(text, m.index + m[0].length - 1);
    for (const token of args.matchAll(/(?<!\$)\{([A-Za-z0-9_]+)\}/g)) allTokens.add(token[1]);
  }
}
const unknownTokens = [...allTokens].filter((t) => !base.has(t));
assert.deepEqual(unknownTokens, [], `unknown placeholder tokens in template definitions: ${unknownTokens.join(', ')}`);

const required = [
  'store', 'guide', 'features', 'join_gate', 'token',
  'userbot.activation_phone_purchase', 'userbot.activation_otp_prompt',
  'userbot.activation_2fa_prompt', 'userbot_activation_success',
  'trial_policy', 'trial_terms', 'trial_activated',
  'userbot_expired_notice', 'userbot.session_invalid',
  'control_panel_main', 'control_panel_base_reply', 'control_panel_message',
  'control_panel_group', 'control_panel_delay', 'control_panel_extra',
  'panel.feature_locked', 'panel.transfer_received', 'panel.input.transfer',
  'store.order_summary', 'store.payment_instruction', 'store.payment_proof_prompt',
  'store.payment_proof_step_caption', 'store.payment_policy',
  'token.check_valid', 'token.check_invalid', 'token.backup_status',
  'system.safe_error',
];
for (const id of required) assert(seen.has(id), `required customization entry missing: ${id}`);
assert.match(fs.readFileSync(path.join(src, 'services', 'mainMenu.service.js'), 'utf8'), /MAIN_SUBMENU_ID\s*=\s*['"]start['"]/);

for (const file of publicFiles) {
  const text = fs.readFileSync(file, 'utf8');
  if (text.includes('Log Channel Transaksi') || text.includes('dikirim ke Log Transaksi')) {
    throw new Error(`public/internal transaction channel leakage remains in ${path.relative(root, file)}`);
  }
}

const engineNames = publicFiles
  .map((f) => fs.readFileSync(f, 'utf8'))
  .join('\n');
assert.doesNotMatch(engineNames, /class\s+Custom(?:Message|Response|Template|Submenu)Service/);
assert.doesNotMatch(engineNames, /function\s+render(?:CustomMessage|CustomResponse|SecondTemplate)/);

console.log(`CUSTOMIZATION_STATIC_CONTRACT_OK entries=${defs.length} placeholders=${base.size}`);
