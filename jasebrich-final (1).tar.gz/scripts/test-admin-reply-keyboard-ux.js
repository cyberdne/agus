'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const keyboard = read('src/keyboards/admin.keyboard.js');
const router = read('src/middlewares/adminReply.middleware.js');
const transaction = read('src/handlers/admin/transaction.handler.js');

// High-level admin navigation is reply-keyboard driven.
for (const label of ['👥 Users', '🤖 Userbot', '🛒 Commerce', '💳 Order & Payment', '📢 Notifications', '📊 Statistics', '⚙️ Settings']) {
  assert.ok(keyboard.includes(`staticReplyButton.primary('${label}'`) || keyboard.includes(`replyButton.primary('${label}'`), `admin root lost reply button: ${label}`);
}

// Detail screens use reply keyboards for normal CRUD actions.
for (const token of ['userDetailKeyboard', 'transactionDetailKeyboard', 'productDetailKeyboard', 'productEditFieldKeyboard', 'poolDetailKeyboard']) {
  const start = keyboard.indexOf(`function ${token}`);
  assert.ok(start >= 0, `missing admin keyboard function ${token}`);
  const end = keyboard.indexOf('\n}', start);
  const block = keyboard.slice(start, end + 2);
  assert.match(block, /Markup\.keyboard\(/, `${token} must use ReplyKeyboard`);
}

// Dynamic reply actions must resolve to existing callback contracts.
for (const token of [
  'Reset Trial User #', 'Lihat Bukti Pembayaran #', 'Approve Order #', 'Reject Order #',
  'Edit Produk #', 'Nonaktifkan Produk #', 'Aktifkan Produk #', 'Arsipkan Produk #',
  'Nama Produk #', 'Deskripsi Produk #', 'Harga Produk #', 'Durasi Produk #',
  'Garansi Produk #', 'Feature Access Produk #', 'Hapus Stok #', 'Refresh Stok #',
]) {
  assert.ok(router.includes(token.replace('#', '')), `admin reply router missing ${token}`);
}
assert.match(router, /PRODUCT_EDIT_FIELD\(Number\(fm\[1\]\), field\)/);
assert.match(router, /POOL_DEL_CONFIRM\(Number\(m\[1\]\)\)/);
assert.match(router, /TRANSACTION_APPROVE\(Number\(m\[1\]\)\)/);

// Back navigation from detail screens is contextual and remains one level up.
assert.match(router, /adminuser:view:\\d\+.*user\.userListCallback/s);
assert.match(router, /admin_transactions_detail:\\d\+.*transaction\.transactionHomeCallback/s);
assert.match(router, /adminproduct:view:\\d\+.*product\.productListCallback/s);
assert.match(router, /adminpool:view:\\d\+.*pool\.poolHomeCallback/s);

// Transaction detail rendering now owns a distinct feature identity so a
// generic reply-keyboard Kembali can return to the transaction list.
assert.match(transaction, /admin_transactions_detail:\$\{id\}/);

console.log('ADMIN_REPLY_KEYBOARD_UX_CONTRACT_OK root=reply detail=reply dynamic_routes=1 contextual_back=1');
