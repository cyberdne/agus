const assert = require('assert');
const fs = require('fs');

const runtime = fs.readFileSync('src/handlers/panel.handler.js', 'utf8');
const panelConfig = fs.readFileSync('src/services/panelConfig.service.js', 'utf8');
const poolConfig = fs.readFileSync('src/services/poolPanelConfig.service.js', 'utf8');
const keyboard = fs.readFileSync('src/keyboards/panelControl.keyboard.js', 'utf8');
const menu = fs.readFileSync('src/constants/menu.js', 'utf8');
const index = fs.readFileSync('src/index.js', 'utf8');

assert.match(runtime, /GROUP_LIST_PAGE_SIZE = 10/);
assert.match(runtime, /GROUP_LIST_TITLE_MAX = 120/);
assert.match(runtime, /countGroups\(s\.asset\.id\)/);
assert.match(runtime, /listGroupsPage\(s\.asset\.id, safePage \* GROUP_LIST_PAGE_SIZE, GROUP_LIST_PAGE_SIZE\)/);
assert.match(runtime, /groupListPaginationKeyboard/);
assert.match(runtime, /Number\(current\.id\) !== userbotId/);
assert.match(runtime, /groupListRefreshCallback/);
assert.match(runtime, /groupListBackCallback/);
assert.doesNotMatch(runtime, /const list=rows\.map\(g=>.*\.join\('\\n'\)/);

assert.match(panelConfig, /function countGroups\(userbotId\)/);
assert.match(panelConfig, /SELECT COUNT\(\*\) AS count FROM panel_groups/);
assert.match(panelConfig, /function listGroupsPage\(userbotId, offset, limit\)/);
assert.match(panelConfig, /LIMIT \? OFFSET \?/);
assert.match(panelConfig, /countGroups, listGroupsPage/);

assert.match(poolConfig, /function countGroups\(id\)/);
assert.match(poolConfig, /function listGroupsPage\(id, offset, limit\)/);
assert.match(poolConfig, /countGroups, listGroupsPage/);

assert.match(keyboard, /function groupListPaginationKeyboard\(userbotId, page, totalPages\)/);
assert.match(keyboard, /PANEL_GROUP_LIST_PAGE\(userbotId/);
assert.match(keyboard, /PANEL_GROUP_LIST_REFRESH\(userbotId/);
assert.match(keyboard, /PANEL_GROUP_LIST_BACK/);
assert.match(keyboard, /groupListPaginationKeyboard,/);

assert.match(menu, /PANEL_GROUP_LIST_PAGE:/);
assert.match(menu, /PANEL_GROUP_LIST_REFRESH:/);
assert.match(menu, /PANEL_GROUP_LIST_BACK:/);
assert.match(index, /panelgrp:list:\\d\+:\\d\+/);
assert.match(index, /panelgrp:listrefresh:\\d\+:\\d\+/);
assert.match(index, /panelgrp:listback/);

// Worst-case bounded display calculation for the production page contract:
// 10 rows x 120-char title + row metadata remains far below Telegram's 4096
// message limit, before the small fixed template/header overhead.
const rowWorstCase = 1 + 10 + 1 + 120 + 20;
assert.ok(rowWorstCase * 10 < 4096, 'bounded page contract must stay well below Telegram message limit');

console.log('PASS: group list pagination contract, bounded SQL reads, callback isolation, and message-size guardrails');
