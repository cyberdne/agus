'use strict';
const assert = require('assert');
const ub = require('../src/services/ubotNotify.policy');
const card = require('../src/services/notifyCard.service');
const health = require('../src/services/systemHealth.policy');

let passed = 0;
function t(name, fn) {
  try { fn(); passed += 1; console.log(`  ok - ${name}`); }
  catch (err) { console.error(`  FAIL - ${name}`); throw err; }
}
const MIN = 60 * 1000; const HOUR = 60 * MIN;
const NOW = Date.parse('2026-10-09T12:00:00Z');

// --- Userbot log policy ---
t("defaults: bot + fail + flood on, saved/owner/success off", () => {
  const s = ub.normalizeSettings(null);
  assert.deepStrictEqual(ub.activeChannels(s), ["channel_bot"]);
  assert.strictEqual(s.on_fail, true); assert.strictEqual(s.on_flood, true); assert.strictEqual(s.on_success, false);
});
t("owner channel is the userbot buyer, not an admin channel", () => {
  assert.ok(ub.CHANNELS.includes("channel_owner"));
  assert.ok(!ub.CHANNELS.includes("channel_admin"));
});
t("cannot switch off the last active channel", () => {
  const s = ub.normalizeSettings(null);
  const r = ub.toggleSettings(s, "channel_bot");
  assert.strictEqual(r.error, "Minimal satu kanal notifikasi harus aktif.");
  assert.strictEqual(r.settings.channel_bot, true);
  const two = ub.toggleSettings(s, "channel_saved");
  assert.deepStrictEqual(ub.activeChannels(two.settings), ["channel_bot", "channel_saved"]);
});
t("short reasons: permission, anchored, slowmode, unknown target, fallback", () => {
  assert.strictEqual(ub.shortReason(new Error("CHAT_WRITE_FORBIDDEN")), "tidak punya izin kirim");
  assert.strictEqual(ub.shortReason(new Error("USER_BANNED_IN_CHANNEL")), "tidak punya izin kirim");
  assert.strictEqual(ub.shortReason(new Error("SLOWMODE_WAIT_30")), "slowmode aktif");
  assert.strictEqual(ub.shortReason(new Error("Could not find the input entity")), "target tidak ditemukan");
  assert.strictEqual(ub.shortReason(new Error("")), "alasan tidak diketahui");
  assert.strictEqual(ub.shortReason(new Error("weird   thing\nhappened")), "weird thing happened");
});
t("fillTemplate replaces known placeholders and keeps unknown ones", () => {
  assert.strictEqual(ub.fillTemplate("Gagal kirim ke {target} ({reason})", { target: "@lpm/grup", reason: "slowmode aktif" }),
    "Gagal kirim ke @lpm/grup (slowmode aktif)");
  assert.strictEqual(ub.fillTemplate("Halo {nama}", { target: "x" }), "Halo {nama}");
});
t("default success line matches the agreed format exactly", () => {
  assert.strictEqual(ub.fillTemplate("Sukses kirim ke {target} ✅", { target: "@lpm/target" }), "Sukses kirim ke @lpm/target ✅");
});
t("entries are newest first and capped", () => {
  let e = [];
  for (let i = 0; i < 250; i++) e = ub.appendEntry(e, { type: "success", target: "t" + i, at: i });
  assert.strictEqual(e.length, 200);
  assert.strictEqual(e[0].target, "t249");
});
t("visible lines respect event toggles, oldest first, capped at 20", () => {
  const all = [];
  for (let i = 0; i < 30; i++) all.push({ type: i % 2 ? "failed" : "success", target: "g" + i, reason: "x" });
  const onlyFail = ub.visibleLines(all, { on_success: false, on_fail: true, on_flood: false });
  assert.ok(onlyFail.every((e) => e.type === "failed"));
  assert.strictEqual(onlyFail.length, 15);
  const withSuccess = ub.visibleLines(all, { on_success: true, on_fail: true, on_flood: false });
  assert.strictEqual(withSuccess.length, 20);
  assert.strictEqual(withSuccess[withSuccess.length - 1].target, "g0");
});
t("card is plain text: targets with underscores and @ stay intact", () => {
  const text = ub.formatCard({ label: "Promo_A", id: 7, lines: ["Sukses kirim ke @lpm_grup/target ✅"] });
  assert.ok(text.includes("@lpm_grup/target")); assert.ok(text.includes("Promo_A"));
  assert.ok(ub.formatCard({ label: "A", id: 1, lines: [] }).includes("Belum ada log pengiriman."));
});

// --- Edit-in-place classification (anti-spam core) ---
t('"message is not modified" is treated as success, not failure', () => {
  assert.ok(card.isNotModified({ description: 'Bad Request: message is not modified: specified new message content' }));
  assert.ok(!card.isGone({ description: 'Bad Request: message is not modified' }));
});
t('deleted card is recognised so exactly one replacement is created', () => {
  assert.ok(card.isGone({ description: 'Bad Request: message to edit not found' }));
  assert.ok(card.isGone(new Error("Bad Request: message can't be edited")));
  assert.ok(!card.isGone(new Error('429 Too Many Requests: retry after 20')));
});
t('content hash is stable and changes with content', () => {
  assert.strictEqual(card.hashText('a'), card.hashText('a'));
  assert.notStrictEqual(card.hashText('a'), card.hashText('b'));
});

// --- Health checks ---
const healthy = (over = {}) => ({
  nowMs: NOW,
  scheduler: { running: true, intervalSeconds: 300, lastTickCompletedAt: new Date(NOW - 60 * 1000).toISOString(), lastTickError: null },
  db: { ok: true }, disk: { freeRatio: 0.5 },
  reminder: { lastRun: { status: 'ok' } },
  backup: { enabled: true, lastRunAt: new Date(NOW - HOUR).toISOString().slice(0, 19).replace('T', ' '), lastStatus: 'ok', intervalHours: 24 },
  ubot: { success: 40, failed: 2 },
  ...over,
});
t('healthy system: every check ok, overall ok', () => {
  const checks = health.evaluateChecks(healthy());
  assert.strictEqual(health.overallStatus(checks), 'ok');
});
t('scheduler stopped or stale is critical', () => {
  const stopped = health.evaluateChecks(healthy({ scheduler: { running: false, intervalSeconds: 300 } }));
  assert.strictEqual(health.overallStatus(stopped), 'critical');
  const stale = health.evaluateChecks(healthy({ scheduler: { running: true, intervalSeconds: 300, lastTickCompletedAt: new Date(NOW - 20 * MIN).toISOString() } }));
  assert.strictEqual(stale.find((c) => c.id === 'scheduler').status, 'critical');
});
t('no false alarm during the very first tick (no completed timestamp yet)', () => {
  const first = health.evaluateChecks(healthy({ scheduler: { running: true, intervalSeconds: 300, lastTickCompletedAt: null, lastTickStartedAt: new Date(NOW - 5000).toISOString() } }));
  assert.strictEqual(first.find((c) => c.id === 'scheduler').status, 'ok');
});
t('disk thresholds: <10% warn, <5% critical', () => {
  assert.strictEqual(health.evaluateChecks(healthy({ disk: { freeRatio: 0.08 } })).find((c) => c.id === 'disk').status, 'warn');
  assert.strictEqual(health.evaluateChecks(healthy({ disk: { freeRatio: 0.03 } })).find((c) => c.id === 'disk').status, 'critical');
});
t('failed reminder cycle and failed backup are warnings', () => {
  const checks = health.evaluateChecks(healthy({ reminder: { lastRun: { status: 'error', error: 'boom' } }, backup: { enabled: true, lastRunAt: 'x', lastStatus: 'error', intervalHours: 24 } }));
  assert.strictEqual(checks.find((c) => c.id === 'reminder').status, 'warn');
  assert.strictEqual(checks.find((c) => c.id === 'backup').status, 'warn');
});
t('overdue backup (beyond 2x interval) is a warning', () => {
  const old = new Date(NOW - 60 * HOUR).toISOString().slice(0, 19).replace('T', ' ');
  const checks = health.evaluateChecks(healthy({ backup: { enabled: true, lastRunAt: old, lastStatus: 'ok', intervalHours: 24 } }));
  assert.strictEqual(checks.find((c) => c.id === 'backup').status, 'warn');
});
t('high userbot failure rate warns, small samples do not', () => {
  assert.strictEqual(health.evaluateChecks(healthy({ ubot: { success: 2, failed: 9 } })).find((c) => c.id === 'ubot').status, 'warn');
  assert.strictEqual(health.evaluateChecks(healthy({ ubot: { success: 0, failed: 3 } })).find((c) => c.id === 'ubot').status, 'ok');
});

// --- Anti-spam card policy ---
t('stable healthy system produces zero card actions for a whole day', () => {
  const sig = health.signatureOf(health.evaluateChecks(healthy()));
  let last = NOW; let actions = [];
  for (let m = 0; m < 24 * 60; m += 5) {
    const a = health.decideCardAction({ prevSignature: sig, nextSignature: sig, lastEditMs: last, nowMs: NOW + m * MIN, heartbeatMs: 6 * HOUR, overall: 'ok' });
    if (a !== 'none') actions.push(a);
  }
  assert.deepStrictEqual(actions, []);
});
t('an open problem gets one heartbeat edit per heartbeat interval, not one per tick', () => {
  const sig = 'x';
  let lastEdit = NOW; const edits = [];
  for (let m = 0; m <= 24 * 60; m += 5) {
    const now = NOW + m * MIN;
    const a = health.decideCardAction({ prevSignature: sig, nextSignature: sig, lastEditMs: lastEdit, nowMs: now, heartbeatMs: 6 * HOUR, overall: 'warn' });
    if (a !== 'none') { edits.push(m); lastEdit = now; }
  }
  assert.strictEqual(edits.length, 4); // 24h / 6h
});
t('a status change edits the card once; first run creates it', () => {
  assert.strictEqual(health.decideCardAction({ prevSignature: null, nextSignature: 'a', lastEditMs: NaN, nowMs: NOW, heartbeatMs: HOUR, overall: 'ok' }), 'create');
  assert.strictEqual(health.decideCardAction({ prevSignature: 'a', nextSignature: 'b', lastEditMs: NOW, nowMs: NOW + 1, heartbeatMs: HOUR, overall: 'warn' }), 'edit');
});
t('health card renders statuses and escapes detail text', () => {
  const checks = [{ id: 'x', label: 'Disk', status: 'critical', detail: '<img>' }];
  const text = health.formatCard({ checks, overall: 'critical', incidentStartedAt: '2026-10-09T11:00:00.000Z', nowLabel: '12:00' });
  assert.ok(text.includes('🔴 Disk')); assert.ok(text.includes('&lt;img&gt;')); assert.ok(text.includes('Masalah sejak'));
});

console.log(`test-notify-health-policy: ${passed} passed`);
