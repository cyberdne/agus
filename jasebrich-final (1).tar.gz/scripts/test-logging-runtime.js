'use strict';
const assert = require('node:assert/strict');

// Exercise the real logger implementation without external dependencies.
process.env.LOG_LEVEL = 'warn';
const logger = require('../src/utils/logger');

const originalLog = console.log;
const originalWarn = console.warn;
const originalError = console.error;
const lines = [];
console.log = (...args) => lines.push(['log', ...args]);
console.warn = (...args) => lines.push(['warn', ...args]);
console.error = (...args) => lines.push(['error', ...args]);

try {
  logger.debug('routine navigation');
  logger.info('routine menu');
  logger.warn('otp=123456 password=secret bot_token=123456789:abcdefghijklmnopqrstuvwxyz');
  logger.error(new Error('api_key=secret session_string=very-secret-token'));
} finally {
  console.log = originalLog;
  console.warn = originalWarn;
  console.error = originalError;
}

assert.equal(lines.length, 2, 'warn/error should be visible while debug/info are suppressed');
const serialized = JSON.stringify(lines);
assert.match(serialized, /\[REDACTED\]/);
assert.doesNotMatch(serialized, /123456789:abcdefghijklmnopqrstuvwxyz/);
assert.doesNotMatch(serialized, /password=secret/);
assert.doesNotMatch(serialized, /api_key=secret/);
assert.doesNotMatch(serialized, /session_string=very-secret-token/);

console.log('LOGGER_RUNTIME_OK level=warn debug_info_suppressed=1 sensitive_redacted=1');
