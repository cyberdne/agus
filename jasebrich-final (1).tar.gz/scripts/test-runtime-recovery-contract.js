'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const schema = read('src/database/schema.js');
const dbIndex = read('src/database/index.js');
const repo = read('src/database/repositories/userbotRuntimeJob.repository.js');
const runtime = read('src/services/userbotRuntime.service.js');
const index = read('src/index.js');

assert.match(schema, /CREATE TABLE IF NOT EXISTS userbot_runtime_jobs/);
assert.match(schema, /owner_kind TEXT NOT NULL CHECK \(owner_kind IN \('owned', 'pool'\)\)/);
assert.match(schema, /job_type TEXT NOT NULL CHECK \(job_type IN \('auto_promosi'\)\)/);
assert.match(schema, /cycle_id TEXT/);
assert.match(schema, /cursor_key TEXT/);
assert.match(schema, /workset_hash TEXT/);
assert.match(schema, /next_run_at TEXT/);
assert.match(dbIndex, /userbot_runtime_jobs/);
assert.match(repo, /atomic|UPDATE userbot_runtime_jobs/);
assert.match(repo, /function checkpoint\(/);
assert.match(repo, /cycle_id = \?/);
assert.match(repo, /function complete\(/);
assert.match(repo, /function markFailed\(/);
assert.match(repo, /function cancel\(/);
assert.match(runtime, /promotionWorksetHash/);
assert.match(runtime, /resolvePromotionResumeIndex/);
assert.match(runtime, /runtimeJobRepo\.ensureRecoverableCycle/);
assert.match(runtime, /runtimeJobRepo\.checkpoint/);
assert.match(runtime, /runtimeJobRepo\.complete/);
assert.match(runtime, /promotionResumeDelay/);
assert.match(runtime, /runtimeJobRepo\.find\(record\.kind, record\.id\)/);
assert.match(runtime, /bootstrapAll\(\)/);
assert.doesNotMatch(runtime, /let currentPage\s*=/);
assert.match(index, /await userbotRuntime\.bootstrapAll\(\)/);
assert.doesNotMatch(index, /JASEB_RUNTIME_CHILD/);
assert.match(index, /reclaimStaleProcessingOrders\(\)/);

console.log('PASS: durable auto-resume, checkpoint, ownership isolation, and startup recovery contracts');
