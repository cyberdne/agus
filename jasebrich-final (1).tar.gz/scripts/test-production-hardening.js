'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const index = read('src/index.js');
const adminKeyboard = read('src/keyboards/admin.keyboard.js');
const adminReply = read('src/middlewares/adminReply.middleware.js');
const adminFlow = read('src/middlewares/adminFlow.middleware.js');
const callbacks = read('src/constants/admin.callback.js');
const inputFlows = read('src/constants/adminInputFlows.js');
const ubotFlow = read('src/handlers/ubotFlow.handler.js');
const userbotService = read('src/services/userbot.service.js');
const ownedRepo = read('src/database/repositories/ownedUserbot.repository.js');
const pingHandler = read('src/handlers/ping.handler.js');
const databaseIndex = read('src/database/index.js');
const pkg = JSON.parse(read('package.json'));

for (const [name, value] of [
  ['admin keyboard', adminKeyboard],
  ['admin reply middleware', adminReply],
  ['admin flow middleware', adminFlow],
  ['admin callbacks', callbacks],
  ['admin input flows', inputFlows],
  ['index', index],
]) {
  assert.doesNotMatch(value, /\bSYSTEM_UPDATE_HOME\b|\bSYSTEM_UPDATE_UPLOAD\b|admin_system_update_upload|system_update:/i, `${name} must not retain removed System Update wiring`);
  assert.doesNotMatch(value, /⬆️ Update Sistem|Batal Update/i, `${name} must not retain removed System Update UI`);
}
assert.equal(fs.existsSync(path.join(root, 'src/services/systemUpdate.service.js')), false, 'systemUpdate service must be removed');
assert.equal(fs.existsSync(path.join(root, 'src/handlers/admin/systemUpdate.handler.js')), false, 'systemUpdate handler must be removed');
assert.equal(fs.existsSync(path.join(root, 'scripts/test-system-update-contract.js')), false, 'obsolete system update test must be removed');
assert.doesNotMatch(index, /Unhandled promise rejection.*proses tetap berjalan/, 'unhandled rejection must not keep a potentially unhealthy process alive');
assert.match(index, /shutdownAfterFatal\(/, 'fatal errors must enter the graceful fatal shutdown path');
assert.match(index, /process\.exit\(1\)/, 'fatal errors must exit non-zero without self-restart');
assert.match(ubotFlow, /userbotService\.updateOwnedUserbotPhone\(/, 'handler must use service/repository boundary for phone persistence');
assert.match(userbotService, /function updateOwnedUserbotPhone\(/, 'userbot service must own phone persistence use case');
assert.match(ownedRepo, /function updatePhone\(/, 'owned repository must own phone persistence');
assert.doesNotMatch(ubotFlow, /getDb\(\)\.prepare\(/, 'ubot flow must not directly access SQLite');
assert.match(databaseIndex, /function checkHealth\(\)/, 'database health probe must be owned by database module');
assert.match(pingHandler, /checkHealth\(\)/, 'ping handler must use database health boundary');
assert.doesNotMatch(pingHandler, /getDb\(\)\.prepare\(/, 'ping handler must not directly access SQLite');

const middlewareOrder = {
  flood: index.indexOf('bot.use(floodGuardMiddleware());'),
  gate: index.indexOf('bot.use(joinGateMiddleware());'),
  start: index.indexOf('bot.start(startHandler);'),
};
assert.ok(middlewareOrder.flood >= 0 && middlewareOrder.gate > middlewareOrder.flood && middlewareOrder.start > middlewareOrder.gate, 'join gate must be registered before every command entry point');
assert.doesNotMatch(read('src/handlers/start.handler.js'), /joinGateService\.ensureAccess\(ctx\)/, 'start handler must not duplicate the global join gate membership check');

// Production archive should retain .env by explicit user requirement, but it
// must never treat runtime DB/session state as source code. This contract is
// checked by the packaging script rather than deleting those files in-place.
assert.equal(pkg.engines && pkg.engines.node, '>=22.23.3');
assert.equal(pkg.scripts.start, 'node src/index.js');

const joinGate = read('src/services/joinGate.service.js');
const runtime = read('src/services/userbotRuntime.service.js');
const owned = read('src/database/repositories/ownedUserbot.repository.js');
const pool = read('src/database/repositories/userbotPool.repository.js');
const productRepo = read('src/database/repositories/product.repository.js');
const featureAccess = read('src/services/featureAccess.service.js');
const broadcastRepo = read('src/database/repositories/broadcast.repository.js');
const broadcastSvc = read('src/services/broadcast.service.js');
const panelHandler = read('src/handlers/panel.handler.js');
const panelConfig = read('src/services/panelConfig.service.js');
const userService = read('src/services/user.service.js');

assert.match(databaseIndex, /busy_timeout = 5000/);
assert.match(owned, /owner_is_banned/);
assert.match(pool, /owner_is_banned/);
assert.match(runtime, /OWNER_BANNED/);
assert.match(userService, /async function banUser\(/);
assert.match(userService, /Promise\.allSettled\(teardown\.map/);
assert.match(joinGate, /User baru tetap DITOLAK sampai konfigurasi\/akses bot ke channel diperbaiki/);
assert.match(joinGate, /if \(result\.systemError\)/);
assert.match(joinGate, /await alertAdminsGateBroken[\s\S]*return false;/);
assert.match(productRepo, /SET is_active = 0/);
assert.match(featureAccess, /entitlement_unresolved/);
assert.match(broadcastRepo, /target_max_user_id/);
assert.match(broadcastRepo, /attempts < \?/);
assert.match(broadcastSvc, /listBroadcastRecipientSnapshotPage\(afterId, PAGE_SIZE, job\.target_max_user_id\)/);
assert.match(panelHandler, /MAX_PANEL_MEDIA_BYTES = 20 \* 1024 \* 1024/);
assert.match(panelHandler, /Readable\.fromWeb/);
assert.match(panelConfig, /cleanupOrphanMedia/);

console.log('PASS production-hardening contracts (system update removed, fatal shutdown hardened, repository boundary restored)');
