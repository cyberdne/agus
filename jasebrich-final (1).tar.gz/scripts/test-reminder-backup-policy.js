'use strict';
const assert = require('assert');
const reminder = require('../src/services/subscriptionReminder.policy');
const backup = require('../src/services/autoBackup.policy');

let passed = 0;
function t(name, fn) {
  try { fn(); passed += 1; console.log(`  ok - ${name}`); }
  catch (err) { console.error(`  FAIL - ${name}`); throw err; }
}
const MIN = 60000; const HOUR = 3600000; const DAY = 24 * HOUR;

// --- Reminder policy ---
t('permanent error: blocked / 403 / chat not found', () => {
  assert.strictEqual(reminder.classifyReminderDeliveryError({ response: { error_code: 403 } }), 'permanent');
  assert.strictEqual(reminder.classifyReminderDeliveryError({ message: 'Forbidden: bot was blocked by the user' }), 'permanent');
  assert.strictEqual(reminder.classifyReminderDeliveryError({ message: 'Bad Request: chat not found' }), 'permanent');
});
t('temporary error: flood, timeout, 5xx', () => {
  assert.strictEqual(reminder.classifyReminderDeliveryError({ response: { error_code: 429 }, message: 'Too Many Requests: retry after 5' }), 'temporary');
  assert.strictEqual(reminder.classifyReminderDeliveryError({ message: 'ETIMEDOUT' }), 'temporary');
  assert.strictEqual(reminder.classifyReminderDeliveryError({ response: { error_code: 400 }, message: 'Bad Request: temporary failure, retry' }), 'temporary');
});
t('threshold: picks the most imminent crossed threshold', () => {
  const th = [10080, 4320, 1440];
  assert.strictEqual(reminder.chooseCurrentThreshold(2000 * MIN, th), 4320);
  assert.strictEqual(reminder.chooseCurrentThreshold(30 * MIN, th), 1440);
});
t('threshold: nothing crossed returns the largest; empty returns null', () => {
  assert.strictEqual(reminder.chooseCurrentThreshold(20000 * MIN, [10080, 4320, 1440]), 10080);
  assert.strictEqual(reminder.chooseCurrentThreshold(MIN, []), null);
  assert.strictEqual(reminder.chooseCurrentThreshold(MIN, null), null);
});
t('sweep totals combine automatic and expiry cycles', () => {
  const total = reminder.summarizeSweep({ sent: 2, skipped: 1, failed: 0, attempted: 2 }, { sent: 1, skipped: 0, failed: 3, attempted: 4 });
  assert.deepStrictEqual(total, { sent: 3, skipped: 1, failed: 3, attempted: 6 });
  assert.deepStrictEqual(reminder.summarizeSweep(null, undefined), { sent: 0, skipped: 0, failed: 0, attempted: 0 });
});
t('run status: error beats partial beats ok', () => {
  assert.strictEqual(reminder.classifyRunStatus({ error: 'x', failed: 9 }), 'error');
  assert.strictEqual(reminder.classifyRunStatus({ error: null, failed: 2 }), 'partial');
  assert.strictEqual(reminder.classifyRunStatus({ error: null, failed: 0 }), 'ok');
});

// --- Backup policy ---
t('interval and retention are clamped to safe values', () => {
  assert.strictEqual(backup.normalizeInterval(0), 24);
  assert.strictEqual(backup.normalizeInterval('12'), 12);
  assert.strictEqual(backup.normalizeInterval(500), 24);
  assert.strictEqual(backup.normalizeRetention(0), 7);
  assert.strictEqual(backup.normalizeRetention(61), 7);
  assert.strictEqual(backup.normalizeRetention(14), 14);
});
t('preset cycling wraps around', () => {
  assert.strictEqual(backup.nextIntervalOption(24), 48);
  assert.strictEqual(backup.nextIntervalOption(168), 6);
  assert.strictEqual(backup.nextIntervalOption(7), 6);
  assert.strictEqual(backup.nextRetentionOption(30), 3);
});
t('due: disabled never due; never-run is due; interval respected', () => {
  const now = Date.parse('2026-10-09T12:00:00Z');
  const ts = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');
  assert.strictEqual(backup.isBackupDue({ enabled: 0, interval_hours: 24, last_run_at: null }, now), false);
  assert.strictEqual(backup.isBackupDue({ enabled: 1, interval_hours: 24, last_run_at: null }, now), true);
  assert.strictEqual(backup.isBackupDue({ enabled: 1, interval_hours: 24, last_run_at: ts(now - HOUR) }, now), false);
  assert.strictEqual(backup.isBackupDue({ enabled: 1, interval_hours: 24, last_run_at: ts(now - 25 * HOUR) }, now), true);
  assert.strictEqual(backup.isBackupDue({ enabled: 1, interval_hours: 6, last_run_at: ts(now - 7 * HOUR) }, now), true);
});
t('file naming: round-trips and rejects foreign or temp files', () => {
  const name = backup.buildBackupFileName(Date.parse('2026-10-09T12:00:00.123Z'));
  assert.ok(backup.isBackupFileName(name));
  assert.ok(!backup.isBackupFileName(`${name}.tmp`));
  assert.ok(!backup.isBackupFileName('jaseb.db'));
  assert.ok(!backup.isBackupFileName('jaseb-auto-x.txt'));
});
t('retention keeps the newest N and never touches foreign files', () => {
  const entries = [
    { name: 'jaseb-auto-a.db', mtimeMs: 100 },
    { name: 'jaseb-auto-b.db', mtimeMs: 400 },
    { name: 'jaseb-auto-c.db', mtimeMs: 300 },
    { name: 'jaseb-auto-d.db', mtimeMs: 200 },
    { name: 'jaseb.db', mtimeMs: 1 },
    { name: 'user-notes.txt', mtimeMs: 0 },
  ];
  const doomed = backup.selectPrunable(entries, 2).map((e) => e.name).sort();
  assert.deepStrictEqual(doomed, ['jaseb-auto-a.db', 'jaseb-auto-d.db']);
});
t('telegram size limit: non-empty and under ~49 MB only', () => {
  assert.ok(backup.canSendToTelegram(10 * 1024 * 1024));
  assert.ok(!backup.canSendToTelegram(60 * 1024 * 1024));
  assert.ok(!backup.canSendToTelegram(0));
});

console.log(`test-reminder-backup-policy: ${passed} passed`);
