'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const panel = read('src/handlers/panel.handler.js');
const runtime = read('src/services/userbotRuntime.service.js');
const placeholders = read('src/utils/placeholders.js');
const mainKeyboard = read('src/keyboards/panelControl.keyboard.js');

function assert(ok, message) {
  if (!ok) throw new Error(message);
}

// START/STOP must be a real ReplyKeyboard toggle. The status screen itself
// must not emit an inline action keyboard.
assert(/const promotionRunningKeyboard\s*=\s*\(kind,\s*id\)\s*=>\s*Markup\.inlineKeyboard/.test(panel),
  'promotionRunningKeyboard must be an InlineKeyboard (reply keyboards block message edits)');
assert(panel.includes('await openPromotionStatus(ctx,panelKind(ctx),'),
  'START must render live promotion status with inline Stop');
assert(/if\(!userbotRuntime\.isAutoPromosiActive\(w\.kind,w\.id\)\)[\s\S]*?panelMainKeyboard\(false\)/.test(panel),
  'live watcher must restore normal Control Panel keyboard when promotion stops');
assert(/editMessageText\(w\.uid,w\.messageId,undefined,content\.text,\{\.\.\.buildReplyOptions\(content\),\.\.\.promotionRunningKeyboard\(w\.kind,w\.id\)\}\)/.test(panel),
  'live status refresh must edit the same status message and keep its inline Stop button');
assert(!/const promotionStatusInlineKeyboard\s*=/.test(panel),
  'promotionStatusInlineKeyboard must not be emitted by the live status UI');
assert(/PROMOTION_STATUS_REFRESH_MS\s*=\s*8000/.test(panel),
  'live status refresh interval contract changed unexpectedly');

// Runtime status must expose actionable phase/wait information from live UI
// state, not guessed/fake values.
for (const token of [
  'phase: phase ||',
  'currentTarget: currentTarget ||',
  'waitReason: waitReason ||',
  'waitRemainingSeconds,',
  'promotionUi',
  'JEDA ANTAR GRUP',
  'JEDA PUTARAN',
  'MENUNGGU TELEGRAM',
]) {
  assert(runtime.includes(token), `runtime promotion status missing contract token: ${token}`);
}

// Custom Submenu placeholder contract must expose the new runtime fields.
for (const token of ['phase', 'current_target', 'wait_reason', 'wait_remaining']) {
  assert(placeholders.includes(`'${token}'`) || placeholders.includes(`{${token}}`),
    `placeholder registry missing ${token}`);
}
assert(/supportedPlaceholders:\s*\[[^\]]*'phase'[^\]]*'current_target'[^\]]*'wait_reason'[^\]]*'wait_remaining'/.test(panel),
  'Status Promosi custom submenu metadata is missing live wait placeholders');

// Main Control Panel keyboard must be one real toggle, never two states at once.
assert(/active\s*\?\s*replyButton\.danger\(PANEL_FEATURE\.STOP\)\s*:\s*replyButton\.success\(PANEL_FEATURE\.START\)/.test(mainKeyboard),
  'main Control Panel keyboard is not a real Start/Stop toggle');

console.log('USERBOT_LIVE_STATUS_UX_CONTRACT_OK start_to_stop=1 text_only_status=1 stop_to_main=1 wait_placeholders=1 rate_safe_refresh=1');
