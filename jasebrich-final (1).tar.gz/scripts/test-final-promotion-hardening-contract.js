'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const runtime = read('src/services/userbotRuntime.service.js');
const job = read('src/database/repositories/userbotRuntimeJob.repository.js');
const cooldown = read('src/database/repositories/baseReplyCooldown.repository.js');
const schema = read('src/database/schema.js');
const migration = read('src/database/index.js');
const panel = read('src/handlers/panel.handler.js');
const keyboard = read('src/keyboards/panelControl.keyboard.js');
const menu = read('src/constants/menu.js');
const access = read('src/services/featureAccess.service.js');
const placeholders = read('src/utils/placeholders.js');
const panelConfig = read('src/services/panelConfig.service.js');
const poolConfig = read('src/services/poolPanelConfig.service.js');

assert.match(schema, /wtb_auto_reset_minutes INTEGER NOT NULL DEFAULT 3/);
assert.match(schema, /CREATE TABLE IF NOT EXISTS userbot_runtime_jobs/);
for (const field of ['total_targets','processed_targets','successful_targets','failed_targets','blocked_targets','removed_targets','sent_count','failed_count','cycle_number','last_activity_at']) {
  assert.match(schema, new RegExp(`\\b${field}\\b`));
  assert.match(migration, new RegExp(`ALTER TABLE userbot_runtime_jobs ADD COLUMN ${field}`));
}
assert.match(schema, /CREATE TABLE IF NOT EXISTS userbot_promotion_target_health/);
assert.match(schema, /CREATE TABLE IF NOT EXISTS base_reply_cooldowns/);
assert.match(schema, /UNIQUE\(owner_kind, owner_id, chat_id, rule_id\)/);
assert.match(cooldown, /function tryClaim/);
assert.match(cooldown, /function markSent/);
assert.match(cooldown, /function release/);
assert.match(runtime, /const WTB_REPLY_MIN_COOLDOWN_MS = 3 \* 60 \* 1000/);
assert.match(runtime, /baseReplyCooldown\.tryClaim/);
assert.match(runtime, /baseReplyCooldown\.markSent/);
assert.match(runtime, /baseReplyCooldown\.release/);
assert.match(runtime, /const ruleKey=String\(reply\.id != null \? reply\.id : 'default'\)/);
assert.match(runtime, /featureAccessSvc\.checkAssetFeature\(asset, 'auto_promosi', kind\)/);
assert.match(runtime, /featureAccessSvc\.checkAssetFeature\(asset, 'base_reply', kind\)/);
assert.match(runtime, /featureAccessSvc\.checkAssetFeature\(asset, 'pm_permit', kind\)/);
assert.match(runtime, /function isFeatureActive/);
assert.match(runtime, /function promotionErrorClass/);
assert.match(runtime, /FLOOD_WAIT/);
assert.match(runtime, /waitPromotionDelay\(record, waitSeconds \* 1000\)/);
assert.match(runtime, /function resolvePromotionTargetHealth/);
assert.match(runtime, /status:'unusable'/);
assert.match(runtime, /runtimeJobRepo\.recordTargetResult/);
assert.match(runtime, /runtimeJobRepo\.updateActivity/);
assert.match(runtime, /function getPromotionStatus/);
assert.match(runtime, /etaSeconds/);
assert.match(runtime, /sendTypingIndicator/);
assert.match(runtime, /event\.message\.getSender\(\)/);
assert.match(job, /function recordTargetResult/);
assert.match(job, /function updateActivity/);
assert.match(job, /function upsertTargetHealth/);
assert.match(job, /function findTargetHealthByTarget/);
assert.match(panel, /control_panel_promotion_status/);
assert.match(menu, /PROMOTION_STATUS/);
assert.match(panel, /const toggleKey=`\$\{panelKind\(ctx\)\}:\$\{assetId\}`/);
assert.match(panel, /userbotRuntime\.isFeatureActive/);
assert.doesNotMatch(keyboard, /replyButton\.primary\(PANEL_FEATURE\.PROMOTION_STATUS\)/);
assert.match(menu, /PROMOTION_STATUS/);
for (const token of ['status','total_groups','processed_groups','successful_groups','failed_groups','blocked_groups','removed_groups','sent_count','failed_count','current_round','progress','remaining_groups','started_at','last_activity','estimated_completion','remaining_time','interval','runtime_status']) {
  assert.match(placeholders, new RegExp(`['"]${token}['"]`));
}
assert.match(panelConfig, /DEFAULT_WTB_COOLDOWN_MINUTES = 3/);
assert.match(panelConfig, /MAX_WTB_COOLDOWN_MINUTES = 10080/);
assert.match(panelConfig, /Number\.isSafeInteger/);
assert.match(poolConfig, /DEFAULT_WTB_COOLDOWN_MINUTES = 3/);
assert.match(poolConfig, /Number\.isSafeInteger/);
assert.match(access, /auto_promosi/);
assert.match(access, /base_reply/);
assert.match(access, /pm_permit/);

console.log('FINAL_PROMOTION_HARDENING_CONTRACT_OK');
