'use strict';

// Contract: the bot is ONE direct process. No supervisor, no child worker,
// no IPC, no internal auto-restart / self-relaunch.
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const pkg = JSON.parse(read('package.json'));
const index = read('src/index.js');

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name.startsWith('.')) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out); else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}
const srcFiles = walk(path.join(root, 'src'));

// Entry point runs main() directly.
assert.equal(pkg.scripts.start, 'node src/index.js');
assert.equal(pkg.main, 'src/index.js');
assert(/if \(require\.main === module\) \{\s*main\(\);\s*\}/.test(index), 'src/index.js must call main() directly');
assert(!fs.existsSync(path.join(root, 'src', 'supervisor.js')), 'src/supervisor.js must not exist');

for (const file of srcFiles) {
  const rel = path.relative(root, file);
  const code = fs.readFileSync(file, 'utf8');
  assert(!/require\(['"]\.{1,2}\/(?:.*\/)?supervisor['"]\)/.test(code), `${rel} must not require a supervisor`);
  assert(!/JASEB_RUNTIME_CHILD/.test(code), `${rel} must not depend on JASEB_RUNTIME_CHILD`);
  assert(!/process\.send\s*\(/.test(code), `${rel} must not use process.send IPC`);
  assert(!/process\.on\(\s*['"]message['"]/.test(code), `${rel} must not listen for IPC messages`);
  assert(!/spawnWorker|handleWorkerExit|worker-ready|worker-stopped|graceful-stop|scheduleRestart|restartFailures|RESTART_(BASE|MAX)_MS/.test(code), `${rel} must not contain worker/restart machinery`);
  assert(!/process\.execPath\s*,\s*\[\s*(?:entry|process\.argv)/.test(code), `${rel} must not relaunch the bot`);
  assert(!/\bfork\s*\(/.test(code), `${rel} must not fork child processes`);
}

// Fatal uncaught exception exits without self-restart.
assert(/process\.on\('uncaughtException'[\s\S]*?process\.exit\(1\)/.test(index), 'uncaughtException must exit the process');

// Graceful shutdown on signals, then normal exit.
assert(/process\.once\('SIGINT'[\s\S]*?shutdown\('SIGINT'\)[\s\S]*?process\.exit\(0\)/.test(index), 'SIGINT graceful shutdown');
assert(/process\.once\('SIGTERM'[\s\S]*?shutdown\('SIGTERM'\)[\s\S]*?process\.exit\(0\)/.test(index), 'SIGTERM graceful shutdown');
assert(/stopScheduler\(\)/.test(index) && /userbotRuntime\.shutdownAll\(\)/.test(index) && /bot\.stop\(signal\)/.test(index), 'shutdown stops scheduler, userbot runtime and bot');

// Scheduler must never restart the process.
const scheduler = read('src/scheduler.js');
assert(!/process\.exit|child_process|spawn\(/.test(scheduler), 'scheduler must not restart/exit the process');

console.log('PASS no-auto-restart contract (direct single process, no supervisor)');
