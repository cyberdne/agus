'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

// Static execution-path contracts: the old Jaseb hard block must be gone from
// Forward/Base Reply, while unsupported capabilities remain explicit.
const panelText = read('src/middlewares/panelText.middleware.js');
const poolConfigSource = read('src/services/poolPanelConfig.service.js');
const panelHandler = read('src/handlers/panel.handler.js');
const featureAccessSource = read('src/services/featureAccess.service.js');
const schema = read('src/database/schema.js');
const migration = read('src/database/index.js');

assert.doesNotMatch(panelText, /if\s*\(\s*panelKind\s*!==\s*['"]owned['"]\s*\)/);
assert.doesNotMatch(panelText, /Fitur forward pesan promosi belum tersedia untuk konfigurasi stok Jaseb/);
assert.match(panelText, /enforceStepFeature\(ctx, guardedAsset, stateEarly\.step\)/);
assert.match(poolConfigSource, /function setForwardMessage\(id, sourceChatId, sourceMessageId\)/);
assert.match(poolConfigSource, /function addReply\(id, keywords, response, entities = \[\]\)/);
assert.doesNotMatch(poolConfigSource, /function setForwardMessage\(\)\s*\{/);
assert.doesNotMatch(poolConfigSource, /function addReply\(\)\s*\{/);
assert.match(panelHandler, /checkAssetFeature\(sel\.asset, featureId, sel\.kind\)/);
assert.match(featureAccessSource, /resolveProductForPoolAsset/);
assert.match(featureAccessSource, /assigned_order_id/);
assert.match(schema, /broadcast_kind TEXT NOT NULL DEFAULT 'text'/);
assert.match(schema, /broadcast_source_chat_id TEXT/);
assert.match(schema, /broadcast_source_message_id INTEGER/);
assert.match(schema, /wtb_replies TEXT NOT NULL DEFAULT '\[\]'/);
assert.match(migration, /ALTER TABLE userbot_pool ADD COLUMN broadcast_kind TEXT NOT NULL DEFAULT 'text'/);
assert.match(migration, /ALTER TABLE userbot_pool ADD COLUMN wtb_replies TEXT NOT NULL DEFAULT '\[\]'/);

const originalLoad = Module._load;

// ---------------------------------------------------------------------------
// Real poolPanelConfig service logic against a deterministic in-memory pool
// repository. No fake production success is introduced; this only replaces
// the persistence boundary so the service's configure -> save -> load logic
// can be exercised without better-sqlite3 installed in the test container.
// ---------------------------------------------------------------------------
let poolRow = {
  id: 7,
  status: 'assigned',
  assigned_order_id: 77,
  broadcast_text: null,
  broadcast_text_entities: '[]',
  broadcast_kind: 'text',
  broadcast_source_chat_id: null,
  broadcast_source_message_id: null,
  wtb_replies: '[]',
  target: null,
  topic_grup: null,
  delay_seconds: 5,
  delay_max_seconds: null,
  round_delay_seconds: 3600,
  wtb_timer: null,
  wtb_auto_reset_minutes: 1440,
  channel_disabled: 0,
  wtb_target_channel: null,
  wtb_banned_words: '',
  wtb_max_chars: 0,
  wtb_filter_links: 0,
  wtb_filter_usernames: 0,
  auto_react: 0,
  auto_react_emoji: '❤️',
};

const poolRepoStub = {
  findById: () => ({ ...poolRow }),
  updateConfig: (_id, fields) => {
    poolRow = { ...poolRow, ...fields };
    return { ...poolRow };
  },
};

Module._load = function(request, parent, isMain) {
  if (request === '../database/repositories/userbotPool.repository' && parent && parent.filename.endsWith('/services/poolPanelConfig.service.js')) return poolRepoStub;
  if (request === './delayPolicy.service' && parent && parent.filename.endsWith('/services/poolPanelConfig.service.js')) return { DEFAULT_GROUP_DELAY_SECONDS: 10, DEFAULT_ROUND_DELAY_SECONDS: 3600, GROUP_DELAY_MAX_SECONDS: 86400, normalizeGroupDelayRange: (a,b) => ({min:a,max:b}), normalizeRoundDelaySeconds: (v) => Number(v), readGroupDelayRange: (s,d) => ({min:Number(s.group_delay_seconds||d),max:Number(s.group_delay_max_seconds||s.group_delay_seconds||d)}), readRoundDelaySeconds: (s,d) => Number(s.round_delay_seconds||d) };
  if (request === './automationConfig.service' && parent && parent.filename.endsWith('/services/poolPanelConfig.service.js')) return {};
  return originalLoad.call(this, request, parent, isMain);
};

try {
  delete require.cache[require.resolve('../src/services/poolPanelConfig.service')];
  const poolConfig = require('../src/services/poolPanelConfig.service');

  poolConfig.setForwardMessage(7, '-100123', 456);
  let msg = poolConfig.getMessage(7);
  assert.deepEqual(msg, {
    kind: 'forward', text: null, entities: '[]', caption_entities: '[]',
    source_chat_id: '-100123', source_message_id: 456,
  });

  poolConfig.setTextMessage(7, 'Promo', [{ type: 'bold', offset: 0, length: 5 }]);
  msg = poolConfig.getMessage(7);
  assert.equal(msg.kind, 'text');
  assert.equal(msg.text, 'Promo');
  assert.match(msg.entities, /bold/);

  const added = poolConfig.addReply(7, 'harga, WTB', 'Balasan', [{ type: 'custom_emoji', offset: 0, length: 1, custom_emoji_id: '1' }]);
  assert.equal(added.id, 1);
  assert.equal(added.enabled, true);
  assert.equal(poolConfig.listReplies(7).length, 1);
  assert.equal(poolConfig.hasEnabledReply(7), true);
  poolConfig.setReplyEnabled(7, false);
  assert.equal(poolConfig.hasEnabledReply(7), false);
  poolConfig.setReplyEnabled(7, true);
  assert.equal(poolConfig.hasEnabledReply(7), true);
  assert.equal(poolConfig.deleteReply(7, 1), 1);
  assert.equal(poolConfig.listReplies(7).length, 0);
} finally {
  Module._load = originalLoad;
  delete require.cache[require.resolve('../src/services/poolPanelConfig.service')];
}

// ---------------------------------------------------------------------------
// Live pool entitlement resolution: assigned_order_id -> order.product_id ->
// product.feature_access, with no Jaseb/type bypass.
// ---------------------------------------------------------------------------
let product = { id: 5, feature_access: JSON.stringify(['message_settings', 'base_reply']) };
const poolAsset = { id: 7, assigned_order_id: 77 };
const order = { id: 77, product_id: 5 };

Module._load = function(request, parent, isMain) {
  if (request === '../database/repositories/order.repository' && parent && parent.filename.endsWith('/services/featureAccess.service.js')) return { findById: (id) => id === 77 ? order : null };
  if (request === './product.service' && parent && parent.filename.endsWith('/services/featureAccess.service.js')) return { getById: (id) => id === 5 ? product : null };
  if (request === '../database/repositories/settings.repository' && parent && parent.filename.endsWith('/services/featureAccess.service.js')) return { get: () => null, set: () => {} };
  if (request === './subscription.service' && parent && parent.filename.endsWith('/services/featureAccess.service.js')) return { isTrial: () => false };
  if (request === '../database/repositories/userbotPool.repository' && parent && parent.filename.endsWith('/services/featureAccess.service.js')) return { findById: () => ({ ...poolAsset }) };
  return originalLoad.call(this, request, parent, isMain);
};

try {
  delete require.cache[require.resolve('../src/services/featureAccess.service')];
  const featureAccess = require('../src/services/featureAccess.service');
  assert.equal(featureAccess.checkAssetFeature(poolAsset, 'message_settings', 'pool').allowed, true);
  assert.equal(featureAccess.checkAssetFeature(poolAsset, 'base_reply', 'pool').allowed, true);
  assert.equal(featureAccess.checkAssetFeature(poolAsset, 'broadcast_pm', 'pool').allowed, false);

  // Simulate an admin changing the same product checklist after purchase.
  product.feature_access = JSON.stringify(['base_reply']);
  assert.equal(featureAccess.checkAssetFeature(poolAsset, 'message_settings', 'pool').allowed, false);
  assert.equal(featureAccess.checkAssetFeature(poolAsset, 'base_reply', 'pool').allowed, true);
} finally {
  Module._load = originalLoad;
  delete require.cache[require.resolve('../src/services/featureAccess.service')];
}

console.log('PASS pool-package-feature-access forward_persistence=1 base_reply_persistence=1 live_entitlement=1 negative_entitlement=1 hardblock_removed=1');
