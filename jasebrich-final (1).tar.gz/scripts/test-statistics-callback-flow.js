const assert = require('assert');
const {
  STATISTICS_SECTIONS,
  STATISTICS_SECTION_IDS,
  STATISTICS_SECTION_CALLBACK_PATTERN,
  STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN,
  isValidStatisticsSection,
  parseStatisticsSectionCallback,
  parseStatisticsSectionRefreshCallback,
} = require('../src/constants/statistics');
const { ADMIN_CALLBACK } = require('../src/constants/admin.callback');

const expectedSections = ['users', 'userbot', 'stock', 'orders', 'payments', 'subscription', 'promotion', 'system'];
assert.deepStrictEqual(STATISTICS_SECTION_IDS, expectedSections, 'canonical statistics registry changed unexpectedly');
assert.strictEqual(STATISTICS_SECTIONS.length, expectedSections.length, 'statistics labels/IDs registry length mismatch');

for (const section of expectedSections) {
  assert.strictEqual(isValidStatisticsSection(section), true, `${section} should be valid`);

  const open = ADMIN_CALLBACK.STATISTICS_SECTION(section);
  const refresh = ADMIN_CALLBACK.STATISTICS_SECTION_REFRESH(section);

  assert.strictEqual(parseStatisticsSectionCallback(open), section, `open callback failed for ${section}`);
  assert.strictEqual(parseStatisticsSectionRefreshCallback(refresh), section, `refresh callback failed for ${section}`);
  assert.strictEqual(STATISTICS_SECTION_CALLBACK_PATTERN.test(open), true, `open route regex rejected ${section}`);
  assert.strictEqual(STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN.test(refresh), true, `refresh route regex rejected ${section}`);

  // Exact shape checks prevent the old split(':')[4] bug, where "refresh"
  // was accidentally interpreted as the section identifier.
  assert.strictEqual(open.split(':').length, 4, `unexpected open callback segments for ${section}`);
  assert.strictEqual(refresh.split(':').length, 5, `unexpected refresh callback segments for ${section}`);
  assert.strictEqual(refresh.split(':')[3], section, `refresh section context lost for ${section}`);
}

const invalidValues = ['', 'undefined', 'refresh', 'user', 'statistic', 'admin:statistics:section:users:unexpected'];
for (const value of invalidValues) {
  assert.strictEqual(parseStatisticsSectionCallback(value), null, `malformed/open callback should be rejected: ${value}`);
  assert.strictEqual(parseStatisticsSectionRefreshCallback(value), null, `malformed/refresh callback should be rejected: ${value}`);
}
assert.strictEqual(parseStatisticsSectionCallback('admin:statistics:section:users:refresh'), null, 'refresh callback must not parse as an open-section callback');
assert.strictEqual(parseStatisticsSectionRefreshCallback('admin:statistics:section:users'), null, 'open callback must not parse as a refresh callback');

console.log('STATISTICS_CALLBACK_FLOW_OK sections=8 open=8 refresh=8 malformed=7');
