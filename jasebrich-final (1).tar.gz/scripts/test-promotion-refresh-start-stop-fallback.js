'use strict';
process.env.LOG_LEVEL='error';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const panel = read('src/handlers/panel.handler.js');
const runtime = read('src/services/userbotRuntime.service.js');
const jobRepo = read('src/database/repositories/userbotRuntimeJob.repository.js');
const render = read('src/utils/render.js');
const panelConfig = read('src/services/panelConfig.service.js');
const poolConfig = read('src/services/poolPanelConfig.service.js');
const menu = read('src/constants/menu.js');
const index = read('src/index.js');
const placeholders = read('src/utils/placeholders.js');

// Status Promosi actions are inline callbacks, not reply-keyboard actions.
assert.match(menu, /PANEL_PROMOTION_STATUS_REFRESH: \(kind, id\) => `panel:promotion:refresh:\$\{kind\}:\$\{id\}`/);
assert.match(menu, /PANEL_PROMOTION_STATUS_START: \(kind, id\)/);
assert.match(menu, /PANEL_PROMOTION_STATUS_STOP: \(kind, id\)/);
assert.match(menu, /PANEL_PROMOTION_STATUS_BACK: \(kind, id\)/);
assert.match(panel, /const promotionStatusInlineKeyboard = \(kind, id, active = false\) => Markup\.inlineKeyboard/);
assert.match(panel, /button\.primary\(PANEL_FEATURE\.PROMOTION_STATUS_REFRESH, CALLBACK\.PANEL_PROMOTION_STATUS_REFRESH/);
assert.match(panel, /button\.danger\(PANEL_FEATURE\.STOP, CALLBACK\.PANEL_PROMOTION_STATUS_STOP/);
assert.match(panel, /button\.success\(PANEL_FEATURE\.START, CALLBACK\.PANEL_PROMOTION_STATUS_START/);
assert.match(panel, /button\.danger\(MENU\.KEMBALI, CALLBACK\.PANEL_PROMOTION_STATUS_BACK/);
assert.doesNotMatch(panel, /const promotionStatusKeyboard = .*Markup\.keyboard/);
assert.doesNotMatch(index, /bot\.hears\(PANEL_FEATURE\.PROMOTION_STATUS_REFRESH/);
assert.match(index, /bot\.action\(\/\^panel:promotion:refresh:\(owned\|pool\):\\d\+\$\/,[\s\S]*promotionStatusRefreshInlineCallback/);
assert.match(index, /bot\.action\(\/\^panel:promotion:start:\(owned\|pool\):\\d\+\$\/,[\s\S]*promotionStatusStartInlineCallback/);
assert.match(index, /bot\.action\(\/\^panel:promotion:stop:\(owned\|pool\):\\d\+\$\/,[\s\S]*promotionStatusStopInlineCallback/);
assert.match(index, /bot\.action\(\/\^panel:promotion:back:\(owned\|pool\):\\d\+\$\/, promotionStatusBackInlineCallback\)/);
assert.match(panel, /function promotionInlineContext\(ctx\)/);
assert.match(panel, /state\.screen !== 'promotion_status'/);

// The tracked screen is per-chat and the renderer edits that exact message;
// only Telegram edit-impossible errors are allowed to fall back to one new send.
assert.match(panel, /screenState\.get\(uid\)/);
assert.match(render, /const tracked = screenState\.get\(chatId\)/);
assert.match(render, /await ctx\.telegram\.editMessageText\(chatId, tracked\.messageId/);
assert.match(render, /if \(NOT_MODIFIED_RE\.test\(desc\)\) return/);
assert.match(render, /if \(EDIT_FALLBACK_RE\.test\(String\(desc\)\)\)/);
assert.doesNotMatch(render, /message not modified[\s\S]*ctx\.reply/);

// Exercise the actual reply-keyboard renderer: same message on success, no-op
// on MESSAGE_NOT_MODIFIED, and exactly one controlled send fallback when the
// tracked Telegram message can no longer be edited.
const screenState = require('../src/state/screenState');
const { renderScreen } = require('../src/utils/render');
async function testRefreshRenderer(){
  const chatId=9001001;
  const feature='control_panel_promotion_status_live';
  screenState.set(chatId,42,feature);
  let edits=0, replies=0;
  const inlineOptions={reply_markup:{inline_keyboard:[[{text:'🔄 Refresh',callback_data:'panel:promotion:refresh:owned:7'}]]}};
  const ctx={chat:{id:chatId,type:'private'}, callbackQuery:{message:{message_id:42,text:'old'}},
    editMessageText: async()=>{edits++;},
    editMessageCaption: async()=>{edits++;},
    reply: async()=>{replies++; return {message_id:42};}};
  await renderScreen(ctx,'fresh content',inlineOptions,feature);
  assert.equal(edits,1);
  assert.equal(replies,0);

  ctx.editMessageText=async()=>{edits++; const e=new Error('Bad Request: message is not modified'); e.description=e.message; throw e;};
  await renderScreen(ctx,'fresh content',inlineOptions,feature);
  assert.equal(replies,0);

  ctx.editMessageText=async()=>{edits++; const e=new Error('Bad Request: message to edit not found'); e.description=e.message; throw e;};
  ctx.reply=async()=>{replies++; return {message_id:43};};
  await renderScreen(ctx,'new content',inlineOptions,feature);
  assert.equal(replies,1);
  assert.equal(screenState.get(chatId).messageId,43);
  screenState.clear(chatId);
}


// Start/Stop is a lifecycle boundary. The runtime generation prevents an old
// worker from becoming live again after a quick Stop -> Start sequence.
assert.match(runtime, /runAutoPromosiCycle\(record, runGeneration = record\.scheduleGeneration\)/);
assert.match(runtime, /promotionGeneration === record\.scheduleGeneration/);
assert.match(runtime, /if\(!isCurrentRun\(\)\) break/);
assert.match(jobRepo, /cycle_number=0/);
assert.match(jobRepo, /processed_targets=0/);
assert.match(jobRepo, /successful_targets=0/);
assert.match(jobRepo, /failed_targets=0/);
assert.match(jobRepo, /started_at=NULL/);
assert.match(panel, /bumpPromotionStatusRenderVersion\(ctx\.from\.id,panelKind\(ctx\),assetId\)/);

// Round pause is durable and timestamp-based. It is persisted as next_run_at
// while the completed cycle is idle, so Status Promosi can show a real
// countdown and a process restart can preserve the same pause boundary.
assert.match(jobRepo, /function complete\(kind, id, cycleId, \{ nextRunAt = null \} = \{\}\)/);
assert.match(runtime, /status === 'idle' && Number\.isFinite\(nextRunMs\)/);
assert.match(runtime, /Math\.ceil\(\(nextRunMs - Date\.now\(\)\) \/ 1000\)/);
assert.match(runtime, /roundPauseRemainingSeconds/);
assert.match(runtime, /persistedAfterCycle\?\.next_run_at/);
assert.match(panel, /round_pause_remaining/);
assert.match(placeholders, /round_pause_remaining/);

// Ping Custom Submenu must receive the same real DB/system snapshot that the
// /ping command uses. The previous crash came from rendering the dynamic
// default with missing extra.ping during the editor reference flow.
const ping = read('src/handlers/ping.handler.js');
const customSubmenu = read('src/handlers/admin/customSubmenu.handler.js');
assert.match(ping, /function getPingRenderContext\(\)/);
assert.match(ping, /checkHealth\(\)/);
assert.match(ping, /statisticsService\.getSystemSnapshot\(\)/);
assert.match(customSubmenu, /normalizedId === 'system\.ping'/);
assert.match(customSubmenu, /getPingRenderContext\(\)/);
assert.match(customSubmenu, /return \{[\s\S]*ping,[\s\S]*placeholderValues:/);

// Continuous-round contract: completion persists a next round timestamp and
// the scheduler re-enters the same worker while the promotion flag remains active.
assert.match(runtime, /const roundDelay=cfg\.getRoundDelaySeconds\(asset\.id\)/);
assert.match(runtime, /runtimeJobRepo\.complete\(record\.kind, record\.id, job\.cycle_id, \{nextRunAt\}\)/);
assert.match(runtime, /if\(persistedAfterCycle\?\.next_run_at\)/);
assert.match(runtime, /record\.timer=setTimeout\(\(\)=>waitAndRun\(0\),Math\.max\(0,persistedWait\)\)/);
assert.match(runtime, /generation!==record\.scheduleGeneration \|\| !record\.flags\.auto_promosi/);
assert.match(jobRepo, /cycle_number=0/);

// Forward fallback is conservative: only a forward-specific restriction can
// trigger it, and only the existing legacy broadcast_text is used as the
// optional plain-text fallback. FloodWait/network/auth errors never fallback.
assert.match(runtime, /FORWARD_FALLBACK_ELIGIBLE_RE/);
assert.match(runtime, /CHAT_FORWARDS_RESTRICTED/);
assert.match(runtime, /if\(!forwardFallbackEligible\(err\) \|\| extractFloodWaitSeconds\(err\)>0\) throw err/);
assert.match(runtime, /getConfiguredTextFallback\(asset\)/);
assert.match(runtime, /await client\.sendMessage\(target/);
assert.match(runtime, /broadcast_text/);
assert.doesNotMatch(runtime, /FLOOD_WAIT[\s\S]{0,500}sendMessage\(target,\{message:fallback/);
assert.match(panelConfig, /UPDATE userbots SET broadcast_text=\? WHERE id=\?/);
assert.match(poolConfig, /Keep the existing broadcast_text as the optional plain-text fallback/);

// Dynamic unit test of the real exported sendConfiguredMessage using isolated
// infrastructure stubs; Telegram delivery itself is represented only by the
// fake client boundary, never by fake promotion state/data.
const originalLoad = Module._load;
const configAsset = { id: 7, __kind: 'owned', broadcast_text: 'Fallback text', broadcast_text_entities: '[]' };
let currentMessage = { kind: 'forward', source_chat_id: '-1001', source_message_id: 99 };
const calls = [];
const panelConfigStub = { getMessage: () => currentMessage };
const poolConfigStub = { getMessage: () => currentMessage };
const dbStub = { prepare: () => ({ get: () => null, all: () => [], run: () => ({ changes: 1 }) }) };
const repoStub = { findById: () => configAsset, listAutomatedActive: () => [], listAutomatedAssigned: () => [], setFlags: () => {}, updateConfig: () => {}, findActiveByOwner: () => [], listByOwner: () => [] };
const noopRepo = { find: () => null, isRecoverable: () => false, cancel: () => true, complete: () => true, checkpoint: () => true, updateActivity: () => true, recordTargetResult: () => true, upsertTargetHealth: () => true, findTargetHealth: () => null, findTargetHealthByTarget: () => null, listTargetHealth: () => [] };
Module._load = function(request, parent, isMain) {
  if (request === '../config') return { config: { telegramApiId: null, telegramApiHash: null, telegramDeviceModel: 'JASEBRICH' } };
  if (request === '../utils/logger') return { error(){}, warn(){}, info(){}, debug(){} };
  if (request === './automationConfig.service') return { getWtbKeywords: () => [], getWtbReplyText: () => '' };
  if (request === './panelConfig.service') return panelConfigStub;
  if (request === './poolPanelConfig.service') return poolConfigStub;
  if (request === '../database/repositories/ownedUserbot.repository') return repoStub;
  if (request === '../database/repositories/userbotPool.repository') return repoStub;
  if (request === '../database/repositories/pmPermitState.repository') return {};
  if (request === '../database/repositories/baseReplyCooldown.repository') return {};
  if (request === './subscription.service') return { isExpiredAt: () => false, parseTimestamp: () => null };
  if (request === './delayPolicy.service') return { readGroupDelayRange: () => ({min:1,max:1}), sampleGroupDelay: () => 1, formatGroupDelayRange: () => '1', DEFAULT_GROUP_DELAY_SECONDS: 1, DEFAULT_ROUND_DELAY_SECONDS: 10, normalizeRoundDelaySeconds: (v)=>Number(v) };
  if (request === '../database/repositories/userbotRuntimeJob.repository') return noopRepo;
  if (request === './featureAccess.service') return { checkAssetFeature: () => ({ allowed: true }) };
  if (request === '../database') return { getDb: () => dbStub };
  return originalLoad.call(this, request, parent, isMain);
};
let runtimeModule;
try {
  delete require.cache[require.resolve('../src/services/userbotRuntime.service')];
  runtimeModule = require('../src/services/userbotRuntime.service');
} finally {
  Module._load = originalLoad;
}

async function run() {
  await testRefreshRenderer();
  const forwardOk = {
    forwardMessages: async (...args) => calls.push(['forward', args]),
    sendMessage: async (...args) => calls.push(['text', args]),
  };
  calls.length = 0;
  await runtimeModule.sendConfiguredMessage(forwardOk, '@target', configAsset);
  assert.deepEqual(calls.map(x => x[0]), ['forward']);

  const fallbackClient = {
    forwardMessages: async () => { throw new Error('CHAT_FORWARDS_RESTRICTED'); },
    sendMessage: async (...args) => calls.push(['text', args]),
  };
  calls.length = 0;
  await runtimeModule.sendConfiguredMessage(fallbackClient, '@target', configAsset);
  assert.deepEqual(calls.map(x => x[0]), ['text']);
  assert.equal(calls[0][1][1].message, 'Fallback text');

  const floodClient = {
    forwardMessages: async () => { const e = new Error('FLOOD_WAIT_120'); throw e; },
    sendMessage: async (...args) => calls.push(['text', args]),
  };
  calls.length = 0;
  await assert.rejects(() => runtimeModule.sendConfiguredMessage(floodClient, '@target', configAsset), /FLOOD_WAIT_120/);
  assert.deepEqual(calls, []);

  const retryAfterClient = {
    forwardMessages: async () => { const e = new Error('Too Many Requests'); e.retry_after = 45; throw e; },
    sendMessage: async (...args) => calls.push(['text', args]),
  };
  calls.length = 0;
  await assert.rejects(() => runtimeModule.sendConfiguredMessage(retryAfterClient, '@target', configAsset), /Too Many Requests/);
  assert.deepEqual(calls, []);

  const networkClient = {
    forwardMessages: async () => { throw new Error('ETIMEDOUT network'); },
    sendMessage: async (...args) => calls.push(['text', args]),
  };
  calls.length = 0;
  await assert.rejects(() => runtimeModule.sendConfiguredMessage(networkClient, '@target', configAsset), /ETIMEDOUT network/);
  assert.deepEqual(calls, []);

  const noFallbackAsset = { ...configAsset, broadcast_text: null };
  const restrictedNoFallback = {
    forwardMessages: async () => { throw new Error('CHAT_FORWARDS_RESTRICTED'); },
    sendMessage: async (...args) => calls.push(['text', args]),
  };
  calls.length = 0;
  await assert.rejects(() => runtimeModule.sendConfiguredMessage(restrictedNoFallback, '@target', noFallbackAsset), /CHAT_FORWARDS_RESTRICTED/);
  assert.deepEqual(calls, []);

  console.log('PROMOTION_REFRESH_START_STOP_FALLBACK_CONTRACT_OK');
}

run().catch((err) => { console.error(err); process.exit(1); });
