'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const cancel = require('../src/services/cancelNotice.service');

assert.equal(cancel.CANCELLED_TEXT, '❌ Tindakan dibatalkan oleh user.');
assert.equal(cancel.NO_ACTIVE_TEXT, 'ℹ️ Tidak ada proses aktif yang berlangsung.');
assert.equal(typeof cancel.replyCancelled, 'function');
assert.equal(typeof cancel.replyNoActive, 'function');
assert.equal(typeof cancel.answerCancelled, 'function');
assert.equal(typeof cancel.answerNoActive, 'function');

(async () => {
  const replies = [];
  await cancel.replyCancelled({ reply: async (text) => replies.push(text) });
  await cancel.replyNoActive({ reply: async (text) => replies.push(text) });
  assert.deepEqual(replies, [cancel.CANCELLED_TEXT, cancel.NO_ACTIVE_TEXT]);

  let answered = [];
  await cancel.answerCancelled({ answerCbQuery: async (...args) => { answered.push(args); } });
  await cancel.answerNoActive({ answerCbQuery: async (...args) => { answered.push(args); } });
  assert.equal(answered[0][0], cancel.CANCELLED_TEXT);
  assert.equal(answered[1][0], cancel.NO_ACTIVE_TEXT);

  const files = [];
  function walk(dir) {
    for (const name of fs.readdirSync(dir)) {
      const full = path.join(dir, name);
      const st = fs.statSync(full);
      if (st.isDirectory()) walk(full);
      else if (full.endsWith('.js')) files.push(full);
    }
  }
  walk(path.join(root, 'src'));

  const adminCancelFiles = files.filter((f) => f.includes(`${path.sep}handlers${path.sep}admin${path.sep}`));
  for (const file of adminCancelFiles) {
    const text = fs.readFileSync(file, 'utf8');
    if (/CancelCallback\s*=|CancelHandler\s*=/.test(text)) {
      assert.match(text, /answerCancelled/, `cancel callback in ${path.relative(root, file)} must use canonical cancellation notice`);
    }
  }

  const reminder = fs.readFileSync(path.join(root, 'src/handlers/admin/reminder.handler.js'), 'utf8');
  assert.match(reminder, /button\.danger\('❌ Batal', ADMIN_CALLBACK\.REMINDER_CANCEL\)/);
  const subext = fs.readFileSync(path.join(root, 'src/handlers/admin/subscriptionExtend.handler.js'), 'utf8');
  assert.match(subext, /button\.danger\('❌ Batal', ADMIN_CALLBACK\.SUBEXT_CANCEL\)/);

  const nav = fs.readFileSync(path.join(root, 'src/middlewares/navigationCancellation.middleware.js'), 'utf8');
  assert.match(nav, /replyCancelled\(ctx\)/);
  assert.match(nav, /replyNoActive\(ctx\)/);
  assert.match(nav, /flowCancellation\.cancelAll\(ctx\.from\.id\)/);

  const store = fs.readFileSync(path.join(root, 'src/handlers/store.handler.js'), 'utf8');
  assert.match(store, /answerCancelled\(ctx\)/);
  assert.match(store, /CANCELLED_TEXT/);
  assert.doesNotMatch(store, /ctx\.answerCbQuery\(\s*['\"](?:✅|❌).*dibatalkan/i);

  console.log('CANCEL_NOTICE_CONTRACT_OK exact_cancel=1 exact_no_active=1 callback_exports=1 cancel_routes=all');
})().catch((err) => { console.error(err); process.exitCode = 1; });
