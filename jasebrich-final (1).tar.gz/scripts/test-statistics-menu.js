'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const handler = read('src/handlers/admin/statistics.handler.js');
const keyboard = read('src/keyboards/adminStatistics.keyboard.js');
const callbacks = read('src/constants/admin.callback.js');
const { ADMIN_CALLBACK } = require('../src/constants/admin.callback');
const index = read('src/index.js');
const service = read('src/services/statistics.service.js');
const statisticsConstants = require('../src/constants/statistics');
const statisticsConstantsSource = read('src/constants/statistics.js');

const expectedSections = ['users', 'userbot', 'stock', 'orders', 'payments', 'subscription', 'promotion', 'system'];
assert.deepStrictEqual(statisticsConstants.STATISTICS_SECTION_IDS, expectedSections, 'canonical statistics registry mismatch');
assert.equal(statisticsConstants.STATISTICS_SECTIONS.length, expectedSections.length, 'statistics registry size mismatch');

for (const section of expectedSections) {
  assert.match(statisticsConstantsSource, new RegExp(`['\\"]${section}['\\"]`), `canonical registry missing ${section}`);
  assert.match(handler, new RegExp(`admin\\.statistics\\.${section}`), `statistics detail template missing ${section}`);
  assert.match(handler, new RegExp(`statistics\\.${section}`), `statistics detail source missing ${section}`);
  assert.equal(statisticsConstants.isValidStatisticsSection(section), true, `${section} should be valid`);
  const open = ADMIN_CALLBACK.STATISTICS_SECTION(section);
  const refresh = ADMIN_CALLBACK.STATISTICS_SECTION_REFRESH(section);
  assert.equal(statisticsConstants.parseStatisticsSectionCallback(open), section, `open callback mismatch for ${section}`);
  assert.equal(statisticsConstants.parseStatisticsSectionRefreshCallback(refresh), section, `refresh callback mismatch for ${section}`);
}

assert.match(keyboard, /STATISTICS_SECTIONS/);
assert.match(keyboard, /ADMIN_CALLBACK\.STATISTICS_SECTION\(section\)/);
assert.match(keyboard, /ADMIN_CALLBACK\.STATISTICS_SECTION_REFRESH\(section\)/);
assert.match(callbacks, /STATISTICS_SECTION: \(section\)/);
assert.match(callbacks, /STATISTICS_SECTION_REFRESH: \(section\)/);
assert.match(handler, /getStatisticsSnapshot\(\)/);
assert.match(handler, /adminStatisticsSectionKeyboard\(normalized\)/);
assert.match(handler, /parseStatisticsSectionCallback\(ctx\.callbackQuery && ctx\.callbackQuery\.data\)/);
assert.match(handler, /parseStatisticsSectionRefreshCallback\(ctx\.callbackQuery && ctx\.callbackQuery\.data\)/);
assert.doesNotMatch(handler, /split\(['"]:\\?['"]\)\[4\]/);
assert.match(index, /bot\.action\(STATISTICS_SECTION_CALLBACK_PATTERN, requireAdmin\(statisticsSectionCallback\)\)/);
assert.match(index, /bot\.action\(STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN, requireAdmin\(statisticsSectionRefreshCallback\)\)/);
assert.match(statisticsConstantsSource, /STATISTICS_SECTION_CALLBACK_PATTERN/);
assert.match(statisticsConstantsSource, /STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN/);
assert.doesNotMatch(index, /admin:statistics:section:\(users\|userbot\|stock\|orders\|payments\|subscription\|promotion\|system\)/);
assert.doesNotMatch(handler, /const allowed = new Set\(\[/);
assert.match(service, /function collectUserStats\(db, now\)/);
assert.match(service, /function collectUserbotStats\(db, now\)/);
assert.match(service, /function collectPoolStats\(db, now\)/);
assert.match(service, /function collectOrderStats\(db\)/);

console.log('STATISTICS_MENU_STATIC_OK category_registry=1 real_snapshot=1 per_section_refresh=1 compact_home=1');
