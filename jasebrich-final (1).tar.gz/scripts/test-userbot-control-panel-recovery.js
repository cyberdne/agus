const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');

const userbotService = read('src/services/userbot.service.js');
const panel = read('src/handlers/panel.handler.js');
const access = read('src/services/userbotAccess.service.js');
const runtime = read('src/services/userbotRuntime.service.js');
const sub = read('src/services/subscription.service.js');

const controlFn = userbotService.match(/function hasControllablePanelAsset[\s\S]*?\n}\nfunction getAvailableJasebStockCount/);
assert(controlFn, 'hasControllablePanelAsset must exist');
assert(controlFn[0].includes('subscription.STATE.ACTIVE'), 'control panel visibility must use entitlement ACTIVE state');
assert(!controlFn[0].includes('session_string'), 'control panel visibility must not depend on session_string');
const executableControlFn = controlFn[0].replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\n)\s*\/\/.*$/gm, '$1');
assert(!executableControlFn.includes('userbotRuntime.'), 'control panel visibility must not depend on runtime liveness');
assert(controlFn[0].includes("row.status !== 'assigned'"), 'leased asset status must be validated');
assert(controlFn[0].includes('expires_at'), 'leased asset expiry must be validated');

assert(/const activeOwned = assets\.owned\.filter\(\(a\) => subscription\.isActiveNow\(a, now\)\)/.test(panel), 'owned picker must use effective active entitlement');
assert(/const activePool = assets\.leased\.filter\(\(a\) => a\.status === 'assigned' && a\.expires_at/.test(panel), 'pool picker must use persisted lease expiry');
assert(!/activeOwned\.filter\([^\n]*session_string/.test(panel), 'panel picker must not require session_string');

const accessFn = access.match(/function checkUserbotControlAccess[\s\S]*?\n}\n\n\/\*\* Throwing variant/);
assert(accessFn, 'control access function must exist');
assert(accessFn[0].includes("asset.status === 'disabled'"), 'disabled pool assets must remain blocked');
assert(accessFn[0].includes('asset.expires_at'), 'pool expiry must remain enforced');
assert(!accessFn[0].includes("if (!asset.session_string)"), 'missing runtime session must not erase valid pool access');
assert(accessFn[0].includes('subscription.getSubscriptionState'), 'owned access must use subscription state');
assert(accessFn[0].includes('STATE.EXPIRED'), 'expired owned userbot must remain blocked from control');

assert(/function withClient\b/.test(runtime), 'runtime must keep a runtime-only client/session guard');
assert(/session|StringSession/.test(runtime), 'runtime layer must still handle session availability');
assert(/function isActiveNow\b/.test(sub) && /getSubscriptionState\(row, nowMs\) === STATE\.ACTIVE/.test(sub), 'subscription active decision must remain time-aware');
const ownedRepo = read('src/database/repositories/ownedUserbot.repository.js');
assert(ownedRepo.includes("status IN ('active', 'expired')"), 'expiring reminder/panel query must tolerate stale expired status when expiry is still future');

console.log('USERBOT_CONTROL_PANEL_RECOVERY_OK');
