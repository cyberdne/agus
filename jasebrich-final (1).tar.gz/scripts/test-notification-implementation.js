'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const failures = [];
const checks = [];

function check(name, condition) {
  checks.push(name);
  if (!condition) failures.push(name);
}

const schema = read('src/database/schema.js');
const dbIndex = read('src/database/index.js');
const userRepo = read('src/database/repositories/user.repository.js');
const orderRepo = read('src/database/repositories/order.repository.js');
const orderService = read('src/services/order.service.js');
const store = read('src/handlers/store.handler.js');
const notification = read('src/services/notification.service.js');
const notificationHandler = read('src/handlers/admin/notification.handler.js');
const adminKeyboard = read('src/keyboards/admin.keyboard.js');
const adminCallback = read('src/constants/admin.callback.js');
const adminFlows = read('src/constants/adminInputFlows.js');
const adminReply = read('src/middlewares/adminReply.middleware.js');
const adminFlow = read('src/middlewares/adminFlow.middleware.js');
const ensureUser = read('src/middlewares/ensureUser.middleware.js');
const scheduler = read('src/scheduler.js');
const index = read('src/index.js');
const orderConfirm = read('src/handlers/admin/orderConfirm.handler.js');

for (const column of [
  'registration_notification_sent_at',
  'registration_notification_message_id',
  'registration_notification_claim_token',
  'registration_notification_claimed_at',
  'payment_proof_requested_at',
  'payment_proof_type',
  'payment_proof_file_id',
  'payment_proof_caption',
  'payment_proof_entities',
  'payment_proof_received_at',
  'transaction_notification_duration_minutes',
  'transaction_notification_expires_at',
  'transaction_notification_chat_id',
  'transaction_notification_message_id',
  'transaction_notification_media_type',
  'transaction_notification_status',
  'transaction_notification_claim_token',
  'transaction_notification_claimed_at',
  'notification_actor_id',
]) {
  check(`schema column ${column}`, schema.includes(column));
  check(`migration column ${column}`, dbIndex.includes(`ADD COLUMN ${column}`));
}

check('notification lifecycle index', dbIndex.includes('idx_orders_notification_lifecycle'));
check('notification service uses settings repository', notification.includes("require('../database/repositories/settings.repository')"));
check('registration notification is claim-based', notification.includes('claimRegistrationNotification') && notification.includes('completeRegistrationNotification'));
check('transaction notification is claim-based', notification.includes('claimTransactionNotification') && notification.includes('recordTransactionNotification'));
check('transaction proof reuses Telegram file_id directly', !notification.includes('downloadFile') && !notification.includes('upload'));
check('transaction notification has approve callback', notification.includes('adminorder:confirm:${orderId}'));
check('transaction notification has reject callback', notification.includes('adminorder:reject:${orderId}'));
check('channel callback binds chat and message', notification.includes('transaction_notification_chat_id') && notification.includes('transaction_notification_message_id'));
check('channel callback validates actor', notification.includes('getChatMember') && notification.includes("['creator', 'administrator']"));
check('channel callback validates active channel setting', notification.includes('getChannel(\'transaction\')'));
check('channel callback rejects non-awaiting state', notification.includes("order.status !== 'awaiting_confirmation'"));
check('channel callback rejects expired notification', notification.includes('transaction_notification_expires_at') && notification.includes('Notification transaksi sudah expired.'));
check('scheduler reuses existing tick', scheduler.includes('notificationService.sweepTransactionNotifications(telegram)') && /const schedulerState = \{[\s\S]*tickRunning: false/.test(scheduler));
check('registration event only follows actual create', ensureUser.includes('ensureFromTelegramUser') && ensureUser.includes('if (ensured.created)'));
check('registration notification is async/non-blocking', ensureUser.includes('sendRegistrationNotification(ctx.telegram, ensured.user)') && ensureUser.includes('.catch'));
check('payment proof request persists', store.includes('requestPaymentProof({ orderId, userId: ctx.from.id })'));
check('payment proof submission persists before awaiting', store.includes('submitPaymentProof({') && orderRepo.includes("status = 'awaiting_confirmation'"));
check('proof supports photo', store.includes("handlePaymentProofPhoto"));
check('proof supports document', store.includes("handlePaymentProofDocument"));
check('proof supports video', store.includes("handlePaymentProofVideo"));
check('proof handlers are wired in index', index.includes('handlePaymentProofPhoto(ctx)') && index.includes('handlePaymentProofDocument(ctx)') && index.includes('handlePaymentProofVideo(ctx)'));
check('existing admin DM notification preserved', store.includes('notifyAdminsOfNewOrder(ctx.telegram, submitted.order, ctx.from)'));
check('admin DM is fallback-only when transaction channel is configured', store.includes("transactionChannelConfigured = Boolean(notificationService.getChannel('transaction'))") && store.includes('if (!transactionChannelConfigured)') && store.includes('notifyAdminsOfNewOrder(ctx.telegram, submitted.order, ctx.from)'));
check('approval notifies owner and starts existing userbot activation flow', (orderConfirm.includes('ctx.telegram.sendMessage') || orderConfirm.includes('telegram.sendMessage')) && orderConfirm.includes("result.type === 'userbot'") && orderConfirm.includes('resumePendingUserbotActivation') && orderConfirm.includes("beginPhoneStep(telegram, order.user_id, pending.id, 'purchase'") && orderConfirm.includes("resumePendingUserbotActivation(telegram, { ...fresh, category: 'userbot', fulfillment_ref: result.pendingOwnedId })"));
check('rejection notifies owner for both channel and admin paths', orderConfirm.includes('Pembayaran Order #${fresh.id} ditolak.') && orderConfirm.includes('notificationService.updateTransactionNotification'));
check('store paid no longer directly marks awaiting', !store.slice(store.indexOf('const storePaidCallback'), store.indexOf('function resolvePaymentProofOrder')).includes('markAwaitingConfirmation'));
check('approval uses existing fulfillment service', orderConfirm.includes('orderService.fulfillOrder(ctx.telegram, orderId)'));
check('reject uses canonical DB transition', orderConfirm.includes('orderService.rejectPendingOrder({ orderId })'));
check('channel projection updated after approval/reject', orderConfirm.includes('notificationService.updateTransactionNotification'));
check('admin panel exposes notification menu', adminKeyboard.includes("'🔔 Notifikasi'") || read('src/handlers/admin/adminPanel.handler.js').includes("['🔔 Notifikasi']"));
check('notification callbacks centralized', adminCallback.includes('NOTIFICATION_HOME') && adminCallback.includes('NOTIFICATION_SET_TRANSACTION_DURATION'));
check('notification input flows have contextual navigation', adminFlows.includes('admin_notification_registration_channel') && adminFlows.includes('admin_notification_transaction_channel') && adminFlows.includes('admin_notification_transaction_duration'));
check('notification reply routes are registered', adminReply.includes("['🔔 Notifikasi'") && adminReply.includes("['📢 Atur Channel Transaksi'"));
check('notification text flow routed', adminFlow.includes('admin_notification_transaction_duration: notificationMgmt.handleNotificationText'));
check('admin notification handlers are protected at dispatcher', index.includes('bot.action(ADMIN_CALLBACK.NOTIFICATION_HOME, requireAdmin(notificationHomeCallback))') && index.includes('NOTIFICATION_SET_TRANSACTION_CHANNEL, requireAdmin'));
check('duration validation rejects non-integers/out-of-range', notification.includes('Number.isInteger(value)') && notification.includes('value < MIN_DURATION_MINUTES || value > MAX_DURATION_MINUTES'));
check('channel validation requires Telegram channel', notification.includes("chat.type !== 'channel'"));
check('channel validation requires bot admin rights', notification.includes('can_post_messages === false'));
check('final notification status is derived from DB order', notification.includes('orderRepo.findById(order.id)') && notification.includes("['fulfilled', 'cancelled', 'rejected'].includes(current.status)"));

// Preserve the existing callback contract; no replacement callback format is introduced for approval/rejection.
check('existing admin confirm callback remains registered', index.includes("bot.action(/^adminorder:confirm:/, requireAdmin(adminOrderConfirmCallback))"));
check('existing admin reject callback remains registered', index.includes("bot.action(/^adminorder:reject:/, requireAdmin(adminOrderRejectCallback))"));

if (failures.length) {
  console.error(`NOTIFICATION_STATIC_CONTRACT_FAIL ${failures.length}/${checks.length}`);
  for (const failure of failures) console.error(` - ${failure}`);
  process.exit(1);
}

console.log(`NOTIFICATION_STATIC_CONTRACT_OK ${checks.length} checks`);
