const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');

const db = read('src/database/index.js');
const repo = read('src/database/repositories/subscriptionReminder.repository.js');
const service = read('src/services/subscriptionReminder.service.js');
const handler = read('src/handlers/admin/reminder.handler.js');
const flow = read('src/constants/adminInputFlows.js');
const scheduler = read('src/scheduler.js');
const index = read('src/index.js');
const callbacks = read('src/constants/admin.callback.js');

assert(/CREATE TABLE IF NOT EXISTS subscription_reminder_settings/.test(db), 'reminder settings migration missing');
assert(/CREATE TABLE IF NOT EXISTS subscription_reminder_events/.test(db), 'reminder events migration missing');
assert(/sub_version INTEGER NOT NULL DEFAULT 0/.test(db), 'reminder event subscription version missing');
assert(/event_key TEXT NOT NULL UNIQUE/.test(db), 'reminder event idempotency constraint missing');
assert(/auto:\$\{row\.id\}:\$\{row\.sub_version/.test(service), 'automatic reminder key must bind subscription version');
assert(/subscriptionChanged|subscription_version_changed|expiry_changed|subscription\.isActiveNow/.test(service), 'fresh subscription/expiry validation missing');
assert(/CALLBACK\.SUBSCRIPTION_RENEW\(fresh\.id\)/.test(service), 'reminder renewal action missing');
assert(/manual:\$\{adminId\}:\$\{row\.id\}:\$\{row\.sub_version/.test(service), 'manual reminder dedup key missing');
assert(/thresholds/.test(service) && /parseThresholds/.test(service), 'configurable thresholds missing');
assert(/quarantineStaleSending/.test(repo) && /status='skipped'/.test(repo) && /function markSkipped/.test(repo), 'ambiguous/permanent reminder sends must not auto-duplicate');
assert(/const threshold = chooseCurrentThreshold\(remainingMs, cfg\.thresholds\)/.test(service), 'automatic sweep must choose one current threshold per userbot');
assert(!/for \(const threshold of cfg\.thresholds\)/.test(service), 'automatic sweep must not send every crossed threshold in one tick');
assert(/sweepAutomaticReminders\(telegram\)/.test(scheduler), 'automatic reminder not integrated into existing scheduler');
assert(!/setInterval\(/.test(service), 'reminder service must not create a second scheduler');
assert(/reminder\.handleReminderText/.test(flow) || /admin_reminder_thresholds/.test(flow), 'admin reminder input flow missing');
assert(/REMINDER_HOME/.test(index) && /REMINDER_TOGGLE/.test(index) && /REMINDER_MANUAL_HOME/.test(index), 'reminder callbacks not fully wired');
assert(/REMINDER_HOME: 'adminreminder:home'/.test(callbacks), 'reminder callback constants missing');
assert(/Automatic Reminder/.test(handler) || /Otomatis/.test(handler), 'automatic reminder UI missing');
assert(/Manual/.test(handler), 'manual reminder UI missing');

// Dynamic template values must be HTML-escaped because reminders are sent
// with Telegram HTML parse mode.
assert(/escapeHtml/.test(service), 'reminder template must escape dynamic HTML values');

console.log('REMINDER_ADMIN_FEATURE_OK');
