'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { ADMIN_CALLBACK } = require('../src/constants/admin.callback');
const submenuRegistry = require('../src/constants/submenu.registry');
const { contentToken } = require('../src/utils/callbackToken');

const root = path.resolve(__dirname, '..');
const ids = [];
for (const dir of ['src/handlers', 'src/services', 'src/utils']) {
  const absolute = path.join(root, dir);
  if (!fs.existsSync(absolute)) continue;
  const stack = [absolute];
  while (stack.length) {
    const current = stack.pop();
    for (const name of fs.readdirSync(current)) {
      const full = path.join(current, name);
      const st = fs.statSync(full);
      if (st.isDirectory()) stack.push(full);
      else if (full.endsWith('.js')) {
        const text = fs.readFileSync(full, 'utf8');
        for (const m of text.matchAll(/define(?:Template|Submenu)\(\s*['\"]([^'\"]+)['\"]/g)) ids.push(m[1]);
      }
    }
  }
}

const unique = [...new Set(ids)];
assert(unique.length >= 250, `unexpectedly small template inventory: ${unique.length}`);

let longestRaw = 0;
for (const id of unique) {
  submenuRegistry.register({ id, label: id, defaultValue: 'x' });
  longestRaw = Math.max(longestRaw, Buffer.byteLength(id, 'utf8'));
  const token = contentToken(id);
  assert.match(token, /^[0-9a-f]{10}$/);
  const callbacks = [
    ADMIN_CALLBACK.CUSTOM_SUBMENU_SELECT(id),
    ADMIN_CALLBACK.CUSTOM_SUBMENU_EDIT(id),
    ADMIN_CALLBACK.CUSTOM_SUBMENU_PREVIEW(id),
    ADMIN_CALLBACK.CUSTOM_SUBMENU_SAVE(id),
    ADMIN_CALLBACK.CUSTOM_SUBMENU_RESEND(id),
    ADMIN_CALLBACK.CUSTOM_SUBMENU_RESET(id),
    ADMIN_CALLBACK.CUSTOM_SUBMENU_RESET_CONFIRM(id),
  ];
  for (const callbackData of callbacks) {
    assert(Buffer.byteLength(callbackData, 'utf8') <= 64, `${id} produced oversized callback_data: ${callbackData.length} bytes`);
  }
  assert.equal(submenuRegistry.resolveCallbackId(token), id, `token did not resolve: ${id}`);
  assert.equal(submenuRegistry.resolveCallbackId(id), id, `legacy raw id no longer resolves: ${id}`);
}

const longId = 'userbot.jaseb_session_replacement_unavailable';
assert(unique.includes(longId), 'expected audited long submenu id missing');
assert(Buffer.byteLength(ADMIN_CALLBACK.CUSTOM_SUBMENU_SELECT(longId), 'utf8') < 64);
assert(longestRaw > 40, 'test fixture did not include genuinely long submenu ids');

console.log(`CUSTOM_SUBMENU_CALLBACK_SAFETY_OK entries=${unique.length} longest_raw_id=${longestRaw} compact_token=10 legacy_resolver=1`);
