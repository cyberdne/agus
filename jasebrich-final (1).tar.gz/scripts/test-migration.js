'use strict';
/**
 * Production migration integration tests against the real better-sqlite3
 * driver, real src/database initialization, and real SQLite PRAGMA metadata.
 * No mocks are used for migration/database behavior.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const assert = require('node:assert/strict');
const Database = require('better-sqlite3');

const root = path.resolve(__dirname, '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-migration-'));
const results = [];

function test(name, fn) {
  try { fn(); results.push(true); console.log(`PASS  ${name}`); }
  catch (e) { results.push(false); console.log(`FAIL  ${name}\n      ${(e && e.stack) || e}`); }
}

function migrate(dbPath) {
  const r = spawnSync(process.execPath, ['-e', `require(${JSON.stringify(path.join(root, 'src/database'))}).initDatabase()`], {
    cwd: tmp,
    encoding: 'utf8',
    env: {
      ...process.env,
      DB_PATH: dbPath,
      BOT_TOKEN: 'test-token',
      ADMIN_IDS: '900',
      TELEGRAM_API_ID: '1',
      TELEGRAM_API_HASH: 'test-hash',
    },
  });
  assert.equal(r.status, 0, `initDatabase failed:\nstdout=${r.stdout}\nstderr=${r.stderr}`);
}

function migrateExpectFailure(dbPath) {
  const r = spawnSync(process.execPath, ['-e', `require(${JSON.stringify(path.join(root, 'src/database'))}).initDatabase()`], {
    cwd: tmp,
    encoding: 'utf8',
    env: {
      ...process.env,
      DB_PATH: dbPath,
      BOT_TOKEN: 'test-token',
      ADMIN_IDS: '900',
      TELEGRAM_API_ID: '1',
      TELEGRAM_API_HASH: 'test-hash',
    },
  });
  assert.notEqual(r.status, 0, 'initDatabase unexpectedly succeeded');
  return `${r.stdout || ''}${r.stderr || ''}`;
}

function inspect(dbPath, fn) {
  const db = new Database(dbPath);
  try { return fn(db); } finally { db.close(); }
}

function cols(db, table) {
  return db.pragma(`table_info(${table})`).map((c) => c.name).sort();
}

function fkGroups(db, table) {
  const rows = db.pragma(`foreign_key_list(${table})`);
  const grouped = new Map();
  for (const row of rows) {
    if (!grouped.has(row.id)) grouped.set(row.id, []);
    grouped.get(row.id).push(row);
  }
  return [...grouped.entries()].sort((a, b) => Number(a[0]) - Number(b[0])).map(([, parts]) => {
    parts.sort((a, b) => Number(a.seq) - Number(b.seq));
    return {
      from: parts.map((r) => r.from),
      table: parts[0].table,
      to: parts.map((r) => r.to),
      onUpdate: parts[0].on_update,
      onDelete: parts[0].on_delete,
      match: parts[0].match,
    };
  }).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
}

function sequence(db, table) {
  const row = db.prepare('SELECT seq FROM sqlite_sequence WHERE name = ?').get(table);
  return row ? Number(row.seq) : null;
}

const freshPath = path.join(tmp, 'fresh.sqlite');
migrate(freshPath);
const fresh = inspect(freshPath, (db) => ({
  orders: cols(db, 'orders'),
  userbots: cols(db, 'userbots'),
  ordersFk: fkGroups(db, 'orders'),
  userbotsFk: fkGroups(db, 'userbots'),
  violations: db.pragma('foreign_key_check'),
}));

test('fresh database has final lease columns and Telegram-ID FKs', () => {
  for (const c of ['qty', 'unit_price', 'total_price', 'duration_days', 'target_userbot_id', 'expires_at', 'processing_started_at', 'processing_heartbeat_at', 'processing_claim_token']) assert.ok(fresh.orders.includes(c));
  for (const c of ['runtime_stop_reason', 'expired_at', 'sub_version', 'updated_at']) assert.ok(fresh.userbots.includes(c));
  assert.ok(fresh.ordersFk.some((fk) => fk.from.length === 1 && fk.from[0] === 'user_id' && fk.table === 'users' && fk.to[0] === 'telegram_id'));
  assert.ok(fresh.userbotsFk.some((fk) => fk.from.length === 1 && fk.from[0] === 'user_id' && fk.table === 'users' && fk.to[0] === 'telegram_id'));
  assert.deepEqual(fresh.violations, []);
});

const LEGACY = `
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT
);
CREATE TABLE products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  price INTEGER NOT NULL DEFAULT 0,
  duration_days INTEGER NOT NULL DEFAULT 30
);
CREATE TABLE orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  product_id INTEGER,
  category TEXT NOT NULL DEFAULT 'jaseb',
  qty INTEGER NOT NULL DEFAULT 1,
  status TEXT DEFAULT 'pending',
  legacy_note TEXT NOT NULL DEFAULT 'keep',
  legacy_a INTEGER,
  legacy_b INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK (id > 0),
  UNIQUE (legacy_a, legacy_b),
  FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE RESTRICT,
  FOREIGN KEY (product_id) REFERENCES products(id) ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX idx_legacy_orders_status ON orders(status);
CREATE TABLE migration_audit (event TEXT NOT NULL);
CREATE TRIGGER trg_legacy_orders_update AFTER UPDATE OF status ON orders
BEGIN
  INSERT INTO migration_audit(event) VALUES ('order-status-updated');
END;
CREATE TABLE userbots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  label TEXT,
  status TEXT DEFAULT 'inactive',
  session_string TEXT,
  expires_at TEXT,
  legacy_a INTEGER,
  legacy_b INTEGER,
  CHECK (id > 0),
  UNIQUE (legacy_a, legacy_b),
  FOREIGN KEY (user_id) REFERENCES users(id) ON UPDATE CASCADE ON DELETE CASCADE
);`;

function mkLegacy(name, populate) {
  const dbPath = path.join(tmp, name);
  const db = new Database(dbPath);
  db.exec(LEGACY);
  if (populate) populate(db);
  db.close();
  return dbPath;
}

test('empty legacy database rebuilds to the current final orders/userbots schema', () => {
  const p = mkLegacy('legacy-empty.sqlite');
  migrate(p);
  inspect(p, (db) => {
    // Final schema = every fresh-database column PLUS the legacy-only columns
    // (legacy_a/b/note), which the FK rebuild must preserve, never drop.
    for (const [table, freshCols] of [['orders', fresh.orders], ['userbots', fresh.userbots]]) {
      const actual = cols(db, table);
      assert.deepEqual(freshCols.filter((c) => !actual.includes(c)), [], `${table}: fresh columns missing after migration`);
      assert.deepEqual(actual.filter((c) => !freshCols.includes(c)).sort(), table === 'orders' ? ['legacy_a', 'legacy_b', 'legacy_note'] : actual.filter((c) => !freshCols.includes(c)).sort());
    }
    assert.ok(fkGroups(db, 'orders').some((fk) => fk.from[0] === 'user_id' && fk.table === 'users' && fk.to[0] === 'telegram_id'));
    assert.ok(fkGroups(db, 'userbots').some((fk) => fk.from[0] === 'user_id' && fk.table === 'users' && fk.to[0] === 'telegram_id'));
    assert.deepEqual(db.pragma('foreign_key_check'), []);
  });
});

test('populated legacy database preserves rows, maps internal IDs, FK actions, constraints, index, trigger, and sequence', () => {
  const p = mkLegacy('legacy-populated.sqlite', (db) => {
    db.prepare('INSERT INTO users (id, telegram_id, username) VALUES (41, 710041, ?)').run('legacy-order');
    db.prepare('INSERT INTO users (id, telegram_id, username) VALUES (83, 880083, ?)').run('legacy-userbot');
    db.prepare("INSERT INTO products (id, category, name, price, duration_days) VALUES (7, 'userbot', 'Legacy Userbot', 12345, 90)").run();
    db.prepare("INSERT INTO products (id, category, name, price, duration_days) VALUES (8, 'jaseb', 'Legacy Jaseb', 54321, 45)").run();
    db.pragma('foreign_keys = OFF');
    db.prepare("INSERT INTO orders (id, user_id, product_id, category, qty, status, legacy_note, legacy_a, legacy_b, created_at, updated_at) VALUES (91, 41, 7, 'userbot', 2, 'fulfilled', 'preserve-order-note', 10, 20, '2035-01-01T00:00:00.000Z', '2035-01-01T00:01:00.000Z')").run();
    db.prepare("INSERT INTO orders (id, user_id, product_id, category, qty, status, legacy_note, legacy_a, legacy_b, created_at, updated_at) VALUES (92, 83, 8, 'jaseb', 3, 'paid', 'preserve-second-order', 11, 21, '2035-01-01T00:02:00.000Z', '2035-01-01T00:03:00.000Z')").run();
    db.prepare("INSERT INTO userbots (id, user_id, label, status, session_string, expires_at, legacy_a, legacy_b) VALUES (55, 83, 'Legacy Ubot', 'active', 'SESSION-OLD', '2035-01-01T00:00:00.000Z', 30, 40)").run();
    db.prepare("INSERT INTO userbots (id, user_id, label, status, session_string, expires_at, legacy_a, legacy_b) VALUES (56, 41, 'Legacy Ubot 2', 'expired', 'SESSION-OLD-2', '2034-12-01T00:00:00.000Z', 31, 41)").run();
    db.prepare("UPDATE sqlite_sequence SET seq = 500 WHERE name = 'orders'").run();
    db.prepare("UPDATE sqlite_sequence SET seq = 700 WHERE name = 'userbots'").run();
  });
  const before = inspect(p, (db) => ({
    orderCount: db.prepare('SELECT COUNT(*) AS c FROM orders').get().c,
    userbotCount: db.prepare('SELECT COUNT(*) AS c FROM userbots').get().c,
    orders: db.prepare('SELECT id, user_id, product_id, category, qty, status, legacy_note, legacy_a, legacy_b, created_at, updated_at FROM orders ORDER BY id').all(),
    userbots: db.prepare('SELECT id, user_id, label, status, session_string, expires_at, legacy_a, legacy_b FROM userbots ORDER BY id').all(),
  }));
  migrate(p);
  inspect(p, (db) => {
    assert.equal(db.prepare('SELECT COUNT(*) AS c FROM orders').get().c, before.orderCount);
    assert.equal(db.prepare('SELECT COUNT(*) AS c FROM userbots').get().c, before.userbotCount);
    const migratedOrders = db.prepare('SELECT id, user_id, product_id, category, qty, status, legacy_note, legacy_a, legacy_b, created_at, updated_at, expires_at FROM orders ORDER BY id').all();
    assert.deepEqual(migratedOrders.map(({ expires_at, ...row }) => row), [
      { ...before.orders[0], user_id: 710041 },
      { ...before.orders[1], user_id: 880083 },
    ]);
    assert.equal(migratedOrders[0].expires_at, '2035-01-01 01:00:00');
    assert.equal(migratedOrders[1].expires_at, '2035-01-01 01:02:00');
    assert.deepEqual(db.prepare('SELECT id, user_id, label, status, session_string, expires_at, legacy_a, legacy_b FROM userbots ORDER BY id').all(), [
      { ...before.userbots[0], user_id: 880083 },
      { ...before.userbots[1], user_id: 710041 },
    ]);

    const orderFks = fkGroups(db, 'orders');
    const userbotFks = fkGroups(db, 'userbots');
    const userOrderFk = orderFks.find((fk) => fk.from[0] === 'user_id');
    const productFk = orderFks.find((fk) => fk.from[0] === 'product_id');
    const userbotFk = userbotFks.find((fk) => fk.from[0] === 'user_id');
    assert.deepEqual(userOrderFk, { from: ['user_id'], table: 'users', to: ['telegram_id'], onUpdate: 'CASCADE', onDelete: 'RESTRICT', match: 'NONE' });
    assert.deepEqual(productFk, { from: ['product_id'], table: 'products', to: ['id'], onUpdate: 'CASCADE', onDelete: 'SET NULL', match: 'NONE' });
    assert.deepEqual(userbotFk, { from: ['user_id'], table: 'users', to: ['telegram_id'], onUpdate: 'CASCADE', onDelete: 'CASCADE', match: 'NONE' });

    assert.ok(db.prepare("SELECT 1 FROM sqlite_master WHERE type='index' AND name='idx_legacy_orders_status'").get());
    assert.ok(db.prepare("SELECT 1 FROM sqlite_master WHERE type='trigger' AND name='trg_legacy_orders_update'").get());
    assert.equal(sequence(db, 'orders'), 500);
    assert.equal(sequence(db, 'userbots'), 700);

    assert.throws(() => db.prepare("INSERT INTO orders (id, user_id, category) VALUES (0, 710041, 'userbot')").run(), /CHECK constraint failed/);
    assert.throws(() => db.prepare("INSERT INTO userbots (id, user_id, label) VALUES (0, 710041, 'bad')").run(), /CHECK constraint failed/);
    assert.throws(() => db.prepare("INSERT INTO orders (user_id, category, legacy_a, legacy_b) VALUES (710041, 'userbot', 10, 20)").run(), /UNIQUE constraint failed/);
    assert.throws(() => db.prepare("INSERT INTO userbots (user_id, label, legacy_a, legacy_b) VALUES (710041, 'bad', 30, 40)").run(), /UNIQUE constraint failed/);
    assert.throws(() => db.prepare("INSERT INTO userbots (user_id, label, status) VALUES (999999, 'bad', 'active')").run(), /FOREIGN KEY/);

    db.prepare("UPDATE orders SET status='paid' WHERE id=91").run();
    assert.equal(db.prepare('SELECT COUNT(*) AS c FROM migration_audit').get().c, 1);

    const newOrder = db.prepare("INSERT INTO orders (user_id, category) VALUES (710041, 'userbot')").run();
    assert.ok(Number(newOrder.lastInsertRowid) > 500, `new order id ${newOrder.lastInsertRowid} must be > preserved sequence 500`);
    assert.deepEqual(db.pragma('foreign_key_check'), []);
  });
});

test('legacy ID mapping is proven with unequal internal and Telegram IDs', () => {
  const p = mkLegacy('legacy-id-map.sqlite', (db) => {
    db.prepare('INSERT INTO users (id, telegram_id) VALUES (501, 991001)').run();
    db.prepare('INSERT INTO users (id, telegram_id) VALUES (502, 991002)').run();
    db.pragma('foreign_keys = OFF');
    db.prepare("INSERT INTO orders (id, user_id, qty, status) VALUES (301, 501, 4, 'paid')").run();
    db.prepare("INSERT INTO userbots (id, user_id, label, status) VALUES (401, 502, 'Mapped', 'expired')").run();
  });
  migrate(p);
  inspect(p, (db) => {
    assert.equal(db.prepare('SELECT user_id FROM orders WHERE id=301').get().user_id, 991001);
    assert.equal(db.prepare('SELECT user_id FROM userbots WHERE id=401').get().user_id, 991002);
    assert.deepEqual(db.pragma('foreign_key_check'), []);
  });
});

test('orphan data fails before destructive swap and leaves both legacy tables untouched', () => {
  const p = mkLegacy('legacy-orphan.sqlite', (db) => {
    db.prepare('INSERT INTO users (id, telegram_id) VALUES (1, 700001)').run();
    db.pragma('foreign_keys = OFF');
    db.prepare("INSERT INTO orders (id, user_id, category, qty, status) VALUES (77, 1, 'userbot', 2, 'paid')").run();
    db.prepare("INSERT INTO userbots (id, user_id, label, status) VALUES (88, 999999, 'Orphan Ubot', 'active')").run();
  });
  const output = migrateExpectFailure(p);
  assert.match(output, /orphan|dibatalkan|user_id/i);
  inspect(p, (db) => {
    assert.equal(db.prepare('SELECT user_id FROM orders WHERE id=77').get().user_id, 1);
    assert.equal(db.prepare('SELECT user_id FROM userbots WHERE id=88').get().user_id, 999999);
    assert.ok(!cols(db, 'orders').includes('processing_started_at'), 'transaction rollback must remove additive columns');
    assert.ok(!cols(db, 'users').includes('is_banned'), 'transaction rollback must remove additive user columns');
    assert.deepEqual(fkGroups(db, 'orders').map((fk) => `${fk.from[0]}->${fk.table}.${fk.to[0]}`), ['product_id->products.id', 'user_id->users.id']);
    assert.deepEqual(fkGroups(db, 'userbots').map((fk) => `${fk.from[0]}->${fk.table}.${fk.to[0]}`), ['user_id->users.id']);
  });
});

test('migration is idempotent on already-migrated current database', () => {
  const p = path.join(tmp, 'current-twice.sqlite');
  migrate(p);
  const before = inspect(p, (db) => ({
    orders: cols(db, 'orders'),
    userbots: cols(db, 'userbots'),
    ordersFk: fkGroups(db, 'orders'),
    userbotsFk: fkGroups(db, 'userbots'),
    ordersSeq: sequence(db, 'orders'),
    userbotsSeq: sequence(db, 'userbots'),
  }));
  migrate(p);
  const after = inspect(p, (db) => ({
    orders: cols(db, 'orders'),
    userbots: cols(db, 'userbots'),
    ordersFk: fkGroups(db, 'orders'),
    userbotsFk: fkGroups(db, 'userbots'),
    ordersSeq: sequence(db, 'orders'),
    userbotsSeq: sequence(db, 'userbots'),
  }));
  assert.deepEqual(after, before);
});

test('migration additive failure is not swallowed when existing column metadata disagrees', () => {
  const p = path.join(tmp, 'legacy-column-mismatch.sqlite');
  const db = new Database(p);
  db.exec(`CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER UNIQUE NOT NULL, is_banned TEXT DEFAULT 'wrong')`);
  db.close();
  const output = migrateExpectFailure(p);
  assert.match(output, /is_banned|DEFAULT|type berbeda|NOT NULL/i);
});

test('migration table creation fails fast when an existing migration table has mismatched constraints', () => {
  const p = path.join(tmp, 'legacy-migration-table-mismatch.sqlite');
  const db = new Database(p);
  db.exec(`CREATE TABLE panel_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userbot_id INTEGER NOT NULL,
    target TEXT NOT NULL,
    title TEXT,
    topic_id INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )`);
  db.close();
  const output = migrateExpectFailure(p);
  assert.match(output, /panel_groups|constraints|schema/i);
});

// Regression for the production startup crash: "users.is_banned sudah ada
// tetapi type berbeda (expected INTEGER NOT, actual INTEGER)". The declared
// type parser swallowed the NOT keyword, so any DB that already had the ALTER
// columns (i.e. every restart) refused to start.
test('restart on an already-migrated DB (existing ALTER columns, older defaults) starts cleanly', () => {
  const p = path.join(tmp, 'prod-restart.sqlite');
  migrate(p); // first boot = fresh schema + migrations
  const db = new Database(p);
  const info = (t, c) => db.prepare(`PRAGMA table_info(${t})`).all().find((x) => x.name === c);
  assert.equal(info('users', 'is_banned').type, 'INTEGER'); // the exact shape from the crash report
  db.close();
  migrate(p); // second boot must not throw
  migrate(p); // and stay stable
});
const failed = results.filter((r) => !r).length;
console.log(`\n${results.length - failed}/${results.length} passed`);
process.exit(failed ? 1 : 0);

