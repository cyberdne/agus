'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const runtime = read('src/services/userbotRuntime.service.js');
const delay = require('../src/services/delayPolicy.service');
const panel = read('src/handlers/panel.handler.js');
const index = read('src/index.js');
const menu = read('src/constants/menu.js');
const ping = read('src/handlers/ping.handler.js');
const custom = read('src/handlers/admin/customSubmenu.handler.js');

// Real production delay parser/sampler: 5-35 is inclusive and every sample
// is independently derived from the original configured range.
const range = delay.parseGroupDelayRangeInput('5-35');
assert.deepEqual(range, {min:5,max:35});
const samples = [0, .2, .51, .999999].map((r) => delay.sampleGroupDelay(range, () => r));
for (const value of samples) assert.ok(value >= 5 && value <= 35);
assert.notEqual(new Set(samples).size, 1);
assert.equal(delay.sampleGroupDelay(range, () => 0), 5);
assert.equal(delay.sampleGroupDelay(range, () => 0.999999999), 35);

// Production worker must checkpoint each next target, sample a fresh delay
// inside the target loop, and persist a next-run timestamp at round completion.
assert.match(runtime, /for\(let i=0;i<groups\.length;i\+\+\)/);
assert.match(runtime, /const groupDelay=delayPolicy\.sampleGroupDelay\(groupDelayRange\)/);
assert.match(runtime, /runtimeJobRepo\.checkpoint\(record\.kind, record\.id, job\.cycle_id/);
assert.match(runtime, /runtimeJobRepo\.complete\(record\.kind, record\.id, job\.cycle_id, \{nextRunAt\}\)/);
assert.match(runtime, /persistedAfterCycle\?\.next_run_at/);
assert.match(runtime, /scheduleAutoPromosi\(r,15000\)/);
assert.match(runtime, /promotionGeneration === record\.scheduleGeneration/);
assert.match(runtime, /cancelPromotionDelayWaits\(r\)/);
assert.match(runtime, /if\(!completed \|\| !isCurrentRun\(\)\) break/);

// Status is inline-only and callbacks are scoped to the selected userbot.
assert.match(panel, /Markup\.inlineKeyboard/);
assert.match(panel, /PANEL_PROMOTION_STATUS_REFRESH/);
assert.match(panel, /promotionInlineContext\(ctx\)/);
assert.match(panel, /state\.screen !== 'promotion_status'/);
assert.doesNotMatch(panel, /const promotionStatusKeyboard = .*Markup\.keyboard/);
assert.doesNotMatch(index, /bot\.hears\(PANEL_FEATURE\.PROMOTION_STATUS_REFRESH/);
for (const action of ['refresh','start','stop','back']) assert.match(index, new RegExp(`panel:promotion:${action}`));

// Ping editor receives a real snapshot instead of invoking its dynamic default
// with an undefined extra.ping object.
assert.match(ping, /getPingRenderContext/);
assert.match(custom, /normalizedId === 'system\.ping'/);
assert.match(custom, /getPingRenderContext\(\)/);
assert.match(custom, /db_ping/);

console.log('PROMOTION_ROUND_INLINE_PING_OK round_loop=1 random_delay=1 inline_status=1 scoped_callbacks=1 ping_context=1');
