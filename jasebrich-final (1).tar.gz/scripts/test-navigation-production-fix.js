'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const menuSource = read('src/constants/menu.js');
const adminPanel = read('src/handlers/admin/adminPanel.handler.js');
const adminKeyboard = read('src/keyboards/admin.keyboard.js');
const adminReply = read('src/middlewares/adminReply.middleware.js');
const navigation = read('src/middlewares/navigationCancellation.middleware.js');
const store = read('src/handlers/store.handler.js');
const storeKeyboard = read('src/keyboards/inline.keyboard.js');
const ubot = read('src/handlers/ubot.handler.js');
const ubotFlow = read('src/handlers/ubotFlow.handler.js');
const mainMenu = read('src/services/mainMenu.service.js');
const render = read('src/utils/render.js');

// 1. The public Store purchase callbacks carry a stable, non-visual origin
// context. Existing store-origin callbacks keep their legacy short form.
const { CALLBACK } = require(path.join(root, 'src/constants/menu'));
for (const data of [
  CALLBACK.STORE_CATEGORY('userbot', 'main'),
  CALLBACK.STORE_PRODUCT(123, 1, 'userbot', undefined, 'main'),
  CALLBACK.STORE_QTY(123, 1, 1, 'userbot', undefined, 'main'),
  CALLBACK.STORE_POLICY(123, 1, 'userbot', undefined, 'main'),
  CALLBACK.STORE_PAY(123, 1, 'userbot', undefined, 'main'),
]) {
  assert.ok(data.endsWith(':main'), `main-origin callback lost: ${data}`);
  assert.ok(Buffer.byteLength(data, 'utf8') <= 64, `callback exceeds Telegram 64-byte limit: ${data}`);
}
assert.equal(CALLBACK.STORE_PRODUCT(123, 1, 'userbot', undefined), 'store:prod:123:1:userbot');

// 2. Main-menu origin is explicit. Do not infer it from decorative text.
assert.match(mainMenu, /effectId,\n\s*'main'\n\s*\);/);
assert.match(ubot, /subscriptionRequiredKeyboard\(\),\n\s*\}, null, 'main'\);/);
assert.ok(store.includes('storeKeyboard(hasUserbot)') && store.includes("null, 'store'"), 'Store screen does not preserve store origin');
assert.match(store, /tracked\.feature === 'main' \? 'main' : 'store'/);

// 3. A pending trial resumed through "Buat Userbot" is a main-menu flow;
// an actual trial Terms flow remains explicitly trial-origin.
assert.match(ubot, /beginPhoneStep\([^\n]+\{ returnTo: 'main' \}\)/);
assert.match(ubotFlow, /beginTrialContactStep[\s\S]*return beginPhoneStep\([^\n]+\{ returnTo: 'trial' \}\)/);
assert.match(ubotFlow, /if \(state\.returnTo === 'trial'\)/);
assert.doesNotMatch(ubotFlow, /if \(state\.flow === 'trial'\) \{\n\s*buyerState\.set\([^\n]+trial_terms/);

// 4. Buyer cancellation clears only the temporary buyer/login state and
// renders the main menu in the SAME interaction.
assert.match(navigation, /if \(adminState\.get\(ctx\.from\.id\)\) return next\(\);/);
assert.match(navigation, /const \{ cancelFlow \} = require\('\.\.\/handlers\/ubotFlow\.handler'\);/);
assert.match(navigation, /if \(await cancelFlow\(ctx\)\) return;/);
assert.match(ubotFlow, /gramjsService\.cancelLogin\(ctx\.from\.id\);[\s\S]*buyerState\.clear\(ctx\.from\.id\);[\s\S]*await replyCancelled\(ctx\);[\s\S]*await require\('\.\.\/services\/mainMenu\.service'\)\.renderMainMenu\(ctx\);/);

// 5. Admin grouping is intentionally domain-based. Users and Statistics are
// direct root feature screens; only multi-feature domains get a category.
for (const label of ['👥 Users', '🤖 Userbot', '🛒 Commerce', '💳 Order & Payment', '📢 Notifications', '📊 Statistics', '⚙️ Settings']) {
  assert.ok(adminKeyboard.includes(`'${label}'`), `root admin label missing: ${label}`);
}
for (const category of ['userbot', 'commerce', 'orders', 'notifications', 'settings']) {
  assert.match(adminPanel, new RegExp(`${category}: \\{`), `grouped category missing: ${category}`);
}
assert.doesNotMatch(adminPanel, /users:\s*\{/);
assert.doesNotMatch(adminPanel, /statistics:\s*\{/);
assert.match(adminPanel, /userbot:[\s\S]*?buttons:[\s\S]*?Perpanjang Userbot/);
assert.match(adminPanel, /commerce:[\s\S]*?buttons:[\s\S]*?Stok Userbot Jaseb/);
assert.doesNotMatch(adminPanel, /settings:[\s\S]*?Perpanjang Userbot/);
assert.match(adminReply, /if \(feature === ADMIN_CALLBACK\.PRODUCT_HOME\) return \[adminCommerceCategoryCallback, 'admin:category:commerce'\];/);
assert.match(adminReply, /if \(feature === ADMIN_CALLBACK\.SUBEXT_HOME\) return \[adminUserbotCategoryCallback, 'admin:category:userbot'\];/);
assert.match(adminReply, /if \(\/\^subext:\/\.test\(feature\)\) return \[adminUserbotCategoryCallback, 'admin:category:userbot'\];/);
assert.doesNotMatch(adminReply, /\(start_sticker\|trial_settings\|premium_emoji\|join_gate\|settings_backup\|button_icons\|custom_submenu\|subext\)/);

// 6. Store back navigation consumes the caller-supplied destination instead
// of silently discarding it.
assert.match(storeKeyboard, /function buildStoreCategoryBackKeyboard\(backCallback = CALLBACK\.STORE_HOME\)/);
assert.match(storeKeyboard, /button\.danger\('🔙 Kembali', destination/);
assert.match(store, /storeCategoryBackKeyboard\(origin === 'main' \? CALLBACK\.NAV_HOME : CALLBACK\.STORE_HOME\)/);
assert.match(storeKeyboard, /CALLBACK\.STORE_PRODUCT\(p\.id, 1, productCategory, mode, origin\)/);
assert.match(storeKeyboard, /CALLBACK\.STORE_QTY\(product\.id, qty, -1, backCategory, mode, origin\)/);
assert.match(storeKeyboard, /CALLBACK\.STORE_POLICY\(product\.id, qty, backCategory, mode, origin\)/);

// 7. screenState remains the existing navigation-context store; no second
// navigation stack is introduced.
assert.match(render, /const screenState = require\('\.\.\/state\/screenState'\);/);
assert.doesNotMatch(navigation, /navigationStack|new Map\(\).*nav/i);
assert.match(render, /screenState\.set\(chatId, sent\.message_id, feature\)/);

console.log('NAVIGATION_PRODUCTION_FIX_STATIC_OK store_origin=1 buyer_cancel_single_pass=1 admin_grouping=1 subext_parent=1 callback_context=1 state_isolation_contract=1');
