const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');

const db = read('src/database/index.js');
const repo = read('src/database/repositories/broadcast.repository.js');
const service = read('src/services/broadcast.service.js');
const handler = read('src/handlers/admin/broadcast.handler.js');
const middleware = read('src/middlewares/adminBroadcast.middleware.js');
const index = read('src/index.js');
const adminReply = read('src/middlewares/adminReply.middleware.js');
const scheduler = read('src/scheduler.js');
const callbacks = read('src/constants/admin.callback.js');
const keyboard = read('src/keyboards/admin.keyboard.js');

assert(/CREATE TABLE IF NOT EXISTS broadcast_jobs/.test(db), 'broadcast_jobs migration missing');
assert(/idempotency_key TEXT NOT NULL UNIQUE/.test(db), 'broadcast job idempotency constraint missing');
assert(/target_max_user_id INTEGER/.test(db), 'broadcast target snapshot boundary missing');
assert(/CREATE TABLE IF NOT EXISTS broadcast_deliveries/.test(db), 'broadcast_deliveries migration missing');
assert(/PRIMARY KEY \(job_id, user_id\)/.test(db), 'delivery uniqueness missing');
assert(/FOREIGN KEY \(user_id\) REFERENCES users\(telegram_id\)/.test(db), 'delivery ownership FK missing');
assert(/status IN \('pending','failed'\)/.test(repo), 'delivery claim must be atomic');
assert(/attempts < \?/.test(repo), 'broadcast delivery retry budget must be bounded across restarts');
assert(/status = 'sent'/.test(repo) && /status = 'skipped'/.test(repo) && /status = 'failed'/.test(repo), 'delivery terminal states missing');
assert(/quarantineStaleSending/.test(repo), 'ambiguous sends must be quarantined');

for (const kind of ['text','photo','video','document','animation','audio','voice','sticker']) {
  assert(service.includes(`case '${kind}'`), `broadcast send support missing: ${kind}`);
}
assert(/normalizeTelegramEntities/.test(service), 'Telegram entities must be preserved');
assert(/isEntityTextInvalidError/.test(service) && /buildHtmlFallbackPayload/.test(service), 'formatting fallback missing');
assert(service.includes("['http:', 'https:']"), 'URL protocol validation missing');
assert(/ROW\s*:\s*\d+/.test(service), 'Broadcast ROW:n layout syntax missing.');
assert(/all buttons.*ROW:n|semua tombol.*ROW:n/i.test(service), 'Mixed explicit/implicit broadcast rows must be rejected deterministically.');
assert(/Buffer\.byteLength\(callbackData, 'utf8'\) > 64/.test(service), 'Broadcast callback_data Telegram limit must be validated before send.');
assert(/buildRows\(buttons, makeButton\)/.test(service), 'Broadcast preview/send must share the same row-building model.');
assert(/const reply_markup = markupWrapper\?\.reply_markup \|\| undefined/.test(service), 'Telegraf Markup wrapper must be unwrapped before direct Telegram API send.');
assert(/MAX_RETRIES = 2/.test(service), 'bounded retry policy missing');
assert(/blocked/.test(service) && /429/.test(service), 'Telegram error classification missing');
assert(/createDelivery\(job\.id, userId\)/.test(service) && /claimDelivery/.test(service), 'delivery idempotency flow missing');
assert(/resumeJobs/.test(service), 'broadcast restart recovery missing');
assert(/listBroadcastRecipientSnapshotPage/.test(service), 'broadcast must honor its captured target snapshot');
assert(/store\.renderCategoryProducts\(ctx, CATEGORIES\.RENEWAL\)/.test(handler), 'renewal action must enter the actual renewal flow');
assert(/BROADCAST_CONFIRM/.test(handler), 'broadcast confirmation action missing');
assert(/preview/.test(handler), 'broadcast preview flow missing');
assert(/admin_broadcast_content/.test(middleware), 'content middleware missing');
assert(/bot\.use\(adminBroadcastMiddleware\(\)\)/.test(index), 'broadcast middleware not wired');
assert(index.indexOf('bot.use(adminBroadcastMiddleware())') < index.indexOf('bot.use(adminFlowTextMiddleware())'), 'broadcast content capture must precede generic admin text flow');
assert(/ADMIN_CALLBACK\.BROADCAST_HOME/.test(index) && /ADMIN_CALLBACK\.BROADCAST_CONFIRM/.test(index) && /\^broadcast:action:/.test(index), 'broadcast callbacks not fully wired');
assert(/📢 Notifications/.test(keyboard) && /📣 Broadcast/.test(adminReply), 'broadcast remains accessible under the grouped Notifications category');
assert(/'📣 Broadcast'/.test(adminReply) && /'📨 Broadcast'/.test(adminReply), 'reply routing missing broadcast labels');
assert(/broadcastService\.resumeJobs\(telegram\)/.test(scheduler), 'scheduler must resume persisted broadcasts on restart');
assert(/BROADCAST_HOME: 'adminbroadcast:home'/.test(callbacks), 'broadcast callback constants missing');

console.log('BROADCAST_ADMIN_FEATURE_OK');
