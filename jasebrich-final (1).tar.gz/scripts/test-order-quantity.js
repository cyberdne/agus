'use strict';
/**
 * Quantity boundary tests (real SQLite + real schema/migrations, real
 * order.service, real store.handler). Only Telegram transport (ctx) is a
 * recording stub. Run: node scripts/test-order-quantity.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-qty-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');

const { initDatabase, getDb } = require(path.join(root, 'src/database'));
initDatabase();
const db = getDb();
const S = (p) => require(path.join(root, 'src', p));
const orderService = S('services/order.service');
const productService = S('services/product.service');
const store = S('handlers/store.handler');
const { CALLBACK } = S('constants/menu');

const USER = 501, OTHER = 502;
for (const id of [USER, OTHER]) db.prepare('INSERT INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(id, `u${id}`, `U${id}`);
const product = productService.create({ category: 'userbot', name: 'Paket Test', description: 'd', price: 25000, durationDays: 30, garansi: false });
const orderCount = () => db.prepare('SELECT COUNT(*) AS c FROM orders').get().c;
const results = [];
async function test(name, fn) {
  try { await fn(); results.push(true); console.log(`PASS  ${name}`); }
  catch (e) { results.push(false); console.log(`FAIL  ${name}\n      ${(e && e.stack) || e}`); }
}
function fakeCtx(userId, data) {
  const replies = [];
  return {
    from: { id: userId, first_name: 'U' }, chat: { id: userId, type: 'private' }, updateType: 'callback_query',
    callbackQuery: { data, message: { message_id: 5, chat: { id: userId } } }, replies,
    telegram: { sendMessage: async (id, text, o) => { replies.push({ text, o }); } },
    reply: async (text, o) => { replies.push({ text, o }); return { message_id: 1 }; },
    replyWithPhoto: async (f, o) => { replies.push({ text: o && o.caption, o }); return { message_id: 1 }; },
    editMessageText: async (text, o) => { replies.push({ text, o, edited: true }); },
    editMessageCaption: async (text, o) => { replies.push({ text, o, edited: true }); },
    deleteMessage: async () => true,
    answerCbQuery: async () => true,
  };
}
const texts = (ctx) => ctx.replies.map((r) => r.text || '').join('\n');
const INVALID = [999, 25, 0, -1, 1.5, NaN, Infinity, -Infinity, '5', '1abc', 'abc', '', null, undefined, {}, [], true, 2 ** 60];
const pay = (qty, mode) => `store:pay:${product.id}:${qty}${mode ? ':' + mode : ''}`;

(async () => {
  // -------- service boundary: createOrder itself enforces the invariant
  for (const [label, qty] of [['minimum', 1], ['normal', 6], ['maximum', 24]]) {
    await test(`createOrder accepts ${label} qty=${qty}; total/duration follow existing calculation`, () => {
      const o = orderService.createOrder({ userId: USER, product, qty });
      const row = orderService.findById(o.id);
      assert.equal(row.qty, qty);
      assert.equal(row.unit_price, 25000);
      assert.equal(row.total_price, 25000 * qty);
      assert.equal(row.duration_days, 30 * qty);
      assert.equal(row.status, 'pending');
    });
  }
  await test('createOrder rejects every invalid qty and creates NO order row', () => {
    const before = orderCount();
    for (const qty of INVALID) {
      assert.throws(() => orderService.createOrder({ userId: USER, product, qty }), (e) => e instanceof orderService.InvalidQuantityError && e.code === 'INVALID_QTY', `qty=${String(qty)}`);
    }
    assert.equal(orderCount(), before);
  });
  await test('createOrder does not clamp (999 is rejected, never stored as 24)', () => {
    assert.throws(() => orderService.createOrder({ userId: USER, product, qty: 999 }));
    assert.equal(db.prepare('SELECT COUNT(*) AS c FROM orders WHERE qty = 24 AND total_price = ?').get(25000 * 999).c, 0);
  });
  await test('renewal category goes through the same enforcement (valid ok, invalid rejected)', () => {
    const ok = orderService.createOrder({ userId: USER, product, qty: 24, category: 'renewal', targetUserbotId: null });
    assert.equal(orderService.findById(ok.id).category, 'renewal');
    const before = orderCount();
    assert.throws(() => orderService.createOrder({ userId: USER, product, qty: 25, category: 'renewal' }), orderService.InvalidQuantityError);
    assert.equal(orderCount(), before);
  });
  await test('validateQty / parseQtyStrict: strict, no coercion', () => {
    assert.equal(orderService.validateQty('1'), 1);
    assert.equal(orderService.validateQty('24'), 24);
    assert.equal(orderService.validateQty(12), 12);
    for (const bad of ['0', '25', '-1', '1.5', '1abc', 'abc', '', ' 5', '5 ', '1e1', '0x10', NaN, Infinity, null, undefined, '999999999999999999999']) assert.equal(orderService.validateQty(bad), null, String(bad));
  });

  // -------- handler boundary: forged callback data never reaches an order
  await test('forged store:pay qty (untrusted callback) is rejected, no order created', async () => {
    const before = orderCount();
    for (const q of ['999', '25', '0', '-1', '1.5', 'abc', '1abc', 'NaN', 'Infinity', '', '99999999999999999999']) {
      const ctx = fakeCtx(USER, pay(q));
      await store.storePayCallback(ctx);
      assert.match(texts(ctx), /Jumlah tidak valid/, `qty=${q}`);
    }
    assert.equal(orderCount(), before);
  });
  await test('forged store:pay in renewal mode is rejected too, no order created', async () => {
    const before = orderCount();
    const ctx = fakeCtx(USER, pay('999', 'renewal'));
    await store.storePayCallback(ctx);
    assert.equal(orderCount(), before);
  });
  await test('valid store:pay creates exactly one order with existing price calculation (min/normal/max)', async () => {
    for (const q of [1, 7, 24]) {
      const before = orderCount();
      const ctx = fakeCtx(USER, pay(q));
      await store.storePayCallback(ctx);
      assert.equal(orderCount(), before + 1, `qty=${q}`);
      const row = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 1').get(USER);
      assert.equal(row.qty, q); assert.equal(row.total_price, 25000 * q); assert.equal(row.duration_days, 30 * q);
    }
  });
  await test('forged store:prod / store:policy with invalid qty is rejected (not clamped to a valid screen)', async () => {
    for (const q of ['999', '0', '-3', '2.5', 'x']) {
      for (const cb of [`store:prod:${product.id}:${q}`, `store:policy:${product.id}:${q}`]) {
        const ctx = fakeCtx(USER, cb);
        await store[cb.startsWith('store:prod') ? 'storeProductCallback' : 'storePolicyCallback'](ctx);
        assert.match(texts(ctx), /Jumlah tidak valid/, cb);
        assert.ok(!/Bulan/.test(JSON.stringify(ctx.replies.map((r) => r.o && r.o.reply_markup))), `${cb} must not render a qty keyboard`);
      }
    }
  });
  await test('stepper: valid taps work; edges stay within 1..24; forged base/delta rejected', async () => {
    const tap = async (base, delta) => { const c = fakeCtx(USER, CALLBACK.STORE_QTY(product.id, base, delta)); await store.storeQtyCallback(c); return c; };
    const label = (c) => JSON.stringify(c.replies[0].o.reply_markup);
    assert.match(label(await tap(5, 1)), /6 Bulan/);
    assert.match(label(await tap(5, -1)), /4 Bulan/);
    assert.match(label(await tap(24, 1)), /24 Bulan/, 'max edge stays at 24');
    assert.match(label(await tap(1, -1)), /1 Bulan/, 'min edge stays at 1');
    for (const [b, d] of [[999, 0], [999, -1], [0, 1], [25, -1], [5, 5], [5, 1.5], ['abc', 0], [5, 'x']]) {
      const c = await tap(b, d);
      assert.match(texts(c), /Jumlah tidak valid/, `${b}/${d}`);
    }
  });

  const failed = results.filter((r) => !r).length;
  console.log(`\n${results.length - failed}/${results.length} passed`);
  process.exit(failed ? 1 : 0);
})();
