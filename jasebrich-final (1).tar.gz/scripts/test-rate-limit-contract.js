'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { PROFILES } = require('../src/utils/interactionRateLimiter');

const root = path.resolve(__dirname, '..');
const flood = fs.readFileSync(path.join(root, 'src/middlewares/floodGuard.middleware.js'), 'utf8');
const limiter = fs.readFileSync(path.join(root, 'src/utils/interactionRateLimiter.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'src/index.js'), 'utf8');
const tpl = fs.readFileSync(path.join(root, 'src/services/userResponseTemplate.service.js'), 'utf8');

for (const key of ['navigation', 'general', 'heavy', 'userbot', 'authentication', 'transaction', 'admin']) {
  assert(PROFILES[key], `missing rate-limit profile: ${key}`);
  assert(Number.isInteger(PROFILES[key].windowMs) && PROFILES[key].windowMs > 0);
  assert(Number.isInteger(PROFILES[key].max) && PROFILES[key].max > 0);
}
assert(PROFILES.navigation.duplicateWindowMs > 0);
assert.match(limiter, /duplicateUpdate/);
assert.match(limiter, /duplicateAction/);
assert.match(flood, /createRateLimiter/);
assert.match(flood, /getActionIdentity/);
assert.match(flood, /userResponseTpl\.rateLimitedCallback/);
assert.match(flood, /userResponseTpl\.rateLimited/);
assert.match(flood, /duplicate_update/);
assert.match(flood, /duplicate_action/);
assert.match(tpl, /system\.rate_limited/);
assert.match(tpl, /system\.rate_limited_callback/);

const ensurePos = index.indexOf('bot.use(ensureUserMiddleware())');
const banPos = index.indexOf('bot.use(banGuardMiddleware())');
const floodPos = index.indexOf('bot.use(floodGuardMiddleware())');
const startPos = index.indexOf('bot.start(startHandler)');
assert(ensurePos >= 0 && banPos > ensurePos && floodPos > banPos && startPos > floodPos, 'global flood guard must sit before handlers');

console.log('RATE_LIMIT_CONTRACT_OK context_aware=1 dedupe=1 escalation=1 admin_isolated=1 pre_handler=1 profiles=7');
