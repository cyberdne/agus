'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const previousCwd = process.cwd();
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'jasebrich-session-test-'));
process.chdir(temp);
try {
  const store = require('../src/utils/userbotSessionStorage');
  const session = '1AbCdEfGhIjKlMnOpQrStUvWxYz';

  const file = store.writeSession('userbot', 17, session);
  assert.ok(file.endsWith(path.join('data', 'userbot_sessions', 'userbot_17.txt')));
  assert.equal(store.readSession('userbot', 17), session);
  assert.equal(fs.readFileSync(file, 'utf8'), session);
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);
  assert.equal(store.readSession('pool', 17), null);

  const databaseFile = path.join(temp, 'legacy.json');
  const fakeDb = {
    updates: [],
    prepare(sql) {
      return {
        all: () => [{ id: 21, session_string: 'legacy-plaintext-session' }, { id: 22, session_string: 'enc:v1:unrecoverable' }],
        run: (id) => this.updates.push({ sql, id }),
      };
    },
  };
  const migrated = store.migrateLegacyRows(fakeDb, 'userbots', 'userbot');
  assert.equal(migrated.migrated, 1);
  assert.equal(migrated.blocked, 1);
  assert.equal(store.readSession('userbot', 21), 'legacy-plaintext-session');
  assert.equal(fakeDb.updates.length, 1);
  assert.equal(store.readSession('userbot', 22), null);

  assert.equal(store.deleteSession('userbot', 17), true);
  assert.equal(store.readSession('userbot', 17), null);

  const storagePlaceholder = store.sessionFilePath('userbot', 777);
  store.writeSession('userbot', 777, 'orphan-session');
  assert.equal(store.cleanupOrphanSessionFiles({
    prepare(sql) {
      if (sql.includes('SELECT 1 FROM userbots WHERE id = ?')) return { get: (id) => id === 21 ? { ok: 1 } : null };
      if (sql.includes('SELECT 1 FROM userbot_pool WHERE id = ?')) return { get: () => null };
      throw new Error(`Unexpected SQL in orphan cleanup test: ${sql}`);
    },
  }), 1, 'only the orphan userbot file should be removed; migrated userbot #21 remains');
  assert.equal(fs.existsSync(storagePlaceholder), false);

  console.log('SESSION_STORAGE_OK txt=1 plaintext=1 mode600=1 legacy_plaintext_migration=1 encrypted_legacy_blocked=1 orphan_cleanup=1 delete=1');
} finally {
  process.chdir(previousCwd);
  fs.rmSync(temp, { recursive: true, force: true });
}
