'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

function makeRawError(code, message = code) {
  const err = new Error(message);
  err.errorMessage = code;
  return err;
}

async function run() {
  // -----------------------------------------------------------------------
  // Static architecture checks: the actual source must place the global BAN
  // guard before commands and must not retain a raw GramJS error in user text.
  // -----------------------------------------------------------------------
  const index = read('src/index.js');
  const ensurePos = index.indexOf('bot.use(ensureUserMiddleware())');
  const banPos = index.indexOf('bot.use(banGuardMiddleware())');
  const startPos = index.indexOf('bot.start(startHandler)');
  const expiredPos = index.indexOf("bot.command('expired', expiredHandler)");
  const masaaktifPos = index.indexOf("bot.command('masaaktif', expiredHandler)");
  assert.ok(ensurePos >= 0 && banPos > ensurePos && startPos > banPos, 'BAN guard must precede /start after ensureUser');
  assert.ok(expiredPos > banPos && masaaktifPos > banPos, 'BAN guard must precede expiry commands');
  assert.equal(index.indexOf('bot.use(banGuardMiddleware())', banPos + 1), -1, 'there must be one runtime BAN guard registration');

  const ubotSource = read('src/handlers/ubotFlow.handler.js');
  assert.doesNotMatch(ubotSource, /placeholderValues:\{reason:\(err&&err\.message\)/, 'user-facing login flow must not inject raw err.message');
  assert.match(ubotSource, /err\.code === 'PHONE_CODE_EXPIRED'[\s\S]*?buyerState\.set\(ctx\.from\.id, \{ step: 'await_phone'/, 'expired OTP must reset buyer state to phone step');
  assert.match(ubotSource, /err\.code === 'OTP_ATTEMPT_LIMIT'[\s\S]*?gramjsService\.getUserFacingErrorMessage/, 'OTP limit and sanitized error path must be present');
  assert.match(ubotSource, /err\.code === 'PASSWORD_ATTEMPT_LIMIT'[\s\S]*?buyerState\.set\(ctx\.from\.id, \{ step: 'await_phone'/, '2FA limit must reset to phone step');

  const startSource = read('src/handlers/start.handler.js');
  assert.doesNotMatch(startSource, /await new Promise\(\(resolve\) => setTimeout\(resolve, START_STICKER_DISPLAY_MS\)\)/, 'start sticker must not block main flow');
  assert.match(startSource, /setTimeout\(\(\) => \{[\s\S]*?deleteMessage\(chatId, messageId\)/, 'sticker deletion must be scheduled against the exact sent message');
  assert.match(startSource, /Promise\.resolve\(ctx\.telegram\.deleteMessage\(chatId, messageId\)\)\.catch/, 'sticker delete promise must have rejection handling');

  const joinGate = read('src/middlewares/joinGate.middleware.js');
  assert.match(joinGate, /callback_query.*join_gate:retry/s, 'join gate callback exception remains documented/implemented');
  assert.match(index, /BAN MUST run before every user-facing command\/handler/);

  // -----------------------------------------------------------------------
  // Behavioral GramJS service tests. Telegram itself is the external system;
  // the test replaces only that network boundary and exercises the real
  // session lifecycle, classification, counters and cancellation code.
  // -----------------------------------------------------------------------
  const originalLoad = Module._load;
  let sendCodeBehavior = null;
  let signInBehavior = 'success';
  let passwordBehavior = 'success';
  let disconnectCount = 0;

  class StringSession {
    constructor(value) { this.value = value; }
  }

  class SignIn {
    constructor(input) { this.kind = 'SignIn'; this.input = input; }
  }
  class GetPassword {
    constructor() { this.kind = 'GetPassword'; }
  }
  class CheckPassword {
    constructor(input) { this.kind = 'CheckPassword'; this.input = input; }
  }

  class FakeTelegramClient {
    constructor() {
      this.session = { save: () => 'SESSION_STRING' };
      this.disconnected = false;
    }
    async connect() {}
    async sendCode() {
      if (sendCodeBehavior) throw sendCodeBehavior;
      return { phoneCodeHash: 'HASH' };
    }
    async invoke(req) {
      if (req.kind === 'SignIn') {
        if (signInBehavior === 'invalid') throw makeRawError('PHONE_CODE_INVALID');
        if (signInBehavior === 'expired') throw makeRawError('PHONE_CODE_EXPIRED');
        if (signInBehavior === '2fa') throw makeRawError('SESSION_PASSWORD_NEEDED');
        if (signInBehavior === 'network') throw Object.assign(new Error('ETIMEDOUT while connecting'), { code: 'ETIMEDOUT' });
        return {};
      }
      if (req.kind === 'GetPassword') return { srpB: 'B' };
      if (req.kind === 'CheckPassword') {
        if (passwordBehavior === 'invalid') throw makeRawError('PASSWORD_HASH_INVALID');
        if (passwordBehavior === 'network') throw Object.assign(new Error('ECONNRESET'), { code: 'ECONNRESET' });
        return {};
      }
      throw new Error(`unexpected fake request ${req.kind}`);
    }
    async getMe() {
      return { id: 777001, username: 'jaseb_test', firstName: 'Test', lastName: 'User', phone: '+628120000000' };
    }
    async disconnect() { this.disconnected = true; disconnectCount += 1; }
  }

  const originalConfig = path.join(root, 'src/config/index.js');
  const originalLogger = path.join(root, 'src/utils/logger.js');
  const configExports = {
    config: { telegramApiId: 12345, telegramApiHash: 'hash' },
  };
  const loggerExports = {
    info() {},
    warn() {},
    error() {},
  };
  require.cache[originalConfig] = { id: originalConfig, filename: originalConfig, loaded: true, exports: configExports };
  require.cache[originalLogger] = { id: originalLogger, filename: originalLogger, loaded: true, exports: loggerExports };

  Module._load = function patched(request, parent, isMain) {
    if (request === 'telegram') return { TelegramClient: FakeTelegramClient };
    if (request === 'telegram/sessions') return { StringSession };
    if (request === 'telegram/tl') return { Api: { auth: { SignIn }, account: { GetPassword } } , default: null, __check: CheckPassword };
    if (request === 'telegram/Password') return { computeCheck: async () => ({ srp: 'CHECK' }) };
    return originalLoad.call(this, request, parent, isMain);
  };

  // The service references Api.auth.CheckPassword. Add it to the export after
  // construction so the real service can instantiate the tested class.
  const tlExport = { Api: { auth: { SignIn, CheckPassword }, account: { GetPassword } } };
  Module._load = function patchedWithTl(request, parent, isMain) {
    if (request === 'telegram') return { TelegramClient: FakeTelegramClient };
    if (request === 'telegram/sessions') return { StringSession };
    if (request === 'telegram/tl') return tlExport;
    if (request === 'telegram/Password') return { computeCheck: async () => ({ srp: 'CHECK' }) };
    return originalLoad.call(this, request, parent, isMain);
  };

  const servicePath = path.join(root, 'src/services/gramjs.service.js');
  delete require.cache[servicePath];
  const gramjs = require(servicePath);
  assert.equal(gramjs.MAX_AUTH_ATTEMPTS, 5);

  const messages = [
    ['FLOOD_WAIT_86400', 'FLOOD_WAIT', 'hari'],
    ['PHONE_NUMBER_BANNED', 'PHONE_NUMBER_BANNED', 'diblokir'],
    ['PHONE_NUMBER_INVALID', 'PHONE_NUMBER_INVALID', 'tidak valid'],
    ['PHONE_NUMBER_FLOOD', 'PHONE_NUMBER_FLOOD', 'terlalu sering'],
    ['PHONE_CODE_INVALID', 'PHONE_CODE_INVALID', 'Kode OTP salah'],
    ['PHONE_CODE_EXPIRED', 'PHONE_CODE_EXPIRED', 'kadaluarsa'],
    ['SESSION_PASSWORD_NEEDED', '2FA_REQUIRED', '2 langkah'],
    ['PASSWORD_HASH_INVALID', 'PASSWORD_INVALID', 'Password 2FA salah'],
  ];
  for (const [raw, code, phrase] of messages) {
    const mapped = gramjs.classifyGramJsError(makeRawError(raw), 'test');
    assert.equal(mapped.code, code, `${raw} must classify as ${code}`);
    assert.match(mapped.message, new RegExp(phrase, 'i'));
    assert.doesNotMatch(mapped.message, /FLOOD_WAIT_\d+|PHONE_CODE_INVALID|PASSWORD_HASH_INVALID/);
  }
  const unknown = gramjs.classifyGramJsError(new Error('database/path/token=secret'), 'test');
  assert.equal(unknown.code, 'GRAMJS_UNKNOWN');
  assert.match(unknown.message, /tidak dapat memproses login/i);

  // Wrong OTP #1-#4 remains active; #5 cancels the real session.
  sendCodeBehavior = null;
  signInBehavior = 'invalid';
  await gramjs.startPhoneLogin(1001, '+628120000001');
  for (let i = 1; i <= 4; i += 1) {
    await assert.rejects(() => gramjs.submitOtp(1001, '00000'), (err) => err.code === 'PHONE_CODE_INVALID');
  }
  await assert.rejects(() => gramjs.submitOtp(1001, '00000'), (err) => err.code === 'OTP_ATTEMPT_LIMIT');
  await assert.rejects(() => gramjs.submitOtp(1001, '00000'), (err) => err.code === 'LOGIN_SESSION_EXPIRED');
  // A new login session for the same user resets the quota.
  signInBehavior = 'invalid';
  await gramjs.startPhoneLogin(1001, '+628120000001');
  await assert.rejects(() => gramjs.submitOtp(1001, '00000'), (err) => err.code === 'PHONE_CODE_INVALID');
  await gramjs.cancelLogin(1001);

  // User B gets a fresh, independent counter.
  await gramjs.startPhoneLogin(1002, '+628120000002');
  for (let i = 0; i < 4; i += 1) {
    await assert.rejects(() => gramjs.submitOtp(1002, '00000'), (err) => err.code === 'PHONE_CODE_INVALID');
  }
  await assert.doesNotReject(async () => {
    signInBehavior = 'success';
    const result = await gramjs.submitOtp(1002, '12345');
    assert.equal(result.sessionString, 'SESSION_STRING');
  });

  // Network failure does not consume an incorrect-credential quota.
  signInBehavior = 'network';
  await gramjs.startPhoneLogin(1003, '+628120000003');
  await assert.rejects(() => gramjs.submitOtp(1003, '00000'), (err) => err.code === 'NETWORK_ERROR');
  signInBehavior = 'invalid';
  for (let i = 0; i < 4; i += 1) {
    await assert.rejects(() => gramjs.submitOtp(1003, '00000'), (err) => err.code === 'PHONE_CODE_INVALID');
  }
  await assert.rejects(() => gramjs.submitOtp(1003, '00000'), (err) => err.code === 'OTP_ATTEMPT_LIMIT');

  // 2FA password uses the same per-session five-attempt boundary.
  signInBehavior = '2fa';
  passwordBehavior = 'invalid';
  await gramjs.startPhoneLogin(1004, '+628120000004');
  await assert.rejects(() => gramjs.submitOtp(1004, '12345'), (err) => err.code === '2FA_REQUIRED');
  for (let i = 0; i < 4; i += 1) {
    await assert.rejects(() => gramjs.submitPassword(1004, 'wrong-password'), (err) => err.code === 'PASSWORD_INVALID');
  }
  await assert.rejects(() => gramjs.submitPassword(1004, 'wrong-password'), (err) => err.code === 'PASSWORD_ATTEMPT_LIMIT');
  await assert.rejects(() => gramjs.submitPassword(1004, 'wrong-password'), (err) => err.code === 'LOGIN_SESSION_EXPIRED');

  // Password-side network errors are not counted as invalid credentials.
  signInBehavior = '2fa';
  passwordBehavior = 'network';
  await gramjs.startPhoneLogin(1005, '+628120000005');
  await assert.rejects(() => gramjs.submitOtp(1005, '12345'), (err) => err.code === '2FA_REQUIRED');
  await assert.rejects(() => gramjs.submitPassword(1005, 'password'), (err) => err.code === 'NETWORK_ERROR');
  passwordBehavior = 'invalid';
  for (let i = 0; i < 4; i += 1) {
    await assert.rejects(() => gramjs.submitPassword(1005, 'wrong-password'), (err) => err.code === 'PASSWORD_INVALID');
  }
  await assert.rejects(() => gramjs.submitPassword(1005, 'wrong-password'), (err) => err.code === 'PASSWORD_ATTEMPT_LIMIT');

  // Concurrent OTP updates are serialized so exactly the fifth invalid
  // credential owns the terminal attempt and cancels the session.
  signInBehavior = 'delayed-invalid';
  const originalInvoke = FakeTelegramClient.prototype.invoke;
  FakeTelegramClient.prototype.invoke = async function invokeWithDelay(req) {
    if (req.kind === 'SignIn' && signInBehavior === 'delayed-invalid') {
      await new Promise((resolve) => setTimeout(resolve, 10));
      throw makeRawError('PHONE_CODE_INVALID');
    }
    return originalInvoke.call(this, req);
  };
  await gramjs.startPhoneLogin(1007, '+628120000007');
  const concurrent = await Promise.allSettled(Array.from({ length: 5 }, () => gramjs.submitOtp(1007, '00000')));
  assert.equal(concurrent.filter((r) => r.status === 'rejected' && r.reason.code === 'PHONE_CODE_INVALID').length, 4);
  assert.equal(concurrent.filter((r) => r.status === 'rejected' && r.reason.code === 'OTP_ATTEMPT_LIMIT').length, 1);
  await assert.rejects(() => gramjs.submitOtp(1007, '00000'), (err) => err.code === 'LOGIN_SESSION_EXPIRED');
  FakeTelegramClient.prototype.invoke = originalInvoke;

  // PHONE_CODE_EXPIRED is cleaned by the service, not left stale.
  signInBehavior = 'expired';
  await gramjs.startPhoneLogin(1006, '+628120000006');
  await assert.rejects(() => gramjs.submitOtp(1006, '12345'), (err) => err.code === 'PHONE_CODE_EXPIRED');
  await assert.rejects(() => gramjs.submitOtp(1006, '12345'), (err) => err.code === 'LOGIN_SESSION_EXPIRED');

  // -----------------------------------------------------------------------
  // Behavioral handler test for the expired OTP UI/state transition.
  // Only external dependencies are replaced; the real handler function runs.
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // Behavioral BAN guard test. The actual middleware is exercised with a
  // small repository/admin boundary stub so banned updates cannot call next,
  // while admins and unbanned users still can.
  // -----------------------------------------------------------------------
  const banRepoPath = path.join(root, 'src/database/repositories/user.repository.js');
  const adminMiddlewarePath = path.join(root, 'src/middlewares/admin.middleware.js');
  const originalBanLoad = Module._load;
  let banned = true;
  let nextCalls = 0;
  Module._load = function banStub(request, parent, isMain) {
    if (request === '../database/repositories/user.repository') return { isBanned: () => banned };
    if (request === './admin.middleware') return { isAdminId: (id) => Number(id) === 9000 };
    return originalBanLoad.call(this, request, parent, isMain);
  };
  const banPath = path.join(root, 'src/middlewares/banGuard.middleware.js');
  delete require.cache[banPath];
  const { banGuardMiddleware } = require(banPath);
  const banGuard = banGuardMiddleware();
  const bannedMessageCtx = {
    from: { id: 8001 },
    updateType: 'message',
    replyCalls: 0,
    async reply() { this.replyCalls += 1; },
  };
  await banGuard(bannedMessageCtx, async () => { nextCalls += 1; });
  assert.equal(nextCalls, 0, 'banned message must be stopped');
  assert.equal(bannedMessageCtx.replyCalls, 1);

  const bannedCallbackCtx = {
    from: { id: 8001 },
    updateType: 'callback_query',
    async answerCbQuery() { this.alerted = true; },
  };
  await banGuard(bannedCallbackCtx, async () => { nextCalls += 1; });
  assert.equal(nextCalls, 0, 'banned callback must be stopped');
  assert.equal(bannedCallbackCtx.alerted, true);

  banned = false;
  await banGuard({ from: { id: 8001 } }, async () => { nextCalls += 1; });
  assert.equal(nextCalls, 1, 'unbanned user must continue');
  await banGuard({ from: { id: 9000 } }, async () => { nextCalls += 1; });
  assert.equal(nextCalls, 2, 'admin bypass must continue');
  Module._load = originalBanLoad;
  delete require.cache[banPath];
  delete require.cache[banRepoPath];
  delete require.cache[adminMiddlewarePath];

  const buyerStatePath = path.join(root, 'src/state/buyerState.js');
  const buyerState = require(buyerStatePath);
  const originalLoad2 = Module._load;
  const fakeGramjsForHandler = {
    cancelLogin() { this.cancelled = true; },
    getUserFacingErrorMessage() { return 'safe'; },
    async submitOtp() { const e = new Error('safe-expired'); e.code = 'PHONE_CODE_EXPIRED'; throw e; },
  };
  const fakeTemplates = {
    defineTemplate() {
      return { getContent() { return { text: 'TEMPLATE', extra: undefined }; } };
    },
    buildReplyOptions() { return {}; },
  };
  Module._load = function handlerStub(request, parent, isMain) {
    if (request === 'telegraf') return { Markup: {
      keyboard(rows) { return { reply_markup: { keyboard: rows }, resize() { return this; } }; },
      inlineKeyboard(rows) { return { reply_markup: { inline_keyboard: rows } }; },
    } };
    if (request === '../utils/buttons') return { replyButton: {
      contactRequest(label) { return { label }; },
      primary(label) { return { label }; },
      danger(label) { return { label }; },
      success(label) { return { label }; },
    } };
    if (request === '../services/gramjs.service') return fakeGramjsForHandler;
    if (request === '../services/custom-submenu.service') return fakeTemplates;
    if (request === '../services/userbot.service') return {};
    if (request === '../services/trialConfig.service') return {};
    if (request === '../services/userbotRuntime.service') return {};
    if (request === '../utils/logger') return loggerExports;
    if (request === '../services/backupToken.service') return {};
    if (request === '../utils/tokenNotice') return {};
    if (request === '../constants/menu') return { MENU: { KEMBALI: '🔙 Kembali' } };
    return originalLoad2.call(this, request, parent, isMain);
  };
  const ubotHandlerPath = path.join(root, 'src/handlers/ubotFlow.handler.js');
  delete require.cache[ubotHandlerPath];
  const ubotFlow = require(ubotHandlerPath);
  const expiredCtx = {
    from: { id: 2001 },
    chat: { id: 2001 },
    message: { message_id: 55, text: '12345' },
    telegram: { async deleteMessage() {} },
    replies: [],
    async reply(text, extra) { this.replies.push({ text, extra }); return {}; },
  };
  buyerState.set(2001, { step: 'await_otp', ownedId: 88, phone: '+628120000001', flow: 'purchase' });
  await ubotFlow.handleOtpInput(expiredCtx, buyerState.get(2001), '1 2 3 4 5');
  assert.equal(fakeGramjsForHandler.cancelled, true, 'expired OTP must cancel GramJS lifecycle');
  assert.equal(buyerState.get(2001).step, 'await_phone', 'expired OTP must move to phone input state');
  assert.ok(expiredCtx.replies.length === 1 && expiredCtx.replies[0].extra && expiredCtx.replies[0].extra.reply_markup, 'expired OTP must render phone keyboard');
  assert.ok(expiredCtx.replies[0].extra.reply_markup.keyboard.some((row) => row.some((b) => b.label === '💬 Kontak Saya')), 'phone keyboard must include contact action');
  buyerState.clear(2001);

  // -----------------------------------------------------------------------
  // Behavioral start-sticker test: no 3s await, exact message deletion,
  // handled promise rejection.
  // -----------------------------------------------------------------------
  const fakeStickerService = { getStartStickerFileId() { return 'STICKER'; } };
  const realSetTimeout = global.setTimeout;
  let scheduledDelay = null;
  let scheduledCallback = null;
  global.setTimeout = (fn, ms) => {
    scheduledCallback = fn;
    scheduledDelay = ms;
    return { unref() {} };
  };
  Module._load = function stickerStub(request, parent, isMain) {
    if (request === '../utils/errors') return { safeHandler: (fn) => fn };
    if (request === '../services/mainMenu.service') return { renderMainMenu: async () => {} };
    if (request === '../services/user.service') return { registerOrUpdateUser() {} };
    if (request === '../utils/logger') return loggerExports;
    if (request === '../services/joinGate.service') return { ensureAccess: async () => true, sendGateMessage: async () => {} };
    if (request === '../services/startSticker.service') return fakeStickerService;
    return originalLoad2.call(this, request, parent, isMain);
  };
  const startPath = path.join(root, 'src/handlers/start.handler.js');
  delete require.cache[startPath];
  const startModule = require(startPath);
  const deleted = [];
  const stickerCtx = {
    chat: { id: 9001 },
    from: { id: 9001 },
    telegram: {
      deleteMessage: async (chatId, messageId) => { deleted.push([chatId, messageId]); },
    },
    async replyWithSticker() { return { message_id: 777 }; },
  };
  const startedAt = Date.now();
  await startModule.sendStartStickerIfConfigured(stickerCtx);
  const elapsed = Date.now() - startedAt;
  assert.ok(elapsed < 100, `/start sticker helper must return without waiting 3s (elapsed=${elapsed}ms)`);
  assert.equal(scheduledDelay, 3000);
  assert.equal(deleted.length, 0, 'delete must remain scheduled, not happen inline');
  scheduledCallback();
  await Promise.resolve();
  assert.deepEqual(deleted, [[9001, 777]], 'scheduled deletion must target the exact chat/message');
  global.setTimeout = realSetTimeout;

  // Restore module loader even when all assertions above pass.
  Module._load = originalLoad;
  delete require.cache[servicePath];
  delete require.cache[ubotHandlerPath];
  delete require.cache[startPath];
  delete require.cache[originalConfig];
  delete require.cache[originalLogger];

  console.log('FINAL_PRODUCTION_REPAIR_TESTS_OK ban_order=1 otp_limit=1 otp_isolation=1 network_noncount=1 password_limit=1 expired_cleanup=1 error_mapping=1 expired_ui=1 sticker_nonblocking=1');
}

run().catch((err) => {
  try { global.setTimeout = global.setTimeout; } catch (_) {}
  console.error('FINAL_PRODUCTION_REPAIR_TESTS_FAIL');
  console.error(err && err.stack ? err.stack : err);
  process.exitCode = 1;
});
