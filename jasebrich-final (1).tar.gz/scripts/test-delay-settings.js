'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const delayPolicy = require('../src/services/delayPolicy.service');

// Test 1 + 2: inclusive random range, including both boundaries.
const range = delayPolicy.parseGroupDelayRangeInput('1-20');
assert.deepEqual(range, { min: 1, max: 20 });
for (let i = 0; i < 10000; i++) {
  const value = delayPolicy.sampleGroupDelay(range);
  assert.ok(Number.isInteger(value));
  assert.ok(value >= 1 && value <= 20, `sample out of range: ${value}`);
}
assert.equal(delayPolicy.sampleGroupDelay(range, () => 0), 1);
assert.equal(delayPolicy.sampleGroupDelay(range, () => 0.9999999999999999), 20);

// Test 3: every interval samples from the original range independently.
const sequence = [0.0, 0.5, 0.9999999999999999].map((r) => delayPolicy.sampleGroupDelay(range, () => r));
assert.deepEqual(sequence, [1, 11, 20]);
assert.notDeepEqual(sequence, [sequence[0], sequence[0], sequence[0]]);

// Test 4 + 5: round delay is a single fixed value, never a range/random value.
assert.equal(delayPolicy.normalizeRoundDelaySeconds(3600), 3600);
assert.equal(delayPolicy.readRoundDelaySeconds({ round_delay_seconds: 3600 }), 3600);
assert.equal(delayPolicy.readRoundDelaySeconds({ round_delay_seconds: 600 }), 600);
assert.equal(delayPolicy.readRoundDelaySeconds({ round_delay_seconds: 'not-a-number' }), 3600);

// Test 6: min=max produces the only possible value without randomness.
const fixed = delayPolicy.parseGroupDelayRangeInput('10-10');
assert.deepEqual(fixed, { min: 10, max: 10 });
for (let i = 0; i < 100; i++) assert.equal(delayPolicy.sampleGroupDelay(fixed, () => { throw new Error('random should not be called for min=max'); }), 10);

// Test 7: malformed, reversed, negative, non-finite, and out-of-range input is rejected.
for (const input of [
  '20-1', '0-20', '-1-20', 'abc', '10-x', '', '1--20', '1-2-3',
  '1-90000', 'Infinity-20', 'NaN-20', '1m-20s', '10.5-20',
]) {
  const parsed = delayPolicy.parseGroupDelayRangeInput(input);
  if (input === '0-20') {
    assert.deepEqual(parsed, { min: 0, max: 20 }, `existing allow-zero behavior changed for ${input}`);
  } else {
    assert.equal(parsed, null, `invalid range accepted: ${input}`);
  }
}
assert.deepEqual(delayPolicy.parseGroupDelayRangeInput('0'), { min: 0, max: 0 });
assert.deepEqual(delayPolicy.parseGroupDelayRangeInput(0), { min: 0, max: 0 });
assert.deepEqual(delayPolicy.parseGroupDelayRangeInput('15s'), { min: 15, max: 15 });
assert.deepEqual(delayPolicy.parseGroupDelayRangeInput('1m-2m'), { min: 60, max: 120 });
assert.equal(delayPolicy.normalizeGroupDelayRange(Infinity, 20), null);
assert.equal(delayPolicy.normalizeGroupDelayRange(1, NaN), null);
assert.equal(delayPolicy.normalizeGroupDelayRange(-1, 20), null);
assert.deepEqual(delayPolicy.parseGroupDelayRangeInput('1-20m'), { min: 60, max: 1200 });

// Backward compatibility: a legacy single stored integer remains fixed.
assert.deepEqual(delayPolicy.readGroupDelayRange({ group_delay_seconds: 10 }), { min: 10, max: 10 });
assert.deepEqual(delayPolicy.readGroupDelayRange({ group_delay_seconds: 5, group_delay_max_seconds: null }), { min: 5, max: 5 });

// Integration assertions against the actual production source: runtime must
// sample inside the inter-group loop and round scheduling must remain fixed.
const runtime = fs.readFileSync(path.join(__dirname, '..', 'src/services/userbotRuntime.service.js'), 'utf8');
assert.match(runtime, /const groupDelayRange=delayPolicy\.readGroupDelayRange\(/);
assert.match(runtime, /for\(let i=0;i<groups\.length;i\+\+\)/);
assert.match(runtime, /if\(i<groups\.length-1 && record\.flags\.auto_promosi\)\{/);
assert.match(runtime, /const groupDelay=delayPolicy\.sampleGroupDelay\(groupDelayRange\);/);
assert.match(runtime, /const completed=await waitPromotionDelay\(record,groupDelay\*1000\);/);
assert.doesNotMatch(runtime, /await sleep\(groupDelay\*1000\)/);
assert.match(runtime, /configForAsset\(repoFor\(record\.kind\)\.findById\(record\.id\)\)\.getRoundDelaySeconds\(record\.id\)/);
assert.match(runtime, /setTimeout\(\(\)=>waitAndRun\(roundDelay\*1000\),0\)/);
assert.doesNotMatch(runtime, /const groupDelay=Math\.max\(0,Number\(settings\.group_delay_seconds/);

// Test 8 + 9: stop/restart generation protections remain in the actual scheduler path.
assert.match(runtime, /generation!==record\.scheduleGeneration \|\| !record\.flags\.auto_promosi \|\| !record\.client/);
assert.match(runtime, /r\.scheduleGeneration=\(r\.scheduleGeneration\|\|0\)\+1/);
assert.match(runtime, /if\(r\.timer\)clearTimeout\(r\.timer\)/);
assert.match(runtime, /if\(r\.warmup\)clearTimeout\(r\.warmup\)/);
assert.match(runtime, /cancelPromotionDelayWaits\(r\)/);

// Test 10: UI messaging explicitly distinguishes random group timing vs fixed round timing.
const panel = fs.readFileSync(path.join(__dirname, '..', 'src/handlers/panel.handler.js'), 'utf8');
assert.match(panel, /acak setiap pindah grup/);
assert.match(panel, /Jeda antar putaran[\s\S]*tetap/i);
assert.match(panel, /parseGroupDelayRangeInput\(text\)/);
assert.match(panel, /updateSettings\(id,\{group_delay_range:range\}\)/);

const schema = fs.readFileSync(path.join(__dirname, '..', 'src/database/schema.js'), 'utf8');
const migration = fs.readFileSync(path.join(__dirname, '..', 'src/database/index.js'), 'utf8');
assert.match(schema, /group_delay_seconds INTEGER NOT NULL DEFAULT 10/);
assert.match(schema, /group_delay_max_seconds INTEGER/);
assert.match(migration, /ALTER TABLE panel_settings ADD COLUMN group_delay_max_seconds INTEGER/);
assert.match(migration, /UPDATE panel_settings SET group_delay_max_seconds = group_delay_seconds WHERE group_delay_max_seconds IS NULL/);

console.log('DELAY_SETTINGS_OK random_range=1 inclusive=1 independent_sampling=1 fixed_round=1 min_equals_max=1 validation=1 backward_compat=1 runtime_integration=1 cancellation_regression=1 ui=1 migration=1');
