'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const panelText = read('src/middlewares/panelText.middleware.js');
const panelConfig = read('src/services/panelConfig.service.js');
const poolPanelConfig = read('src/services/poolPanelConfig.service.js');
const runtime = read('src/services/userbotRuntime.service.js');
const icon = read('src/services/buttonIconConfig.service.js');
const keyboard = read('src/keyboards/panelControl.keyboard.js');
const menu = read('src/constants/menu.js');
const index = read('src/index.js');

assert.match(panelText, /function extractForwardSource\(message\)/);
assert.match(panelText, /forward_origin/);
assert.match(panelText, /forward_from_chat/);
assert.match(panelText, /panelKind = stateEarly\.kind === 'pool' \? 'pool' : 'owned'/);
assert.match(panelText, /poolPanelConfig/);
assert.match(panelText, /assetRepo = panelKind === 'pool' \? poolRepo : ownedRepo/);
assert.doesNotMatch(panelText, /ensureForwardAccess\('owned',ctx\.from\.id/);

assert.match(panelConfig, /function normalizeMessageKind\(rawKind\)/);
assert.match(panelConfig, /value === 'forward'/);
assert.match(panelConfig, /function parseStoredMessage\(row\)/);
assert.match(panelConfig, /function getMessage\(userbotId\)/);
assert.match(panelConfig, /return parseStoredMessage\(row\)/);
assert.match(panelConfig, /function setForwardMessage\([\s\S]*VALUES \([^)]*'forward'/);
assert.match(runtime, /msg\.kind==='forward'/);

assert.match(keyboard, /iconKey: 'Berikutnya'/);
assert.match(keyboard, /iconKey: 'Sebelumnya'/);
assert.match(keyboard, /iconKey: 'Refresh'/);
assert.match(keyboard, /iconKey: 'Kembali'/);
assert.match(icon, /stripTrailingDecorativeEmoji/);
assert.match(icon, /for \(const key of candidates\)/);
assert.match(icon, /entry\.customEmojiId/);
assert.match(icon, /stripTrailingDecorativeEmoji\(normalizedLabel\)/);
assert.doesNotMatch(keyboard, /Berikutnya[^\n]*\+?\s*\{[^}]*customEmojiId/);
assert.match(menu, /PANEL_GROUP_LIST_PAGE/);
assert.match(menu, /PANEL_GROUP_LIST_REFRESH/);
assert.match(menu, /PANEL_GROUP_LIST_BACK/);

console.log('PASS: forward lifecycle canonicalization, group pagination custom-icon lookup, and callback preservation contracts');
