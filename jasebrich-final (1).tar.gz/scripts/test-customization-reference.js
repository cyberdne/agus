'use strict';

const assert = require('node:assert/strict');

// Keep this test focused on the actual template service without requiring the
// production SQLite/Telegram runtime. The dependencies are stubbed only at
// module boundaries; no production implementation is bypassed.
const repoPath = require.resolve('../src/database/repositories/submenuCustomization.repository');
const registry = require('../src/constants/submenu.registry');
const placeholderPath = require.resolve('../src/utils/placeholders');
const loggerPath = require.resolve('../src/utils/logger');

let stored = null;
require.cache[repoPath] = {
  id: repoPath,
  filename: repoPath,
  loaded: true,
  exports: {
    findBySubmenuId: () => stored,
    upsert: () => stored,
    deleteBySubmenuId: () => {},
  },
};
require.cache[placeholderPath] = {
  id: placeholderPath,
  filename: placeholderPath,
  loaded: true,
  exports: {
    applyPlaceholders: (text, entities) => ({ text, entities: Array.isArray(entities) ? entities : [] }),
    extractPlaceholders: (text) => [...String(text).matchAll(/\{([A-Za-z0-9_]+)\}/g)].map((m) => m[1]),
    PLACEHOLDER_DOCS: [
      { token: '{userbot_id}', desc: 'ID userbot' },
      { token: '{expired_at}', desc: 'Waktu kedaluwarsa' },
    ],
  },
};
require.cache[loggerPath] = {
  id: loggerPath,
  filename: loggerPath,
  loaded: true,
  exports: { info() {}, warn() {}, error() {} },
};

const service = require('../src/services/custom-submenu.service');

registry.register({
  id: '__reference_test',
  label: 'Reference Test',
  feature: 'Test',
  defaultValue: '⛔ *Userbot* #{userbot_id}\n⏳ *{expired_at}*',
  parseMode: 'Markdown',
  supportedPlaceholders: ['userbot_id', 'expired_at'],
});

const reference = service.getTemplateReference('__reference_test', { from: { id: 1 }, chat: { id: 1 } });
assert.equal(reference.currentCustom, null);
assert.equal(reference.defaultContent.text, '⛔ *Userbot* #{userbot_id}\n⏳ *{expired_at}*');
assert.equal(reference.activeContent.text, '⛔ *Userbot* #{userbot\\_id}\n⏳ *{expired\\_at}*');
assert.equal(reference.maxLength, 4096);
assert.deepEqual(reference.placeholders.map((p) => p.token), ['{userbot_id}', '{expired_at}']);

stored = {
  submenu_id: '__reference_test',
  content_text: 'Custom *{userbot_id}*',
  content_entities: JSON.stringify([{ type: 'bold', offset: 7, length: 13 }]),
  updated_by: 1,
  updated_at: '2026-09-21 15:00:00',
};
const customReference = service.getTemplateReference('__reference_test', { from: { id: 1 }, chat: { id: 1 } });
assert.ok(customReference.currentCustom);
assert.equal(customReference.activeContent.text, 'Custom *{userbot_id}*');
assert.deepEqual(service.buildReplyOptions(customReference.activeContent), {
  entities: customReference.activeContent.entities,
});
assert.deepEqual(service.buildReplyOptions({ text: '<b>default</b>', parse_mode: 'HTML', entities: [] }), {
  parse_mode: 'HTML',
});
assert.deepEqual(service.buildCaptionOptions({ caption: '<b>default</b>', parse_mode: 'HTML', entities: [] }), {
  parse_mode: 'HTML',
});

registry.register({
  id: '__dynamic_reference_test',
  label: 'Dynamic Reference Test',
  feature: 'Statistics',
  defaultValue: (ctx, extra) => `Users: ${extra.statistics.users.total} / CPU: ${extra.statistics.system.cpuLoadPercent}%`,
  parseMode: 'HTML',
});
const dynamicReference = service.getTemplateReference('__dynamic_reference_test', { from: { id: 1 }, chat: { id: 1 } }, {
  statistics: { users: { total: 7 }, system: { cpuLoadPercent: 12.5 } },
});
assert.equal(dynamicReference.defaultContent.text, 'Users: 7 / CPU: 12.5%');
assert.equal(dynamicReference.activeContent.text, 'Users: 7 / CPU: 12.5%');

console.log('CUSTOMIZATION_REFERENCE_OK active_single_source=1 placeholder_markdown_safe=1 custom_entities_preserved=1 dynamic_default_context=1');
