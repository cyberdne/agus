'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const lifecycle = fs.readFileSync(path.join(root, 'src/services/userbotLifecycle.service.js'), 'utf8');
const runtime = fs.readFileSync(path.join(root, 'src/services/userbotRuntime.service.js'), 'utf8');
const owned = fs.readFileSync(path.join(root, 'src/database/repositories/ownedUserbot.repository.js'), 'utf8');
const pool = fs.readFileSync(path.join(root, 'src/database/repositories/userbotPool.repository.js'), 'utf8');
const ubot = fs.readFileSync(path.join(root, 'src/handlers/ubot.handler.js'), 'utf8');
const flow = fs.readFileSync(path.join(root, 'src/handlers/ubotFlow.handler.js'), 'utf8');
const backup = fs.readFileSync(path.join(root, 'src/services/backupToken.service.js'), 'utf8');

assert.match(runtime, /AUTH_KEY_UNREGISTERED\|AUTH_KEY_INVALID\|AUTH_KEY_DUPLICATED/);
assert.match(runtime, /SESSION_INVALID/);
assert.match(runtime, /new Api\.updates\.GetState\(\)/);
assert.match(runtime, /SESSION_HEALTH_INTERVAL_MS\s*=\s*60\s*\*\s*1000/);
assert.match(runtime, /verifyAssetSession/);
assert.match(runtime, /handleSessionInvalid\(kind,id\)/);

assert.match(lifecycle, /userbot\.session_invalid/);
assert.match(lifecycle, /userbot\.jaseb_session_replaced/);
assert.match(lifecycle, /userbot\.jaseb_session_replacement_unavailable/);
assert.match(lifecycle, /ownedRepo\.markSessionInvalid\(id\)/);
assert.match(lifecycle, /poolRepo\.listAvailableForPurchase\(\)/);
assert.match(lifecycle, /runtime\.verifyAssetSession\('pool', candidate\.id\)/);
assert.match(lifecycle, /runtime\.teardownAsset\('pool', candidate\.id\)/);
assert.match(lifecycle, /poolRepo\.replaceInvalidAssignment\(id, candidate\.id/);
assert.match(lifecycle, /poolRepo\.disableInvalidAssignment\(id\)/);
assert.match(lifecycle, /subscription\.isExpiredAt\(fresh\.expires_at\)/);
assert.match(lifecycle, /poolRepo\.returnExpiredToPool\(id, fresh\.expires_at, nowIso\)/);
assert.match(lifecycle, /buildReplyOptions\(content\)/);

assert.match(owned, /markSessionInvalid/);
assert.match(owned, /runtime_stop_reason = 'SESSION_INVALID'/);
assert.match(owned, /replaceSession/);
assert.match(owned, /runtime_stop_reason = CASE WHEN runtime_stop_reason = 'SESSION_INVALID' THEN NULL/);

assert.match(pool, /const RESET_CONFIG_SQL = `/);
for (const field of ['pm_permit_text','wtb_timer','wtb_auto_reset_minutes','channel_disabled','wtb_target_channel','wtb_banned_words','wtb_max_chars','wtb_filter_links','wtb_filter_usernames','auto_react','auto_react_emoji','delay_max_seconds','round_delay_seconds','auto_promosi','wtb_reply','pm_permit']) {
  assert.match(pool, new RegExp(`\\b${field.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}\\s*=`), `RESET_CONFIG_SQL missing ${field}`);
}
assert.match(pool, /replaceInvalidAssignment\(oldId, newId/);
assert.match(pool, /expires_at = \?[\s\S]*?AND expires_at > datetime\('now'\)/);
assert.match(pool, /expires_at > datetime\('now'\)/);
assert.match(pool, /candidate\.status !== 'available'/);
assert.match(pool, /SET status = 'assigned'/);
assert.match(pool, /UPDATE orders[\s\S]*category = 'jaseb'[\s\S]*fulfillment_ref = \?/);

assert.match(ubot, /runtime_stop_reason === 'SESSION_INVALID'/);
assert.match(ubot, /beginPhoneStep\(ctx\.telegram, ctx\.from\.id, invalid\.id, 'reauth'\)/);
assert.match(flow, /finalizeReauth/);
assert.match(flow, /completeRecovery/);
assert.match(backup, /replaceSession/);
assert.match(backup, /Subscription columns .* never written/s);

console.log('USERBOT_SESSION_RECOVERY_CONTRACT_OK invalid_detection=1 owned_reauth=1 pool_replace=1 expiry_preserved=1 promo_candidate_reset=1');
