'use strict';

const assert = require('node:assert/strict');
const { createRateLimiter, classifyAction, PROFILES } = require('../src/utils/interactionRateLimiter');

let now = 0;
const limiter = createRateLimiter({ maxEntries: 1000, now: () => now });

assert.equal(classifyAction('custom_submenu:list', true), 'admin');
assert.equal(classifyAction('📋 Daftar Reply & Settings', false), 'navigation');
assert.equal(classifyAction('🚀 Mulai Promosi', false), 'heavy');
assert.equal(classifyAction('store:paid:123', false), 'transaction');
assert.equal(classifyAction('panel:asset:42', false), 'heavy');
assert.equal(classifyAction('panel:settings:42', false), 'userbot');
assert.equal(classifyAction('otp:submit', false), 'authentication');

// Different users have isolated buckets.
for (let i = 0; i < PROFILES.navigation.max; i += 1) {
  assert.equal(limiter.consume({ userId: 101, chatId: 1, action: `nav:${i}`, bucket: 'navigation', updateId: i }).allowed, true);
}
assert.equal(limiter.consume({ userId: 101, chatId: 1, action: 'nav:overflow', bucket: 'navigation', updateId: 100 }).rateLimited, true);
assert.equal(limiter.consume({ userId: 202, chatId: 1, action: 'nav:ok', bucket: 'navigation', updateId: 200 }).allowed, true);

// A rapid repeat of the exact same navigation action is deduped, not rate-limited.
now = 10_000;
const first = limiter.consume({ userId: 303, chatId: 1, action: '📋 Daftar Reply & Settings', bucket: 'navigation', updateId: 301 });
assert.equal(first.allowed, true);
now += 100;
const duplicate = limiter.consume({ userId: 303, chatId: 1, action: '📋 Daftar Reply & Settings', bucket: 'navigation', updateId: 302 });
assert.equal(duplicate.duplicateAction, true);
assert.equal(duplicate.rateLimited, undefined);
now += 900;
assert.equal(limiter.consume({ userId: 303, chatId: 1, action: '📋 Daftar Reply & Settings', bucket: 'navigation', updateId: 303 }).allowed, true);

// Duplicate Telegram delivery with the same update_id is idempotently ignored.
const dupeSource = limiter.consume({ userId: 404, chatId: 1, action: 'menu:test', bucket: 'general', updateId: 500 });
assert.equal(dupeSource.allowed, true);
const dupeDelivery = limiter.consume({ userId: 404, chatId: 1, action: 'menu:test', bucket: 'general', updateId: 500 });
assert.equal(dupeDelivery.duplicateUpdate, true);

// Admin isolation: one admin can hit their own admin bucket without affecting another.
now = 20_000;
for (let i = 0; i < PROFILES.admin.max; i += 1) {
  assert.equal(limiter.consume({ userId: 1, chatId: 1, action: `admin:${i}`, bucket: 'admin', updateId: 600 + i }).allowed, true);
}
assert.equal(limiter.consume({ userId: 1, chatId: 1, action: 'admin:overflow', bucket: 'admin', updateId: 700 }).rateLimited, true);
assert.equal(limiter.consume({ userId: 2, chatId: 1, action: 'admin:ok', bucket: 'admin', updateId: 800 }).allowed, true);

console.log('RATE_LIMIT_BEHAVIOR_OK profiles=navigation/general/heavy/userbot/authentication/transaction/admin dedupe=1 update_id=1 isolation=1');
