const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
const pkg = JSON.parse(read('package.json'));

assert(pkg.scripts['test:userbot-control-panel'], 'userbot control panel test script missing');
assert(pkg.scripts['test:broadcast-admin'], 'broadcast test script missing');
assert(pkg.scripts['test:reminder-admin'], 'reminder test script missing');
assert(pkg.scripts['test:admin-new-features'], 'aggregate feature test script missing');

const index = read('src/index.js');
assert(index.includes("require('./handlers/admin/broadcast.handler')"), 'broadcast handler import missing');
assert(index.includes("require('./handlers/admin/reminder.handler')"), 'reminder handler import missing');
assert(index.includes("require('./middlewares/adminBroadcast.middleware')"), 'broadcast middleware import missing');

console.log('ADMIN_NEW_FEATURES_WIRING_OK');
