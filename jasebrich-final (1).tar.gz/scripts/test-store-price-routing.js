'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const menu = read('src/constants/menu.js');
const keyboard = read('src/keyboards/inline.keyboard.js');
const store = read('src/handlers/store.handler.js');
const product = read('src/services/product.service.js');
const order = read('src/services/order.service.js');
const repo = read('src/database/repositories/order.repository.js');
const notification = read('src/services/notification.service.js');
const adminProduct = read('src/handlers/admin/productManagement.handler.js');

assert.match(menu, /STORE_USERBOT: 'store:userbot'/);
assert.match(menu, /STORE_JASEB: 'store:jaseb'/);
assert.match(menu, /STORE_PRODUCT: \(id, qty = 1, category, mode, origin\)/);
assert.match(menu, /STORE_QTY: \(id, qty, delta, category, mode, origin\)/);
assert.match(menu, /STORE_POLICY: \(id, qty, category, mode, origin\)/);
assert.match(menu, /STORE_PAY: \(id, qty, category, mode, origin\)/);
assert.match(keyboard, /const productCategory = \(p\.category === CATEGORIES\.USERBOT \|\| p\.category === CATEGORIES\.JASEB\)/);
assert.match(keyboard, /CALLBACK\.STORE_PRODUCT\(p\.id, 1, productCategory, mode, origin\)/);
assert.match(keyboard, /storeCategoryEntryCallback\(backCategory, origin\)/);
assert.match(store, /storeUserbotCallback/);
assert.match(store, /storeJasebCallback/);
assert.match(store, /storeTpl\.userbotProductsList/);
assert.match(store, /storeTpl\.jasebProductsList/);
assert.match(store, /resolveStorePurchaseProduct\(id, category, mode\)/);
assert.match(store, /orderService\.createOrder\(\{[\s\S]*?category,[\s\S]*?mode,/);
assert.match(product, /requestedCategory !== CATEGORIES\.RENEWAL && product\.category !== requestedCategory/);
assert.match(product, /requestedCategory === CATEGORIES\.RENEWAL && product\.category !== CATEGORIES\.USERBOT/);
assert.match(order, /resolvePurchaseProduct\(product && product\.id, category, mode\)/);
assert.match(order, /catalogCategory: authoritative\.category/);
assert.match(repo, /SELECT \?, p\.id, \?, p\.name, \?, p\.price, p\.price \* \?, p\.duration_days \* \?, 'pending'/);
assert.match(repo, /p\.category = \?/);
assert.match(repo, /WHERE user_id = \? AND status IN \('pending','awaiting_confirmation'\)/);
assert.match(notification, /formatRupiah\(order\.total_price\)/);
assert.match(adminProduct, /category: state\.category/);
// No price literals may be introduced as a product-category fallback in runtime source.
assert.doesNotMatch(store, /userbotPrice\s*=\s*\d/);
assert.doesNotMatch(store, /jasebPrice\s*=\s*\d/);

console.log('STORE_PRICE_ROUTING_STATIC_OK category_bound=1 db_authoritative_price=1 order_total=1 payment_chain=1 cross_category_guard=1 pending_atomic_guard=1');
