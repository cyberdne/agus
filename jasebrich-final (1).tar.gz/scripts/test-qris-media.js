'use strict';
/** Real behavior test: an invalid persisted QRIS Telegram file_id must be
 * cleared and payment flow must fall back to the existing text renderer.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');

try { require.resolve('better-sqlite3'); require.resolve('telegraf'); } catch (_) {
  console.error('BLOCKED  QRIS_MEDIA_REAL_DB — better-sqlite3/telegraf is not installed in this environment');
  process.exit(2);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-qris-media-'));
process.env.DB_PATH = path.join(tmp, 'qris.sqlite');
process.env.BOT_TOKEN = 'test-token';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'test-hash';

const { initDatabase, getDb } = require('../src/database');
const productService = require('../src/services/product.service');
const paymentService = require('../src/services/payment.service');
const { storePayCallback } = require('../src/handlers/store.handler');

initDatabase();
const db = getDb();
const userId = 992001;
db.prepare('INSERT INTO users (telegram_id, first_name) VALUES (?,?)').run(userId, 'QRIS Test');
const product = productService.create({ category: 'userbot', name: 'QRIS Fallback', description: 'test', price: 5000, durationDays: 30, garansi: false });
paymentService.setQrisFileId('BAIK_TAPI_TIDAK_VALID');
paymentService.setQrisNote('QRIS');
paymentService.setBankInfo('Bank test');

const replies = [];
const ctx = {
  from: { id: userId, first_name: 'QRIS Test', username: 'qris_test' },
  chat: { id: userId, type: 'private' },
  callbackQuery: { data: `store:pay:${product.id}:1:userbot`, message: { chat: { id: userId, type: 'private' }, message_id: 42 } },
  answerCbQuery: async () => {},
  replyWithPhoto: async () => { const err = new Error('400: Bad Request: wrong file identifier/HTTP URL specified'); err.description = 'Bad Request: wrong file identifier/HTTP URL specified'; throw err; },
  reply: async (text, options) => { replies.push({ text, options }); return { message_id: 43 }; },
  editMessageText: async () => {},
};

(async () => {
  await storePayCallback(ctx);
  const savedOrder = db.prepare('SELECT status, expires_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 1').get(userId);
  assert.equal(savedOrder.status, 'pending');
  assert.ok(savedOrder.expires_at);
  assert.equal(paymentService.getQrisFileId(), null);
  assert.equal(replies.length, 1);
  assert.match(replies[0].text, /Pembayaran Order/);
  assert.match(replies[0].text, /QRIS|Bank test/);
  console.log('PASS  invalid QRIS file_id is cleared and existing payment text flow is used');
  console.log('PASS  invalid QRIS media does not delete/cancel the real pending order');
  process.exit(0);
})().catch((err) => {
  console.error('FAIL ', err && err.stack || err);
  process.exit(1);
});
