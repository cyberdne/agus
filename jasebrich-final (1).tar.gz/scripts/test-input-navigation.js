'use strict';
/**
 * Input-navigation regression tests. Real modules end to end: real SQLite +
 * schema, real state modules, real handlers, real keyboards, real middlewares
 * (composed in the same order as src/index.js). Only the Telegram transport
 * (ctx) is a recording stub. Run: node scripts/test-input-navigation.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-nav-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');
const S = (p) => require(path.join(root, 'src', p));

S('database').initDatabase();
const adminState = S('state/adminState');
const buyerState = S('state/buyerState');
const tokenClaimState = S('state/tokenClaimState');
const panelState = S('state/panelState');
const flows = S('constants/adminInputFlows');
const { MENU } = S('constants/menu');
const nav = S('utils/navDebounce');
const { adminReplyMiddleware } = S('middlewares/adminReply.middleware');
const { customSubmenuTextMiddleware } = S('middlewares/customSubmenuText.middleware');
const flowMw = S('middlewares/adminFlow.middleware');
const { ubotLoginTextMiddleware } = S('middlewares/ubotLoginText.middleware');
const { tokenClaimTextMiddleware } = S('middlewares/tokenClaimText.middleware');
const product = S('handlers/admin/productManagement.handler');
const pool = S('handlers/admin/poolManagement.handler');
const buttonIcons = S('services/buttonIconConfig.service');

const ADMIN = 900, USER = 501;
const results = [];
async function test(name, fn) {
  try { nav.reset(); await fn(); results.push(true); console.log(`PASS  ${name}`); }
  catch (e) { results.push(false); console.log(`FAIL  ${name}\n      ${(e && e.stack) || e}`); }
}

function makeCtx(userId, message, extra = {}) {
  const replies = [];
  const ctx = {
    from: { id: userId, first_name: 'T' }, chat: { id: userId }, msgId: 1,
    updateType: 'message', message, update: { message }, replies,
    telegram: { deleteMessage: async () => true, sendMessage: async (id, text, o) => { replies.push({ text, extra: o }); return { message_id: 9 }; } },
    get callbackQuery() { return this.update.callback_query; },
    answerCbQuery: async () => true,
    reply: async (text, o) => { replies.push({ text, extra: o }); return { message_id: replies.length }; },
    ...extra,
  };
  return ctx;
}
const kbLabels = (extra) => ((extra && extra.reply_markup && extra.reply_markup.keyboard) || []).flat().map((b) => (typeof b === 'string' ? b : b.text));
const lastKb = (ctx) => { for (let i = ctx.replies.length - 1; i >= 0; i--) { const l = kbLabels(ctx.replies[i].extra); if (l.length) return l; } return []; };

// Same relative order as src/index.js.
async function dispatch(ctx) {
  const chain = [adminReplyMiddleware(), customSubmenuTextMiddleware(), flowMw.adminFlowTextMiddleware(), flowMw.adminFlowDocumentMiddleware(),
    ubotLoginTextMiddleware(), tokenClaimTextMiddleware()];
  if (ctx.message.photo) chain.push(flowMw.adminFlowPhotoMiddleware());
  if (ctx.message.sticker) chain.push(flowMw.adminFlowStickerMiddleware());
  chain.push(flowMw.adminFlowMismatchMiddleware());
  let fell = false;
  let i = 0;
  const next = async () => { const mw = chain[i++]; if (!mw) { fell = true; return; } return mw(ctx, next); };
  await next();
  return { fell };
}
const say = async (userId, text) => { const ctx = makeCtx(userId, { message_id: 5, text }); const r = await dispatch(ctx); return { ctx, ...r }; };
async function startProductAdd() {
  const ctx = makeCtx(ADMIN, undefined);
  ctx.update = { callback_query: { data: 'adminproduct:add:userbot', message: { message_id: 3 } } };
  await product.productAddCallback(ctx);
  return ctx;
}

(async () => {
  await test('inventory: every adminState action in source has a flow definition', () => {
    const dir = path.join(root, 'src/handlers/admin');
    const found = new Set();
    for (const f of fs.readdirSync(dir)) {
      const src = fs.readFileSync(path.join(dir, f), 'utf8');
      for (const m of src.matchAll(/adminState\.set\([^;]*?action:\s*'([a-z_]+)'/gs)) found.add(m[1]);
    }
    assert.ok(found.size >= 20, `expected many actions, saw ${found.size}`);
    for (const a of found) assert.ok(flows.getFlow(a), `no input flow for ${a}`);
  });

  await test('inventory: every flow has an exit path (Kembali + Batal) in its keyboard', () => {
    for (const action of Object.keys(flows.FLOWS)) {
      const spec = flows.navSpec({ action }).flat().map((b) => b.type);
      assert.ok(spec.includes('back') && spec.includes('cancel'), action);
      assert.ok(flows.resolveBack({ action, category: 'userbot', productId: 1, telegramId: 1, token: 'a'.repeat(10), userbotId: 1, submenuId: 's' }), action);
    }
  });

  await test('Lewati exists only on optional steps', () => {
    const withSkip = Object.entries(flows.FLOWS).filter(([, f]) => f.skip).map(([a]) => a).sort();
    assert.deepEqual(withSkip, ['admin_product_add_desc', 'admin_user_ban_reason']);
  });

  await test('product add: prompt + keyboard per step, Kembali keeps data, invalid retry keeps keyboard', async () => {
    const c0 = await startProductAdd();
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_name');
    assert.deepEqual(lastKb(c0), ['🔙 Kembali', '❌ Batal']);
    await say(ADMIN, 'Paket A');
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_price');
    const bad = await say(ADMIN, 'abc');
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_price', 'invalid input stays on the step');
    assert.match(bad.ctx.replies[0].text, /^❌/);
    assert.deepEqual(kbLabels(bad.ctx.replies[0].extra), ['🔙 Kembali', '❌ Batal'], 'error carries step keyboard');
    await say(ADMIN, '15000');
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_duration');
    nav.reset();
    const back = await say(ADMIN, MENU.KEMBALI);
    const st = adminState.get(ADMIN);
    assert.equal(st.action, 'admin_product_add_price');
    assert.equal(st.name, 'Paket A', 'earlier valid data preserved');
    assert.equal(st.price, 15000);
    assert.match(back.ctx.replies[0].text, /Langkah 2\/6/);
    adminState.clear(ADMIN);
  });

  await test('product add: Kembali from first step returns to the category list and clears state', async () => {
    await startProductAdd();
    nav.reset();
    const r = await say(ADMIN, MENU.KEMBALI);
    assert.equal(adminState.get(ADMIN), null);
    assert.ok(r.ctx.replies.some((x) => /Produk/.test(x.text)));
    assert.ok(lastKb(r.ctx).length > 0, 'a reply keyboard belonging to the new screen is installed');
    const after = await say(ADMIN, 'stray text');
    assert.ok(after.fell, 'old wizard no longer captures input');
  });

  await test('product add: Batal clears whole wizard; next message is not consumed', async () => {
    await startProductAdd();
    await say(ADMIN, 'Paket B');
    const r = await say(ADMIN, MENU.BATAL);
    assert.equal(adminState.get(ADMIN), null);
    assert.ok(lastKb(r.ctx).length > 0);
    assert.ok((await say(ADMIN, '15000')).fell);
  });

  await test('product add: Lewati Deskripsi really advances to Feature Access; Kembali there returns to description', async () => {
    await startProductAdd();
    adminState.set(ADMIN, { action: 'admin_product_add_desc', category: 'userbot', name: 'N', price: 1000, durationDays: 30, garansi: false });
    assert.deepEqual(flows.navSpec(adminState.get(ADMIN)).flat().map((b) => b.label), ['⏭️ Lewati Deskripsi', '🔙 Kembali', '❌ Batal']);
    const r = await say(ADMIN, '⏭️ Lewati Deskripsi');
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_features');
    assert.equal(adminState.get(ADMIN).description, '');
    assert.ok(r.ctx.replies.some((x) => x.extra && x.extra.reply_markup && x.extra.reply_markup.inline_keyboard), 'inline checklist shown');
    assert.deepEqual(lastKb(r.ctx), ['🔙 Kembali', '❌ Batal'], 'reply keyboard now belongs to the features step');
    nav.reset();
    const back2 = (await say(ADMIN, MENU.KEMBALI)).ctx;
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_desc');
    assert.deepEqual(lastKb(back2).slice(0, 1), ['⏭️ Lewati Deskripsi']);
    adminState.clear(ADMIN);
  });

  await test('double tap: duplicate Kembali within the window steps back only once', async () => {
    adminState.set(ADMIN, { action: 'admin_product_add_duration', category: 'userbot', name: 'N', price: 1000 });
    const ctxA = makeCtx(ADMIN, { message_id: 6, text: MENU.KEMBALI });
    const ctxB = makeCtx(ADMIN, { message_id: 7, text: MENU.KEMBALI });
    await dispatch(ctxA); await dispatch(ctxB);
    assert.equal(adminState.get(ADMIN).action, 'admin_product_add_price');
    assert.equal(ctxB.replies.length, 0, 'duplicate produces no output');
    adminState.clear(ADMIN);
  });

  await test('pool: method -> label -> phone; session Kembali -> method preserves label; OTP Kembali -> phone', async () => {
    adminState.set(ADMIN, { action: 'admin_pool_label', method: 'phone' });
    await say(ADMIN, 'Slot 1');
    let st = adminState.get(ADMIN);
    assert.equal(st.action, 'admin_pool_phone');
    assert.equal(st.method, 'phone');
    const bad = await say(ADMIN, '12');
    assert.deepEqual(kbLabels(bad.ctx.replies[bad.ctx.replies.length - 1].extra), ['💬 Kontak Saya', '🔙 Kembali', '❌ Batal']);
    nav.reset();
    await say(ADMIN, MENU.KEMBALI);
    st = adminState.get(ADMIN);
    assert.equal(st.action, 'admin_pool_label');
    assert.equal(st.label, 'Slot 1');
    assert.equal(st.method, 'phone');

    adminState.set(ADMIN, { action: 'admin_pool_session', label: 'Slot 1', method: 'session' });
    nav.reset();
    const sessionBack = await say(ADMIN, MENU.KEMBALI);
    st = adminState.get(ADMIN);
    assert.equal(st.action, 'admin_pool_method');
    assert.equal(st.label, 'Slot 1');
    assert.ok(sessionBack.ctx.replies.length > 0, 'session back re-renders method selector');

    adminState.set(ADMIN, { action: 'admin_pool_otp', label: 'Slot 1', phone: '+628123456789', method: 'phone' });
    nav.reset();
    const r = await say(ADMIN, MENU.KEMBALI);
    st = adminState.get(ADMIN);
    assert.equal(st.action, 'admin_pool_phone');
    assert.equal(st.label, 'Slot 1');
    assert.ok(lastKb(r.ctx).includes('💬 Kontak Saya'));
    const otp = await say(ADMIN, '1 2 3 4 5');
    assert.notEqual((adminState.get(ADMIN) || {}).action, 'admin_pool_otp', 'stale OTP state must not capture messages');
    adminState.clear(ADMIN);
  });

  await test('single-step inputs: Kembali returns to parent, clears state, leaves a keyboard for the parent', async () => {
    for (const action of ['admin_payment_note', 'admin_payment_bank', 'admin_trial_duration', 'admin_start_sticker', 'admin_user_search', 'admin_user_add',
      'admin_join_gate_channel', 'admin_join_gate_group', 'admin_premium_emoji_garansi', 'admin_premium_emoji_nongaransi', 'admin_payment_qris_photo', 'admin_settings_backup_import']) {
      adminState.set(ADMIN, { action });
      nav.reset();
      const r = await say(ADMIN, MENU.KEMBALI);
      assert.equal(adminState.get(ADMIN), null, `${action} state cleared`);
      assert.ok(r.ctx.replies.length > 0 && lastKb(r.ctx).length > 0, `${action} shows parent + keyboard`);
      assert.ok(!lastKb(r.ctx).includes('🔙 Kembali'), `${action} input keyboard is gone`);
    }
  });

  await test('every contextual Batal label clears its state', async () => {
    for (const [action, f] of Object.entries(flows.FLOWS)) {
      if (action === 'previewing') continue;
      adminState.set(ADMIN, { action, category: 'userbot', productId: 1, telegramId: 7, token: 'a'.repeat(10), userbotId: 1, submenuId: 'store', returnTo: 'list' });
      await say(ADMIN, f.cancel);
      assert.equal(adminState.get(ADMIN), null, `${action} cancelled by "${f.cancel}"`);
    }
  });

  await test('photo/sticker/document steps: text and wrong media are answered in place with the step keyboard', async () => {
    adminState.set(ADMIN, { action: 'admin_start_sticker' });
    const t = await say(ADMIN, 'halo');
    assert.equal(adminState.get(ADMIN).action, 'admin_start_sticker');
    assert.match(t.ctx.replies[0].text, /sticker/i);
    assert.deepEqual(kbLabels(t.ctx.replies[0].extra), ['🔙 Kembali', '❌ Batal']);
    const ctx = makeCtx(ADMIN, { message_id: 8, photo: [{ file_id: 'x' }] });
    await dispatch(ctx);
    assert.match(ctx.replies[0].text, /^❌ Input tidak sesuai/);
    assert.deepEqual(kbLabels(ctx.replies[0].extra), ['🔙 Kembali', '❌ Batal']);
    assert.equal(adminState.get(ADMIN).action, 'admin_start_sticker');
    adminState.clear(ADMIN);
  });

  await test('stale/no state: Kembali & Lewati do nothing dangerous and fall through', async () => {
    adminState.clear(ADMIN);
    assert.ok((await say(ADMIN, MENU.KEMBALI)).fell);
    assert.ok((await say(ADMIN, '⏭️ Lewati Deskripsi')).fell);
  });

  await test('expired admin state (TTL) is not revived by a stale Kembali', async () => {
    adminState.set(ADMIN, { action: 'admin_product_add_price', category: 'userbot', name: 'N' });
    const real = Date.now; Date.now = () => real() + 11 * 60 * 1000;
    try {
      const r = await say(ADMIN, MENU.KEMBALI);
      assert.ok(r.fell);
      assert.equal(adminState.get(ADMIN), null);
    } finally { Date.now = real; }
  });

  await test('non-admin cannot use admin Kembali/Lewati routes', async () => {
    adminState.set(USER, { action: 'admin_product_add_price', category: 'userbot' });
    const r = await say(USER, MENU.KEMBALI);
    assert.ok(r.fell);
    adminState.clear(USER);
  });

  await test('custom submenu: Kembali honours returnTo; preview Kembali reopens input', async () => {
    adminState.set(ADMIN, { action: 'waiting_for_custom_text', submenuId: 'store', pendingContent: null, returnTo: 'list' });
    const r = await say(ADMIN, MENU.KEMBALI);
    assert.equal(adminState.get(ADMIN), null);
    assert.ok(r.ctx.replies.length > 0);
    adminState.set(ADMIN, { action: 'previewing', submenuId: 'store', pendingContent: { text: 'x', entities: [] }, returnTo: 'list' });
    nav.reset();
    await say(ADMIN, MENU.KEMBALI);
    const st = adminState.get(ADMIN);
    assert.equal(st.action, 'waiting_for_custom_text');
    assert.equal(st.pendingContent, null);
    adminState.clear(ADMIN);
  });

  await test('buyer login: OTP invalid keeps keyboard; Kembali -> phone (login cancelled); old OTP step no longer active', async () => {
    buyerState.set(USER, { step: 'await_otp', ownedId: null, phone: '+628123456789', flow: 'purchase' });
    const bad = await say(USER, 'zz');
    assert.equal(buyerState.get(USER).step, 'await_otp');
    assert.deepEqual(kbLabels(bad.ctx.replies[0].extra), ['🔙 Kembali', '❌ Batalkan']);
    const back = await say(USER, MENU.KEMBALI);
    assert.equal(buyerState.get(USER).step, 'await_phone');
    assert.deepEqual(lastKb(back.ctx), ['💬 Kontak Saya', '🔙 Kembali', '❌ Batalkan']);
    nav.reset();
    const stale = await say(USER, '1 2 3 4 5');
    assert.equal(buyerState.get(USER).step, 'await_phone', 'old OTP step no longer active');
    buyerState.clear(USER);
  });

  await test('buyer login: trial phone Kembali -> Terms with its own keyboard; state is trial_terms', async () => {
    buyerState.set(USER, { step: 'await_phone', ownedId: 1, flow: 'trial' });
    const r = await say(USER, MENU.KEMBALI);
    assert.equal(buyerState.get(USER).step, 'trial_terms');
    assert.ok(lastKb(r.ctx).some((l) => /Saya Setuju/.test(l)));
    assert.ok(!lastKb(r.ctx).includes('🔙 Kembali'), 'terms has no Kembali (trial already claimed)');
    buyerState.clear(USER);
  });

  await test('token claim: Kembali leaves the flow silently; token is never the word "Kembali"; Batal cancels', async () => {
    tokenClaimState.set(USER, { step: 'await_token' });
    await say(USER, MENU.KEMBALI);
    assert.equal(tokenClaimState.get(USER), null);
    tokenClaimState.set(USER, { step: 'await_token' });
    const bad = await say(USER, 'NOPE-123');
    assert.ok(tokenClaimState.get(USER), 'retry keeps the flow open');
    assert.deepEqual(kbLabels(bad.ctx.replies[0].extra), ['🔙 Kembali', '❌ Batal']);
    await say(USER, '❌ Batal');
    assert.equal(tokenClaimState.get(USER), null);
  });

  await test('panel: Tambah Reply step 2 Kembali -> step 1 keeps keywords; other steps -> origin screen', async () => {
    const h = S('handlers/panel.handler');
    panelState.set(USER, { kind: 'owned', id: 1, step: 'await_add_reply_text', screen: 'reply', pendingReplyKeywords: 'harga,wtb', adminMode: false });
    const ctx = makeCtx(USER, { message_id: 3, text: MENU.KEMBALI });
    await h.inputBack(ctx, panelState.get(USER));
    const st = panelState.get(USER);
    assert.equal(st.step, 'await_add_reply_keyword');
    assert.equal(st.pendingReplyKeywords, 'harga,wtb');
    assert.deepEqual(lastKb(ctx), ['🔙 Kembali', '❌ Batal']);
    panelState.clear(USER);
  });

  await test('custom icon: customized Kembali label still resolves back to the routing label', async () => {
    S('keyboards/admin.keyboard').adminInputKeyboard({ action: 'admin_pool_phone' }); // registers labels
    buttonIcons.setIcon('🔙 Kembali', '⬅️');
    const rendered = S('keyboards/admin.keyboard').adminInputKeyboard({ action: 'admin_pool_phone' });
    const back = rendered.reply_markup.keyboard.flat().find((b) => /Kembali/.test(b.text));
    assert.ok(back.text.includes('⬅️'), 'icon applied at render time (not frozen)');
    assert.equal(buttonIcons.resolveIncomingButtonLabel(back.text), '🔙 Kembali');
    assert.ok(back.style, 'style preserved');
    buttonIcons.removeIcon && buttonIcons.removeIcon('🔙 Kembali');
  });

  const passed = results.filter(Boolean).length;
  console.log(`\n${passed}/${results.length} passed`);
  process.exit(passed === results.length ? 0 : 1);
})();
