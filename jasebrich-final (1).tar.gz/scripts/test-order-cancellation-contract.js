'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const repo = read('src/database/repositories/order.repository.js');
const service = read('src/services/order.service.js');
const store = read('src/handlers/store.handler.js');
const nav = read('src/middlewares/navigationCancellation.middleware.js');
const kb = read('src/keyboards/inline.keyboard.js');
const menu = read('src/constants/menu.js');
const index = read('src/index.js');

assert.match(repo, /function findOpenOrdersByUser\(userId, nowIso = null\)/);
assert.match(repo, /WHERE user_id = \?\s+AND status IN \('pending','awaiting_confirmation'\)/);
assert.match(repo, /AND expires_at IS NOT NULL\s+AND datetime\(expires_at\) > datetime\('now'\)/);
assert.match(repo, /NOT EXISTS \(\s*SELECT 1 FROM orders WHERE user_id = \? AND status IN \('pending','awaiting_confirmation'\)/);
assert.match(repo, /SET status = 'awaiting_confirmation'[\s\S]*WHERE id = \?[\s\S]*AND status = 'pending'/);
assert.match(repo, /UPDATE orders SET status = 'cancelled'.*WHERE id = \? AND user_id = \? AND status = 'pending'/s);
assert.match(repo, /function cancelAllOwnedPending\(userId\)/);
assert.match(repo, /WHERE user_id = \? AND status = 'pending'/s);

assert.match(service, /this\.orders = orders/);
assert.match(service, /findOpenOrdersByUser\(userId\)/);
assert.match(service, /function cancelAllOwnPendingOrders/);
assert.match(service, /function refreshOrder\(orderId, nowIso = null\)/);
assert.match(service, /function expireStaleOrders\(nowIso = null\)/);
assert.match(repo, /datetime\(expires_at\) > datetime\('now'\)/);

assert.match(store, /renderPendingOrderRecovery/);
assert.match(store, /storeResumeCallback/);
assert.match(store, /showPaymentCancelConfirmation/);
assert.match(store, /buyerState\.set\(ctx\.from\.id, \{ step: 'await_payment'/);
assert.match(store, /orderService\.cancelOwnOrder\(\{ orderId, userId: ctx\.from\.id \}\)/);
assert.match(store, /const storeCancelYesCallback = safeHandler/);
assert.match(store, /if \(!result\.ok\) \{\s*buyerState\.clear\(ctx\.from\.id\)/);
assert.match(store, /stale\/double callback/);
assert.match(store, /if \(ctx\.callbackQuery\) await ctx\.answerCbQuery\(\);/);
assert.doesNotMatch(store, /paymentService\.getQrisFileId\(\)[\s\S]{0,900}catch \(_\) \{\}/);
assert.match(store, /await renderStoreScreen\(ctx\);/);
assert.match(store, /buyerState\.set\(ctx\.from\.id, \{ step: 'await_payment_cancel_confirm'/);
assert.match(store, /storeCancelAllYesCallback/);
assert.match(store, /status !== 'pending'/);

assert.match(nav, /buyer\.step === 'await_payment'/);
assert.match(nav, /showPaymentCancelConfirmation/);
assert.match(nav, /await_payment_cancel_confirm/);

assert.match(kb, /STORE_RESUME/);
assert.match(kb, /STORE_STATUS/);
assert.match(kb, /STORE_CANCEL_ALL/);
assert.match(menu, /STORE_RESUME: \(orderId\) => `store:resume:\$\{orderId\}`/);
assert.match(menu, /STORE_CANCEL_ALL: 'store:cancel_all'/);
assert.match(index, /bot\.action\(\/\^store:resume:\/\, storeResumeCallback\)/);
assert.match(index, /bot\.action\(CALLBACK\.STORE_CANCEL_ALL, storeCancelAllCallback\)/);

console.log('ORDER_CANCELLATION_CONTRACT_OK pending_cas=1 bulk_recovery=1 payment_state=1 actionable_pending=1 ownership_checks=1');
