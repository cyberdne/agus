'use strict';

const assert = require('node:assert/strict');
const registry = require('../src/constants/submenu.registry');

// A missing maxLength is metadata omission, not a zero-length template.
registry.register({
  id: '__test_default_limit',
  label: 'Test Default Limit',
  defaultValue: 'Default {id}',
});
assert.equal(registry.getById('__test_default_limit').maxLength, 4096);

registry.register({
  id: '__test_caption_limit',
  label: 'Test Caption Limit',
  messageType: 'caption',
  defaultValue: 'Caption default',
});
assert.equal(registry.getById('__test_caption_limit').maxLength, 1024);

registry.register({
  id: '__test_caption_or_text_limit',
  label: 'Test Caption Or Text Limit',
  messageType: 'caption_or_text',
  defaultValue: 'Caption or text default',
});
assert.equal(registry.getById('__test_caption_or_text_limit').maxLength, 1024);

registry.register({
  id: '__test_callback_limit',
  label: 'Test Callback Limit',
  messageType: 'callback_alert',
  defaultValue: 'Callback default',
});
assert.equal(registry.getById('__test_callback_limit').maxLength, 200);

assert.throws(
  () => registry.register({ id: '__test_zero', label: 'Invalid', defaultValue: 'x', maxLength: 0 }),
  /invalid maxLength/
);
assert.throws(
  () => registry.register({ id: '__test_negative', label: 'Invalid', defaultValue: 'x', maxLength: -1 }),
  /invalid maxLength/
);
assert.throws(
  () => registry.register({ id: '__test_no_default', label: 'Invalid' }),
  /real defaultValue/
);

console.log('CUSTOMIZATION_METADATA_OK missing_limit_fallback=4096 caption=1024 caption_or_text=1024 callback=200 invalid_zero_rejected=1');
