'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const files = [];
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const st = fs.statSync(full);
    if (st.isDirectory()) walk(full);
    else if (full.endsWith('.js')) files.push(full);
  }
}
walk(path.join(root, 'src'));

const publicFiles = files.filter((f) => !f.includes(`${path.sep}handlers${path.sep}admin${path.sep}`));
const defs = [];
function extractCallArgs(text, openIndex) {
  let depth = 1;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = openIndex + 1; i < text.length; i += 1) {
    const ch = text[i];
    const next = text[i + 1];
    if (lineComment) { if (ch === '\n') lineComment = false; continue; }
    if (blockComment) { if (ch === '*' && next === '/') { blockComment = false; i += 1; } continue; }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (ch === '\\') { escaped = true; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '/' && next === '/') { lineComment = true; i += 1; continue; }
    if (ch === '/' && next === '*') { blockComment = true; i += 1; continue; }
    if (ch === '\'' || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === '(') depth += 1;
    else if (ch === ')') { depth -= 1; if (depth === 0) return text.slice(openIndex + 1, i); }
  }
  throw new Error('unclosed call');
}

const registry = fs.readFileSync(path.join(root, 'src/constants/submenu.registry.js'), 'utf8');
assert.match(registry, /scope:\s*'USER'/);
assert.match(registry, /editable:\s*true/);
assert.match(registry, /defaultMaxLengthForMessageType/);

for (const file of publicFiles) {
  const text = fs.readFileSync(file, 'utf8');
  const re = /define(?:Template|Submenu)\s*\(/g;
  let m;
  while ((m = re.exec(text))) {
    const args = extractCallArgs(text, m.index + m[0].length - 1);
    const idMatch = args.match(/^\s*(['"])([^'"\n]+)\1/);
    if (idMatch) defs.push({ id: idMatch[2], args, file: path.relative(root, file) });
  }
}
assert(defs.length >= 200, `customizable USER inventory unexpectedly small: ${defs.length}`);
const duplicateIds = defs.map((d) => d.id).filter((id, i, arr) => arr.indexOf(id) !== i);
assert.deepEqual(duplicateIds, []);

const placeholderSource = fs.readFileSync(path.join(root, 'src/utils/placeholders.js'), 'utf8');
const baseMatch = placeholderSource.match(/BASE_PLACEHOLDERS\s*=\s*new Set\(\[([\s\S]*?)\]\)/);
assert(baseMatch, 'BASE_PLACEHOLDERS registry missing from placeholders.js');
const base = new Set([...baseMatch[1].matchAll(/['"]([A-Za-z0-9_]+)['"]/g)].map((x) => x[1]));
assert(base.size >= 70);

const requiredIds = [
  'control_panel_main', 'control_panel_base_reply', 'control_panel_message', 'control_panel_group',
  'control_panel_delay', 'control_panel_extra', 'control_panel_guide', 'control_panel_select_asset',
  'create_ubot', 'token.new_token_notice', 'userbot.session_invalid',
  'userbot.jaseb_session_replaced', 'userbot.jaseb_session_replacement_unavailable',
  'system.custom_input_invalid', 'system.rate_limited', 'system.rate_limited_callback',
];
for (const id of requiredIds) assert(defs.some((d) => d.id === id), `customization entry missing: ${id}`);

for (const d of defs) {
  const tokenNames = new Set([...d.args.matchAll(/(?<!\$)\{([A-Za-z0-9_]+)\}/g)].map((m) => m[1]));
  if (!tokenNames.size) continue;
  const supportedMatch = d.args.match(/supportedPlaceholders\s*:\s*\[([^\]]*)\]/s);
  const supported = new Set(supportedMatch ? [...supportedMatch[1].matchAll(/['"]([A-Za-z0-9_]+)['"]/g)].map((m) => m[1]) : []);
  const unsupported = [...tokenNames].filter((t) => !supported.has(t));
  // Ignore JS object-destructuring tokens accidentally caught by the lexical
  // scan; all actual template placeholder tokens are documented in this registry.
  const actualUnsupported = unsupported.filter((t) => base.has(t));
  assert.deepEqual(actualUnsupported, [], `${d.file}:${d.id} has template placeholder(s) missing from supportedPlaceholders: ${actualUnsupported.join(', ')}`);
}

const customService = fs.readFileSync(path.join(root, 'src/services/custom-submenu.service.js'), 'utf8');
assert.match(customService, /hasCustomContent\(submenuId\)\s*\{\s*return getCustomContent\(submenuId\)/s);
assert.match(customService, /getTemplateReference/);
assert.match(customService, /validateContent/);
assert.match(customService, /normalizeTelegramEntities/);
assert.doesNotMatch(customService, /eval\s*\(/);

const customHandler = fs.readFileSync(path.join(root, 'src/handlers/admin/customSubmenu.handler.js'), 'utf8');
assert.match(customHandler, /submenuRegistry\.getAll\(\{ scope: 'USER' \}\)/);
assert.match(customHandler, /handleIncomingCustomText/);
assert.match(customHandler, /customSubmenuService\.setCustomContent/);

const tokenNotice = fs.readFileSync(path.join(root, 'src/utils/tokenNotice.js'), 'utf8');
assert.match(tokenNotice, /token\.new_token_notice/);
assert.match(tokenNotice, /newTokenNoticeContent/);
for (const file of ['src/handlers/token.handler.js','src/handlers/ubotFlow.handler.js','src/handlers/panel.handler.js']) {
  const t = fs.readFileSync(path.join(root, file), 'utf8');
  assert.match(t, /newTokenNoticeContent\(/, `${file} must render the customizable token notice`);
}

const placeholders = fs.readFileSync(path.join(root, 'src/utils/placeholders.js'), 'utf8');
for (const p of ['timer','auto_reset','reaction','message_type','target_channel','banned_words','max_chars','filter_link','filter_username']) {
  assert.match(placeholders, new RegExp(`['"]${p}['"]`));
}

console.log(`PANEL_CUSTOMIZATION_CONTRACT_OK entries=${defs.length} required_contexts=${requiredIds.length} placeholder_registry=${base.size}`);
