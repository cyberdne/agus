const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const runtime = fs.readFileSync(path.join(root, 'src/services/userbotRuntime.service.js'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/handlers/panel.handler.js'), 'utf8');
const keyboard = fs.readFileSync(path.join(root, 'src/keyboards/panelControl.keyboard.js'), 'utf8');
const menu = fs.readFileSync(path.join(root, 'src/constants/menu.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'src/index.js'), 'utf8');
const pm = fs.readFileSync(path.join(root, 'src/database/repositories/pmPermitState.repository.js'), 'utf8');
const schema = fs.readFileSync(path.join(root, 'src/database/schema.js'), 'utf8');
const db = fs.readFileSync(path.join(root, 'src/database/index.js'), 'utf8');

function has(re, text, message) { assert.match(text, re, message); }
function not(re, text, message) { assert.doesNotMatch(text, re, message); }

// Group health / promotion pre-flight.
has(/getPermissions\(entity,\s*'me'\)/, runtime, 'promotion/group validation must inspect actual send capability');
has(/bannedRights\?\.sendMessages === true/, runtime, 'banned send rights must be classified');
has(/permissions\?\.sendMessages === false/, runtime, 'explicit sendMessages=false must be classified');
has(/status:'unusable'/, runtime, 'permanent unusable targets must be persisted');
has(/status:'transient'/, runtime, 'transient target failures must remain transient');
has(/FloodWait|RETRY_AFTER|FLOOD_WAIT/, runtime, 'FloodWait/retry_after handling must exist');
not(/FLOOD_WAIT[^\n]*[\s\S]{0,300}removePromotionTarget/, runtime, 'FloodWait must not directly remove a target');

// Leave Group: live scan, real Telegram leave, bounded UI pagination, edit-in-place.
has(/scanUnusableGroups/, runtime, 'leave-group flow must use a real runtime scan');
has(/Api\.messages\.DeleteChatUser/, runtime, 'basic groups must use the Telegram basic-group leave operation');
has(/Api\.channels\.LeaveChannel/, runtime, 'supergroups/channels must use channels.LeaveChannel');
has(/function groupLeavePaginationKeyboard/, keyboard, 'leave-group pagination keyboard must exist');
has(/panelgrp:leavepage/, menu, 'leave page callback must be scoped');
has(/panelgrp:leaverefresh/, menu, 'leave refresh callback must be scoped');
has(/panelgrp:leave:/, menu, 'leave target callback must carry target context');
has(/renderScreen\(ctx,c\.text,\{\.\.\.buildReplyOptions\(c\),\.\.\.groupLeavePaginationKeyboard/, panel, 'leave pages must edit the existing panel screen');
has(/panelState\.set\(ctx\.from\.id,\{leaveGroupScan:/, panel, 'leave scan state must be user-scoped, not global');

// Delete Group pagination + same-message refresh.
has(/const GROUP_DELETE_PAGE_SIZE = 10/, panel, 'delete-group page size must be bounded');
has(/listGroupsPage\(s\.asset\.id/, panel, 'delete-group must query one page');
has(/PANEL_GROUP_DEL_PAGE/, menu, 'delete page callback must exist');
has(/panelgrp:delpage/, index, 'delete page callback must be wired');
has(/groupDeleteListKeyboard\(view\.rows,view\.page,view\.totalPages/, panel, 'delete list must render only the current page');
has(/groupDeleteConfirmKeyboard\(row\.id,page\)/, panel, 'delete confirmation must retain current page');

// Topic detection: actual Telegram forum flag only; no invented topic id fallback.
has(/entity\.className === 'Channel' && Boolean\(entity\.forum\)/, runtime, 'topic detection must use the real forum flag');
has(/topicId = open \? Number\(open\.id\) : null/, runtime, 'topic id must come from a real Telegram ForumTopic');
not(/topicId\s*=\s*1\s*;/, runtime, 'topic scan must not fabricate topic id 1 on API failure');
has(/if \(!isRealGroupEntity\(entity\)\) continue;/, runtime, 'topic scan must exclude non-group entities');
has(/entity\.className === 'Channel' && Boolean\(entity\.forum\)/, runtime, 'supergroup != forum must remain distinct');

// Managed connection lifecycle.
has(/const clients = new Map\(\)/, runtime, 'managed clients must be isolated per asset');
has(/ensureManagedClientLocked/, runtime, 'connection reuse must use the managed client path');
has(/clients\.get\(keyFor\(kind,id\)\)/, runtime, 'runtime state must be keyed by userbot');
has(/record\.client\.connected === false/, runtime, 'real connection state must be checked');
has(/scheduleAutoPromosi\(r,15000\)/, runtime, 'promotion must run through the managed runtime');
not(/for\s*\([^\n]*\)\s*\{[^}]{0,200}disconnect\(\)[^}]{0,200}sendConfiguredMessage/s, runtime, 'promotion must not disconnect per target');

// PM Permit: persistent rolling 24h window, atomic claim, scoped by userbot + peer.
has(/last_responded_at TEXT/, schema, 'PM state must persist the last successful response timestamp');
has(/ALTER TABLE pm_permit_state ADD COLUMN last_responded_at TEXT/, db, 'existing databases need an additive PM timestamp migration');
has(/UNIQUE\(owner_kind, owner_id, peer_id\)/, schema, 'PM state must be scoped and unique per userbot + peer');
has(/last_responded_at/, pm, 'PM repository must read/write the persistent response timestamp');
has(/datetime\('now', '-24 hours'\)/, pm, 'daily PM reset must use a persistent time window, not setTimeout');
has(/UPDATE pm_permit_state[\s\S]*status='pending'/, pm, 'PM claim must be atomic/idempotent');
has(/last_responded_at = datetime\('now'\)/, pm, 'successful response must persist its timestamp');
has(/event\.message\.getSender\(\)/, runtime, 'incoming PM sender resolution must use the actual GramJS message');
has(/if\(event\.isPrivate && record\.flags\.pm_permit\)/, runtime, 'PM Permit must remain private-message-only');
has(/pmPermitState\.releaseClaim/, runtime, 'failed/transient PM response must release claim rather than fake success');

console.log('PASS: group health + leave/delete pagination + topic detection + managed connection + PM daily reset contracts verified.');
