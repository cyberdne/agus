// Testimoni otomatis: test nyata terhadap database SQLite sementara.
// Batas jaringan Telegram diganti stub pencatat panggilan (bukan keberhasilan palsu):
// stub hanya mencatat apa yang dikirim dan mengembalikan message yang dicatat.
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-testi-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');
const req = (m) => require(path.join(root, m));

const { initDatabase, getDb } = req('src/database');
initDatabase();
const db = getDb();
const T = req('src/services/testimonial.service');
const settingsRepo = req('src/database/repositories/settings.repository');
const orderRepo = req('src/database/repositories/order.repository');

const BUYER = 7001;
db.prepare("INSERT INTO users (telegram_id, username, first_name, last_name) VALUES (?, 'budi_test', 'Budi', 'Santoso')").run(BUYER);

function makeOrder({ status = 'fulfilled', proofType = 'photo', proofId = 'FILE_ABC', category = 'jaseb', product = 'Jaseb 1 Bulan', total = 50000 } = {}) {
  const r = db.prepare(`INSERT INTO orders (user_id, category, product_name, qty, unit_price, total_price, status, payment_proof_type, payment_proof_file_id)
    VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?)`).run(BUYER, category, product, total, total, status, proofType, proofId);
  return Number(r.lastInsertRowid);
}

// Telegram boundary stub: records every call and returns a message id.
function makeTelegram({ failFirst = null, styleReject = false } = {}) {
  const calls = [];
  let mid = 500;
  const send = (method) => async (chat, file, extra) => {
    calls.push({ method, chat, file, extra });
    if (failFirst && calls.length === 1) { const e = failFirst; throw e; }
    if (styleReject && extra.reply_markup && JSON.stringify(extra.reply_markup).includes('"style"') && calls.length === 1) {
      const e = new Error('400: Bad Request: can\'t parse reply keyboard markup JSON: unknown field style');
      e.description = "Bad Request: can't parse reply keyboard markup JSON: unknown field style";
      throw e;
    }
    return { message_id: ++mid, chat: { id: chat } };
  };
  return {
    calls,
    getMe: async () => ({ username: 'jasebrich_bot' }),
    sendPhoto: send('sendPhoto'),
    sendDocument: send('sendDocument'),
    sendVideo: send('sendVideo'),
  };
}

const results = [];
const ok = (name) => { results.push(name); };

(async () => {
  // 1. parsing and validation
  const b1 = T.parseButtonLine('🛒 Beli Sekarang | STORE | success | ROW:1');
  assert.equal(b1.target, 'STORE'); assert.equal(b1.style, 'success'); assert.equal(b1.row, 1);
  const b2 = T.parseButtonLine('📢 Promo | URL | https://example.com | primary | ROW:2');
  assert.equal(b2.value, 'https://example.com');
  assert.throws(() => T.parseButtonLine('X | CALLBACK | primary | ROW:1'), /Target tombol/);
  assert.throws(() => T.parseButtonLine('X | URL | http://insecure.com | primary | ROW:1'), /https/);
  assert.throws(() => T.parseButtonLine('X | BOT | neon | ROW:1'), /Style/);
  assert.throws(() => T.parseButtonLine('X | BOT | primary | ROW:99'), /1–8/);
  ok('button parsing rejects CALLBACK, http, bad style, bad row');

  // 2. channel not configured: nothing is sent and no delivery row is created
  const oNoChannel = makeOrder();
  const tgA = makeTelegram();
  const rNoChannel = await T.publishForOrder(tgA, oNoChannel);
  assert.equal(rNoChannel.reason, 'not_configured');
  assert.equal(tgA.calls.length, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM testimonial_deliveries WHERE order_id=?').get(oNoChannel).n, 0);
  ok('channel not configured -> no send, no row');

  // configure channel + buttons (persisted settings, same as admin save)
  settingsRepo.set(T.SETTINGS_KEYS.CHANNEL_ID, '-1001234567890');
  settingsRepo.set(T.SETTINGS_KEYS.CHANNEL_TITLE, 'Testimoni Jasebrich');
  T.setButtons([
    { label: 'Beli Sekarang', target: 'STORE', style: 'success', row: 1 },
    { label: 'Promo', target: 'URL', value: 'https://example.com', style: 'primary', row: 2 },
  ]);

  // 2b. image not configured: refused before claim, no row, nothing sent
  settingsRepo.set(T.SETTINGS_KEYS.IMAGE_FILE_ID, null);
  const oNoImage = makeOrder();
  const tgNoImg = makeTelegram();
  const rNoImg = await T.publishForOrder(tgNoImg, oNoImage);
  assert.equal(rNoImg.ok, false);
  assert.equal(rNoImg.reason, 'image_not_configured');
  assert.equal(tgNoImg.calls.length, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM testimonial_deliveries WHERE order_id=?').get(oNoImage).n, 0);
  assert.equal(T.getImageFileId(), null);
  ok('image not configured -> refused before claim, no row, nothing sent');

  // 3. non-fulfilled states never publish
  for (const status of ['pending', 'awaiting_confirmation', 'paid', 'processing', 'rejected', 'cancelled', 'expired']) {
    const id = makeOrder({ status });
    const tg = makeTelegram();
    const r = await T.publishForOrder(tg, id);
    assert.equal(r.ok, false, status);
    assert.equal(r.reason, 'not_fulfilled', status);
    assert.equal(tg.calls.length, 0, status);
  }
  ok('pending/awaiting/paid/processing/rejected/cancelled/expired -> NO testimonial');

  // 4. admin image set: exactly one post, admin image file_id, payment proof never used, markup via button helpers
  T.setImageFileId('ADMIN_IMG_1');
  assert.equal(T.getImageFileId(), 'ADMIN_IMG_1');
  const oFul = makeOrder({ proofType: 'photo', proofId: 'REAL_FILE_1' });
  const tgF = makeTelegram();
  const r4 = await T.publishForOrder(tgF, oFul);
  assert.equal(r4.ok, true, JSON.stringify(r4));
  assert.equal(tgF.calls.length, 1);
  const c4 = tgF.calls[0];
  assert.equal(c4.method, 'sendPhoto');
  assert.equal(c4.file, 'ADMIN_IMG_1', 'must use the admin-set image, not the payment proof');
  assert.notEqual(c4.file, 'REAL_FILE_1');
  assert.equal(String(c4.chat), '-1001234567890');
  assert.ok(c4.extra.caption.length <= 1024);
  assert.match(c4.extra.caption, /Jaseb 1 Bulan/);
  assert.match(c4.extra.caption, /Rp 50\.000/);
  assert.match(c4.extra.caption, /#\d+/);
  assert.doesNotMatch(c4.extra.caption, /7001/, 'buyer telegram id must not leak');
  assert.doesNotMatch(c4.extra.caption, /tg:\/\//, 'no id-based mention link');
  const kb = c4.extra.reply_markup.inline_keyboard;
  assert.equal(kb[0][0].url, 'https://t.me/jasebrich_bot?start=store');
  assert.equal(kb[0][0].style, 'success');
  assert.equal(kb[1][0].url, 'https://example.com');
  assert.equal(kb[1][0].style, 'primary');
  const row = db.prepare('SELECT status, message_id FROM testimonial_deliveries WHERE order_id=?').get(oFul);
  assert.equal(row.status, 'sent'); assert.equal(row.message_id, 501);
  ok('fulfilled -> one sendPhoto with admin image file_id, placeholders, URL/store buttons, style');

  // 5. idempotency: publish again -> no second message
  const r5 = await T.publishForOrder(tgF, oFul);
  assert.equal(r5.reason, 'already_handled');
  assert.equal(tgF.calls.length, 1);
  ok('second publish of same order -> already_handled, still one message');

  // 6. race: concurrent publishes -> exactly one message
  const oRace = makeOrder({ proofType: 'document', proofId: 'DOC_1' });
  const tgR = makeTelegram();
  const results6 = await Promise.all([1, 2, 3, 4, 5].map(() => T.publishForOrder(tgR, oRace)));
  assert.equal(tgR.calls.length, 1, `race sent ${tgR.calls.length} messages`);
  assert.equal(results6.filter((r) => r.ok).length, 1);
  assert.equal(tgR.calls[0].method, 'sendPhoto');
  assert.equal(tgR.calls[0].file, 'ADMIN_IMG_1');
  ok('5 concurrent publishes -> exactly one message');

  // 7. order without any payment proof still posts the admin image (proof is no longer a requirement)
  const oNoProof = makeOrder({ proofType: null, proofId: null });
  const tg7 = makeTelegram();
  const r7 = await T.publishForOrder(tg7, oNoProof);
  assert.equal(r7.ok, true, JSON.stringify(r7));
  assert.equal(tg7.calls.length, 1);
  assert.equal(tg7.calls[0].file, 'ADMIN_IMG_1');
  ok('fulfilled without payment proof -> posts admin image, no proof dependency');

  // 8. rate limit: retryable, then a later publish succeeds exactly once
  const oRetry = makeOrder({ proofType: 'video', proofId: 'VID_1' });
  const rl = new Error('429: Too Many Requests: retry after 1'); rl.parameters = { retry_after: 1 }; rl.description = 'Too Many Requests: retry after 1';
  const tg8 = makeTelegram({ failFirst: rl });
  const r8a = await T.publishForOrder(tg8, oRetry);
  assert.equal(r8a.reason, 'retryable');
  assert.equal(db.prepare('SELECT status FROM testimonial_deliveries WHERE order_id=?').get(oRetry).status, 'retryable');
  const r8b = await T.publishForOrder(tg8, oRetry);
  assert.equal(r8b.ok, true);
  assert.equal(tg8.calls.length, 2);
  assert.equal(db.prepare('SELECT status FROM testimonial_deliveries WHERE order_id=?').get(oRetry).status, 'sent');
  ok('429 -> retryable, later retry sends once');

  // 9. permanent config failure (bot not admin / chat not found): not retried automatically
  const oPerm = makeOrder();
  const perm = new Error('400: Bad Request: chat not found'); perm.description = 'Bad Request: chat not found';
  const tg9 = makeTelegram({ failFirst: perm });
  const r9 = await T.publishForOrder(tg9, oPerm);
  assert.equal(r9.reason, 'permanent');
  assert.equal(db.prepare('SELECT status FROM testimonial_deliveries WHERE order_id=?').get(oPerm).status, 'failed_permanent');
  ok('chat not found -> failed_permanent');

  // 10. narrow style fallback: explicit style rejection -> one retry without style, success recorded once
  const oStyle = makeOrder({ proofType: 'photo', proofId: 'STYLE_1' });
  const tg10 = makeTelegram({ styleReject: true });
  const r10 = await T.publishForOrder(tg10, oStyle);
  assert.equal(r10.ok, true, JSON.stringify(r10));
  assert.equal(tg10.calls.length, 2);
  assert.ok(tg10.calls[0].extra.reply_markup.inline_keyboard[0][0].style);
  assert.equal(tg10.calls[1].extra.reply_markup.inline_keyboard[0][0].style, undefined);
  assert.equal(tg10.calls[1].extra.reply_markup.inline_keyboard[0][0].url, 'https://t.me/jasebrich_bot?start=store');
  ok('style rejection -> single retry without style, label/url kept');

  // 11. caption over 1024 is refused, never truncated
  const longProduct = 'X'.repeat(1100);
  const oLong = makeOrder({ product: longProduct });
  const tg11 = makeTelegram();
  const r11 = await T.publishForOrder(tg11, oLong);
  assert.equal(r11.reason, 'caption_too_long');
  assert.equal(tg11.calls.length, 0);
  ok('caption > 1024 -> refused, not truncated');

  // 12. markdown-dangerous buyer name is escaped, not broken
  db.prepare("UPDATE users SET first_name='A_b*c', username=NULL WHERE telegram_id=?").run(BUYER);
  const oName = makeOrder({ proofType: 'photo', proofId: 'NAME_1' });
  const buyerRow = db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(BUYER);
  const vals = T.buildValues(db.prepare('SELECT * FROM orders WHERE id = ?').get(oName), buyerRow);
  assert.equal(vals.nama, 'A\\_b\\*c');
  assert.equal(vals.mention, 'A\\_b\\*c');
  assert.equal(vals.username, '-');
  ok('markdown characters in buyer name are escaped');

  // 13. preview: real fulfilled order + admin image; refused when image not set
  const tgPrev = makeTelegram();
  const prev = await T.previewLatest(tgPrev, 900);
  assert.equal(prev.ok, true);
  assert.equal(prev.orderId >= oFul, true);
  assert.equal(tgPrev.calls.length, 1);
  assert.equal(tgPrev.calls[0].file, 'ADMIN_IMG_1');
  assert.equal(String(tgPrev.calls[0].chat), '900');
  settingsRepo.set(T.SETTINGS_KEYS.IMAGE_FILE_ID, null);
  const prevNoImg = await T.previewLatest(makeTelegram(), 900);
  assert.equal(prevNoImg.reason, 'image_not_configured');
  T.setImageFileId('ADMIN_IMG_1');
  ok('preview sends admin image with real fulfilled order; refused without image');

  // 14. regression: transaction notification settings untouched by testimonial settings
  settingsRepo.set('notification_transaction_channel_id', '-1009999');
  T.resetSettings();
  assert.equal(settingsRepo.get('notification_transaction_channel_id'), '-1009999');
  assert.equal(T.getChannel(), null);
  ok('reset testimonial does not touch transaction notification channel');

  // 15. Custom Submenu registration: canonical template, all placeholders registered and documented
  const cs = req('src/services/custom-submenu.service');
  const meta = cs.getTemplateMeta(T.TEMPLATE_ID);
  assert.ok(meta, 'template must be registered');
  assert.equal(meta.id, 'notification.testimonial');
  assert.deepEqual([...meta.supportedPlaceholders].sort(), [...T.PLACEHOLDERS].sort());
  const docs = cs.getPlaceholderDocs(T.TEMPLATE_ID).map((d) => d.token.replace(/[{}]/g, ''));
  for (const p of T.PLACEHOLDERS) assert.ok(docs.includes(p), `placeholder ${p} needs a description`);
  ok('Custom Submenu: notification.testimonial registered, every placeholder documented');

  // 16. channel validation: must be a real channel, bot must be admin with posting permission
  const fakeNotChannel = { getChat: async () => ({ id: -1001000555, type: 'supergroup', title: 'G' }), getMe: async () => ({ id: 1 }), getChatMember: async () => ({ status: 'administrator', can_post_messages: true }) };
  await assert.rejects(T.setChannel(fakeNotChannel, '-1001000555'), /channel/i);
  const fakeNoPerm = { getChat: async () => ({ id: -1001000556, type: 'channel', title: 'C' }), getMe: async () => ({ id: 1 }), getChatMember: async () => ({ status: 'administrator', can_post_messages: false }) };
  await assert.rejects(T.setChannel(fakeNoPerm, '-1001000556'), /izin/);
  ok('channel validation rejects non-channel and missing posting permission');

  // 17. admin wiring (static contract against the real source files)
  const fs2 = require('fs');
  const idx = fs2.readFileSync(path.join(root, 'src/index.js'), 'utf8');
  const reply = fs2.readFileSync(path.join(root, 'src/middlewares/adminReply.middleware.js'), 'utf8');
  const flow = fs2.readFileSync(path.join(root, 'src/middlewares/adminFlow.middleware.js'), 'utf8');
  const adminKb = fs2.readFileSync(path.join(root, 'src/keyboards/admin.keyboard.js'), 'utf8');
  for (const c of ['NOTIFICATION_TESTIMONIAL_HOME', 'NOTIFICATION_TESTIMONIAL_SET_CHANNEL', 'NOTIFICATION_TESTIMONIAL_SET_BUTTONS', 'NOTIFICATION_TESTIMONIAL_SET_IMAGE', 'NOTIFICATION_TESTIMONIAL_TOGGLE', 'NOTIFICATION_TESTIMONIAL_CUSTOM', 'NOTIFICATION_TESTIMONIAL_PREVIEW', 'NOTIFICATION_TESTIMONIAL_RESET']) {
    assert.ok(idx.includes(`bot.action(ADMIN_CALLBACK.${c}`), `bot.action missing for ${c}`);
  }
  for (const label of ['🧾 Testimoni', '📢 Atur Channel Testimoni', '🎨 Custom Testimoni', '🔘 Atur Tombol', '🖼️ Atur Gambar', '🔴 Matikan Testimoni', '🟢 Nyalakan Testimoni', '👁️ Preview Testimoni', '♻️ Reset Pengaturan']) {
    assert.ok(reply.includes(`'${label}'`), `reply route missing: ${label}`);
  }
  assert.ok(flow.includes('admin_notification_testimonial_channel') && flow.includes('admin_notification_testimonial_buttons'), 'input flow missing');
  assert.ok(flow.includes('admin_notification_testimonial_image'), 'image photo flow missing');
  const flows = fs2.readFileSync(path.join(root, 'src/constants/adminInputFlows.js'), 'utf8');
  assert.ok(flows.includes('admin_notification_testimonial_image: { kind: \'photo\''), 'image input flow must be kind photo');
  assert.ok(adminKb.includes("staticReplyButton.primary('🧾 Testimoni')"), 'Notification home button missing');
  ok('admin wiring: callbacks, reply labels, input flows, Notification home button');

  // 18. deep links: /start payload store/renewal routed; plain /start still startHandler
  assert.ok(/payload === 'store' \|\| payload === 'renewal'\) return storeHandler/.test(idx), 'deep-link routing missing');
  assert.ok(/return startHandler\(ctx, next\);/.test(idx), 'plain /start must still use startHandler');
  ok('deep links: store/renewal routed, plain /start unchanged');

  // 19. button style pipeline: every CTA keeps style through utils/buttons (no raw objects)
  const kbOut = T.buildKeyboard([{ label: 'X', target: 'BOT', style: 'danger', row: 1, value: null }], 'b', true);
  assert.equal(kbOut.inline_keyboard[0][0].style, 'danger');
  const kbNoStyle = T.buildKeyboard([{ label: 'X', target: 'BOT', style: 'danger', row: 1, value: null }], 'b', false);
  assert.equal(kbNoStyle.inline_keyboard[0][0].style, undefined);
  assert.equal(kbNoStyle.inline_keyboard[0][0].url, 'https://t.me/b');
  ok('button style pipeline: style kept, fallback removes only style');

  // channel was reset by test 14; configure it again for the delivery tests below
  settingsRepo.set(T.SETTINGS_KEYS.CHANNEL_ID, '-1001234567890');
  settingsRepo.set(T.SETTINGS_KEYS.CHANNEL_TITLE, 'Testimoni Jasebrich');
  T.setButtons([{ label: 'Beli Sekarang', target: 'STORE', style: 'success', row: 1 }]);
  T.setImageFileId('ADMIN_IMG_1');
  // 20. retry sweep: a retryable delivery is retried by the sweep and sent exactly once
  const oSweep = makeOrder({ proofType: 'photo', proofId: 'SWEEP_1' });
  const tbl = new Error('429: Too Many Requests: retry after 1'); tbl.parameters = { retry_after: 1 }; tbl.description = 'Too Many Requests: retry after 1';
  const tg20 = makeTelegram({ failFirst: tbl });
  await T.publishForOrder(tg20, oSweep);
  assert.equal(db.prepare('SELECT status FROM testimonial_deliveries WHERE order_id=?').get(oSweep).status, 'retryable');
  const sw = await T.sweepRetryable(tg20, 10);
  assert.ok(sw.some((r) => r.orderId === oSweep && r.ok === true), 'sweep must send the retryable order');
  assert.equal(db.prepare('SELECT status FROM testimonial_deliveries WHERE order_id=?').get(oSweep).status, 'sent');
  await T.sweepRetryable(tg20, 10);
  const sweepSends = tg20.calls.filter((c) => c.extra.caption.includes(`#${oSweep}`));
  assert.equal(sweepSends.length, 2, 'one failed attempt + one successful send, nothing more');
  assert.ok(sweepSends.every((c) => c.file === 'ADMIN_IMG_1'));
  ok('retry sweep sends a retryable delivery once and stops after success');

  // 21. max attempts: endless retryable failures end as failed_permanent
  const oMax = makeOrder({ proofType: 'photo', proofId: 'MAX_1' });
  const always429 = { calls: [], getMe: async () => ({ username: 'jasebrich_bot' }), sendPhoto: async () => { const e = new Error('429'); e.parameters = { retry_after: 1 }; e.description = 'Too Many Requests: retry after 1'; throw e; } };
  for (let i = 0; i < T.MAX_ATTEMPTS + 2; i++) await T.publishForOrder(always429, oMax);
  const rowMax = db.prepare('SELECT status, attempts, last_error FROM testimonial_deliveries WHERE order_id=?').get(oMax);
  assert.equal(rowMax.status, 'failed_permanent');
  assert.equal(rowMax.attempts, T.MAX_ATTEMPTS);
  assert.match(rowMax.last_error, /max_attempts/);
  ok(`retryable failures stop at ${T.MAX_ATTEMPTS} attempts`);

  // 22. custom template: a saved custom Testimoni text still resolves real order placeholders
  const cs2 = req('src/services/custom-submenu.service');
  cs2.setCustomContent(T.TEMPLATE_ID, { text: 'Order #{order_id} untuk {nama}: {produk}', entities: [] }, 900);
  const oCustom = makeOrder({ product: 'Paket Custom' });
  const capCustom = T.renderCaption(db.prepare('SELECT * FROM orders WHERE id=?').get(oCustom), db.prepare('SELECT * FROM users WHERE telegram_id=?').get(BUYER), new Date());
  // buyer name was changed to A_b*c in test 12; it must appear Markdown-escaped in the custom template
  assert.equal(capCustom.text, 'Order #' + oCustom + ' untuk A\\_b\\*c: Paket Custom');
  cs2.deleteCustomContent(T.TEMPLATE_ID, 900);
  ok('custom template resolves order placeholders (no fake ctx)');

  // 23. buttons stay eligible for Custom Icon Tombol (no customizable:false on CTA)
  const svcSrc = fs2.readFileSync(path.join(root, 'src/services/testimonial.service.js'), 'utf8');
  assert.doesNotMatch(svcSrc, /customizable:\s*false/, 'CTA buttons must remain customizable');
  assert.doesNotMatch(svcSrc, /payment_proof/, 'service must never read payment proof for posting');
  assert.doesNotMatch(svcSrc, /sendDocument|sendVideo/, 'only the admin image (photo) is ever posted');
  ok('CTA buttons remain eligible for Custom Icon Tombol; no proof dependency');

  // 24. on/off switch: OFF = no send, no delivery row, no retry sweep; ON = publishing resumes
  T.setEnabled(false);
  assert.equal(T.isEnabled(), false);
  const oOff = makeOrder();
  const tgOff = makeTelegram();
  const rOff = await T.publishForOrder(tgOff, oOff);
  assert.equal(rOff.reason, 'disabled');
  assert.equal(tgOff.calls.length, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM testimonial_deliveries WHERE order_id=?').get(oOff).n, 0);
  assert.deepEqual(await T.sweepRetryable(tgOff, 10), []);
  T.setEnabled(true);
  assert.equal(T.isEnabled(), true);
  const rOn = await T.publishForOrder(makeTelegram(), makeOrder());
  assert.equal(rOn.ok, true, JSON.stringify(rOn));
  ok('on/off switch: off blocks send, row and sweep; on resumes publishing');

  console.log(`TESTIMONIAL_TESTS_OK ${results.length} checks`);
  results.forEach((n) => console.log(` - ${n}`));
  process.exit(0);
})().catch((err) => { console.error('TESTIMONIAL_TESTS_FAIL', err && err.stack || err); process.exit(1); });
