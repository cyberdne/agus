const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };

const navigation = read('src/middlewares/navigationCancellation.middleware.js');
const adminKeyboard = read('src/keyboards/admin.keyboard.js');
const adminPanel = read('src/handlers/admin/adminPanel.handler.js');
const adminReply = read('src/middlewares/adminReply.middleware.js');
const panelKeyboard = read('src/keyboards/panelControl.keyboard.js');
const panelHandler = read('src/handlers/panel.handler.js');
const panelText = read('src/middlewares/panelText.middleware.js');
const userbotService = read('src/services/userbot.service.js');
const customService = read('src/services/custom-submenu.service.js');
const customRepo = read('src/database/repositories/submenuCustomization.repository.js');
const store = read('src/handlers/store.handler.js');
const ping = read('src/handlers/ping.handler.js');

// 1. Root userbot Control Panel must leave the whole panel subtree.
assert(/case 'main':[\s\S]*?panelState\.clear\(ctx\.from\.id\);[\s\S]*?backToMainHandler/.test(navigation),
  'Root Control Panel Back no longer exits to the main menu.');
assert(/case 'reply':[\s\S]*?homePanelHandler/.test(navigation),
  'Nested panel Back no longer returns to the selected control-panel parent.');

// 2. Picker labels use package metadata/ID only, not decorative emoji prefixes.
assert(panelKeyboard.includes("assetButtonLabel('owned', a)"), 'Owned picker does not use the canonical package label helper.');
assert(panelKeyboard.includes("assetButtonLabel('pool', a)"), 'Pool picker does not use the canonical package label helper.');
assert(panelKeyboard.includes('function assetButtonLabel(kind, row)'), 'assetButtonLabel must be declared in module scope; export-only property does not make it callable inside panelSelectAssetKeyboard.');
assert(panelKeyboard.includes('  assetButtonLabel,'), 'assetButtonLabel must be exported from the same canonical function.');
assert(/function assetButtonLabel\(kind, row\)[\s\S]*?packageName = row && \(row\.package_name \|\| row\.label\)/.test(panelKeyboard),
  'Picker label helper does not resolve package metadata from the real asset row.');
assert(userbotService.includes('function packageLabelForAsset'), 'Package-name resolver missing from userbot service.');
assert(userbotService.includes('orderRepository.findById'), 'Package-name resolver does not use the real order/product metadata.');
assert(userbotService.includes("return 'Trial'"), 'Trial package label normalization missing.');

// 3. The exact MarkdownV2 defects shown in the runtime log are escaped.
assert(/Order \\#\$\{escapeMdV2\(order\.id\)\}/.test(store), 'Pending-order list still emits an unescaped MarkdownV2 #.');
assert(/selesai\\\.\*\\n/.test(store), 'Pending-order default still contains an unescaped period.');
assert(/dapat dibatalkan\\\.\\n/.test(store), 'Cancel-all confirmation still contains an unescaped period.');
assert(/ikut dibatalkan\\\./.test(store), 'Cancel-all confirmation second period still unescaped.');
assert(/Order \\\#\{order_id\} sudah kedaluwarsa\\\./.test(store), 'Expired-order default still contains an unescaped # or period.');
assert(/Batas waktu order: \{masa_berlaku\}\\\./.test(store), 'Expired-order deadline period is not MarkdownV2 safe.');

// 4. Legacy custom template under the old picker key is moved only to the
// canonical selected-control-panel context when that destination is empty.
assert(customService.includes('LEGACY_CONTROL_PANEL_PLACEHOLDERS'), 'Legacy customization migration contract missing.');
assert(customService.includes("repo.moveIfDestinationMissing('control_panel_select_asset', 'control_panel_main')"), 'Legacy control-panel customization is not migrated to the canonical context.');
assert(customRepo.includes('function moveIfDestinationMissing'), 'Customization repository lacks the atomic migration primitive.');
assert(customRepo.includes('ON CONFLICT') === false || true, 'No-op');

// 5. Admin panel is grouped by function, while existing feature routes remain.
for (const label of ['👥 Users', '🤖 Userbot', '🛒 Commerce', '💳 Order & Payment', '📢 Notifications', '📊 Statistics', '⚙️ Settings']) {
  assert(adminKeyboard.includes(label), `Admin category missing: ${label}`);
  assert(adminReply.includes(`['${label}'`), `Admin reply router missing category route: ${label}`);
}
for (const legacyFeature of ['👥 User Management', '📦 Produk Management', '🎛️ Kontrol Panel Ubot', '💳 Payment', '🔔 Notifikasi', '📣 Broadcast', '⏰ Reminder', '⚙️ Configuration']) {
  assert(adminReply.includes(`['${legacyFeature}'`), `Existing admin feature route lost: ${legacyFeature}`);
}
assert(adminReply.includes('admin:category:(userbot|commerce|orders|notifications|settings)'), 'Grouped category Back routing is not registered.');
assert(adminReply.includes("if (feature === 'admin:category:users' || feature === 'admin:category:statistics') return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];"), 'Legacy singleton category Back compatibility is missing.');
assert(adminPanel.includes('const ADMIN_CATEGORIES'), 'Admin category definitions are not centralized.');

// 6. Atur Pesan remains ReplyKeyboard with 2+2+1 layout.
const messageKey = panelKeyboard.match(/function messageKeyboard\(\)[\s\S]*?\n}\n/);
assert(messageKey, 'messageKeyboard definition not found.');
const replyRows = messageKey[0].match(/\[replyButton\.[^\n]+/g) || [];
assert(replyRows.length >= 3, 'Atur Pesan keyboard rows not detected.');
assert(messageKey[0].includes('MESSAGE_TEXT_MEDIA') && messageKey[0].includes('MESSAGE_FORWARD'), 'Row 1 actions missing.');
assert(messageKey[0].includes('MESSAGE_VIEW') && messageKey[0].includes('MESSAGE_DELETE'), 'Row 2 actions missing.');
assert(messageKey[0].includes('MENU.KEMBALI'), 'Row 3 Kembali missing.');
assert(panelText.includes("assetButtonLabel('owned', a)"), 'Picker routing does not share the canonical package label helper.');

// 7. No stale botPings property access remains in the actual source tree.
function walk(dir) {
  const out = [];
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const st = fs.statSync(full);
    if (st.isDirectory()) out.push(...walk(full));
    else if (/\.(?:js|json)$/.test(name)) out.push(full);
  }
  return out;
}
const botPingRefs = walk(path.join(root, 'src')).filter((file) => fs.readFileSync(file, 'utf8').includes('botPings'));
assert(botPingRefs.length === 0, `Stale botPings references remain: ${botPingRefs.map((x) => path.relative(root, x)).join(', ')}`);
assert(ping.includes('botPingMs') && ping.includes('dbPingMs'), 'Current ping handler did not initialize real ping metrics.');

console.log('LATEST_UX_HARDENING_OK navigation_back=1 markdown_v2=1 legacy_custom_migration=1 package_labels=1 admin_grouping=1 message_keyboard=1 botPings_stale_refs=0');
