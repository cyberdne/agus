'use strict';

const assert = require('node:assert/strict');

const subscriptionPath = require.resolve('../src/services/subscription.service');
require.cache[subscriptionPath] = {
  id: subscriptionPath,
  filename: subscriptionPath,
  loaded: true,
  exports: { getSubscriptionState: () => 'ACTIVE' },
};

const { applyPlaceholders } = require('../src/utils/placeholders');
const {
  normalizeTelegramEntities,
  entitiesToTelegramHtml,
  buildHtmlFallbackPayload,
} = require('../src/utils/telegramFormatting');

function assertEntityRanges(text, entities) {
  for (const e of entities) {
    assert(Number.isInteger(e.offset) && Number.isInteger(e.length));
    assert(e.offset >= 0);
    assert(e.length > 0);
    assert(e.offset + e.length <= text.length);
  }
}

function fakeCtx() {
  return {
    from: { id: 1250507726, first_name: 'Benny', last_name: 'Boss', username: 'bi9boss' },
    chat: { id: 1250507726, type: 'private' },
    message: { date: Math.floor(Date.now() / 1000) },
  };
}

// Placeholder replacement after a non-BMP character must keep UTF-16 offsets.
{
  const text = '🎉 Halo {nama_lengkap}!';
  const entity = [{ type: 'bold', offset: text.indexOf('{'), length: '{nama_lengkap}'.length }];
  const out = applyPlaceholders(text, entity, fakeCtx());
  assert.equal(out.text, '🎉 Halo Benny Boss!');
  assertEntityRanges(out.text, out.entities);
  assert.equal(out.entities[0].type, 'bold');
  assert.equal(entitiesToTelegramHtml(out.text, out.entities), '🎉 Halo <b>Benny Boss</b>!');
}

// Screenshot-style token in a blockquote stays structurally valid after expansion.
{
  const text = '🎉 Userbot\n🔑 Token Garansi Anda:\n{token_garansi}\n\nHarap simpan!';
  const start = text.indexOf('{token_garansi}');
  const entities = [{ type: 'blockquote', offset: start, length: '{token_garansi}'.length }];
  const out = applyPlaceholders(text, entities, fakeCtx(), {
    userbot: { token: 'JASEB-TEST-XYZ' },
  });
  assert.equal(out.text.includes('JASEB-TEST-XYZ'), true);
  assertEntityRanges(out.text, out.entities);
  const html = entitiesToTelegramHtml(out.text, out.entities);
  assert.match(html, /<blockquote>JASEB-TEST-XYZ<\/blockquote>/);
}

// Deep/nested formatting must become properly nested HTML.
{
  const text = 'Hello world';
  const entities = [
    { type: 'bold', offset: 0, length: text.length },
    { type: 'italic', offset: 6, length: 5 },
    { type: 'underline', offset: 6, length: 5 },
  ];
  const html = entitiesToTelegramHtml(text, entities);
  assert.equal(html, '<b>Hello <i><u>world</u></i></b>');
}

// Premium/custom emoji must retain the regular emoji character inside the tag.
{
  const text = 'A 🥳 B';
  const entities = [{ type: 'custom_emoji', offset: 2, length: 2, custom_emoji_id: '5368324170671202286' }];
  const html = entitiesToTelegramHtml(text, entities);
  assert.equal(html, 'A <tg-emoji emoji-id="5368324170671202286">🥳</tg-emoji> B');
}

// Date/time entities are supported by current Bot API formatting.
{
  const text = '17 March 2026';
  const entities = [{ type: 'date_time', offset: 0, length: text.length, unix_time: 1773705600, date_time_format: 'wDT' }];
  const html = entitiesToTelegramHtml(text, entities);
  assert.equal(html, '<tg-time unix="1773705600" format="wDT">17 March 2026</tg-time>');
}

// Malformed/crossing ranges are removed before they can reach Telegram.
{
  const text = 'abcdefghij';
  const entities = normalizeTelegramEntities(text, [
    { type: 'bold', offset: 0, length: 6 },
    { type: 'italic', offset: 4, length: 6 },
  ]);
  assert.equal(entities.length, 1);
  assertEntityRanges(text, entities);
}

// The API retry payload preserves every non-formatting option (buttons, reply params, etc.).
{
  const payload = {
    chat_id: 123,
    text: '<b>not raw html</b>',
    entities: [{ type: 'bold', offset: 0, length: 19 }],
    reply_markup: { inline_keyboard: [[{ text: 'OK', callback_data: 'ok' }]] },
  };
  const fallback = buildHtmlFallbackPayload(payload);
  assert.equal(fallback.reply_markup, payload.reply_markup);
  assert.equal(fallback.parse_mode, 'HTML');
  assert.equal('entities' in fallback, false);
  assert.equal(fallback.text, '<b>&lt;b&gt;not raw html&lt;/b&gt;</b>');
}

console.log('custom-submenu formatting regression tests: OK');
