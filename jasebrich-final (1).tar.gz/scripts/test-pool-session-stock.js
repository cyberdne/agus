const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

// Structural tests that never print or embed a real credential.
const poolHandler = read('src/handlers/admin/poolManagement.handler.js');
const flows = read('src/constants/adminInputFlows.js');
const callbacks = read('src/constants/admin.callback.js');
const storage = read('src/utils/userbotSessionStorage.js');
const poolRepo = read('src/database/repositories/userbotPool.repository.js');
const gram = read('src/services/gramjs.service.js');
const index = read('src/index.js');
const keyboard = read('src/keyboards/admin.keyboard.js');

assert.match(callbacks, /POOL_ADD_PHONE:\s*'adminpool:add:phone'/);
assert.match(callbacks, /POOL_ADD_SESSION:\s*'adminpool:add:session'/);
assert.match(flows, /admin_pool_method:\s*\{\s*kind:\s*'choice'/);
assert.match(flows, /admin_pool_session:\s*\{\s*kind:\s*'text',\s*cancel:\s*CANCEL\.pool,\s*prev:\s*'admin_pool_method'/);
assert.match(poolHandler, /gramjsService\.verifySessionString\(sessionString\)/);
assert.match(poolHandler, /deleteSensitiveInputMessage\(ctx\)/);
assert.match(poolHandler, /DUPLICATE_USERBOT/);
assert.match(poolRepo, /findExistingAcrossUserbotTables/);
assert.match(poolRepo, /db\.transaction\(\(\) =>/);
assert.match(poolRepo, /sessionStore\.writeSession\('pool'/);
assert.match(gram, /async function verifySessionString\(sessionString\)/);
assert.match(gram, /new StringSession\(normalized\)/);
assert.match(gram, /client\.getMe\(\)/);
assert.match(gram, /client\.checkAuthorization/);
assert.match(gram, /client\.session\?\.save/);
assert.match(storage, /data\/userbot_sessions/);
assert.doesNotMatch(gram, /SESSION_ENCRYPTION_KEY|AES\/GCM|createCipheriv|encrypt\(/);
assert.doesNotMatch(poolHandler, /console\.(log|error).*sessionString/i);
assert.match(index, /ADMIN_CALLBACK\.POOL_ADD_PHONE/);
assert.match(index, /ADMIN_CALLBACK\.POOL_ADD_SESSION/);
assert.match(keyboard, /ADMIN_CALLBACK\.POOL_ADD_SESSION/);
assert.match(keyboard, /Markup\.inlineKeyboard/);

// Exercise verifySessionString with a fully controlled GramJS fake. The test
// validates the actual service contract (StringSession -> connect -> auth ->
// getMe -> saved session -> disconnect) without pretending the fake is a
// Telegram success in production.
const originalLoad = Module._load;
const fakeClientCalls = [];
const FakeStringSession = class {
  constructor(value) {
    fakeClientCalls.push(['StringSession', value]);
    if (value === 'CORRUPT') throw new Error('bad session');
    this.value = value;
  }
  save() { fakeClientCalls.push(['save']); return `CANONICAL:${this.value}`; }
};
class FakeTelegramClient {
  constructor(session) { this.session = session; this.value = session.value; }
  async connect() {
    fakeClientCalls.push(['connect']);
    if (this.value === 'NETWORK') { const e = new Error('EAI_AGAIN telegram.example'); e.code = 'EAI_AGAIN'; throw e; }
  }
  async disconnect() { fakeClientCalls.push(['disconnect']); }
  async checkAuthorization() {
    fakeClientCalls.push(['checkAuthorization']);
    if (this.value === 'UNAUTHORIZED') return false;
    return true;
  }
  async getMe() {
    fakeClientCalls.push(['getMe']);
    if (this.value === 'REVOKED') { const e = new Error('AUTH_KEY_UNREGISTERED'); throw e; }
    return { id: 99123, username: 'verified', firstName: 'Verified', lastName: 'Account', phone: '+628123456789' };
  }
  async invoke() { fakeClientCalls.push(['invoke']); return {}; }
}
const previous = {
  TELEGRAM_API_ID: process.env.TELEGRAM_API_ID,
  TELEGRAM_API_HASH: process.env.TELEGRAM_API_HASH,
};
process.env.TELEGRAM_API_ID = '12345';
process.env.TELEGRAM_API_HASH = 'hash';
Module._load = function(request, parent, isMain) {
  if (request === 'dotenv') return { config: () => ({}) };
  if (request === 'telegram') return { TelegramClient: FakeTelegramClient };
  if (request === 'telegram/sessions') return { StringSession: FakeStringSession };
  if (request === 'telegram/tl') return { Api: { updates: { GetState: class GetState {} } } };
  return originalLoad.call(this, request, parent, isMain);
};


async function testPoolRepositoryContracts() {
  const calls = [];
  let row = { id: 42, label: 'Slot 42', phone: '+628123456789', session_string: 'CANONICAL:VALID_SESSION', telegram_userbot_id: 99123, status: 'available' };
  let duplicate = null;
  let failWrite = false;
  const fakeDb = {
    transaction(fn) { return () => fn(); },
    prepare(sql) {
      return {
        get(...args) {
          if (/UNION ALL/.test(sql)) return duplicate;
          if (/FROM userbot_pool\b/.test(sql)) return row;
          return null;
        },
        all() { return []; },
        run(...args) {
          calls.push(['run', sql, args]);
          if (/INSERT INTO userbot_pool/.test(sql)) { row = { ...row, id: 42 }; return { lastInsertRowid: 42, changes: 1 }; }
          return { changes: 1 };
        },
      };
    },
  };
  const originalLoad = Module._load;
  const writes = [];
  const deleted = [];
  Module._load = function(request, parent, isMain) {
    if (request === '../index' && parent && parent.filename.endsWith('/database/repositories/userbotPool.repository.js')) return { getDb: () => fakeDb };
    if (request === '../../utils/userbotSessionStorage' && parent && parent.filename.endsWith('/database/repositories/userbotPool.repository.js')) return {
      hydrateRow: (r) => r,
      hydrateRows: (r) => r,
      writeSession: (_k, id, value) => { writes.push([id, value]); if (failWrite) throw new Error('disk full'); },
      readSession: () => 'CANONICAL:VALID_SESSION',
      deleteSession: (_k, id) => { deleted.push(id); return true; },
    };
    return originalLoad.call(this, request, parent, isMain);
  };
  try {
    delete require.cache[require.resolve('../src/database/repositories/userbotPool.repository')];
    const repo = require('../src/database/repositories/userbotPool.repository');
    duplicate = null;
    row = { id: 42, label: 'Slot 42', phone: '+628123456789', session_string: 'CANONICAL:VALID_SESSION', telegram_userbot_id: 99123, status: 'available' };
    writes.length = 0; deleted.length = 0;
    const created = repo.create({ label: 'Slot 42', phone: '+628123456789', sessionString: 'CANONICAL:VALID_SESSION', telegramUserbotId: 99123 });
    assert.equal(created.id, 42);
    assert.deepEqual(writes, [[42, 'CANONICAL:VALID_SESSION']]);
    assert.deepEqual(deleted, []);

    duplicate = { source: 'pool', id: 7, label: 'Existing', status: 'available', telegram_userbot_id: 99123 };
    writes.length = 0; deleted.length = 0;
    await assert.rejects(Promise.resolve().then(() => repo.create({ label: 'Dup', phone: '+628123456789', sessionString: 'SENSITIVE', telegramUserbotId: 99123 })), (err) => {
      assert.equal(err.code, 'DUPLICATE_USERBOT');
      return true;
    });
    assert.deepEqual(writes, []);
    assert.deepEqual(deleted, []);

    duplicate = null;
    failWrite = true;
    writes.length = 0; deleted.length = 0;
    await assert.rejects(Promise.resolve().then(() => repo.create({ label: 'Disk Fail', phone: '+628123456789', sessionString: 'SENSITIVE', telegramUserbotId: 99124 })), /disk full/);
    assert.deepEqual(writes, [[42, 'SENSITIVE']]);
    assert.deepEqual(deleted, [42]);
  } finally {
    Module._load = originalLoad;
    delete require.cache[require.resolve('../src/database/repositories/userbotPool.repository')];
  }
}

(async () => {
  try {
    delete require.cache[require.resolve('../src/services/gramjs.service')];
    const service = require('../src/services/gramjs.service');
    const result = await service.verifySessionString(' VALID_SESSION ');
    assert.equal(result.telegramUserbotId, 99123);
    assert.equal(result.account.phone, '+628123456789');
    assert.equal(result.sessionString, 'CANONICAL:VALID_SESSION');
    assert.deepEqual(fakeClientCalls, [
      ['StringSession', 'VALID_SESSION'], ['connect'], ['invoke'],
      ['checkAuthorization'], ['getMe'], ['save'], ['disconnect'],
    ]);

    await assert.rejects(service.verifySessionString('CORRUPT'), (err) => {
      assert.equal(err.code, 'SESSION_CORRUPT');
      assert.doesNotMatch(err.message, /bad session/i);
      return true;
    });

    await assert.rejects(service.verifySessionString('UNAUTHORIZED'), (err) => {
      assert.equal(err.code, 'SESSION_INVALID');
      assert.equal(err.message, 'Session tidak terotorisasi dan tidak dapat digunakan.');
      return true;
    });

    await assert.rejects(service.verifySessionString('REVOKED'), (err) => {
      assert.equal(err.code, 'SESSION_INVALID');
      assert.doesNotMatch(err.message, /AUTH_KEY_UNREGISTERED/);
      return true;
    });

    await assert.rejects(service.verifySessionString('NETWORK'), (err) => {
      assert.equal(err.code, 'NETWORK_ERROR');
      assert.doesNotMatch(err.message, /EAI_AGAIN/);
      return true;
    });

    await assert.rejects(service.verifySessionString('   '), (err) => {
      assert.equal(err.code, 'SESSION_INVALID');
      return true;
    });
    await testPoolRepositoryContracts();
    console.log('PASS test-pool-session-stock');
  } finally {
    Module._load = originalLoad;
    if (previous.TELEGRAM_API_ID === undefined) delete process.env.TELEGRAM_API_ID; else process.env.TELEGRAM_API_ID = previous.TELEGRAM_API_ID;
    if (previous.TELEGRAM_API_HASH === undefined) delete process.env.TELEGRAM_API_HASH; else process.env.TELEGRAM_API_HASH = previous.TELEGRAM_API_HASH;
  }
})();
