'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');

const forbiddenGeneratedHints = [
  'Tekan ${MENU.KEMBALI} untuk kembali atau ${MENU.BATAL} di bawah untuk membatalkan.',
  'Tekan 🔙 Kembali untuk kembali atau ❌ Batal di bawah untuk membatalkan.',
  '⌨️ Navigasi: Kembali ke langkah sebelumnya, atau Batal.',
  '⌨️ Navigasi: Kembali ke Edit Produk, atau Batal.',
  '⌨️ Navigasi: Kembali ke Durasi Trial, atau Batal.',
  'Untuk kembali tanpa mengganti, tekan Batal.',
  'Coba lagi atau tekan Batal.',
  'Gunakan tombol di atas untuk memilih fitur, lalu tekan Simpan Perubahan atau Batal.',
  'Gunakan tombol di atas untuk memilih fitur, lalu tekan Simpan atau Batal.',
  'Kirim ulang pesan custom yang valid, tekan 🔙 Kembali, atau ❌ Batal Custom Submenu.',
  'atau tombol Kembali / Batal di bawah.',
  '⌨️ Navigasi:',
  'atau tekan Kembali / Batalkan.',
];

const files = [
  'src/handlers/panel.handler.js',
  'src/handlers/admin/productManagement.handler.js',
  'src/handlers/admin/trialSettings.handler.js',
  'src/handlers/admin/subscriptionExtend.handler.js',
  'src/handlers/admin/buttonIcons.handler.js',
  'src/handlers/admin/premiumEmoji.handler.js',
  'src/middlewares/customSubmenuText.middleware.js',
  'src/middlewares/adminFlow.middleware.js',
  'src/middlewares/adminReply.middleware.js',
  'src/handlers/token.handler.js',
  'src/handlers/ubotFlow.handler.js',
  'src/middlewares/ubotLoginText.middleware.js',
];

const source = files.map((f) => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
for (const phrase of forbiddenGeneratedHints) {
  assert.equal(source.includes(phrase), false, `automatic navigation phrase remains: ${phrase}`);
}

const panel = fs.readFileSync(path.join(root, 'src/handlers/panel.handler.js'), 'utf8');
assert.match(panel, /const text = content\.text;/, 'panel input renderer must use submenu content directly');
assert.match(panel, /panelInputKeyboard\(\)/, 'panel input renderer must retain navigation keyboard');
assert.doesNotMatch(panel, /content\.text\}\s*\\n\\nTekan/, 'panel renderer must not append navigation prose');

const product = fs.readFileSync(path.join(root, 'src/handlers/admin/productManagement.handler.js'), 'utf8');
assert.doesNotMatch(product, /⌨️ Navigasi:/, 'product flow must not emit separate navigation prose');

const trial = fs.readFileSync(path.join(root, 'src/handlers/admin/trialSettings.handler.js'), 'utf8');
assert.doesNotMatch(trial, /⌨️ Navigasi:/, 'trial flow must not emit separate navigation prose');

const adminReply = fs.readFileSync(path.join(root, 'src/middlewares/adminReply.middleware.js'), 'utf8');
assert.doesNotMatch(adminReply, /ctx\.reply\(['"]⌨️ Navigasi:/, 'fallback navigation must not emit visible navigation prose');
assert.match(adminReply, /ctx\.reply\(['"]\\u2063['"]/, 'fallback navigation must retain keyboard via an invisible carrier');

console.log('NAVIGATION_HINT_STATIC_AUDIT_OK');
