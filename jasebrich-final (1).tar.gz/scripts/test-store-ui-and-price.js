'use strict';
const assert = require('node:assert/strict');
const Module = require('node:module');

// Boundary stubs only: production resolver and keyboard code remain the code
// under test. No business result is mocked inside the implementation.
const databaseIndexPath = require.resolve('../src/database');
require.cache[databaseIndexPath] = {
  id: databaseIndexPath,
  filename: databaseIndexPath,
  loaded: true,
  exports: { getDb: () => { throw new Error('DB access must not occur in this unit test'); } },
};
const orderRepoPath = require.resolve('../src/database/repositories/order.repository');
require.cache[orderRepoPath] = { id: orderRepoPath, filename: orderRepoPath, loaded: true, exports: {} };

const productRepoPath = require.resolve('../src/database/repositories/product.repository');
const fakeProducts = new Map([
  [1, { id: 1, category: 'userbot', name: 'Basic', price: 5000, duration_days: 30, garansi: 1, is_active: 1 }],
  [2, { id: 2, category: 'userbot', name: 'Special', price: 9000, duration_days: 30, garansi: 1, is_active: 1 }],
  [3, { id: 3, category: 'jaseb', name: 'Basic', price: 7000, duration_days: 30, garansi: 1, is_active: 1 }],
  [4, { id: 4, category: 'jaseb', name: 'Special', price: 12000, duration_days: 30, garansi: 1, is_active: 1 }],
]);
require.cache[productRepoPath] = {
  id: productRepoPath,
  filename: productRepoPath,
  loaded: true,
  exports: {
    findById: (id) => fakeProducts.get(Number(id)) || null,
    listByCategory: (category) => [...fakeProducts.values()].filter((p) => p.category === category && p.is_active),
    listByGaransi: () => [...fakeProducts.values()],
  },
};

const productService = require('../src/services/product.service');
const { CATEGORIES } = productService;

for (const [id, category, price] of [
  [1, CATEGORIES.USERBOT, 5000],
  [2, CATEGORIES.USERBOT, 9000],
  [3, CATEGORIES.JASEB, 7000],
  [4, CATEGORIES.JASEB, 12000],
]) {
  const resolved = productService.resolvePurchaseProduct(id, category);
  assert.equal(resolved.product.price, price);
  assert.equal(resolved.product.category, category);
  assert.equal(resolved.category, category);
}
assert.throws(() => productService.resolvePurchaseProduct(1, CATEGORIES.JASEB), /kategori/i);
assert.throws(() => productService.resolvePurchaseProduct(3, CATEGORIES.USERBOT), /kategori/i);

// Exercise the actual production button helper/keyboard builder. Telegraf is
// substituted only as a transport-shape stub because it is not installed in
// this archive's test environment.
const originalLoad = Module._load;
Module._load = function patched(request, parent, isMain) {
  if (request === 'telegraf') {
    return {
      Markup: {
        inlineKeyboard: (rows) => ({ reply_markup: { inline_keyboard: rows } }),
        keyboard: (rows) => ({ reply_markup: { keyboard: rows } }),
      },
    };
  }
  return originalLoad.call(this, request, parent, isMain);
};

const buttonIconsPath = require.resolve('../src/services/buttonIconConfig.service');
require.cache[buttonIconsPath] = {
  id: buttonIconsPath,
  filename: buttonIconsPath,
  loaded: true,
  exports: {
    registerButtonLabel() {},
    getButtonConfig: () => ({ text: '✅ COLLIDE', iconCustomEmojiId: null }),
  },
};
const settingsRepoPath = require.resolve('../src/database/repositories/settings.repository');
require.cache[settingsRepoPath] = {
  id: settingsRepoPath,
  filename: settingsRepoPath,
  loaded: true,
  exports: { get: () => null, set: () => {} },
};
const premiumPath = require.resolve('../src/services/premiumEmojiConfig.service');
require.cache[premiumPath] = {
  id: premiumPath,
  filename: premiumPath,
  loaded: true,
  exports: {
    configForGaransi: () => ({ icon: '⭐', customEmojiId: null }),
  },
};

const inline = require('../src/keyboards/inline.keyboard');
const kb = inline.storeProductListKeyboard(CATEGORIES.USERBOT, [fakeProducts.get(1), fakeProducts.get(2)]);
Module._load = originalLoad;

const productButtons = kb.reply_markup.inline_keyboard[0];
assert.equal(productButtons.length, 2);
assert.equal(productButtons[0].text, 'Basic');
assert.equal(productButtons[1].text, 'Special');
assert.equal(productButtons[0].text.includes('Bergaransi'), false);
assert.equal(productButtons[1].text.includes('Bergaransi'), false);
assert.equal(productButtons[0].text.includes('✅ COLLIDE'), false);
assert.equal(productButtons[1].text.includes('✅ COLLIDE'), false);

const longKb = inline.storeProductListKeyboard(CATEGORIES.USERBOT, [
  { ...fakeProducts.get(1), name: 'Paket Super Panjang Sekali' },
  { ...fakeProducts.get(2), name: 'Paket Super Panjang Dua' },
]);
const rows = longKb.reply_markup.inline_keyboard;
assert.equal(rows[0].length, 1);
assert.equal(rows[1].length, 1);

console.log('STORE_UI_PRICE_RUNTIME_OK category_isolation=1 authoritative_price=1 warranty_label_compact=1 custom_icon_suppressed=1 adaptive_rows=1');
