'use strict';
/**
 * Real integration tests for the order expiration state machine.
 * Uses better-sqlite3 + the actual repositories/services; no mocks.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');

try { require.resolve('better-sqlite3'); } catch (_) {
  console.error('BLOCKED  ORDER_EXPIRATION_REAL_DB — better-sqlite3 is not installed in this environment');
  process.exit(2);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-order-expiration-'));
process.env.DB_PATH = path.join(tmp, 'orders.sqlite');
process.env.BOT_TOKEN = 'test-token';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'test-hash';

const { initDatabase, getDb } = require('../src/database');
const orderRepo = require('../src/database/repositories/order.repository');
const orderService = require('../src/services/order.service');
const productService = require('../src/services/product.service');

initDatabase();
const db = getDb();
const USER = 991111;
const USER2 = 991112;
for (const id of [USER, USER2]) db.prepare('INSERT INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(id, `u${id}`, `User${id}`);
const product = productService.create({ category: 'userbot', name: 'Expiry Test', description: 'expiry', price: 5000, durationDays: 30, garansi: false });

function directOrder({ id, userId = USER, status = 'pending', createdAt = '2099-01-01 00:00:00', expiresAt = '2099-01-01 01:00:00', category = 'userbot', productId = product.id, productName = 'Expiry Test', unitPrice = 5000, total = 5000, qty = 1, durationDays = 30 } = {}) {
  db.prepare(`
    INSERT INTO orders
      (id,user_id,product_id,category,product_name,qty,unit_price,total_price,duration_days,status,created_at,expires_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(id, userId, productId, category, productName, qty, unitPrice, total, durationDays, status, createdAt, expiresAt);
  return orderRepo.findById(id);
}

const tests = [];
function test(name, fn) {
  try { fn(); tests.push(true); console.log(`PASS  ${name}`); }
  catch (err) { tests.push(false); console.log(`FAIL  ${name}\n      ${err && err.stack || err}`); }
}

const created = orderService.createOrder({ userId: USER, product, qty: 1 });
test('new order stores an individual one-hour expiration derived from SQLite creation time', () => {
  assert.match(created.created_at, /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
  assert.match(created.expires_at, /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
  const createdMs = new Date(created.created_at.replace(' ', 'T') + 'Z').getTime();
  const expiresMs = new Date(created.expires_at.replace(' ', 'T') + 'Z').getTime();
  assert.equal(expiresMs - createdMs, 60 * 60 * 1000);
});

// Free the one-open-order rule through a real cancellation before subsequent cases.
orderService.cancelOwnOrder({ orderId: created.id, userId: USER });

const past = directOrder({ id: 7001, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 01:00:00' });
const future = directOrder({ id: 7002, createdAt: '2099-01-01 02:00:00', expiresAt: '2099-01-01 03:00:00' });
const future2 = directOrder({ id: 7003, userId: USER2, createdAt: '2099-01-01 02:15:00', expiresAt: '2099-01-01 03:15:00' });

// The time anchor is explicit so these checks are deterministic.
const NOW = '2030-01-01T02:00:00.000Z';

test('expired pending order is atomically terminalized and no longer appears in active recovery', () => {
  assert.equal(orderService.expireStaleOrders(NOW), 1);
  assert.equal(orderRepo.findById(past.id).status, 'expired');
  assert.deepEqual(orderRepo.findOpenOrdersByUser(USER, NOW), []);
});

test('idempotent expiration does not touch already expired/terminal rows', () => {
  assert.equal(orderService.expireStaleOrders(NOW), 0);
  assert.equal(orderRepo.findById(past.id).status, 'expired');
  assert.equal(orderRepo.findById(created.id).status, 'cancelled');
});

test('multiple orders have independent expiration timestamps', () => {
  const a = directOrder({ id: 7004, userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 01:00:00' });
  const b = directOrder({ id: 7005, userId: USER2, createdAt: '2030-01-01 00:30:00', expiresAt: '2030-01-01 01:30:00' });
  assert.equal(new Date(a.expires_at.replace(' ', 'T') + 'Z').getTime() - new Date(a.created_at.replace(' ', 'T') + 'Z').getTime(), 3600000);
  assert.equal(new Date(b.expires_at.replace(' ', 'T') + 'Z').getTime() - new Date(b.created_at.replace(' ', 'T') + 'Z').getTime(), 3600000);
  orderService.expireStaleOrders('2030-01-01T01:15:00.000Z');
  assert.equal(orderRepo.findById(a.id).status, 'expired');
  assert.equal(orderRepo.findById(b.id).status, 'pending');
});

test('createOrder performs real stale-order cleanup before applying one-open-order guard', () => {
  const stale = directOrder({ id: 7010, userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 00:30:00' });
  assert.equal(orderRepo.findById(stale.id).status, 'pending');
  const fresh = orderService.createOrder({ userId: USER, product, qty: 1 });
  assert.equal(orderRepo.findById(stale.id).status, 'expired');
  assert.equal(fresh.status, 'pending');
  assert.ok(fresh.expires_at);
  orderService.cancelOwnOrder({ orderId: fresh.id, userId: USER });
});

test('expired order cannot request payment proof', () => {
  const o = directOrder({ id: 7011, userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 00:30:00' });
  const r = orderService.requestPaymentProof({ orderId: o.id, userId: USER });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'expired');
  assert.equal(orderRepo.findById(o.id).status, 'expired');
});

test('expired order cannot accept payment proof', () => {
  const o = directOrder({ id: 7012, userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 00:30:00' });
  db.prepare("UPDATE orders SET payment_proof_requested_at='2030-01-01T00:05:00.000Z' WHERE id=?").run(o.id);
  const r = orderService.submitPaymentProof({ orderId: o.id, userId: USER, proofType: 'photo', fileId: 'real-test-file-id', caption: '', entities: [], durationMinutes: 30 });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'expired');
  assert.equal(orderRepo.findById(o.id).status, 'expired');
});

test('expired order cannot be buyer-cancelled as a live pending order', () => {
  const o = directOrder({ id: 7013, userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 00:30:00' });
  const r = orderService.cancelOwnOrder({ orderId: o.id, userId: USER });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'expired');
  assert.equal(orderRepo.findById(o.id).status, 'expired');
});

test('expired order cannot be claimed for processing', () => {
  const o = directOrder({ id: 7014, status: 'awaiting_confirmation', userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 00:30:00' });
  assert.equal(orderRepo.claimForProcessing(o.id), null);
  assert.equal(orderRepo.findById(o.id).status, 'awaiting_confirmation');
  orderService.refreshOrder(o.id);
  assert.equal(orderRepo.findById(o.id).status, 'expired');
});

test('stale processing recovery expires a processing order whose absolute order deadline has passed', () => {
  const o = directOrder({ id: 7015, status: 'processing', userId: USER, createdAt: '2020-01-01 00:00:00', expiresAt: '2020-01-01 00:30:00' });
  db.prepare("UPDATE orders SET processing_started_at='2030-01-01T00:40:00.000Z', processing_heartbeat_at='2030-01-01T00:40:00.000Z', processing_claim_token='crashed', updated_at='2030-01-01T00:40:00.000Z' WHERE id=?").run(o.id);
  assert.equal(orderService.reclaimStaleProcessingOrders('2030-01-01T01:00:00.000Z'), 1);
  assert.equal(orderRepo.findById(o.id).status, 'expired');
});

test('stale processing recovery keeps a still-live order retryable as paid', () => {
  const o = directOrder({ id: 7016, status: 'processing', userId: USER, createdAt: '2030-01-01 00:00:00', expiresAt: '2030-01-01 03:00:00' });
  db.prepare("UPDATE orders SET processing_started_at='2030-01-01T00:00:00.000Z', processing_heartbeat_at='2030-01-01T00:40:00.000Z', processing_claim_token='crashed-live', updated_at='2030-01-01T00:40:00.000Z' WHERE id=?").run(o.id);
  assert.equal(orderService.reclaimStaleProcessingOrders('2030-01-01T01:00:00.000Z'), 1);
  assert.equal(orderRepo.findById(o.id).status, 'paid');
});

test('processing claim release after deadline cannot return an expired order to paid', () => {
  const o = directOrder({ id: 7017, status: 'awaiting_confirmation', userId: USER, createdAt: '2099-01-01 00:00:00', expiresAt: '2099-01-01 03:00:00' });
  const token = orderRepo.claimForProcessing(o.id);
  assert.ok(token);
  db.prepare("UPDATE orders SET expires_at='2000-01-01 00:00:00' WHERE id=?").run(o.id);
  assert.equal(orderRepo.releaseProcessingClaim(o.id, token, 'paid'), true);
  assert.equal(orderRepo.findById(o.id).status, 'expired');
});

test('historical order keeps price snapshot while a new order reads the current product price', () => {
  const first = orderService.createOrder({ userId: USER2, product, qty: 1 });
  assert.equal(first.unit_price, 5000);
  productService.update(product.id, { price: 10000 });
  orderService.cancelOwnOrder({ orderId: first.id, userId: USER2 });
  const second = orderService.createOrder({ userId: USER2, product, qty: 1 });
  assert.equal(first.unit_price, 5000);
  assert.equal(orderRepo.findById(first.id).unit_price, 5000);
  assert.equal(second.unit_price, 10000);
  assert.equal(second.total_price, 10000);
  orderService.cancelOwnOrder({ orderId: second.id, userId: USER2 });
});

test('retiring a product preserves historical order snapshot and entitlement reference', () => {
  const doomed = productService.create({ category: 'userbot', name: 'Delete Snapshot', description: 'keep', price: 8000, durationDays: 60, garansi: false });
  const o = orderService.createOrder({ userId: USER, product: doomed, qty: 2 });
  productService.remove(doomed.id);
  const saved = orderRepo.findById(o.id);
  assert.equal(saved.product_id, doomed.id);
  assert.equal(productService.getById(doomed.id).is_active, 0);
  assert.equal(saved.product_name, 'Delete Snapshot');
  assert.equal(saved.unit_price, 8000);
  assert.equal(saved.total_price, 16000);
  assert.equal(saved.duration_days, 120);
  orderService.cancelOwnOrder({ orderId: o.id, userId: USER });
});

test('terminal states are never expired by the expiration sweep', () => {
  for (const [i, status] of ['cancelled', 'rejected', 'fulfilled'].entries()) {
    directOrder({ id: 7100 + i, userId: USER, status, createdAt: '2000-01-01 00:00:00', expiresAt: '2000-01-01 01:00:00' });
  }
  orderService.expireStaleOrders('2030-01-01T00:00:00.000Z');
  assert.deepEqual(db.prepare("SELECT status FROM orders WHERE id IN (7100,7101,7102) ORDER BY id").all().map(r => r.status), ['cancelled', 'rejected', 'fulfilled']);
});

test('foreign key integrity is clean after order lifecycle tests', () => {
  assert.deepEqual(db.pragma('foreign_key_check'), []);
});

const failed = tests.filter((x) => !x).length;
console.log(`\n${tests.length - failed}/${tests.length} passed`);
process.exit(failed ? 1 : 0);
