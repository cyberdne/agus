'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const statsHandler = read('src/handlers/admin/statistics.handler.js');
const customHandler = read('src/handlers/admin/customSubmenu.handler.js');
const customService = read('src/services/custom-submenu.service.js');

// Regression guard for the reported crash: dynamic statistics templates must
// be rendered through one shared, real statistics context builder.
assert.match(statsHandler, /function buildStatisticsRenderContext\(\)/);
assert.match(statsHandler, /const statistics = statisticsService\.getStatisticsSnapshot\(\)/);
assert.match(statsHandler, /return \{[\s\S]*statistics,[\s\S]*placeholderValues: placeholderValues\(statistics\)/);
assert.match(statsHandler, /const renderContext = buildStatisticsRenderContext\(\)/);
assert.match(customHandler, /normalizedId === 'admin\.statistics' \|\| normalizedId\.startsWith\('admin\.statistics\.'\)/);
assert.match(customHandler, /buildStatisticsRenderContext\(\)/);

// The reference path must use the same runtime template registry and actual
// template function; no duplicate hardcoded statistics message is introduced.
assert.match(customHandler, /getTemplateReference\(submenuId, ctx, buildPreviewExtra\(ctx, submenuId\)\)/);
assert.doesNotMatch(customHandler, /Template Reference/);

// Custom Submenu service continues to execute the registry's actual dynamic
// default value with the supplied context instead of manufacturing a fallback.
assert.match(customService, /typeof defaultContent\.text === 'function' \? defaultContent\.text\(ctx, extra\)/);
assert.match(customService, /const fallback = resolveDefault\(\{ text: entry\.defaultValue, parse_mode: entry\.parseMode \}, ctx, extra\)/);

const expectedPlaceholders = {
  users: ['total_users', 'active_users', 'inactive_users'],
  userbot: ['total_userbots', 'active_userbots', 'pending_userbots'],
  stock: ['stock_total', 'stock_available', 'stock_used'],
  orders: ['orders_total', 'orders_pending', 'orders_successful'],
  payments: ['payment_pending', 'payment_verified'],
  subscription: ['subscription_active', 'trial_active'],
  promotion: ['promotion_running', 'active_promotion_loops'],
  system: ['uptime', 'node_version', 'platform', 'arch', 'process_memory', 'heap_used', 'heap_total', 'system_memory', 'external_memory', 'system_free_memory', 'cpu_load', 'cpu_load_1m', 'cpu_cores', 'db_status', 'db_latency', 'db_size', 'db_integrity', 'wal_status', 'foreign_keys', 'scheduler_status', 'scheduler_last_tick', 'app_version', 'server_time', 'pid'],
};
const sections = Object.keys(expectedPlaceholders);
for (const [index, section] of sections.entries()) {
  const marker = `  ${section}: defineTemplate(`;
  const sectionStart = statsHandler.indexOf(marker);
  assert.notEqual(sectionStart, -1, `statistics template missing: ${section}`);
  const nextMarker = index + 1 < sections.length ? `\n  ${sections[index + 1]}: defineTemplate(` : '\n};';
  const next = statsHandler.indexOf(nextMarker, sectionStart + marker.length);
  const sectionSource = statsHandler.slice(sectionStart, next === -1 ? statsHandler.length : next);
  assert.match(sectionSource, /supportedPlaceholders:\s*\[[^\]]+\]/, `${section} must expose a category-specific placeholder allowlist`);
  for (const token of expectedPlaceholders[section]) {
    assert.match(sectionSource, new RegExp(`['\"]${token}['\"]`), `${section} placeholder missing: ${token}`);
  }
}

console.log('STATISTICS_CUSTOM_SUBMENU_STATIC_OK shared_context=1 dynamic_reference=1 category_placeholders=8');
