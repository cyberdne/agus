'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const assertEq = (actual, expected, message) => assert.strictEqual(actual, expected, message);

const keyboard = read('src/keyboards/panelControl.keyboard.js');
const panel = read('src/handlers/panel.handler.js');
const adminPanel = read('src/handlers/admin/panelUbot.handler.js');
const feature = read('src/services/featureAccess.service.js');
const index = read('src/index.js');
const gramjs = read('src/services/gramjs.service.js');
const runtime = read('src/services/userbotRuntime.service.js');
const config = read('src/config/index.js');
const nav = read('src/middlewares/navigationCancellation.middleware.js');

assert(!/kind\s*===\s*['"]pool['"]/.test(keyboard), 'panel keyboard has no product-kind-specific layout branch');
assert(/function panelMainKeyboard\(active = false\)/.test(keyboard), 'canonical panel main keyboard is shared');
assert(/function baseReplyKeyboard\(\)/.test(keyboard), 'Base Reply keyboard is shared');
assert(/function messageKeyboard\(\)/.test(keyboard), 'Message keyboard is shared');
const messageFn = keyboard.slice(keyboard.indexOf('function messageKeyboard'), keyboard.indexOf('function groupKeyboard'));
assert.match(messageFn, /\[replyButton\.primary\(PANEL_FEATURE\.MESSAGE_TEXT_MEDIA\), replyButton\.primary\(PANEL_FEATURE\.MESSAGE_FORWARD\)\]/, 'Message row 1 is Text/Media + Forward');
assert.match(messageFn, /\[replyButton\.success\(PANEL_FEATURE\.MESSAGE_VIEW\), replyButton\.danger\(PANEL_FEATURE\.MESSAGE_DELETE\)\]/, 'Message row 2 is View + Delete');
assert.match(messageFn, /\[replyButton\.danger\(MENU\.KEMBALI, \{ customizable: false \}\)\]/, 'Message row 3 is standalone Kembali');
assert(panel.includes('showAssetPicker'), 'selected multi-userbot panel can return to the real asset picker');
assert(panel.includes("returnTo:'home'"), 'root panel entry records main-menu parent context');
assert(panel.includes("returnTo:current && current.screen === 'select' ? 'select' : 'home'"), 'selected asset records picker context only when actually selected from picker');
assert(adminPanel.includes("returnTo: 'admin_ubot_list'"), 'admin-selected userbot records Admin userbot-picker parent context');
assert(nav.includes("panel.adminMode && panel.returnTo === 'admin_ubot_list'"), 'admin control-panel Back returns to Admin userbot picker');
assert(!nav.includes("!panel.adminMode && panel.returnTo === 'select'"), 'root user control-panel Back must exit instead of reopening the picker');
assert(nav.includes("case 'main':") && nav.includes("backToMainHandler"), 'root user control-panel Back returns to the main menu');
assert(/function groupKeyboard\(\)/.test(keyboard), 'Group keyboard is shared');
assert(/function delayKeyboard\(\)/.test(keyboard), 'Delay keyboard is shared');
assert(/function extraKeyboard\(isAdmin = false\)/.test(keyboard), 'Extra keyboard is shared');

const mainRows = keyboard.slice(keyboard.indexOf('function panelMainKeyboard'), keyboard.indexOf('\n}\n\nfunction baseReplyKeyboard'));
const expectedOrder = [
  'PANEL_FEATURE.BASE_REPLY',
  'PANEL_FEATURE.STORE',
  'PANEL_FEATURE.EXTRA',
  'PANEL_FEATURE.MESSAGE',
  'PANEL_FEATURE.GROUP',
  'PANEL_FEATURE.DELAY',
  'PANEL_FEATURE.GUIDE',
  'MENU.KEMBALI',
];
let previous = -1;
for (const token of expectedOrder) {
  const pos = mainRows.indexOf(token);
  assert(pos > previous, `canonical main panel button order contains ${token}`);
  previous = pos;
}

assert(panel.includes('panelMainKeyboard(active)'), 'panel renderer delegates layout to the canonical keyboard without product-kind branching');
assert(panel.includes('featureAccessSvc.checkAssetFeature(sel.asset, featureId, sel.kind)'), 'feature access remains the backend capability boundary');
assert(feature.includes('resolveProductForPoolAsset'), 'pool entitlement resolves through assigned order product');
assert(feature.includes("if (kind === 'pool')"), 'pool assets use the same feature-access API');

assert(adminPanel.includes("const poolRepo = require('../../database/repositories/userbotPool.repository')"), 'admin panel imports canonical Jaseb pool repository');
assert(adminPanel.includes('const pool = poolRepo.listAll();'), 'admin control-panel picker includes Jaseb pool assets');
assert(adminPanel.includes("if (!['owned', 'pool'].includes(kind))"), 'admin control-panel selection validates both asset kinds');
assert(adminPanel.includes("const repo = kind === 'pool' ? poolRepo : ownedRepo;"), 'admin selection resolves the selected asset using its real kind');
assert(index.includes("bot.action(/^adminpanelubot:select:/, requireAdmin(panelUbotSelectCallback));"), 'admin panel selection remains admin-only');

assert(config.includes("telegramDeviceModel: process.env.TELEGRAM_DEVICE_MODEL || 'JASEBRICH'"), 'device model stays centrally configurable');
assert(gramjs.includes("deviceModel: config.telegramDeviceModel || 'JASEBRICH'"), 'authorization login uses the configured device model');
assert(runtime.includes("deviceModel: config.telegramDeviceModel || 'JASEBRICH'"), 'runtime reconnection uses the configured device model');
assert(!/proxy/i.test(`${gramjs}\n${runtime}\n${config}`), 'no fabricated Jakarta location/proxy implementation exists');

console.log('CONTROL_PANEL_CONSISTENCY_PASS unified-layout=1 entitlement-boundary=1 jaseb-admin-panel=1 device-config=1');
