'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

for (const rel of [
  'src/keyboards/admin.keyboard.js',
  'src/keyboards/adminStatistics.keyboard.js',
  'src/keyboards/inline.keyboard.js',
  'src/keyboards/panelControl.keyboard.js',
]) {
  const source = read(rel);
  assert.doesNotMatch(source, /🔙 Kembali ke (?:Setting|Settings|Panel|Admin Panel|Produk|User Management|Statistik|Daftar|Detail|Status)/);
}

const inputFlows = read('src/constants/adminInputFlows.js');
const adminKeyboard = read('src/keyboards/admin.keyboard.js');
const adminReply = read('src/middlewares/adminReply.middleware.js');
const render = read('src/utils/render.js');
assert.match(inputFlows, /CANCEL_LABEL = MENU\.BATAL/);
assert.match(inputFlows, /type: 'cancel', label: CANCEL_LABEL/);
assert.match(adminKeyboard, /const \{ navSpec, CANCEL_LABEL \}/);
assert.match(adminKeyboard, /return replyButton\.danger\(CANCEL_LABEL\)/);
assert.match(adminReply, /text === inputFlows\.CANCEL_LABEL/);
assert.match(adminReply, /findStaticRoute\(flow\.cancel\)/);
assert.match(adminReply, /text === inputFlows\.BACK_LABEL/);
assert.match(adminReply, /resolveGenericBackRoute\(ctx\)/);
assert.match(adminReply, /screenState\.get/);
assert.match(adminReply, /Markup\.removeKeyboard/);
assert.ok(adminReply.includes('if (/^admin:statistics(?::|$)/.test(feature))'));
assert.ok(adminReply.includes("if (feature === ADMIN_CALLBACK.PRODUCT_HOME) return [adminCommerceCategoryCallback, 'admin:category:commerce'];"));
assert.ok(adminReply.includes("if (/^adminuser:list:\\d+$/.test(feature)) return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];"));
assert.ok(adminReply.includes("if (feature === ADMIN_CALLBACK.BROADCAST_HOME) return [adminNotificationsCategoryCallback, 'admin:category:notifications'];"));
assert.ok(adminReply.includes("if (feature === ADMIN_CALLBACK.PAYMENT_HOME) return [adminOrdersCategoryCallback, 'admin:category:orders'];"));
assert.ok(adminReply.includes("if (feature === ADMIN_CALLBACK.PANEL_UBOT_HOME) return [adminUserbotCategoryCallback, 'admin:category:userbot'];"));
assert.ok(adminReply.includes('if (/^admintrx:/.test(feature))'));
assert.ok(adminReply.includes('if (/^adminpanelubot:/.test(feature))'));
assert.match(render, /screenState\.set\(chatId, sent\.message_id, feature\)/);
assert.match(render, /return ctx\.callbackQuery\.data;/);
assert.ok(read('src/handlers/admin/statistics.handler.js').includes('ADMIN_CALLBACK.STATISTICS_HOME'));
assert.ok(read('src/handlers/admin/statistics.handler.js').includes('ADMIN_CALLBACK.STATISTICS_SECTION(normalized)'));
assert.doesNotMatch(render, /callbackQuery\.data\.split\(':'.*\)\[0\]/);

console.log('NAVIGATION_STANDARD_STATIC_OK standard_back=1 contextual_cancel=1 context_parent=1 stale_keyboard_removed=1');
