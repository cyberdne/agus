'use strict';
/**
 * Trial Feature Access — real end-to-end tests (real SQLite + real schema,
 * real featureAccess.service / trialConfig.service / product.service /
 * userbot.service / panel.handler enforcement, real admin handlers/state).
 * Only Telegram transport (ctx) is a recording stub, same convention as the
 * rest of scripts/test-*.js. Run: node scripts/test-trial-feature-access.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('node:assert/strict');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jaseb-trialfeat-'));
process.env.DB_PATH = path.join(tmp, 't.sqlite');
process.env.BOT_TOKEN = 'test';
process.env.ADMIN_IDS = '900';
process.env.TELEGRAM_API_ID = '1';
process.env.TELEGRAM_API_HASH = 'x';
process.chdir(tmp);
const root = path.resolve(__dirname, '..');

const { initDatabase, getDb } = require(path.join(root, 'src/database'));
initDatabase();
const db = getDb();
const S = (p) => require(path.join(root, 'src', p));

const featureAccess = S('services/featureAccess.service');
const trialConfigService = S('services/trialConfig.service');
const userbotService = S('services/userbot.service');
const productService = S('services/product.service');
const orderService = S('services/order.service');
const ownedRepo = S('database/repositories/ownedUserbot.repository');
const settingsRepo = S('database/repositories/settings.repository');
const trialHandler = S('handlers/admin/trialSettings.handler');
const adminState = S('state/adminState');
const { ADMIN_CALLBACK } = S('constants/admin.callback');

const ADMIN = 900, BUYER = 501, TRIAL_USER = 601;
for (const id of [BUYER, TRIAL_USER]) {
  db.prepare('INSERT INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(id, `u${id}`, `U${id}`);
}

const results = [];
function test(name, fn) {
  try {
    fn();
    results.push(true);
    console.log(`PASS  ${name}`);
  } catch (e) {
    results.push(false);
    console.log(`FAIL  ${name}\n      ${(e && e.stack) || e}`);
  }
}
async function testAsync(name, fn) {
  try {
    await fn();
    results.push(true);
    console.log(`PASS  ${name}`);
  } catch (e) {
    results.push(false);
    console.log(`FAIL  ${name}\n      ${(e && e.stack) || e}`);
  }
}
const asyncTests = [];
function queueAsync(name, fn) {
  asyncTests.push([name, fn]);
}

function fakeCallbackCtx(fromId, data) {
  const replies = [];
  return {
    from: { id: fromId },
    chat: { id: fromId },
    callbackQuery: { data, message: { message_id: 1, chat: { id: fromId } } },
    answerCbQuery: async () => true,
    reply: async (text, extra) => { replies.push({ text, extra }); return { message_id: replies.length }; },
    editMessageText: async (text, extra) => { replies.push({ text, extra, edited: true }); return true; },
    telegram: { sendMessage: async () => ({}) },
    __replies: replies,
  };
}

function makeTrialAsset(userId, durationHours = 1) {
  return userbotService.createTrialOwned({ userId, durationHours });
}

function makePurchasedAsset(userId, featureAccessJson) {
  const product = productService.create({
    category: 'userbot',
    name: `Produk ${Math.random()}`,
    description: 'd',
    price: 10000,
    durationDays: 30,
    garansi: false,
  });
  if (featureAccessJson !== undefined) {
    productService.update(product.id, { featureAccess: featureAccessJson });
  }
  const order = orderService.createOrder({
    userId,
    product,
    category: 'userbot',
    qty: 1,
  });
  const asset = ownedRepo.create({ userId, label: 'Userbot', phone: null, orderId: order.id, expiresAt: null });
  return { asset, product };
}

// ---------------------------------------------------------------------
// TASK 39/44 — semantics: NULL / [] / [A,B], invalid data fails safe
// ---------------------------------------------------------------------

test('trial config starts as NULL (never configured) -> unrestricted', () => {
  assert.equal(featureAccess.getTrialFeatureAccess(), null);
  const trial = makeTrialAsset(TRIAL_USER);
  for (const f of featureAccess.listFeatures()) {
    assert.equal(featureAccess.checkOwnedAssetFeature(trial, f.id).allowed, true);
  }
});

test('trial config [] -> every feature denied (not unrestricted)', () => {
  featureAccess.setTrialFeatureAccess([]);
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), []);
  const trial = makeTrialAsset(TRIAL_USER);
  for (const f of featureAccess.listFeatures()) {
    const check = featureAccess.checkOwnedAssetFeature(trial, f.id);
    assert.equal(check.allowed, false);
    assert.equal(check.restricted, true);
  }
});

test('trial config [base_reply] -> only base_reply allowed, timer denied', () => {
  featureAccess.setTrialFeatureAccess(['base_reply']);
  const trial = makeTrialAsset(TRIAL_USER);
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'base_reply').allowed, true);
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, false);
});

test('every FEATURE_REGISTRY entry is individually tested by trial config, not just one', () => {
  for (const f of featureAccess.listFeatures()) {
    featureAccess.setTrialFeatureAccess([f.id]);
    const trial = makeTrialAsset(TRIAL_USER);
    for (const other of featureAccess.listFeatures()) {
      const expected = other.id === f.id;
      assert.equal(featureAccess.checkOwnedAssetFeature(trial, other.id).allowed, expected, `feature ${other.id} with only ${f.id} granted`);
    }
  }
});

test('unknown/forged feature ids are dropped on save, never granted', () => {
  featureAccess.setTrialFeatureAccess(['base_reply', 'not_a_real_feature', '__proto__']);
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), ['base_reply']);
});

test('invalid JSON / non-array configured value fails closed to no features, never crashes or grants access', () => {
  settingsRepo.set('trial_feature_access', '{not json');
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), []);
  settingsRepo.set('trial_feature_access', '"just a string"');
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), []);
  settingsRepo.set('trial_feature_access', '42');
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), []);
});

test('resetTrialFeatureAccess() explicitly stores NULL (distinct call from an empty array save)', () => {
  featureAccess.setTrialFeatureAccess([]);
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), []);
  featureAccess.resetTrialFeatureAccess();
  assert.equal(featureAccess.getTrialFeatureAccess(), null);
});

// ---------------------------------------------------------------------
// TASK 36 — trial vs purchased independence
// ---------------------------------------------------------------------

test('Trial config never affects a purchased userbot, and vice versa', () => {
  featureAccess.setTrialFeatureAccess(['base_reply']);
  const trial = makeTrialAsset(TRIAL_USER);
  const { asset: purchased } = makePurchasedAsset(BUYER, JSON.stringify(['timer']));

  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'base_reply').allowed, true);
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, false);
  assert.equal(featureAccess.checkOwnedAssetFeature(purchased, 'timer').allowed, true);
  assert.equal(featureAccess.checkOwnedAssetFeature(purchased, 'base_reply').allowed, false);

  // Changing the product's checklist must not move the trial's, and
  // resetting the trial must not move the product's.
  productService.update(
    db.prepare('SELECT product_id FROM orders WHERE id = ?').get(purchased.order_id).product_id,
    { featureAccess: JSON.stringify(['base_reply']) }
  );
  assert.equal(featureAccess.checkOwnedAssetFeature(purchased, 'base_reply').allowed, true);
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, false); // unchanged

  featureAccess.resetTrialFeatureAccess();
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, true); // trial now unrestricted
  assert.equal(featureAccess.checkOwnedAssetFeature(purchased, 'base_reply').allowed, true); // product untouched
});

test('Product feature_access=NULL (legacy) purchased userbot stays unrestricted regardless of trial config', () => {
  featureAccess.setTrialFeatureAccess([]); // trial: nothing allowed
  const { asset: purchased } = makePurchasedAsset(BUYER); // no featureAccess passed -> NULL
  for (const f of featureAccess.listFeatures()) {
    assert.equal(featureAccess.checkOwnedAssetFeature(purchased, f.id).allowed, true);
  }
});

test('Purchase-backed asset with an unresolved entitlement fails closed, not trial-gated', () => {
  featureAccess.setTrialFeatureAccess([]); // trial: nothing allowed
  const product = productService.create({ category: 'userbot', name: 'To Delete', description: '', price: 1, durationDays: 1, garansi: false });
  const order = orderService.createOrder({ userId: BUYER, product, category: 'userbot', qty: 1 });
  const asset = ownedRepo.create({ userId: BUYER, label: 'Userbot Lama', phone: null, orderId: order.id, expiresAt: null });
  db.prepare('DELETE FROM products WHERE id=?').run(product.id); // simulate corruption/legacy hard deletion
  assert.equal(featureAccess.isTrialAsset(asset), false);
  for (const f of featureAccess.listFeatures()) {
    const result = featureAccess.checkOwnedAssetFeature(asset, f.id);
    assert.equal(result.allowed, false);
    assert.equal(result.reason, 'entitlement_unresolved');
  }
});

test('Legacy owned row with NULL order_id but NOT the trial label is still treated as unrestricted, never as trial', () => {
  featureAccess.setTrialFeatureAccess([]); // trial: nothing allowed
  const legacyAsset = ownedRepo.create({ userId: BUYER, label: 'Userbot Warisan', phone: null, orderId: null, expiresAt: null });
  assert.equal(featureAccess.isTrialAsset(legacyAsset), false);
  for (const f of featureAccess.listFeatures()) {
    assert.equal(featureAccess.checkOwnedAssetFeature(legacyAsset, f.id).allowed, true);
  }
});

// ---------------------------------------------------------------------
// TASK 19/20 — trial duration stays independent of feature access
// ---------------------------------------------------------------------

test('Trial duration and Trial Feature Access do not interfere with each other', () => {
  trialConfigService.setTrialDurationHours(24);
  featureAccess.setTrialFeatureAccess(['base_reply', 'timer']);
  assert.equal(trialConfigService.getTrialDurationHours(), 24);
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), ['base_reply', 'timer']);

  trialConfigService.setTrialDurationHours(72);
  assert.equal(trialConfigService.getTrialDurationHours(), 72);
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), ['base_reply', 'timer']); // unchanged by duration change

  featureAccess.setTrialFeatureAccess(['message_settings']);
  assert.equal(trialConfigService.getTrialDurationHours(), 72); // unchanged by feature change
});

// ---------------------------------------------------------------------
// TASK 40 — live revocation, no stale snapshot
// ---------------------------------------------------------------------

test('Live revocation: admin change is reflected immediately for an EXISTING trial asset, no snapshot', () => {
  featureAccess.setTrialFeatureAccess(['base_reply', 'timer']);
  const trial = makeTrialAsset(TRIAL_USER);
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, true);

  featureAccess.setTrialFeatureAccess(['base_reply']); // admin removes timer
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, false);
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'base_reply').allowed, true);

  featureAccess.setTrialFeatureAccess(['base_reply', 'timer']); // admin adds timer back
  assert.equal(featureAccess.checkOwnedAssetFeature(trial, 'timer').allowed, true);
});

// ---------------------------------------------------------------------
// TASK 25/38 — admin checklist backend: security, validation, staging
// ---------------------------------------------------------------------

queueAsync('Admin checklist: toggle validates feature id, keeps state staged, does not persist until Save', async () => {
  featureAccess.resetTrialFeatureAccess();
  adminState.clear(ADMIN);

  await trialHandler.trialFeaturesHomeCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_HOME));
  let state = adminState.get(ADMIN);
  assert.equal(state.action, 'admin_trial_features');
  // NULL opened the editor with every box checked (same convention as Product Feature Access).
  assert.deepEqual(new Set(state.selectedFeatures), new Set(featureAccess.listFeatures().map((f) => f.id)));

  // Toggle one real feature off.
  await trialHandler.trialFeaturesToggleCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_TOGGLE('timer')));
  state = adminState.get(ADMIN);
  assert.ok(!state.selectedFeatures.includes('timer'));
  // Nothing persisted yet.
  assert.equal(featureAccess.getTrialFeatureAccess(), null);

  // Forged/unknown feature id toggle is rejected, state unchanged.
  const before = adminState.get(ADMIN).selectedFeatures.slice();
  await trialHandler.trialFeaturesToggleCallback(fakeCallbackCtx(ADMIN, 'trial_settings:feattoggle:not_a_real_feature'));
  assert.deepEqual(adminState.get(ADMIN).selectedFeatures, before);

  // Cancel discards the staged selection; persisted config stays NULL.
  await trialHandler.trialFeaturesCancelCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_CANCEL));
  assert.equal(adminState.get(ADMIN), null);
  assert.equal(featureAccess.getTrialFeatureAccess(), null);
});

queueAsync('Admin checklist: Save persists exactly the staged selection, including an explicit empty selection', async () => {
  adminState.clear(ADMIN);
  await trialHandler.trialFeaturesHomeCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_HOME));
  // Uncheck everything one by one down to zero, proving 0 features is reachable.
  for (const f of featureAccess.listFeatures()) {
    await trialHandler.trialFeaturesToggleCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_TOGGLE(f.id)));
  }
  assert.deepEqual(adminState.get(ADMIN).selectedFeatures, []);
  await trialHandler.trialFeaturesSaveCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_SAVE));
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), []); // [] persisted, NOT null
  assert.equal(adminState.get(ADMIN), null); // state cleared after successful save
});

queueAsync('Admin checklist: Save is rejected outside a valid session (stale/forged), nothing persisted', async () => {
  adminState.clear(ADMIN);
  featureAccess.setTrialFeatureAccess(['base_reply']);
  const before = featureAccess.getTrialFeatureAccess();
  await trialHandler.trialFeaturesSaveCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_SAVE));
  assert.deepEqual(featureAccess.getTrialFeatureAccess(), before); // untouched
});

queueAsync('Admin checklist: Reset saves NULL (unrestricted), not an all-checked array', async () => {
  adminState.clear(ADMIN);
  featureAccess.setTrialFeatureAccess(['base_reply']);
  await trialHandler.trialFeaturesHomeCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_HOME));
  await trialHandler.trialFeaturesResetCallback(fakeCallbackCtx(ADMIN, ADMIN_CALLBACK.TRIAL_FEATURES_RESET));
  assert.equal(featureAccess.getTrialFeatureAccess(), null);
  assert.equal(adminState.get(ADMIN), null);
});

// ---------------------------------------------------------------------
// TASK 42 — trial claim/creation flow unaffected
// ---------------------------------------------------------------------

test('createTrialOwned() still creates a one-time, order-less, correctly-labeled trial row, and it resolves as trial', () => {
  featureAccess.setTrialFeatureAccess(['base_reply']);
  const before = trialConfigService.getTrialDurationHours();
  const row = userbotService.createTrialOwned({ userId: TRIAL_USER, durationHours: before });
  assert.equal(row.order_id, null);
  assert.equal(row.label, '🎁 Trial Userbot');
  assert.equal(row.status, 'pending_otp');
  assert.equal(featureAccess.isTrialAsset(row), true);
  assert.equal(featureAccess.checkOwnedAssetFeature(row, 'base_reply').allowed, true);
  assert.equal(featureAccess.checkOwnedAssetFeature(row, 'timer').allowed, false);
});

// ---------------------------------------------------------------------
// Regression — FEATURE_REGISTRY is not duplicated: trial ids ARE product ids
// ---------------------------------------------------------------------

test('No second feature registry: every id offered by the trial checklist exists in FEATURE_REGISTRY', () => {
  const registryIds = new Set(featureAccess.listFeatures().map((f) => f.id));
  featureAccess.setTrialFeatureAccess(Array.from(registryIds));
  assert.deepEqual(new Set(featureAccess.getTrialFeatureAccess()), registryIds);
});

queueAsync('Wizard revocation: base_reply allowed then live-revoked mid-wizard blocks the pending step and clears it', async () => {
  const panel = S('handlers/panel.handler');
  const panelState = S('state/panelState');

  const WIZARD_USER = 602;
  db.prepare('INSERT OR IGNORE INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(WIZARD_USER, `u${WIZARD_USER}`, `U${WIZARD_USER}`);

  featureAccess.setTrialFeatureAccess(['base_reply', 'timer']);
  const trial = userbotService.createTrialOwned({ userId: WIZARD_USER, durationHours: 24 });
  ownedRepo.activate(trial.id, { sessionString: 'sess', telegramUserbotId: 1, token: 'TOK-TEST', expiresAt: null });

  panelState.set(WIZARD_USER, { kind: 'owned', id: trial.id, step: 'await_add_reply' });

  const replies1 = [];
  const ctx1 = {
    from: { id: WIZARD_USER },
    chat: { id: WIZARD_USER },
    reply: async (text, extra) => { replies1.push(text); return { message_id: 1 }; },
    telegram: { sendMessage: async () => ({}) },
  };
  const handled1 = await panel.handleStepInput(ctx1, { step: 'await_add_reply' }, 'promo|Balasan promo');
  assert.equal(handled1, true);
  assert.ok(replies1.some((t) => /reply ditambahkan/i.test(t)), 'base_reply step should have succeeded while allowed');

  // Admin revokes base_reply from the trial while nothing else about the
  // wizard/session changes — no new trial, no re-login, same panelState.
  featureAccess.setTrialFeatureAccess(['timer']);
  panelState.set(WIZARD_USER, { kind: 'owned', id: trial.id, step: 'await_add_reply' }); // simulate user still mid-wizard

  const replies2 = [];
  const ctx2 = {
    from: { id: WIZARD_USER },
    chat: { id: WIZARD_USER },
    callbackQuery: null,
    reply: async (text, extra) => { replies2.push(text); return { message_id: 2 }; },
    telegram: { sendMessage: async () => ({}) },
  };
  const handled2 = await panel.handleStepInput(ctx2, { step: 'await_add_reply' }, 'promo2|Balasan lain');
  assert.equal(handled2, true);
  assert.ok(replies2.some((t) => /Fitur Terkunci/i.test(t)), 'stale wizard step must be blocked after live revocation');
  assert.equal(panelState.get(WIZARD_USER).step, null, 'blocked step must be cleared, not left pending');
});

queueAsync('Entry point enforcement: requireFeature wrapper blocks a trial asset the same way as the wizard', async () => {
  const panel = S('handlers/panel.handler');
  const panelState = S('state/panelState');

  const ENTRY_USER = 603;
  db.prepare('INSERT OR IGNORE INTO users (telegram_id, username, first_name) VALUES (?,?,?)').run(ENTRY_USER, `u${ENTRY_USER}`, `U${ENTRY_USER}`);

  featureAccess.setTrialFeatureAccess(['timer']); // base_reply NOT granted
  const trial = userbotService.createTrialOwned({ userId: ENTRY_USER, durationHours: 24 });
  ownedRepo.activate(trial.id, { sessionString: 'sess', telegramUserbotId: 2, token: 'TOK-TEST-2', expiresAt: null });
  panelState.set(ENTRY_USER, { kind: 'owned', id: trial.id });

  const gated = panel.requireFeature('base_reply', async () => {
    throw new Error('handler body must NEVER run when the feature is not entitled');
  });

  const replies = [];
  const ctx = {
    from: { id: ENTRY_USER },
    chat: { id: ENTRY_USER },
    callbackQuery: null,
    reply: async (text) => { replies.push(text); return { message_id: 1 }; },
    telegram: { sendMessage: async () => ({}) },
  };
  await gated(ctx);
  assert.ok(replies.some((t) => /Fitur Terkunci/i.test(t)));

  // Now grant it and prove the SAME entry point opens live, no new trial needed.
  featureAccess.setTrialFeatureAccess(['timer', 'base_reply']);
  let bodyRan = false;
  const gatedOk = panel.requireFeature('base_reply', async () => { bodyRan = true; });
  await gatedOk(ctx);
  assert.equal(bodyRan, true);
});

(async () => {
  for (const [name, fn] of asyncTests) {
    // eslint-disable-next-line no-await-in-loop
    await testAsync(name, fn);
  }
  const passed = results.filter(Boolean).length;
  console.log(`\n${passed}/${results.length} passed`);
  if (passed !== results.length) process.exit(1);
})();
