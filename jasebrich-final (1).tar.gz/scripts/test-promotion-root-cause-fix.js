'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const panel = read('src/handlers/panel.handler.js');
const keyboard = read('src/keyboards/panelControl.keyboard.js');
const runtime = read('src/services/userbotRuntime.service.js');
const ownedConfig = read('src/services/panelConfig.service.js');
const poolConfig = read('src/services/poolPanelConfig.service.js');

// #1 The production ReferenceError must be impossible: panel.handler.js must
// import the same replyButton helper that it already uses in its keyboards.
assert.match(panel, /const \{ button, replyButton \} = require\('\.\.\/utils\/buttons'\);/);
assert.doesNotMatch(panel, /const \{ button \} = require\('\.\.\/utils\/buttons'\);/);

// #2 Status Promosi is always reachable from the canonical panel layout.
const mainKeyboard = keyboard.slice(keyboard.indexOf('function panelMainKeyboard'), keyboard.indexOf('\n}\n\nfunction baseReplyKeyboard'));
assert.doesNotMatch(mainKeyboard, /replyButton\.primary\(PANEL_FEATURE\.PROMOTION_STATUS\)/);
assert.match(mainKeyboard, /active \? replyButton\.danger\(PANEL_FEATURE\.STOP\) : replyButton\.success\(PANEL_FEATURE\.START\)/);
assert.match(panel, /const promotionStatusInlineKeyboard = \(kind, id, active = false\)/);
assert.match(panel, /Markup\.inlineKeyboard/);
assert.doesNotMatch(panel, /const promotionStatusKeyboard = \(active = false\)/);
assert.match(panel, /const active=userbotRuntime\.isAutoPromosiActive\(panelKind\(ctx\),s\.asset\.id\);/);

// #3 A permanently unusable target is removed from configuration, not merely
// hidden behind a health TTL. The helper is used both during pre-flight and
// after a permanent Telegram send error.
assert.match(runtime, /function removePromotionTarget\(kind, id, target, reason = null\)/);
assert.match(runtime, /removePromotionTarget\(record\.kind, record\.id, g\.target, 'pre-flight target unusable'\)/);
assert.match(runtime, /removePromotionTarget\(record\.kind, record\.id, g\.target, err\.message\)/);
assert.doesNotMatch(runtime, /HEALTH_TTL_MS = 10 \* 60 \* 1000/);

// #4 Permanent Telegram errors cover the concrete unsendable conditions seen
// in production, while generic/transient failures are not blanket-classified.
for (const token of [
  'USER_BANNED_IN_CHANNEL',
  'CHAT_RESTRICTED',
  'CHAT_WRITE_FORBIDDEN',
  'CHAT_SEND_MEDIA_FORBIDDEN',
  'CHAT_SEND_PLAIN_FORBIDDEN',
]) assert.match(runtime, new RegExp(token));
assert.match(runtime, /if \(seconds > 0 \|\| upper\.includes\('FLOOD_WAIT'\) \|\| upper\.includes\('RETRY_AFTER'\)\) return \{ type:'temporary'/);
assert.doesNotMatch(runtime, /USER_BANNED_IN_CHANNEL[^\n]*forbidden[^\n]*\/i/);

// #5 Permanent failures fast-skip the inter-group delay; valid/transient
// targets still use the configured delay path.
assert.match(runtime, /if \(permanentTargetFailure && i < groups\.length - 1 && record\.flags\.auto_promosi\)/);
assert.match(runtime, /sampleGroupDelay\(groupDelayRange\)/);
assert.match(runtime, /else if\(i<groups\.length-1 && record\.flags\.auto_promosi\)/);

// #6 Validation must perform the actual removal for permanent invalid targets.
const validation = runtime.slice(runtime.indexOf('async function validateGroupTargets'), runtime.indexOf('\n// Real GramJS check', runtime.indexOf('async function validateGroupTargets')));
assert.match(validation, /removePromotionTarget\(kind, id, row\.target/);
assert.match(validation, /if \(permanent\)/);
assert.match(validation, /uncertain\.push\(row\)/);

// #7 Re-adding a target clears its old health verdict; deleting a target clears
// its health row. This prevents a legitimate re-add from inheriting a stale
// permanent verdict.
assert.match(ownedConfig, /DELETE FROM userbot_promotion_target_health WHERE owner_kind=\? AND owner_id=\? AND target=\?/);
assert.match(poolConfig, /DELETE FROM userbot_promotion_target_health WHERE owner_kind=\? AND owner_id=\? AND target=\?/);

console.log('PROMOTION_ROOT_CAUSE_FIX_CONTRACT_OK');
