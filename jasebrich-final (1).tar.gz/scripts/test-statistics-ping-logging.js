'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const stats = read('src/services/statistics.service.js');
const statsHandler = read('src/handlers/admin/statistics.handler.js');
const adminKeyboard = read('src/keyboards/admin.keyboard.js');
const ping = read('src/handlers/ping.handler.js');
const index = read('src/index.js');
const logger = read('src/utils/logger.js');

for (const token of [
  'COUNT(*) AS total', 'active_30d', 'banned', 'COUNT(*) AS c',
  "FROM userbots", "FROM userbot_pool", "FROM orders", "FROM users",
  'getRuntimeStats', 'getSchedulerStatus', 'process.memoryUsage', 'os.totalmem', 'os.freemem', 'os.loadavg',
]) assert.ok(stats.includes(token), `statistics source missing real metric: ${token}`);
assert.match(stats, /function getSystemSnapshot\(\)/);
assert.match(stats, /function getDatabaseHealth\(db\)/);
assert.match(statsHandler, /statisticsService\.getStatisticsSnapshot\(\)/);
assert.match(statsHandler, /promotion_stopped/);
assert.match(stats, /promotionStopped/);
assert.match(statsHandler, /adminStatisticsKeyboard\(\)/);
assert.match(ping, /checkHealth\(\)/);
assert.match(ping, /statisticsService\.getSystemSnapshot\(\)/);
assert.match(ping, /ctx\.telegram\.editMessageText/);
assert.doesNotMatch(ping, /setInterval|setTimeout/);
assert.match(index, /bot\.command\('ping', pingHandler\)/);
assert.match(index, /bot\.start\(startHandler\)/);
assert.equal((index.match(/bot\.start\(startHandler\)/g) || []).length, 1);
assert.match(index, /bot\.use\(banGuardMiddleware\(\)\)[\s\S]*?bot\.command\('ping'/);
assert.match(index, /bot\.hears\(MENU\.ADMIN_STATISTICS, requireAdmin\(statisticsHandler\)\)/);

for (const token of ['LOG_LEVEL', 'debug', 'info', 'warn', 'error', 'REDACTED']) {
  assert.ok(logger.includes(token), `logger contract missing ${token}`);
}
assert.doesNotMatch(logger, /logger\.info/);

console.log('STATS_PING_LOGGING_STATIC_OK real_db=1 runtime=1 system=1 admin_guard=1 ping=1 single_start=1 log_levels=1 redaction=1');
