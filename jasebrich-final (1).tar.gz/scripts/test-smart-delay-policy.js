'use strict';
const assert = require('assert');
const sd = require('../src/services/smartDelay.policy');
const delayPolicy = require('../src/services/delayPolicy.service');

let passed = 0;
function t(name, fn) {
  try { fn(); passed += 1; console.log(`  ok - ${name}`); }
  catch (err) { console.error(`  FAIL - ${name}`); throw err; }
}
const range = (min, max) => ({ min, max });

t('OFF is exactly the manual sample for the same random source', () => {
  for (const r of [0.0, 0.25, 0.5, 0.99]) {
    const rnd = () => r;
    const manual = delayPolicy.sampleGroupDelay(range(5, 40), rnd);
    const off = sd.chooseGroupDelay({ enabled: false, state: { current: 999, streak: 3 }, range: range(5, 40), random: rnd });
    assert.strictEqual(off, manual);
  }
});
t('ON starts at the manual floor, never below it', () => {
  const s = sd.normalizeState(null, range(10, 60));
  assert.strictEqual(s.current, 10);
  const v = sd.chooseGroupDelay({ enabled: true, state: null, range: range(10, 60), random: () => 0 });
  assert.ok(v >= 10 && v <= 12);
});
t('FloodWait raises the delay and resets the clean streak', () => {
  const s = sd.onFlood({ current: 20, streak: 4 }, range(10, 60), 5);
  assert.strictEqual(s.current, 30); // max(20*1.5, 20+5)
  assert.strictEqual(s.streak, 0);
  const big = sd.onFlood({ current: 20, streak: 0 }, range(10, 60), 120);
  assert.strictEqual(big.current, 60); // 20+120 capped at manual max
});
t('ceiling is the manual maximum; growth never exceeds it', () => {
  let s = { current: 10, streak: 0 };
  for (let i = 0; i < 20; i++) s = sd.onFlood(s, range(10, 60), 30);
  assert.strictEqual(s.current, 60);
});
t('clean sends relax the delay only after the streak threshold', () => {
  let s = { current: 50, streak: 0 };
  for (let i = 0; i < sd.SUCCESS_STREAK_TO_DECAY - 1; i++) s = sd.onSuccess(s, range(10, 60));
  assert.strictEqual(s.current, 50);
  s = sd.onSuccess(s, range(10, 60));
  assert.strictEqual(s.current, 45); // floor(50*0.9)
  assert.strictEqual(s.streak, 0);
});
t('decay never drops below the manual floor', () => {
  let s = { current: 10, streak: 0 };
  for (let i = 0; i < 200; i++) s = sd.onSuccess(s, range(10, 60));
  assert.strictEqual(s.current, 10);
});
t('manual range change clamps the learned value on the next read', () => {
  const s = sd.normalizeState({ current: 80, streak: 2 }, range(5, 30));
  assert.strictEqual(s.current, 30);
  const low = sd.normalizeState({ current: 1, streak: 0 }, range(5, 30));
  assert.strictEqual(low.current, 5);
});
t('fixed value gets headroom: ceiling = max(3x, 60s)', () => {
  assert.deepStrictEqual(sd.bounds(range(10, 10)), { floor: 10, ceiling: 60 });
  assert.deepStrictEqual(sd.bounds(range(30, 30)), { floor: 30, ceiling: 90 });
  assert.deepStrictEqual(sd.bounds(range(0, 0)), { floor: 0, ceiling: 60 });
});
t('ON sampling stays inside [current, min(ceiling, current*1.2)]', () => {
  for (let i = 0; i < 200; i++) {
    const r = i / 200;
    const v = sd.chooseGroupDelay({ enabled: true, state: { current: 50, streak: 0 }, range: range(10, 60), random: () => r });
    assert.ok(v >= 50 && v <= 60, `got ${v}`);
  }
});
t('describe reports OFF with the manual range, ON with current and bounds', () => {
  assert.ok(sd.describe({ enabled: false, state: null, range: range(1, 20) }).includes('1-20 detik'));
  const on = sd.describe({ enabled: true, state: { current: 12, streak: 0 }, range: range(5, 40) });
  assert.ok(on.includes('saat ini 12 dtk') && on.includes('5-40'));
});
t('invalid random source is rejected rather than silently sampled', () => {
  assert.throws(() => sd.chooseGroupDelay({ enabled: true, state: { current: 10, streak: 0 }, range: range(10, 60), random: () => 1 }));
});

console.log(`test-smart-delay-policy: ${passed} passed`);
