'use strict';
const assert = require('node:assert/strict');
const path = require('path');

const trialConfigPath = require.resolve('../src/services/trialConfig.service');
require.cache[trialConfigPath] = {
  id: trialConfigPath,
  filename: trialConfigPath,
  loaded: true,
  exports: { getTrialDurationHours: () => 24 },
};

const { applyPlaceholders, extractPlaceholders } = require('../src/utils/placeholders');

const ctx = {
  from: { id: 123, first_name: 'Benny', last_name: 'Boss', username: 'boss' },
  chat: { id: 123 },
  message: { date: Math.floor(Date.now() / 1000) },
};

{
  const text = '🎉 Halo {nama_lengkap}!';
  const start = text.indexOf('{nama_lengkap}');
  const out = applyPlaceholders(text, [{ type: 'bold', offset: start, length: '{nama_lengkap}'.length }], ctx);
  assert.equal(out.text, '🎉 Halo Benny Boss!');
  assert.deepEqual(out.entities, [{ type: 'bold', offset: 8, length: 10 }]);
}

{
  const text = 'A {response} B';
  const out = applyPlaceholders(text, [], ctx, {
    placeholderValues: {
      response: {
        text: '🥳 Reply',
        entities: [{ type: 'custom_emoji', offset: 0, length: 2, custom_emoji_id: '5432101234567890' }],
      },
    },
  });
  assert.equal(out.text, 'A 🥳 Reply B');
  assert.equal(out.entities.length, 1);
  assert.equal(out.entities[0].type, 'custom_emoji');
  assert.equal(out.entities[0].offset, 2);
  assert.equal(out.entities[0].length, 2);
}

{
  const out = applyPlaceholders('X {does_not_exist} Y', [], ctx);
  assert.equal(out.text, 'X {does_not_exist} Y');
  assert.deepEqual(extractPlaceholders('{nama} {nama_lengkap} {nama}'), ['nama', 'nama_lengkap']);
}

{
  const text = 'Hello {nama}';
  const entity = [{ type: 'spoiler', offset: 6, length: '{nama}'.length }];
  const out = applyPlaceholders(text, entity, ctx);
  assert.equal(out.text, 'Hello Benny');
  assert.equal(out.entities[0].type, 'spoiler');
  assert.equal(out.entities[0].offset, 6);
  assert.equal(out.entities[0].length, 5);
}

console.log('CUSTOMIZATION_UNIT_OK placeholder_entity_offsets=1 nested_entities=1 fallback=1');
