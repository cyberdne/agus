'use strict';

const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const store = read('src/handlers/store.handler.js');
const slash = '\\';
assert.ok(store.includes('bulan ' + slash + slash + '('), 'store order-summary opening parenthesis is not escaped in source');
assert.ok(store.includes('hari' + slash + slash + ')'), 'store order-summary closing parenthesis is not escaped in source');
assert.ok(store.includes("boldMdV2('Lanjut Bayar')}" + slash + slash + '.'), 'store payment sentence period is not escaped in source');
assert.ok(store.includes('Spesial Non' + slash + slash + '-Garansi'), 'store non-garansi hyphen is not escaped in source');

const render = read('src/utils/render.js');
assert.match(render, /EDIT_FALLBACK_RE/);
assert.match(render, /EDIT_FALLBACK_RE\.test\(String\(desc\)\)/);
assert.match(render, /throw err;/);

const approval = read('src/handlers/admin/orderConfirm.handler.js');
assert.match(approval, /resumePendingUserbotActivation/);
assert.match(approval, /order\.status === 'fulfilled' && order\.category === 'userbot'/);
assert.ok(approval.includes("resumePendingUserbotActivation(telegram, { ...fresh, category: 'userbot', fulfillment_ref: result.pendingOwnedId })"));

const schema = read('src/database/schema.js');
const migration = read('src/database/index.js');
const poolRepo = read('src/database/repositories/userbotPool.repository.js');
const poolHandler = read('src/handlers/admin/poolManagement.handler.js');
const order = read('src/services/order.service.js');
const userbot = read('src/services/userbot.service.js');
const scheduler = read('src/scheduler.js');

assert.match(schema, /telegram_userbot_id INTEGER/);
assert.match(migration, /ALTER TABLE userbot_pool ADD COLUMN telegram_userbot_id INTEGER/);
assert.match(poolRepo, /telegramUserbotId/);
assert.match(poolRepo, /returnExpiredToPool/);
assert.match(poolHandler, /telegramUserbotId/);
assert.match(order, /telegram_userbot_id/);
assert.match(userbot, /await userbotRuntime\.teardownAsset\('pool', row\.id\)/);
assert.match(userbot, /returnExpiredToPool\(row\.id, fresh\.expires_at/);
assert.match(scheduler, /await userbotService\.sweepExpiredPool\(\)/);

const ensureUser = read('src/middlewares/ensureUser.middleware.js');
assert.match(ensureUser, /ensureUserMiddleware failed/);
assert.match(ensureUser, /throw err/);

const index = read('src/index.js');
assert.doesNotMatch(index, /ctx\.reply\(`❌ \$\{e\.message\}`/);

console.log('PRODUCTION_AUDIT_FIXES_OK screenshot_markdown=1 render_fallback=1 activation_resume=1 pool_teardown_order=1 pool_identity=1 ensure_user_fail_closed=1 public_error_safety=1');
