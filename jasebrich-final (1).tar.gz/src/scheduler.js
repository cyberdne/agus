const logger = require('./utils/logger');
const userbotService = require('./services/userbot.service');
const lifecycle = require('./services/userbotLifecycle.service');
const orderService = require('./services/order.service');
const notificationService = require('./services/notification.service');
const broadcastService = require('./services/broadcast.service');
const reminderService = require('./services/subscriptionReminder.service');
const autoBackup = require('./services/autoBackup.service');
const systemHealth = require('./services/systemHealth.service');
const ubotNotify = require('./services/ubotNotify.service');

const SWEEP_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

let schedulerInterval = null;
const schedulerState = {
  running: false,
  tickRunning: false,
  lastTickStartedAt: null,
  lastTickCompletedAt: null,
  lastTickError: null,
};

/**
 * Periodically returns expired "Beli Jaseb" pool leases back to
 * stock and notifies the buyer whose access just ended.
 */
function startScheduler(telegram) {
  lifecycle.setTelegram(telegram);
  ubotNotify.setTelegram(telegram);
  ubotNotify.start();
  systemHealth.setTelegram(telegram);
  // Restart recovery for persisted background broadcast jobs. The service
  // serializes workers and uses delivery claims so a queued/running job can
  // resume without creating a second worker.
  broadcastService.resumeJobs(telegram).catch((err) => logger.error('Broadcast resume failed:', err));
  // Prevent an accidental second registration from creating overlapping
  // timers. Existing callers still receive a cleanup function.
  if (schedulerInterval) return stopScheduler;

  schedulerState.running = true;
  schedulerState.lastTickError = null;

  const tick = async () => {
    if (schedulerState.tickRunning) {
      logger.debug('Scheduler tick masih berjalan, tick berikutnya dilewati.');
      return;
    }
    schedulerState.tickRunning = true;
    schedulerState.lastTickStartedAt = new Date().toISOString();
    schedulerState.lastTickError = null;
    try {
      const expiredOrders = orderService.expireStaleOrders();
      if (expiredOrders > 0) logger.info(`Scheduler: ${expiredOrders} order open/paid expired dan diterminalkan.`);
      orderService.reclaimStaleProcessingOrders();
      await notificationService.sweepTransactionNotifications(telegram);
      // Testimoni retries are isolated: a failure here must not block expiry or the other sweeps.
      try { await require('./services/testimonial.service').sweepRetryable(telegram); } catch (err) { logger.error('Scheduler testimonial sweep failed:', err); }
      await lifecycle.sweepExpiredOwned();
      try {
        // One isolated cycle; its outcome is persisted for the admin panel.
        await reminderService.runSweep(telegram);
      } catch (err) {
        // Reminder failure must not prevent the scheduler from expiring pool
        // leases/trials/orders on the same tick. The next tick retries.
        logger.error('Scheduler reminder sweep failed:', err);
      }
      try {
        const backup = await autoBackup.runIfDue({ telegram });
        if (backup.error) logger.warn(`Auto backup dilewati: ${backup.error}`);
      } catch (err) {
        logger.error('Scheduler auto backup failed:', err);
      }
      try {
        await systemHealth.runCheck({ telegram, schedulerStatus: getStatus() });
      } catch (err) {
        logger.error('Scheduler health check failed:', err);
      }

      const returned = await userbotService.sweepExpiredPool();
      const expiredTrials = await userbotService.sweepExpiredTrials();

      for (const trial of expiredTrials) {
        try {
          await telegram.sendMessage(
            trial.userId,
            `⏰ *Trial Berakhir*\n\nMasa trial gratis kamu telah berakhir. Terima kasih sudah mencoba layanan kami.\n\nUntuk melanjutkan menggunakan userbot, silakan cek 🛒 Toko.`,
            { parse_mode: 'Markdown' }
          );
        } catch (err) {
          logger.warn(`Failed to notify user ${trial.userId} of trial expiry: ${(err && err.message) || err}`);
        }
      }

      for (const { label, notifyUserId } of returned) {
        if (!notifyUserId) continue;
        try {
          await telegram.sendMessage(
            notifyUserId,
            `⌛ Masa aktif userbot Jaseb "${label}" telah berakhir dan dikembalikan ke stok.\n\nBeli lagi lewat 🛒 Toko untuk memperpanjang.`
          );
        } catch (err) {
          logger.warn(`Failed to notify user ${notifyUserId} of expiry: ${(err && err.message) || err}`);
        }
      }
    } catch (err) {
      schedulerState.lastTickError = err && err.message ? err.message : String(err);
      logger.error('Scheduler sweep failed:', err);
    } finally {
      schedulerState.lastTickCompletedAt = new Date().toISOString();
      schedulerState.tickRunning = false;
    }
  };

  schedulerInterval = setInterval(tick, SWEEP_INTERVAL_MS);
  schedulerInterval.unref?.();
  tick(); // run once immediately at boot
  return stopScheduler;
}

function stopScheduler() {
  if (schedulerInterval) clearInterval(schedulerInterval);
  schedulerInterval = null;
  schedulerState.running = false;
  schedulerState.tickRunning = false;
}

function getStatus() {
  return {
    running: schedulerState.running,
    tickRunning: schedulerState.tickRunning,
    lastTickStartedAt: schedulerState.lastTickStartedAt,
    lastTickCompletedAt: schedulerState.lastTickCompletedAt,
    lastTickError: schedulerState.lastTickError,
    intervalSeconds: SWEEP_INTERVAL_MS / 1000,
  };
}

module.exports = { startScheduler, stopScheduler, getStatus };
