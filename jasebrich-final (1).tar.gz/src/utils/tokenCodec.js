'use strict';
/**
 * Backup Token codec: generation, input normalization and hashing.
 *
 * Deliberately has NO database/service dependency so both the DB bootstrap
 * (legacy backfill) and services/backupToken.service.js can use the exact
 * same functions — one definition of "what a token is and how it is hashed".
 *
 * Tokens are high-entropy random secrets (>= 192 bits, crypto.randomBytes).
 * Only the SHA-256 of the normalized token is ever persisted, so a database
 * read (backup, leak, admin with sqlite access) does not yield a usable
 * credential. A fast hash is appropriate here precisely because the input
 * is a long random secret, not a human-chosen password.
 */
const crypto = require('crypto');

const MIN_TOKEN_LENGTH = 16;
const MAX_TOKEN_LENGTH = 256;
const MAX_RAW_INPUT_LENGTH = 1024;

const PREFIX = Object.freeze({
  PURCHASE: 'JASEB',
  TRIAL: 'LIFE-UBOT',
});

/**
 * Formats are unchanged from the previous "Token Garansi" so what buyers
 * already see stays familiar:
 *   trial    -> "LIFE-UBOT : <48 hex chars>"   (192 bits)
 *   purchase -> "JASEB-<~60 base62 chars>"     (~360 bits)
 */
function generate(prefix = PREFIX.PURCHASE) {
  if (prefix === PREFIX.TRIAL) {
    return `${PREFIX.TRIAL} : ${crypto.randomBytes(24).toString('hex').toUpperCase()}`;
  }
  const random = crypto.randomBytes(48).toString('base64').replace(/[^a-zA-Z0-9]/g, '');
  return `${prefix}-${random.slice(0, 90)}`;
}

/**
 * Canonical form of user-typed/pasted input, or null when it cannot possibly
 * be a token (wrong type, too short/long, non-printable characters).
 * Whitespace and quote/backtick characters are dropped so a token copied out
 * of a Telegram code span, with or without the spaces around ":", resolves
 * to the same value that was hashed at generation time.
 */
function normalize(raw) {
  if (typeof raw !== 'string' || raw.length > MAX_RAW_INPUT_LENGTH) return null;
  const stripped = raw.replace(/[`'"\s]/g, '');
  if (stripped.length < MIN_TOKEN_LENGTH || stripped.length > MAX_TOKEN_LENGTH) return null;
  if (!/^[\x21-\x7E]+$/.test(stripped)) return null;
  return stripped;
}

function sha256Hex(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/** Hash of a token as a user would present it; null when malformed. */
function hashInput(raw) {
  const normalized = normalize(raw);
  return normalized ? sha256Hex(normalized) : null;
}

/**
 * Hash of a plaintext token that was ALREADY stored by an older version.
 * Never rejects on shape (a legacy value must stay reachable) — it applies
 * the same whitespace/quote stripping as normalize() and hashes the result.
 */
function hashStored(raw) {
  if (typeof raw !== 'string') return null;
  const stripped = raw.replace(/[`'"\s]/g, '');
  return stripped ? sha256Hex(stripped) : null;
}

module.exports = { PREFIX, generate, normalize, hashInput, hashStored, MIN_TOKEN_LENGTH, MAX_TOKEN_LENGTH };
