'use strict';

/**
 * Canonical userbot session storage.
 *
 * Current source of truth:
 *   data/userbot_sessions/{userbot_<id>|pool_<id>}.txt
 *
 * The SQLite `session_string` columns are legacy compatibility fields only.
 * They are never written by the current application. Existing plaintext
 * values are migrated non-destructively after the corresponding .txt file has
 * been written and verified. Legacy encrypted values are intentionally left
 * untouched because this version has no encryption key and must never guess or
 * manufacture one.
 */
const fs = require('node:fs');
const path = require('node:path');
const logger = require('./logger');

const SESSION_DIR_NAME = 'userbot_sessions';
const LEGACY_ENCRYPTED_PREFIX = 'enc:v1:';

function sessionDirectory() {
  return path.resolve(process.cwd(), 'data', SESSION_DIR_NAME);
}

function normalizeKind(kind) {
  if (kind === 'owned' || kind === 'userbot' || kind === 'userbots') return 'userbot';
  if (kind === 'pool' || kind === 'userbot_pool') return 'pool';
  throw new TypeError(`Unsupported userbot session kind: ${kind}`);
}

function validateId(id) {
  const n = Number(id);
  if (!Number.isSafeInteger(n) || n <= 0) throw new TypeError(`Invalid userbot session id: ${id}`);
  return n;
}

function sessionFilePath(kind, id) {
  const normalizedKind = normalizeKind(kind);
  const normalizedId = validateId(id);
  return path.join(sessionDirectory(), `${normalizedKind}_${normalizedId}.txt`);
}

function isLegacyEncrypted(value) {
  return typeof value === 'string' && value.startsWith(LEGACY_ENCRYPTED_PREFIX);
}

function ensureDirectory() {
  fs.mkdirSync(sessionDirectory(), { recursive: true, mode: 0o700 });
  try { fs.chmodSync(sessionDirectory(), 0o700); } catch (_) {}
}

function writeSession(kind, id, sessionString) {
  if (sessionString == null || String(sessionString) === '') {
    throw new TypeError('sessionString must be a non-empty StringSession value');
  }
  const value = String(sessionString);
  ensureDirectory();
  const target = sessionFilePath(kind, id);
  const temp = `${target}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(temp, value, { encoding: 'utf8', mode: 0o600, flag: 'w' });
    try { fs.chmodSync(temp, 0o600); } catch (_) {}
    const verify = fs.readFileSync(temp, 'utf8');
    if (verify !== value) throw new Error('session file verification failed');
    fs.renameSync(temp, target);
    try { fs.chmodSync(target, 0o600); } catch (_) {}
    return target;
  } catch (err) {
    try { fs.unlinkSync(temp); } catch (_) {}
    throw err;
  }
}

function readSession(kind, id) {
  const file = sessionFilePath(kind, id);
  try {
    const value = fs.readFileSync(file, 'utf8').trim();
    return value || null;
  } catch (err) {
    if (err && err.code === 'ENOENT') return null;
    logger.warn(`Gagal membaca session file ${file}: ${err.message}`);
    return null;
  }
}

function deleteSession(kind, id) {
  const file = sessionFilePath(kind, id);
  try {
    fs.unlinkSync(file);
    return true;
  } catch (err) {
    if (err && err.code === 'ENOENT') return false;
    throw err;
  }
}

function clearLegacyDbSession(database, table, id) {
  const allowed = new Set(['userbots', 'userbot_pool']);
  if (!allowed.has(table)) throw new TypeError(`Unsupported legacy session table: ${table}`);
  database.prepare(`UPDATE ${table} SET session_string = NULL WHERE id = ?`).run(id);
}

/**
 * Hydrates a repository row from the canonical .txt file. If an older DB row
 * still contains plaintext, move it into the file first. Encrypted legacy
 * values are not readable without their missing key and therefore become null
 * in the runtime projection while remaining untouched in the DB.
 */
function hydrateRow(row, kind, database) {
  if (!row || row.id == null) return row;
  let value = readSession(kind, row.id);
  if (!value && row.session_string) {
    if (isLegacyEncrypted(row.session_string)) {
      logger.warn(`BLOCKED: legacy encrypted session_string ditemukan pada ${normalizeKind(kind)} #${row.id}; session dibiarkan utuh di database karena key tidak tersedia.`);
      value = null;
    } else {
      try {
        writeSession(kind, row.id, row.session_string);
        value = readSession(kind, row.id);
        if (value && database) clearLegacyDbSession(database, normalizeKind(kind) === 'userbot' ? 'userbots' : 'userbot_pool', row.id);
      } catch (err) {
        logger.error(`Gagal memigrasikan session legacy ${normalizeKind(kind)} #${row.id}: ${err.message}`);
        value = row.session_string;
      }
    }
  }
  row.session_string = value;
  return row;
}

function hydrateRows(rows, kind, database) {
  if (Array.isArray(rows)) rows.forEach((row) => hydrateRow(row, kind, database));
  return rows;
}

/**
 * Startup migration. Only legacy plaintext rows are migrated. Encrypted rows
 * are counted as BLOCKED and retained exactly as-is.
 */
function migrateLegacyRows(database, table, kind) {
  const rows = database.prepare(`SELECT id, session_string FROM ${table} WHERE session_string IS NOT NULL AND trim(session_string) <> ''`).all();
  let migrated = 0;
  let blocked = 0;
  for (const row of rows) {
    if (isLegacyEncrypted(row.session_string)) {
      blocked += 1;
      logger.warn(`BLOCKED: legacy encrypted session ${table}#${row.id} tidak dapat direcover tanpa key; database tidak diubah.`);
      continue;
    }
    try {
      writeSession(kind, row.id, row.session_string);
      const verified = readSession(kind, row.id);
      if (!verified) throw new Error('session file verification failed');
      clearLegacyDbSession(database, table, row.id);
      migrated += 1;
    } catch (err) {
      logger.error(`Gagal migrasi session plaintext ${table}#${row.id}: ${err.message}`);
    }
  }
  return { migrated, blocked };
}

function migrateLegacySessions(database) {
  return {
    userbots: migrateLegacyRows(database, 'userbots', 'userbot'),
    userbotPool: migrateLegacyRows(database, 'userbot_pool', 'pool'),
  };
}

/**
 * Remove only session files whose corresponding DB record no longer exists.
 * This is a safety net for a crash after DB deletion but before filesystem
 * cleanup. Existing DB rows are never touched.
 */
function cleanupOrphanSessionFiles(database) {
  ensureDirectory();
  const entries = fs.readdirSync(sessionDirectory(), { withFileTypes: true });
  const checks = {
    userbot: database.prepare('SELECT 1 FROM userbots WHERE id = ? LIMIT 1'),
    pool: database.prepare('SELECT 1 FROM userbot_pool WHERE id = ? LIMIT 1'),
  };
  let removed = 0;
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    const match = /^(userbot|pool)_(\d+)\.txt$/u.exec(entry.name);
    if (!match) continue;
    const kind = match[1];
    const id = Number(match[2]);
    if (!checks[kind].get(id)) {
      try {
        fs.unlinkSync(path.join(sessionDirectory(), entry.name));
        removed += 1;
      } catch (err) {
        logger.warn(`Gagal menghapus orphan session file ${entry.name}: ${err.message}`);
      }
    }
  }
  return removed;
}

module.exports = {
  SESSION_DIR_NAME,
  LEGACY_ENCRYPTED_PREFIX,
  sessionDirectory,
  sessionFilePath,
  isLegacyEncrypted,
  writeSession,
  readSession,
  deleteSession,
  hydrateRow,
  hydrateRows,
  migrateLegacyRows,
  migrateLegacySessions,
  cleanupOrphanSessionFiles,
};
