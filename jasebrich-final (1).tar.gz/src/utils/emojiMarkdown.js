/**
 * Helpers for embedding a Premium/custom emoji inside plain message TEXT
 * (as opposed to a button — see src/utils/buttons.js for the button-icon
 * path, which already worked via `icon_custom_emoji_id`).
 *
 * ROOT CAUSE this fixes: every screen that prints a saved emoji as part
 * of a sentence (Store product list, order confirmation, admin product
 * view, the Emoji Premium settings screen itself, ...) built its text
 * with legacy `parse_mode: 'Markdown'` and interpolated only the plain
 * fallback character (`premiumEmojiConfig.forGaransi()` /
 * `buttonIconConfig.getIcon()`). Legacy Markdown has no way to attach a
 * `custom_emoji` entity to arbitrary text, so a saved custom/Premium
 * emoji was silently downgraded to its generic fallback glyph on every
 * one of those screens — which is most of the bot. Only the handful of
 * places that build an inline KEYBOARD BUTTON (src/keyboards/inline.
 * keyboard.js) could actually show the real emoji, via the native
 * `icon_custom_emoji_id` button field. That's why "almost all" custom
 * emoji appeared not to apply even though they were saved correctly.
 *
 * Fix: Telegram's MarkdownV2 format has a dedicated syntax for this —
 * `![<fallback>](tg://emoji?id=<custom_emoji_id>)` — which renders the
 * real custom emoji wherever the bot is allowed to show custom emoji
 * icons (same conditions as icon_custom_emoji_id on buttons: Fragment
 * usernames, or the bot owner has Telegram Premium). Screens that print
 * a possibly-custom emoji now build MarkdownV2 text via these helpers
 * instead of legacy Markdown.
 */

// Every character MarkdownV2 requires to be escaped outside of an
// entity, per https://core.telegram.org/bots/api#markdownv2-style
const ESCAPE_RE = /[_*[\]()~`>#+\-=|{}.!\\]/g;

function escapeMdV2(text) {
  return String(text == null ? '' : text).replace(ESCAPE_RE, '\\$&');
}

// Bold helper that escapes its own content, so callers never have to
// hand-escape dynamic values mixed into bold text.
function boldMdV2(text) {
  return `*${escapeMdV2(text)}*`;
}

/**
 * `config` is a { icon, customEmojiId } pair, e.g. from
 * premiumEmojiConfig.configForGaransi() or buttonIconConfig.getIcon().
 * Returns a MarkdownV2-safe fragment: the real custom/Premium emoji
 * link when a customEmojiId is set, otherwise just the escaped plain
 * icon character (identical visual result to before on non-Premium
 * emoji, since those have nothing to escape).
 */
function emojiMdV2(config) {
  if (!config) return '';
  if (config.customEmojiId) {
    // The fallback glyph inside [] is required by Telegram (must be a
    // real emoji) but is NOT escaped — this whole token is a single
    // MarkdownV2 entity, not literal text.
    return `![${config.icon}](tg://emoji?id=${config.customEmojiId})`;
  }
  return escapeMdV2(config.icon);
}

module.exports = { escapeMdV2, boldMdV2, emojiMdV2 };
