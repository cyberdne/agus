/**
 * Production placeholder renderer used by Custom Submenu and configurable
 * activation/panel messages. Raw custom text/entities stay untouched in DB;
 * substitution happens only at render time and entity offsets are adjusted
 * for each replacement.
 */

const BASE_PLACEHOLDERS = new Set(['nama','nama_lengkap','first_name','last_name','username','mention','id','chat_id','tanggal','waktu','hari','kecepatan_respon','durasi_trial','akun','nama_akun','userbot_id','telegram_userbot_id','userbot_nomor','userbot_username','userbot_produk','userbot_order','userbot_status','expired','expired_at','sisa','sisa_waktu','sisa_detik','durasi_userbot','aktivasi_at','token_garansi','grup','jumlah_grup','reply','jumlah_reply','jenis_pesan','jeda_grup','jeda_putaran','channel','auto_promosi','wtb_reply','pm_permit','kategori','produk','harga','jumlah','total','durasi_hari','order_id','status','jenis','status_info','status_token','metode_pembayaran','masa_berlaku','qris_note','bank_info','userbot_list','product_list','reply_list','group_list','hasil','pesan','reason','keyword','response','sisa_info','rotasi_info','asal','message_id','media','timer','auto_reset','reaction','teks','jam','message_type','target_channel','banned_words','max_chars','filter_link','filter_username','halaman','status','total_groups','processed_groups','successful_groups','failed_groups','blocked_groups','removed_groups','sent_count','failed_count','current_round','progress','remaining_groups','round_pause_remaining','phase','current_target','wait_reason','wait_remaining','started_at','last_activity','estimated_completion','remaining_time','interval','runtime_status','package_name']);

function extractPlaceholders(text) {
  const found = new Set();
  const re = /\{([A-Za-z0-9_]+)\}/g;
  let m;
  while ((m = re.exec(String(text || ''))) !== null) found.add(m[1]);
  return Array.from(found);
}

const { normalizeTelegramEntities } = require('./telegramFormatting');

const PLACEHOLDER_DOCS = [
  { token: '{nama}', desc: 'Nama depan pengguna' },
  { token: '{nama_lengkap}', desc: 'Nama depan + nama belakang pengguna' },
  { token: '{first_name}', desc: 'Nama depan pengguna (sama seperti {nama})' },
  { token: '{last_name}', desc: 'Nama belakang pengguna ("-" jika tidak ada)' },
  { token: '{username}', desc: 'Username pengguna, format @username ("-" jika tidak punya)' },
  { token: '{mention}', desc: 'Mention otomatis pengguna' },
  { token: '{id}', desc: 'Telegram user ID pengguna' },
  { token: '{chat_id}', desc: 'ID chat tempat pesan ditampilkan' },
  { token: '{tanggal}', desc: 'Tanggal saat pesan ditampilkan (WIB)' },
  { token: '{waktu}', desc: 'Jam saat pesan ditampilkan (WIB)' },
  { token: '{hari}', desc: 'Hari saat pesan ditampilkan (mis. Senin)' },
  { token: '{kecepatan_respon}', desc: 'Perkiraan waktu proses pesan masuk sampai dirender' },
  { token: '{durasi_trial}', desc: 'Durasi trial yang sedang dikonfigurasi' },
  { token: '{akun}', desc: 'Nama akun Telegram userbot yang sedang diakses' },
  { token: '{nama_akun}', desc: 'Alias nama akun userbot yang sedang diakses' },
  { token: '{userbot_id}', desc: 'ID internal userbot milik pengguna (nomor #panel)' },
  { token: '{telegram_userbot_id}', desc: 'Telegram ID akun userbot yang login' },
  { token: '{userbot_nomor}', desc: 'Nomor Telegram userbot' },
  { token: '{userbot_username}', desc: 'Username akun Telegram userbot' },
  { token: '{userbot_produk}', desc: 'Nama produk userbot' },
  { token: '{userbot_order}', desc: 'Nomor order userbot' },
  { token: '{userbot_status}', desc: 'Status userbot (AKTIF/KADALUARSA/dll.)' },
  { token: '{expired}', desc: 'Sisa masa aktif userbot, contoh: 6 hari 3 jam 12 menit' },
  { token: '{expired_at}', desc: 'Tanggal/jam userbot kedaluwarsa (WIB)' },
  { token: '{sisa}', desc: 'Alias {expired}, berupa sisa masa aktif userbot' },
  { token: '{sisa_waktu}', desc: 'Alias {expired}, berupa sisa masa aktif userbot' },
  { token: '{sisa_detik}', desc: 'Sisa masa aktif userbot dalam detik' },
  { token: '{durasi_userbot}', desc: 'Durasi masa aktif userbot dari data expiry yang tersedia' },
  { token: '{aktivasi_at}', desc: 'Waktu aktivasi userbot (WIB)' },
  { token: '{token_garansi}', desc: 'Token garansi userbot' },
  { token: '{grup}', desc: 'Jumlah grup target pada panel userbot' },
  { token: '{jumlah_grup}', desc: 'Alias {grup}' },
  { token: '{reply}', desc: 'Jumlah WTB reply pada panel userbot' },
  { token: '{jumlah_reply}', desc: 'Alias {reply}' },
  { token: '{jenis_pesan}', desc: 'Jenis pesan promosi: Teks/Media/Forward/Belum diatur' },
  { token: '{jeda_grup}', desc: 'Range jeda antar grup dalam detik (dipilih acak setiap perpindahan grup)' },
  { token: '{jeda_putaran}', desc: 'Jeda antar putaran dalam detik' },
  { token: '{channel}', desc: 'Status pemrosesan channel pada panel' },
  { token: '{auto_promosi}', desc: 'Status Auto Promosi' },
  { token: '{wtb_reply}', desc: 'Status WTB Reply' },
  { token: '{pm_permit}', desc: 'Status PM Permit' },
  { token: '{kategori}', desc: 'Kategori layanan pada Store' },
  { token: '{produk}', desc: 'Nama produk yang sedang ditampilkan/dibeli' },
  { token: '{harga}', desc: 'Harga produk / unit' },
  { token: '{jumlah}', desc: 'Jumlah unit/bulan pada order' },
  { token: '{total}', desc: 'Total harga order' },
  { token: '{durasi_hari}', desc: 'Total durasi order dalam hari' },
  { token: '{order_id}', desc: 'ID order tanpa format tambahan' },
  { token: '{status}', desc: 'Status transaksi/order yang tersedia pada context' },
  { token: '{jenis}', desc: 'Jenis layanan/status akses yang memang tersedia pada context, mis. Trial atau Berlangganan' },
  { token: '{status_info}', desc: 'Keterangan status runtime yang aman ditampilkan pada context Backup Token' },
  { token: '{status_token}', desc: 'Status token backup yang dihitung oleh runtime' },
  { token: '{metode_pembayaran}', desc: 'Metode/instruksi pembayaran yang tersedia' },
  { token: '{masa_berlaku}', desc: 'Batas waktu pembayaran yang tersedia pada context' },
  { token: '{qris_note}', desc: 'Catatan QRIS yang dikonfigurasi admin' },
  { token: '{bank_info}', desc: 'Informasi bank/e-wallet pembayaran yang dikonfigurasi admin' },
  { token: '{userbot_list}', desc: 'Daftar userbot yang tersedia pada layar pilihan' },
  { token: '{product_list}', desc: 'Daftar produk yang tersedia pada kategori' },
  { token: '{reply_list}', desc: 'Daftar Base Reply pada userbot yang sedang dipilih' },
  { token: '{group_list}', desc: 'Daftar target grup pada userbot yang sedang dipilih' },
  { token: '{hasil}', desc: 'Hasil operasi yang sudah dihitung oleh runtime/service' },
  { token: '{pesan}', desc: 'Isi pesan/response yang memang tersedia pada context' },
  { token: '{reason}', desc: 'Alasan bisnis non-rahasia yang aman ditampilkan ke user' },
  { token: '{keyword}', desc: 'Kata kunci yang baru saja diproses pada flow Base Reply' },
  { token: '{response}', desc: 'Isi response yang baru saja disimpan pada flow Base Reply' },
  { token: '{sisa_info}', desc: 'Keterangan sisa masa aktif yang dihitung oleh runtime token recovery' },
  { token: '{rotasi_info}', desc: 'Keterangan waktu rotasi token backup yang tersedia pada context' },
  { token: '{asal}', desc: 'Sumber pesan forward yang sedang dipreview' },
  { token: '{message_id}', desc: 'Message ID sumber forward yang sedang dipreview' },
  { token: '{media}', desc: 'Keterangan media yang tersedia pada preview forward' },
  { token: '{app_version}', desc: 'Versi aplikasi yang berjalan' },
  { token: '{server_time}', desc: 'Waktu server saat statistik dirender' },
  { token: '{pid}', desc: 'Process ID Node.js yang sedang berjalan' },
  { token: '{external_memory}', desc: 'Penggunaan external memory process' },
  { token: '{system_free_memory}', desc: 'RAM sistem yang masih bebas' },
  { token: '{cpu_load_1m}', desc: 'Load average CPU 1 menit' },
  { token: '{cpu_cores}', desc: 'Jumlah logical CPU core yang terdeteksi' },
  { token: '{db_integrity}', desc: 'Hasil SQLite quick_check' },
  { token: '{timer}', desc: 'Status timer WTB pada userbot' },
  { token: '{auto_reset}', desc: 'Durasi auto reset cooldown dalam menit' },
  { token: '{reaction}', desc: 'Emoji reaksi Auto React yang sedang dikonfigurasi' },
  { token: '{message_type}', desc: 'Jenis pesan yang sedang dikonfigurasi pada Base Reply' },
  { token: '{target_channel}', desc: 'Target channel Base Reply yang sedang dikonfigurasi' },
  { token: '{banned_words}', desc: 'Daftar banned words Base Reply yang sedang dikonfigurasi' },
  { token: '{max_chars}', desc: 'Batas karakter Base Reply yang sedang dikonfigurasi' },
  { token: '{filter_link}', desc: 'Status filter link Base Reply' },
  { token: '{filter_username}', desc: 'Status filter username Base Reply' },
  { token: '{halaman}', desc: 'Nomor halaman pada daftar yang sedang ditampilkan' },
  { token: '{total_groups}', desc: 'Total target grup pada siklus promosi aktif' },
  { token: '{processed_groups}', desc: 'Target yang sudah diproses pada siklus aktif' },
  { token: '{successful_groups}', desc: 'Target yang berhasil dikirimi pesan' },
  { token: '{failed_groups}', desc: 'Target yang gagal diproses' },
  { token: '{blocked_groups}', desc: 'Target yang terblokir/tidak dapat menerima pesan' },
  { token: '{removed_groups}', desc: 'Target unusable yang dikeluarkan dari percobaan berikutnya' },
  { token: '{sent_count}', desc: 'Jumlah pesan promosi yang benar-benar berhasil dikirim' },
  { token: '{failed_count}', desc: 'Jumlah pengiriman yang gagal' },
  { token: '{current_round}', desc: 'Nomor siklus/putaran promosi aktif' },
  { token: '{progress}', desc: 'Progress deterministik berdasarkan target yang sudah diproses' },
  { token: '{remaining_groups}', desc: 'Target yang tersisa pada siklus aktif' },
  { token: '{round_pause_remaining}', desc: 'Sisa waktu jeda sebelum putaran promosi berikutnya, dihitung dari timestamp runtime' },
  { token: '{phase}', desc: 'Fase runtime promosi saat ini, mis. MEMERIKSA TARGET, MENGIRIM, JEDA ANTAR GRUP, JEDA PUTARAN, atau MENUNGGU TELEGRAM' },
  { token: '{current_target}', desc: 'Target grup yang sedang diproses oleh runtime promosi' },
  { token: '{wait_reason}', desc: 'Alasan runtime sedang menunggu, mis. jeda antar grup, jeda putaran, timer, atau FloodWait Telegram' },
  { token: '{wait_remaining}', desc: 'Sisa waktu tunggu runtime saat status sedang pause/wait' },
  { token: '{started_at}', desc: 'Waktu mulai siklus promosi aktif' },
  { token: '{last_activity}', desc: 'Waktu aktivitas runtime promosi terakhir' },
  { token: '{estimated_completion}', desc: 'Estimasi selesai berbasis throughput aktual; fallback jika sampel belum cukup' },
  { token: '{remaining_time}', desc: 'Estimasi sisa waktu dalam detik jika throughput tersedia' },
  { token: '{interval}', desc: 'Interval/jeda antar grup yang dikonfigurasi' },
  { token: '{runtime_status}', desc: 'Status runtime userbot yang nyata' },
  { token: '{package_name}', desc: 'Nama paket/produk userbot yang tersedia' },  { token: '{timer}', desc: 'Status timer WTB pada userbot' },
  { token: '{auto_reset}', desc: 'Durasi auto reset cooldown dalam menit' },
  { token: '{reaction}', desc: 'Emoji reaksi Auto React yang sedang dikonfigurasi' },
  { token: '{message_type}', desc: 'Jenis pesan yang sedang dikonfigurasi pada Base Reply' },
  { token: '{target_channel}', desc: 'Target channel Base Reply yang sedang dikonfigurasi' },
  { token: '{banned_words}', desc: 'Daftar banned words Base Reply yang sedang dikonfigurasi' },
  { token: '{max_chars}', desc: 'Batas karakter Base Reply yang sedang dikonfigurasi' },
  { token: '{filter_link}', desc: 'Status filter link Base Reply' },
  { token: '{filter_username}', desc: 'Status filter username Base Reply' },
  { token: '{halaman}', desc: 'Nomor halaman pada daftar yang sedang ditampilkan' },
  { token: '{total_groups}', desc: 'Total target grup pada siklus promosi aktif' },
  { token: '{processed_groups}', desc: 'Target yang sudah diproses pada siklus aktif' },
  { token: '{successful_groups}', desc: 'Target yang berhasil dikirimi pesan' },
  { token: '{failed_groups}', desc: 'Target yang gagal diproses' },
  { token: '{blocked_groups}', desc: 'Target yang terblokir/tidak dapat menerima pesan' },
  { token: '{removed_groups}', desc: 'Target unusable yang dikeluarkan dari percobaan berikutnya' },
  { token: '{sent_count}', desc: 'Jumlah pesan promosi yang benar-benar berhasil dikirim' },
  { token: '{failed_count}', desc: 'Jumlah pengiriman yang gagal' },
  { token: '{current_round}', desc: 'Nomor siklus/putaran promosi aktif' },
  { token: '{progress}', desc: 'Progress deterministik berdasarkan target yang sudah diproses' },
  { token: '{remaining_groups}', desc: 'Target yang tersisa pada siklus aktif' },
  { token: '{round_pause_remaining}', desc: 'Sisa waktu jeda sebelum putaran promosi berikutnya, dihitung dari timestamp runtime' },
  { token: '{started_at}', desc: 'Waktu mulai siklus promosi aktif' },
  { token: '{last_activity}', desc: 'Waktu aktivitas runtime promosi terakhir' },
  { token: '{estimated_completion}', desc: 'Estimasi selesai berbasis throughput aktual; fallback jika sampel belum cukup' },
  { token: '{remaining_time}', desc: 'Estimasi sisa waktu dalam detik jika throughput tersedia' },
  { token: '{interval}', desc: 'Interval/jeda antar grup yang dikonfigurasi' },
  { token: '{runtime_status}', desc: 'Status runtime userbot yang nyata' },
  { token: '{package_name}', desc: 'Nama paket/produk userbot yang tersedia' },];

const WIB_TZ = 'Asia/Jakarta';

function computeResponseSpeed(ctx) {
  const sentAt = ctx && ctx.message && ctx.message.date;
  if (!sentAt) return '-';
  const elapsedMs = Date.now() - sentAt * 1000;
  if (elapsedMs < 0) return '0 detik';
  return `${(elapsedMs / 1000).toFixed(2)} detik`;
}

function formatTrialDuration() {
  try {
    const trialConfigService = require('../services/trialConfig.service');
    const hours = trialConfigService.getTrialDurationHours();
    return hours === 1 ? '1 jam' : `${hours} jam`;
  } catch (_) {
    return '-';
  }
}

function formatIndonesiaDate(value) {
  if (!value) return '-';
  const raw = String(value);
  const normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw) ? raw.replace(' ', 'T') + 'Z' : raw;
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) return String(value);
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: WIB_TZ,
    dateStyle: 'long',
    timeStyle: 'short',
  }).format(d) + ' WIB';
}

function formatRemainingDuration(expiresAt, now = Date.now()) {
  if (!expiresAt) return '-';
  const raw = String(expiresAt);
  const normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw) ? raw.replace(' ', 'T') + 'Z' : raw;
  const target = new Date(normalized).getTime();
  if (!Number.isFinite(target)) return '-';
  let seconds = Math.floor((target - now) / 1000);
  if (seconds <= 0) return 'KADALUARSA';

  const days = Math.floor(seconds / 86400);
  seconds %= 86400;
  const hours = Math.floor(seconds / 3600);
  seconds %= 3600;
  const minutes = Math.floor(seconds / 60);
  seconds %= 60;
  const parts = [];
  if (days) parts.push(`${days} hari`);
  if (hours) parts.push(`${hours} jam`);
  if (minutes) parts.push(`${minutes} menit`);
  if (!parts.length) parts.push(`${seconds} detik`);
  return parts.join(' ');
}

function secondsRemaining(expiresAt, now = Date.now()) {
  if (!expiresAt) return '-';
  const raw = String(expiresAt);
  const normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw) ? raw.replace(' ', 'T') + 'Z' : raw;
  const target = new Date(normalized).getTime();
  if (!Number.isFinite(target)) return '-';
  return String(Math.max(0, Math.floor((target - now) / 1000)));
}

function normalizeUserbot(data) {
  if (!data) return null;
  return data.userbot || data.asset || data.ownedUserbot || null;
}

function buildPlaceholderValues(ctx, extra = {}) {
  const user = (ctx && ctx.from) || {};
  const userbot = normalizeUserbot(extra);
  const firstName = user.first_name || user.firstName || 'Kamu';
  const lastName = user.last_name || user.lastName || '';
  const fullName = [firstName, lastName].filter(Boolean).join(' ');
  const now = new Date();
  const stats = extra.panelStats || {};

  let statusText = '-';
  if (userbot) {
    const sub = require('../services/subscription.service');
    const st = userbot.status === 'active' || userbot.status === 'expired' ? sub.getSubscriptionState(userbot) : null;
    statusText = st === 'EXPIRED' ? 'EXPIRED' : userbot.status === 'active' ? 'AKTIF' : String(userbot.status || '-').toUpperCase();
  }

  const username = userbot && (userbot.telegram_username || userbot.username || extra.userbotUsername)
    ? String(userbot.telegram_username || userbot.username || extra.userbotUsername).replace(/^@/, '')
    : '';
  const accountName = userbot && (userbot.account_name || userbot.name || extra.accountName || userbot.label)
    ? String(userbot.account_name || userbot.name || extra.accountName || userbot.label)
    : '-';

  const values = {
    nama: firstName,
    nama_lengkap: fullName || firstName,
    first_name: firstName,
    last_name: lastName || '-',
    username: user.username ? `@${user.username}` : '-',
    mention: user.username ? `@${user.username}` : fullName || firstName,
    id: user.id != null ? String(user.id) : '-',
    chat_id: ctx && ctx.chat && ctx.chat.id != null ? String(ctx.chat.id) : '-',
    tanggal: now.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric', timeZone: WIB_TZ }),
    waktu: `${now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: WIB_TZ })} WIB`,
    hari: now.toLocaleDateString('id-ID', { weekday: 'long', timeZone: WIB_TZ }),
    kecepatan_respon: computeResponseSpeed(ctx),
    durasi_trial: formatTrialDuration(),

    akun: accountName,
    nama_akun: accountName,
    userbot_id: userbot && userbot.id != null ? String(userbot.id) : '-',
    telegram_userbot_id: userbot && (userbot.telegram_userbot_id != null || userbot.telegramUserbotId != null) ? String(userbot.telegram_userbot_id ?? userbot.telegramUserbotId) : '-',
    userbot_nomor: userbot && (userbot.phone || userbot.userbot_phone) ? String(userbot.phone || userbot.userbot_phone) : '-',
    userbot_username: username ? `@${username}` : '-',
    userbot_produk: userbot && (userbot.label || userbot.product_name) ? String(userbot.label || userbot.product_name) : '-',
    userbot_order: userbot && userbot.order_id != null ? `#${userbot.order_id}` : '-',
    userbot_status: statusText,
    expired: formatRemainingDuration(userbot && userbot.expires_at),
    expired_at: formatIndonesiaDate(userbot && userbot.expires_at),
    sisa: formatRemainingDuration(userbot && userbot.expires_at),
    sisa_waktu: formatRemainingDuration(userbot && userbot.expires_at),
    sisa_detik: secondsRemaining(userbot && userbot.expires_at),
    durasi_userbot: extra.userbotDuration || (userbot && userbot.expires_at ? formatRemainingDuration(userbot.expires_at, userbot.activated_at ? new Date(userbot.activated_at).getTime() : now.getTime()) : '-'),
    aktivasi_at: formatIndonesiaDate(userbot && userbot.activated_at),
    token_garansi: userbot && userbot.token ? String(userbot.token) : '-',

    grup: stats.groupCount != null ? String(stats.groupCount) : '-',
    jumlah_grup: stats.groupCount != null ? String(stats.groupCount) : '-',
    reply: stats.replyCount != null ? String(stats.replyCount) : '-',
    jumlah_reply: stats.replyCount != null ? String(stats.replyCount) : '-',
    jenis_pesan: stats.messageType || '-',
    jeda_grup: stats.groupDelay != null ? String(stats.groupDelay) : '-',
    jeda_putaran: stats.roundDelay != null ? String(stats.roundDelay) : '-',
    channel: stats.channelStatus || '-',
    auto_promosi: stats.autoPromosi || (userbot && userbot.auto_promosi ? 'AKTIF' : 'NONAKTIF'),
    wtb_reply: stats.wtbReply || (userbot && userbot.wtb_reply ? 'AKTIF' : 'NONAKTIF'),
    pm_permit: stats.pmPermit || (userbot && userbot.pm_permit ? 'AKTIF' : 'NONAKTIF'),
  };

  // Promotion-status placeholders are backed by panelPlaceholderContext()'s
  // panelStats object, which in turn comes directly from
  // userbotRuntime.getPromotionStatus() / the durable runtime-job repository.
  // Add these values only when that audited promotion context is present so
  // generic `{status}` templates elsewhere keep their existing semantics.
  if (Object.prototype.hasOwnProperty.call(stats, 'promotionStatus')) {
    Object.assign(values, {
      status: stats.promotionStatus == null ? '-' : String(stats.promotionStatus),
      total_groups: stats.totalGroups == null ? '-' : String(stats.totalGroups),
      processed_groups: stats.processedGroups == null ? '-' : String(stats.processedGroups),
      successful_groups: stats.successfulGroups == null ? '-' : String(stats.successfulGroups),
      failed_groups: stats.failedGroups == null ? '-' : String(stats.failedGroups),
      blocked_groups: stats.blockedGroups == null ? '-' : String(stats.blockedGroups),
      removed_groups: stats.removedGroups == null ? '-' : String(stats.removedGroups),
      sent_count: stats.sentCount == null ? '-' : String(stats.sentCount),
      failed_count: stats.failedCount == null ? '-' : String(stats.failedCount),
      current_round: stats.currentRound == null ? '-' : String(stats.currentRound),
      progress: stats.progress == null ? '-' : String(stats.progress),
      remaining_groups: stats.remainingGroups == null ? '-' : String(stats.remainingGroups),
      round_pause_remaining: stats.roundPauseRemaining == null ? '-' : String(stats.roundPauseRemaining),
      phase: stats.phase == null ? '-' : String(stats.phase),
      current_target: stats.currentTarget == null ? '-' : String(stats.currentTarget),
      wait_reason: stats.waitReason == null ? '-' : String(stats.waitReason),
      wait_remaining: stats.waitRemaining == null ? '-' : String(stats.waitRemaining),
      started_at: stats.startedAt == null ? '-' : String(stats.startedAt),
      last_activity: stats.lastActivity == null ? '-' : String(stats.lastActivity),
      estimated_completion: stats.estimatedCompletion == null ? '-' : String(stats.estimatedCompletion),
      remaining_time: stats.remainingTime == null ? '-' : String(stats.remainingTime),
      interval: stats.interval == null ? '-' : String(stats.interval),
      runtime_status: stats.runtimeStatus == null ? '-' : String(stats.runtimeStatus),
      package_name: stats.packageName == null ? '-' : String(stats.packageName),
    });
  }

  return values;
}

/**
 * Replace placeholder tokens and shift Telegram MessageEntity offsets so
 * formatting, links, custom emoji, spoilers, code, etc. remain valid.
 */
function applyPlaceholders(text, entities, ctx, extra = {}) {
  if (typeof text !== 'string' || !text.includes('{')) {
    return { text: text || '', entities: normalizeTelegramEntities(text || '', entities || []) };
  }

  const safeExtra = {};
  for (const [key, value] of Object.entries((extra && extra.placeholderValues) || {})) {
    if (value == null) safeExtra[key] = '-';
    else if (['string', 'number', 'boolean'].includes(typeof value)) safeExtra[key] = String(value);
    else if (value && typeof value === 'object' && typeof value.text === 'string') {
      safeExtra[key] = {
        text: value.text,
        entities: normalizeTelegramEntities(value.text, Array.isArray(value.entities) ? value.entities : []),
      };
    }
  }
  function resolveReplacement(value) {
    if (value && typeof value === 'object' && typeof value.text === 'string') {
      return {
        text: value.text,
        entities: Array.isArray(value.entities) ? value.entities : [],
      };
    }
    return { text: String(value ?? '-'), entities: [] };
  }
  // ctx is optional: channel renders (e.g. Testimoni) pass real data via extra.placeholderValues only.
  const values = { ...(ctx ? buildPlaceholderValues(ctx, extra) : {}), ...safeExtra };
  const replacements = [];
  let match;
  const placeholderPattern = /\{([A-Za-z0-9_]+)\}/g;

  while ((match = placeholderPattern.exec(text)) !== null) {
    const token = match[0];
    const key = match[1];
    const resolved = Object.prototype.hasOwnProperty.call(values, key) ? resolveReplacement(values[key]) : { text: token, entities: [] };
    replacements.push({
      start: match.index,
      end: match.index + token.length,
      value: resolved.text,
      entities: resolved.entities,
    });
  }

  if (!replacements.length) {
    return { text, entities: normalizeTelegramEntities(text, entities || []) };
  }

  let result = '';
  let cursor = 0;
  const mapped = [];

  for (const replacement of replacements) {
    result += text.slice(cursor, replacement.start);
    const newStart = result.length;
    result += replacement.value;
    const newEnd = result.length;
    mapped.push({ ...replacement, newStart, newEnd });
    cursor = replacement.end;
  }
  result += text.slice(cursor);

  function mapOffset(originalOffset, side) {
    for (const replacement of mapped) {
      if (originalOffset < replacement.start) break;
      if (originalOffset > replacement.end) continue;
      if (originalOffset === replacement.start) return replacement.newStart;
      if (originalOffset === replacement.end) return replacement.newEnd;
      return side === 'end' ? replacement.newEnd : replacement.newStart;
    }

    let delta = 0;
    for (const replacement of mapped) {
      if (replacement.end <= originalOffset) {
        delta += (replacement.value.length - (replacement.end - replacement.start));
      } else {
        break;
      }
    }
    return originalOffset + delta;
  }

  const transformed = Array.isArray(entities)
    ? entities.map((entity) => {
        const originalStart = Number(entity.offset);
        const originalEnd = originalStart + Number(entity.length);
        const newStart = mapOffset(originalStart, 'start');
        const newEnd = mapOffset(originalEnd, 'end');
        return {
          ...entity,
          offset: newStart,
          length: newEnd - newStart,
        };
      })
    : [];

  for (const replacement of mapped) {
    if (!Array.isArray(replacement.entities) || !replacement.entities.length) continue;
    for (const entity of replacement.entities) {
      transformed.push({
        ...entity,
        offset: replacement.newStart + Number(entity.offset || 0),
      });
    }
  }

  // normalizeTelegramEntities performs a final UTF-16 boundary check and
  // removes only malformed/crossing ranges. It never changes the text.
  return {
    text: result,
    entities: normalizeTelegramEntities(result, transformed),
  };
}

module.exports = {
  applyPlaceholders,
  buildPlaceholderValues,
  PLACEHOLDER_DOCS,
  BASE_PLACEHOLDERS,
  extractPlaceholders,
  formatIndonesiaDate,
  formatRemainingDuration,
};
