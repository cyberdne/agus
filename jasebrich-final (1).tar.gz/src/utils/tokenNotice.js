'use strict';
/**
 * Rendering of everything a user sees about Backup Tokens — one place, so the
 * wording for "Cek Token", "Backup Token" and the claim flow cannot drift.
 *
 * Markdown, the same parse mode as the surrounding token/panel screens. A
 * freshly issued token exists in plaintext ONLY inside newTokenNotice(): the
 * database keeps just a hash, so it cannot be shown again (owner regenerates).
 * A token contains only [A-Za-z0-9-: ] so it is safe inside a code span.
 *
 * None of these renderers ever includes internal ids, phone numbers, session
 * data, order ids or another user's information.
 */
const { formatIndonesiaDate, formatRemainingDuration } = require('./placeholders');
const { STATE, MODE } = require('../services/backupToken.service');
const { defineTemplate } = require('../services/custom-submenu.service');

const newTokenTemplate = defineTemplate(
  'token.new_token_notice',
  'Backup Token',
  'Token Backup Baru',
  '🔑 *Token Backup Baru Anda*\n`{token_garansi}`\n\n{pesan} Token ini hanya ditampilkan sekali — simpan baik-baik dan jangan bagikan ke siapa pun. Gunakan lewat 🎫 Klaim Token jika userbot logout atau error.',
  { supportedPlaceholders: ['token_garansi', 'pesan'] }
);

const tokenMessageTpl = {
  checkValid: defineTemplate('token.check_valid', 'Backup Token', 'Token Valid', '✅ *TOKEN VALID*\n\nUserbot: *{produk}*\nJenis: {jenis}\nSisa masa aktif: *{sisa}*\n{status_info}\n\nToken hanya memulihkan userbot yang sama; tidak membuat userbot baru dan tidak memperpanjang masa aktif. Setelah dipakai untuk pemulihan, token diganti dengan yang baru.', { supportedPlaceholders: ['produk', 'jenis', 'sisa', 'status_info'] }),
  checkExpiredTrial: defineTemplate('token.check_expired_trial', 'Backup Token', 'Token Trial Kedaluwarsa', '⏰ *TOKEN TIDAK DAPAT DIGUNAKAN*\n\nMasa aktif trial sudah berakhir. Trial tidak dapat diaktifkan kembali.'),
  checkExpiredUserbot: defineTemplate('token.check_expired_userbot', 'Backup Token', 'Token Userbot Kedaluwarsa', '⏰ *TOKEN TIDAK DAPAT DIGUNAKAN*\n\nMasa aktif userbot sudah berakhir. Perpanjang langganan lewat 🛒 Toko.'),
  checkRotated: defineTemplate('token.check_rotated', 'Backup Token', 'Token Sudah Dirotasi', '🔁 *TOKEN SUDAH DIROTASI*\n\nToken ini sudah tidak berlaku (sudah digunakan atau diganti dengan token baru).'),
  checkRevoked: defineTemplate('token.check_revoked', 'Backup Token', 'Token Dicabut', '🚫 *TOKEN DICABUT*\n\nToken ini sudah dicabut karena userbot terkait telah dihapus.'),
  checkNotRecoverable: defineTemplate('token.check_not_recoverable', 'Backup Token', 'Userbot Belum Dapat Dipulihkan', 'ℹ️ *USERBOT BELUM DAPAT DIPULIHKAN*\n\nAktivasi userbot untuk token ini belum selesai.'),
  checkRateLimited: defineTemplate('token.check_rate_limited', 'Backup Token', 'Percobaan Token Terlalu Banyak', '⏳ Terlalu banyak percobaan token yang gagal. Coba lagi dalam beberapa menit.'),
  checkInvalid: defineTemplate('token.check_invalid', 'Backup Token', 'Token Tidak Valid', '❌ *TOKEN TIDAK VALID*\n\nToken tidak ditemukan atau tidak dapat digunakan oleh akun ini.'),
  backupStatus: defineTemplate('token.backup_status', 'Backup Token', 'Status Backup Token', '🪽 *Backup Token*\n\nUserbot: *{akun}*\nJenis: {jenis}\nSisa masa aktif: *{sisa}*\n{status_token}\n{rotasi_info}\n\nToken disimpan dalam bentuk hash sehingga tidak dapat ditampilkan ulang. Token yang kamu terima saat aktivasi dipakai lewat 🎫 Klaim Token bila userbot ter-logout atau error: userbot yang *sama* dipulihkan, bukan userbot baru, dan masa aktif tidak diperpanjang.\n\nUntuk membuat token baru (token lama langsung tidak berlaku), tekan tombol 🔑 Buat Token Baru.', { supportedPlaceholders: ['akun', 'jenis', 'sisa', 'status_token', 'rotasi_info'] }),
};

function renderTokenTemplate(template, ctx, placeholderValues = {}) {
  return template.getContent(ctx, { placeholderValues });
}

function newTokenNoticeContent(ctx, token, { intro = 'Token sebelumnya sudah tidak berlaku.' } = {}) {
  const content = newTokenTemplate.getContent(ctx || null, {
    placeholderValues: {
      token_garansi: String(token || ''),
      pesan: String(intro || '').trim(),
    },
  });
  return content;
}

// Backward-compatible text-only helper for non-context callers/tests. Production
// user-facing callers pass ctx to newTokenNoticeContent() so persisted custom
// content and Telegram entities are actually honored.
function newTokenNotice(token, { intro = 'Token sebelumnya sudah tidak berlaku.', ctx = null } = {}) {
  if (!ctx) {
    return `🔑 *Token Backup Baru Anda*\n\`${String(token || '')}\`\n\n${String(intro || '').trim()} Token ini hanya ditampilkan sekali — simpan baik-baik dan jangan bagikan ke siapa pun. Gunakan lewat 🎫 Klaim Token jika userbot logout atau error.`;
  }
  return newTokenNoticeContent(ctx, token, { intro }).text;
}


const SESSION_LINE = {
  [MODE.HEALTHY]: '🟢 Sesi userbot normal — belum perlu pemulihan.',
  [MODE.RECOVER_SESSION]: '🟠 Sesi userbot perlu login ulang. Gunakan token ini lewat 🎫 Klaim Token.',
  [MODE.REACTIVATE]: '🟠 Akses userbot sedang dinonaktifkan. 🎫 Klaim Token dapat memulihkannya selama masa aktif belum berakhir.',
};

/** Reply to "🔥 Cek Token". `res` is backupToken.checkToken()'s owner-safe result. */
function checkResultContent(ctxLike, res) {
  switch (res.state) {
    case STATE.VALID:
      return renderTokenTemplate(tokenMessageTpl.checkValid, ctxLike, {
        produk: res.label || 'Userbot',
        jenis: res.trial ? 'Trial' : 'Berlangganan',
        sisa: res.expiresAt ? formatRemainingDuration(res.expiresAt) : 'tanpa batas waktu',
        status_info: SESSION_LINE[res.mode] || '-',
      });
    case STATE.EXPIRED:
      return renderTokenTemplate(res.trial ? tokenMessageTpl.checkExpiredTrial : tokenMessageTpl.checkExpiredUserbot, ctxLike);
    case STATE.ROTATED:
      return renderTokenTemplate(tokenMessageTpl.checkRotated, ctxLike);
    case STATE.REVOKED:
      return renderTokenTemplate(tokenMessageTpl.checkRevoked, ctxLike);
    case STATE.NOT_RECOVERABLE:
      return renderTokenTemplate(tokenMessageTpl.checkNotRecoverable, ctxLike);
    case STATE.RATE_LIMITED:
      return renderTokenTemplate(tokenMessageTpl.checkRateLimited, ctxLike);
    default:
      return renderTokenTemplate(tokenMessageTpl.checkInvalid, ctxLike);
  }
}

function describeCheckResult(res, ctxLike = null) {
  return checkResultContent(ctxLike, res).text;
}

/** The "🪽 Backup Token" screen, from backupToken.getStatus() (owner-verified, token-free). */
function backupStatusContent(ctxLike, label, status) {
  const tokenLine = status.hasToken
    ? `Status token: ✅ Aktif`
    : 'Status token: ⚠️ Belum ada token untuk userbot ini';
  const rotationInfo = status.hasToken && status.rotatedAt
    ? `(dibuat/diperbarui ${formatIndonesiaDate(status.rotatedAt)})`
    : '';
  return renderTokenTemplate(tokenMessageTpl.backupStatus, ctxLike, {
    akun: label || 'Userbot',
    jenis: status.trial ? 'Trial' : 'Berlangganan',
    sisa: status.expiresAt ? formatRemainingDuration(status.expiresAt) : 'tanpa batas waktu',
    status_token: tokenLine,
    rotasi_info: rotationInfo,
  });
}

function describeBackupStatus(label, status, ctxLike = null) {
  return backupStatusContent(ctxLike, label, status).text;
}

module.exports = { newTokenNotice, newTokenNoticeContent, describeCheckResult, describeBackupStatus, checkResultContent, backupStatusContent, tokenMessageTpl, newTokenTemplate };
