/**
 * Shared single-emoji validator.
 *
 * BUG THIS FIXES: every emoji-input feature used to validate with raw
 * `string.length` (UTF-16 code units). That works for simple emoji like
 * ⭐ (1 unit) or 💎 (2 units), but silently rejects perfectly valid
 * single emoji that are made of multiple codepoints — flags (🇮🇩 = 4
 * units), skin-tone modifiers (👍🏽 = 4 units), ZWJ sequences (👨‍👩‍👧‍👦 = 11
 * units, 🧑‍💻 = 5 units) — because those all count as "too long" even
 * though a human sees exactly one emoji. That's why some emoji "worked"
 * and others didn't: it was never about the emoji itself, just how many
 * UTF-16 units its codepoints happened to take up.
 *
 * Fix: count Unicode grapheme clusters (what a person actually perceives
 * as "one character") via Intl.Segmenter instead of raw .length. Node 20+
 * (this project's minimum) has Intl.Segmenter built in — no dependency.
 */

const segmenter = new Intl.Segmenter('id', { granularity: 'grapheme' });

// Custom/Premium emoji are sent as a placeholder codepoint (commonly a
// generic ⭐-like glyph) plus a `custom_emoji` entity — the raw text
// itself is always exactly one grapheme, same as any other emoji.
const EMOJI_TEST = /\p{Extended_Pictographic}|\p{Emoji_Presentation}/u;

/**
 * Validates that `raw` is exactly one emoji (any complexity — flags,
 * ZWJ sequences, skin tones, or a custom/Premium emoji placeholder).
 * Returns { ok: true, value } or { ok: false, reason }.
 */
function validateSingleEmoji(raw) {
  const value = String(raw || '').trim();
  if (!value) return { ok: false, reason: 'Emoji tidak boleh kosong.' };

  const graphemes = Array.from(segmenter.segment(value)).map((s) => s.segment);
  if (graphemes.length !== 1) {
    return {
      ok: false,
      reason:
        graphemes.length > 1
          ? 'Kirim hanya SATU emoji (terdeteksi lebih dari satu karakter).'
          : 'Emoji tidak valid.',
    };
  }

  if (!EMOJI_TEST.test(value)) {
    return { ok: false, reason: 'Itu bukan emoji yang valid. Kirim satu emoji saja.' };
  }

  return { ok: true, value };
}

module.exports = { validateSingleEmoji };
