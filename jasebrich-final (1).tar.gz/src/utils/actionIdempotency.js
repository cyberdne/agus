'use strict';

/**
 * Small in-process idempotency primitive for event-driven UI actions.
 *
 * The key MUST be a stable event/message identity supplied by the caller
 * (for example Telegram update_id, callback_query.id, or a consumed source
 * message id). This is deliberately not a label/text/cooldown gate.
 *
 * A completed key is remembered only for a bounded retention window because
 * Telegram update/callback IDs are unique; a different real user action has
 * a different key and therefore is never suppressed.
 */
function createActionIdempotency({ ttlMs = 60_000, maxEntries = 2000 } = {}) {
  const inFlight = new Map();
  const completed = new Map();

  function prune(now = Date.now()) {
    for (const [key, at] of completed) {
      if (now - at > ttlMs) completed.delete(key);
    }
    if (completed.size <= maxEntries) return;
    const overflow = completed.size - maxEntries;
    const oldest = [...completed.entries()]
      .sort((a, b) => a[1] - b[1])
      .slice(0, overflow);
    for (const [key] of oldest) completed.delete(key);
  }

  async function run(key, action) {
    if (key == null || key === '') return action();

    const now = Date.now();
    prune(now);
    if (completed.has(key)) return { deduped: true };

    const active = inFlight.get(key);
    if (active) return active;

    let succeeded = false;
    const work = (async () => {
      try {
        const result = await action();
        succeeded = true;
        return result;
      } finally {
        inFlight.delete(key);
        if (succeeded) completed.set(key, Date.now());
        prune();
      }
    })();

    inFlight.set(key, work);
    return work;
  }

  function clear() {
    inFlight.clear();
    completed.clear();
  }

  return Object.freeze({ run, clear });
}

module.exports = { createActionIdempotency };
