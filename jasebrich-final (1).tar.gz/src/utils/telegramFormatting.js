/**
 * Telegram text/entity normalization + loss-minimizing HTML fallback.
 *
 * Why this exists:
 * Telegram's Bot API validates entity offsets/ranges very strictly. A
 * placeholder replacement can change the UTF-16 length of the message, and
 * even a single stale offset causes 400 ENTITY_TEXT_INVALID. We therefore:
 * 1) normalize and validate entity ranges in UTF-16 code units;
 * 2) serialize valid entities to Telegram HTML when an API call rejects the
 *    raw entities; and
 * 3) never let a formatting problem turn into a user-facing dead-end.
 */

const SUPPORTED_ENTITY_TYPES = new Set([
  'mention', 'hashtag', 'cashtag', 'bot_command', 'url', 'email', 'phone_number',
  'bold', 'italic', 'underline', 'strikethrough', 'spoiler', 'blockquote',
  'expandable_blockquote', 'code', 'pre', 'text_link', 'text_mention', 'custom_emoji', 'date_time',
]);

const SAFE_INLINE_TYPES = new Set(['bold', 'italic', 'underline', 'strikethrough', 'spoiler', 'blockquote', 'expandable_blockquote', 'code', 'pre', 'text_link', 'text_mention', 'custom_emoji']);
const LEAF_TYPES = new Set(['code', 'pre', 'date_time']);

function escapeHtml(text) {
  return String(text == null ? '' : text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeHtmlAttribute(value) {
  return escapeHtml(value).replace(/'/g, '&#39;');
}

function isSafeBoundary(text, position) {
  const pos = Number(position);
  if (!Number.isInteger(pos) || pos < 0 || pos > text.length) return false;
  if (pos === 0 || pos === text.length) return true;
  const before = text.charCodeAt(pos - 1);
  const after = text.charCodeAt(pos);
  return !(before >= 0xd800 && before <= 0xdbff && after >= 0xdc00 && after <= 0xdfff);
}

function entityPriority(type) {
  switch (type) {
    case 'pre': return 100;
    case 'code': return 90;
    case 'custom_emoji': return 40;
    case 'blockquote':
    case 'expandable_blockquote': return 70;
    case 'text_link':
    case 'text_mention': return 60;
    case 'bold':
    case 'italic':
    case 'underline':
    case 'strikethrough':
    case 'spoiler': return 50;
    default: return 10;
  }
}

function normalizeEntity(text, raw) {
  if (!raw || typeof raw.type !== 'string' || !SUPPORTED_ENTITY_TYPES.has(raw.type)) return null;
  const offset = Number(raw.offset);
  const length = Number(raw.length);
  if (!Number.isInteger(offset) || !Number.isInteger(length) || offset < 0 || length <= 0) return null;
  const end = offset + length;
  if (end > text.length || !isSafeBoundary(text, offset) || !isSafeBoundary(text, end)) return null;

  const entity = { type: raw.type, offset, length };
  if (raw.type === 'text_link') {
    if (typeof raw.url !== 'string' || !raw.url.trim()) return null;
    entity.url = raw.url;
  }
  if (raw.type === 'text_mention') {
    if (!raw.user || raw.user.id == null) return null;
    entity.user = raw.user;
  }
  if (raw.type === 'custom_emoji') {
    if (raw.custom_emoji_id == null || String(raw.custom_emoji_id).trim() === '') return null;
    entity.custom_emoji_id = String(raw.custom_emoji_id);
  }
  if (raw.type === 'date_time') {
    const unix = Number(raw.unix_time);
    const format = raw.date_time_format == null ? '' : String(raw.date_time_format);
    if (!Number.isInteger(unix) || unix < 0) return null;
    if (!/^r$|^w?[dD]?[tT]?$/.test(format)) return null;
    entity.unix_time = unix;
    entity.date_time_format = format;
  }
  if (raw.type === 'pre' && raw.language) entity.language = String(raw.language);
  return entity;
}

function overlaps(a, b) {
  const as = a.offset;
  const ae = a.offset + a.length;
  const bs = b.offset;
  const be = b.offset + b.length;
  return as < be && bs < ae;
}

function contains(a, b) {
  return a.offset <= b.offset && (a.offset + a.length) >= (b.offset + b.length);
}

/**
 * Telegram permits nested entities but not arbitrary crossing ranges. This
 * routine preserves as much formatting as possible while removing malformed
 * crossing/leaf overlaps before an API call.
 */
function normalizeTelegramEntities(text, entities) {
  if (!Array.isArray(entities) || !entities.length) return [];

  const candidates = entities
    .map((e) => normalizeEntity(text, e))
    .filter(Boolean)
    .sort((a, b) => {
      if (a.offset !== b.offset) return a.offset - b.offset;
      if (a.length !== b.length) return b.length - a.length;
      return entityPriority(b.type) - entityPriority(a.type);
    });

  const accepted = [];
  for (const candidate of candidates) {
    let reject = false;
    for (const existing of accepted) {
      if (!overlaps(candidate, existing)) continue;

      // Code/pre/custom emoji are treated as leaf ranges. Preserve the
      // highest-priority leaf and drop any entity that would partially
      // intersect it or be nested inside it.
      if (LEAF_TYPES.has(existing.type) || LEAF_TYPES.has(candidate.type)) {
        if (existing.type === 'custom_emoji' && candidate.type === 'custom_emoji') {
          // Two custom emoji cannot occupy the same characters meaningfully;
          // keep the earlier one.
          reject = true;
          break;
        }
        if (LEAF_TYPES.has(existing.type)) {
          reject = true;
          break;
        }
        if (LEAF_TYPES.has(candidate.type)) {
          // Candidate leaf gets precedence over a generic formatter that
          // merely contains it, unless the candidate is wholly inside the
          // formatter and both are valid HTML nesting candidates. For pre the
          // outer formatting is never retained because Telegram is strict.
          if (contains(candidate, existing) || contains(existing, candidate)) {
            // Prefer the leaf for safety.
            const idx = accepted.indexOf(existing);
            accepted.splice(idx, 1);
          } else {
            reject = true;
            break;
          }
        }
      }

      // Blockquote and expandable_blockquote cannot contain each other, even
      // when one range fully contains the other. Preserve the first entity.
      const bothBlockquotes = (candidate.type === 'blockquote' || candidate.type === 'expandable_blockquote')
        && (existing.type === 'blockquote' || existing.type === 'expandable_blockquote');
      if (bothBlockquotes) {
        reject = true;
        break;
      }

      // Crossing intervals are not valid nested markup. Keep the entity with
      // the broader range / higher priority and drop the crossing one.
      const candidateContains = contains(candidate, existing);
      const existingContains = contains(existing, candidate);
      if (!candidateContains && !existingContains) {
        if (entityPriority(candidate.type) > entityPriority(existing.type)) {
          const idx = accepted.indexOf(existing);
          accepted.splice(idx, 1);
        } else {
          reject = true;
          break;
        }
      }
    }
    if (!reject) accepted.push(candidate);
  }

  return accepted.sort((a, b) => {
    if (a.offset !== b.offset) return a.offset - b.offset;
    if (a.length !== b.length) return b.length - a.length;
    return entityPriority(b.type) - entityPriority(a.type);
  });
}

function entityTag(entity, text) {
  const raw = text.slice(entity.offset, entity.offset + entity.length);
  switch (entity.type) {
    case 'bold': return ['<b>', '</b>'];
    case 'italic': return ['<i>', '</i>'];
    case 'underline': return ['<u>', '</u>'];
    case 'strikethrough': return ['<s>', '</s>'];
    case 'spoiler': return ['<tg-spoiler>', '</tg-spoiler>'];
    case 'blockquote': return ['<blockquote>', '</blockquote>'];
    case 'expandable_blockquote': return ['<blockquote expandable>', '</blockquote>'];
    case 'code': return ['<code>', '</code>'];
    case 'pre': {
      const language = entity.language ? ` class="language-${escapeHtmlAttribute(entity.language).replace(/[^a-zA-Z0-9_-]/g, '')}"` : '';
      return [`<pre><code${language}>`, '</code></pre>'];
    }
    case 'text_link': return [`<a href="${escapeHtmlAttribute(entity.url)}">`, '</a>'];
    case 'text_mention': return [`<a href="tg://user?id=${encodeURIComponent(String(entity.user.id))}">`, '</a>'];
    case 'custom_emoji': return [`<tg-emoji emoji-id="${escapeHtmlAttribute(entity.custom_emoji_id)}">`, '</tg-emoji>'];
    case 'date_time': {
      const format = entity.date_time_format ? ` format="${escapeHtmlAttribute(entity.date_time_format)}"` : '';
      return [`<tg-time unix="${entity.unix_time}"${format}>`, '</tg-time>'];
    }
    default: return [null, null];
  }
}

/**
 * Converts Bot API entities to valid Telegram HTML. This is deliberately
 * generated from ranges rather than by doing markdown replacement, so emoji,
 * unicode and arbitrary user text are escaped safely.
 */
function entitiesToTelegramHtml(text, entities) {
  const normalized = normalizeTelegramEntities(text, entities);
  if (!normalized.length) return escapeHtml(text);

  // Events are used instead of recursive slicing so nested entities are
  // emitted in deterministic parent->child order.
  const opens = new Map();
  const closes = new Map();
  normalized.forEach((entity, order) => {
    const [open, close] = entityTag(entity, text);
    if (!open) return;
    const start = entity.offset;
    const end = entity.offset + entity.length;
    const item = { entity, open, close, order };
    if (!opens.has(start)) opens.set(start, []);
    if (!closes.has(end)) closes.set(end, []);
    opens.get(start).push(item);
    closes.get(end).push(item);
  });

  const points = new Set([0, text.length]);
  for (const p of opens.keys()) points.add(p);
  for (const p of closes.keys()) points.add(p);
  const positions = [...points].sort((a, b) => a - b);

  let out = '';
  for (let i = 0; i < positions.length; i += 1) {
    const pos = positions[i];

    // Close children first: shorter ranges first when they share an end.
    const ending = closes.get(pos) || [];
    ending.sort((a, b) => {
      const aStart = a.entity.offset;
      const bStart = b.entity.offset;
      if (aStart !== bStart) return bStart - aStart;
      // Same-range entities form a stack. Close the most recently opened one
      // first so HTML nesting is always well-formed: <b><i>...</i></b>.
      return b.order - a.order;
    });
    for (const item of ending) {
      if (item.entity.type === 'custom_emoji') {
        out += item.close;
      } else {
        out += item.close;
      }
    }

    // Open parents first: longer ranges first when they share a start.
    const starting = opens.get(pos) || [];
    starting.sort((a, b) => {
      const aEnd = a.entity.offset + a.entity.length;
      const bEnd = b.entity.offset + b.entity.length;
      if (aEnd !== bEnd) return bEnd - aEnd;
      const priority = entityPriority(b.entity.type) - entityPriority(a.entity.type);
      return priority || a.order - b.order;
    });
    for (const item of starting) out += item.open;

    const next = positions[i + 1];
    if (next == null || next <= pos) continue;

    // Telegram requires a valid regular emoji as the content of a custom
    // emoji tag, so the original text is kept inside <tg-emoji>.
    out += escapeHtml(text.slice(pos, next));
  }

  // The event loop above closes an entity before opening a same-position
  // successor, which is exactly what Telegram's HTML parser expects.
  return out;
}

function extractApiErrorMessage(err) {
  return String(
    (err && err.description) ||
    (err && err.response && err.response.description) ||
    (err && err.message) ||
    ''
  );
}

function isEntityTextInvalidError(err) {
  return /ENTITY_TEXT_INVALID|can't parse entities|can'?t parse entities|Bad Request: ENTITY/i.test(extractApiErrorMessage(err));
}

function isFormattingPayload(payload) {
  return Boolean(payload && (
    Array.isArray(payload.entities) ||
    Array.isArray(payload.caption_entities)
  ));
}

function buildHtmlFallbackPayload(payload) {
  const next = { ...payload };
  if (Array.isArray(payload.entities)) {
    const text = typeof payload.text === 'string' ? payload.text : '';
    next.text = entitiesToTelegramHtml(text, payload.entities);
    next.parse_mode = 'HTML';
    delete next.entities;
  }
  if (Array.isArray(payload.caption_entities)) {
    const text = typeof payload.caption === 'string' ? payload.caption : '';
    next.caption = entitiesToTelegramHtml(text, payload.caption_entities);
    next.parse_mode = 'HTML';
    delete next.caption_entities;
  }
  return next;
}

module.exports = {
  SUPPORTED_ENTITY_TYPES,
  escapeHtml,
  normalizeTelegramEntities,
  entitiesToTelegramHtml,
  extractApiErrorMessage,
  isEntityTextInvalidError,
  isFormattingPayload,
  buildHtmlFallbackPayload,
};
