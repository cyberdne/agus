const logger = require('./logger');

const SAFE_MESSAGE = '❌ Terjadi kesalahan saat memproses permintaan.\n\nSilakan coba lagi beberapa saat lagi.';
const { defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');
const safeErrorTemplate = defineTemplate('system.safe_error', 'Sistem', 'Error Aman', SAFE_MESSAGE, { maxLength: 4096 });
function getSafeErrorContent(ctx) {
  try {
    const content = safeErrorTemplate.getContent(ctx);
    return { text: content.text, options: buildReplyOptions(content) };
  } catch (_) {
    return { text: SAFE_MESSAGE, options: {} };
  }
}

/**
 * Wrap a handler so any thrown error is logged safely and the user
 * gets a generic message instead of leaking internal details.
 */
function safeHandler(handler) {
  return async (ctx, ...rest) => {
    try {
      await handler(ctx, ...rest);
    } catch (err) {
      logger.error('Handler error:', err && err.message ? err.message : err);
      try {
        const safe = getSafeErrorContent(ctx);
        await ctx.reply(safe.text, safe.options);
      } catch (replyErr) {
        logger.error('Failed to send safe error message:', replyErr && replyErr.message);
      }
    }
  };
}

module.exports = { safeHandler, SAFE_MESSAGE, getSafeErrorContent };
