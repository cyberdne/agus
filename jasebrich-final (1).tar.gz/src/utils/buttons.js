/**
 * Semantic button style helper.
 *
 * Telegram Bot API 9.4 (Feb 9, 2026) added a native `style` field to both
 * KeyboardButton and InlineKeyboardButton, so buttons CAN now have real
 * colors — this is no longer just an emoji/label convention.
 *
 * Supported values (per Telegram Bot API): 'primary' (blue), 'success'
 * (green), 'danger' (red). There is no native "secondary"/gray value —
 * Every button in this project explicitly receives one of those three styles.
 *
 * Telegraf passes extra fields straight through to the Bot API, so
 * `style` works even on Telegraf versions whose TypeScript typings
 * don't know about it yet — it's just JSON.
 *
 * RULE FOR FUTURE FEATURES: every new button (inline or reply keyboard)
 * must be created through this helper (`button.*` or `replyButton.*`)
 * so styling stays consistent project-wide. Pick style by function, not
 * by taste:
 *   - primary  -> normal navigation / default action
 *   - success  -> confirm, start, positive/"go" actions
 *   - danger   -> stop, delete, destructive/negative actions
 *   - secondary/neutral -> primary (Telegram has no native secondary style)
 *
 * RULE FOR CUSTOM-ICON ELIGIBILITY: EVERY button created through this
 * helper — inline or reply, main feature or generic chrome (pagination,
 * "Kembali"/"Batal"/"Tutub" navigation, admin CRUD like Ban/Hapus/Edit),
 * static or built from dynamic data — is registered into Admin Panel ->
 * Settings -> Custom Icon Tombol, no exceptions. A caller may still pass
 * `{ customizable: false }` for historical reasons, but as of this
 * revision it is a no-op: registration and icon lookup always happen.
 * See applyStyle() below.
 */

const STYLES = new Set(['primary', 'success', 'danger']);

/** Telegram Bot API callback_data is strictly 1-64 UTF-8 bytes.
 *  Validate at the single button-construction choke point so a malformed
 *  callback can never reach Telegram as a late 400 BUTTON_DATA_INVALID.
 */
function validateCallbackData(callbackData, context = 'inline button') {
  if (typeof callbackData !== 'string' || callbackData.length === 0) {
    throw new TypeError(`Invalid callback_data for ${context}: callback_data must be a non-empty string.`);
  }
  const bytes = Buffer.byteLength(callbackData, 'utf8');
  if (bytes > 64) {
    throw new RangeError(`Invalid callback_data for ${context}: ${bytes} UTF-8 bytes exceeds Telegram's 64-byte limit.`);
  }
  return callbackData;
}
const buttonIcons = require('../services/buttonIconConfig.service');

function applyStyle(base, style, opts = {}) {
  // Universal auto-discovery: EVERY button that passes through this
  // helper registers its label into the known-buttons list, so it
  // becomes pickable in Admin Panel -> Settings -> Custom Icon Tombol
  // — main features, nav/pagination chrome ("Kembali", "Batal",
  // "Berikutnya"...), admin CRUD (Ban/Hapus/Edit), and buttons whose
  // text is built from dynamic data, all included, no exceptions.
  // `opts.customizable` is intentionally ignored here (kept only so
  // older call sites that still pass it don't break) — registration
  // and icon lookup now always run, per product decision to make
  // literally every button in the bot customizable.
  // `iconKey` lets dynamic buttons (for example Join Gate's channel title)
  // keep one stable Custom Icon Tombol identity even when the visible text
  // changes. Without it, changing the channel title would orphan the
  // previously configured icon because the lookup key would change too.
  const iconKey = opts.iconKey || base.text;
  // Keep BOTH the original handler-facing label and the stable icon lookup
  // key. Reply keyboards return only rendered text to the bot, so routing
  // must be able to translate the customized text back to `base.text`.
  buttonIcons.registerButtonLabel(base.text, iconKey);
  // A caller-supplied `opts.iconCustomEmojiId` (e.g. a per-product
  // garansi badge from premiumEmojiConfig, or the "Saya Setuju &
  // Lanjutkan" badge) means this specific button already carries its
  // own purpose-built icon baked into `base.text`. The label is still
  // registered above — so it shows up in Admin Panel -> Settings ->
  // Custom Icon Tombol like every other button, no exceptions — but
  // the generic lookup's text substitution is skipped for it, since
  // applying a second icon prefix on top of the badge would render
  // BOTH side by side (the badge as native icon_custom_emoji_id, the
  // admin's fallback character baked into the text) on any client that
  // supports native button icons. Buttons with no explicit badge behave
  // exactly as before: fully driven by the Custom Icon Tombol config.
  const hasExplicitBadge = !!opts.iconCustomEmojiId;
  const suppressCustomIcon = opts.disableCustomIcon === true;
  const cfg = hasExplicitBadge || suppressCustomIcon
    ? { text: base.text, iconCustomEmojiId: null }
    : buttonIcons.getButtonConfig(base.text, iconKey);
  const styled = { ...base, text: cfg.text, style: style && STYLES.has(style) ? style : 'primary' };
  const iconCustomEmojiId = opts.iconCustomEmojiId || (suppressCustomIcon ? null : cfg.iconCustomEmojiId);
  if (iconCustomEmojiId) styled.icon_custom_emoji_id = String(iconCustomEmojiId);
  return styled;
}

/**
 * Inline keyboard buttons: { text, callback_data, style? }
 * Used inside Markup.inlineKeyboard([[ ... ]]).
 *
 * Optional `opts.iconCustomEmojiId` attaches a specific Premium custom
 * emoji as the button's native icon (Bot API 9.4+). `opts.disableCustomIcon`
 * disables the generic Custom Icon Tombol lookup for dynamic labels whose
 * own visual meaning must remain stable (for example product/warranty
 * picker buttons).
 */
const button = {
  primary(label, callbackData, opts) {
    return applyStyle({ text: label, callback_data: validateCallbackData(callbackData, label) }, 'primary', opts);
  },
  success(label, callbackData, opts) {
    return applyStyle({ text: label, callback_data: validateCallbackData(callbackData, label) }, 'success', opts);
  },
  danger(label, callbackData, opts) {
    return applyStyle({ text: label, callback_data: validateCallbackData(callbackData, label) }, 'danger', opts);
  },
  secondary(label, callbackData, opts) {
    return applyStyle({ text: label, callback_data: validateCallbackData(callbackData, label) }, 'primary', opts);
  },
  neutral(label, callbackData, opts) {
    return applyStyle({ text: label, callback_data: validateCallbackData(callbackData, label) }, 'primary', opts);
  },

  // URL buttons use the same icon/style pipeline as callback buttons. This
  // is important for Join Gate buttons: they used to be raw Telegram
  // objects, so they never entered Custom Icon Tombol and could not be
  // customized.
  primaryUrl(label, url, opts) {
    return applyStyle({ text: label, url }, 'primary', opts);
  },
  successUrl(label, url, opts) {
    return applyStyle({ text: label, url }, 'success', opts);
  },
  dangerUrl(label, url, opts) {
    return applyStyle({ text: label, url }, 'danger', opts);
  },
};

/**
 * Reply keyboard buttons: { text, style? }
 * Used inside Markup.keyboard([[ ... ]]).
 */
const replyButton = {
  contactRequest(label, opts) {
    return applyStyle({ text: label, request_contact: true }, 'success', opts);
  },
  text(label, opts) {
    return applyStyle({ text: label }, 'danger', opts);
  },
  primary(label, opts) {
    return applyStyle({ text: label }, 'primary', opts);
  },
  success(label, opts) {
    return applyStyle({ text: label }, 'success', opts);
  },
  danger(label, opts) {
    return applyStyle({ text: label }, 'danger', opts);
  },
  secondary(label, opts) {
    return applyStyle({ text: label }, 'primary', opts);
  },
  neutral(label, opts) {
    return applyStyle({ text: label }, 'primary', opts);
  },
};

module.exports = { button, replyButton, STYLES, validateCallbackData };
