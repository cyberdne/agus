'use strict';

/**
 * Context-aware inbound interaction limiter.
 *
 * This module is intentionally independent from Telegram/DB modules so the
 * limiter's state machine can be tested without a live bot or database.
 */

const PROFILES = Object.freeze({
  navigation: Object.freeze({ windowMs: 2_000, max: 8, duplicateWindowMs: 800 }),
  general: Object.freeze({ windowMs: 10_000, max: 20, duplicateWindowMs: 0 }),
  heavy: Object.freeze({ windowMs: 5_000, max: 6, duplicateWindowMs: 0 }),
  userbot: Object.freeze({ windowMs: 5_000, max: 6, duplicateWindowMs: 700 }),
  authentication: Object.freeze({ windowMs: 10_000, max: 10, duplicateWindowMs: 0 }),
  transaction: Object.freeze({ windowMs: 10_000, max: 8, duplicateWindowMs: 500 }),
  admin: Object.freeze({ windowMs: 5_000, max: 12, duplicateWindowMs: 600 }),
});

const ACTION_PATTERNS = [
  { bucket: 'authentication', re: /^(?:claim|token|otp|password|auth|login)/i },
  { bucket: 'transaction', re: /^(?:store:(?:qty|pay|paid|resume|status|cancel)|subscription:renew|adminorder:)/i },
  { bucket: 'heavy', re: /^(?:adminbroadcast:|broadcast:|panel:asset:|panelgrp:|adminpanelubot:)/i },
  { bucket: 'userbot', re: /^(?:panel:|panel_ubot:)/i },
  { bucket: 'admin', re: /^(?:admin:|adminuser:|adminproduct:|adminpayment:|adminpool:|admintrx:|adminbroadcast:|adminreminder:|notification:|button_icons:|custom_submenu:|start_sticker:|trial_settings:|premium_emoji:|join_gate:|settings_backup:|subext:)/i },
  { bucket: 'navigation', re: /^(?:nav:|menu:|store:home|store:cat:|store:garansi:|store:prod:|store:policy:)/i },
];

const HEAVY_TEXTS = new Set([
  '🚀 Mulai Promosi', '🛑 Stop Promosi', '✅ Aktifkan Auto React', '❌ Nonaktifkan Auto React',
  '🔄 Ganti Reaction',
]);

const USERBOT_NAV_TEXTS = new Set([
  '💬 Base Reply', '📋 Daftar Reply & Settings', '📝 Atur Pesan', '👥 Atur Grup',
  '⏱️ Atur Jeda', '🧰 Fitur Ekstra', '📖 Panduan Pakai', '⏱️ Timer WTB',
  '➕ Tambah Reply', '🗑️ Hapus Reply', '⚙️ Pengaturan Global', '🤖 Auto React',
]);

const NAV_TEXT_HINTS = [
  /^🔙 /u,
  /^🏠 /u,
  /^Kembali$/u,
  /^Batal$/u,
  /^⚙️ Settings$/u,
  /^⚙️ Configuration$/u,
  /^🎨 Custom Submenu$/u,
  /^👥 Users$/u,
  /^🤖 Userbot$/u,
  /^🛒 Commerce$/u,
  /^💳 Order & Payment$/u,
  /^📢 Notifications$/u,
  /^📊 Statistics$/u,
];

function classifyAction(action, isAdmin = false) {
  const value = String(action || '').trim();
  if (!value) return isAdmin ? 'admin' : 'general';

  for (const rule of ACTION_PATTERNS) {
    if (rule.re.test(value)) return rule.bucket;
  }
  if (HEAVY_TEXTS.has(value)) return 'heavy';
  if (USERBOT_NAV_TEXTS.has(value)) return 'navigation';
  if (NAV_TEXT_HINTS.some((re) => re.test(value))) return isAdmin ? 'admin' : 'navigation';
  return isAdmin ? 'admin' : 'general';
}

function getActionIdentity(ctx, isAdmin = false) {
  const callbackData = ctx && ctx.callbackQuery && typeof ctx.callbackQuery.data === 'string'
    ? ctx.callbackQuery.data.trim()
    : '';
  if (callbackData) return { action: callbackData, bucket: classifyAction(callbackData, isAdmin), kind: 'callback' };

  const text = ctx && ctx.message && typeof ctx.message.text === 'string'
    ? ctx.message.text.trim()
    : '';
  return { action: text, bucket: classifyAction(text, isAdmin), kind: 'message' };
}

function getProfile(bucket) {
  return PROFILES[bucket] || PROFILES.general;
}

function createRateLimiter({ maxEntries = 10_000, now = () => Date.now() } = {}) {
  const buckets = new Map();
  const seenUpdates = new Map();
  const recentActions = new Map();
  const WARN_COOLDOWN_MS = 30_000;
  const DUPLICATE_UPDATE_TTL_MS = 60_000;
  const STRIKE_DECAY_MS = 60_000;

  function prune(timestamp) {
    if (seenUpdates.size > maxEntries) {
      for (const [key, seenAt] of seenUpdates) {
        if (timestamp - seenAt > DUPLICATE_UPDATE_TTL_MS) seenUpdates.delete(key);
        if (seenUpdates.size <= maxEntries) break;
      }
    }
    if (recentActions.size > maxEntries) {
      for (const [key, seenAt] of recentActions) {
        if (timestamp - seenAt > 10_000) recentActions.delete(key);
        if (recentActions.size <= maxEntries) break;
      }
    }
    if (buckets.size > maxEntries) {
      for (const [key, entry] of buckets) {
        const last = entry.timestamps[entry.timestamps.length - 1] || entry.lastSeenAt || 0;
        if (timestamp - last > Math.max(60_000, entry.profile.windowMs * 6)) buckets.delete(key);
        if (buckets.size <= maxEntries) break;
      }
    }
  }

  function consume({ userId, chatId, action, bucket, updateId }) {
    const timestamp = now();
    const profile = getProfile(bucket);
    const identity = `${String(userId)}:${String(chatId ?? 'private')}`;
    prune(timestamp);

    if (updateId != null) {
      const updateKey = `${identity}:${String(updateId)}`;
      const seenAt = seenUpdates.get(updateKey);
      if (seenAt != null && timestamp - seenAt <= DUPLICATE_UPDATE_TTL_MS) {
        return { allowed: false, duplicateUpdate: true, level: 0, retryAfterMs: 0, profile };
      }
      seenUpdates.set(updateKey, timestamp);
    }

    const bucketKey = `${identity}:${bucket}`;
    let entry = buckets.get(bucketKey);
    if (!entry) {
      entry = { profile, timestamps: [], strikes: 0, blockedUntil: 0, lastWarnedAt: 0, lastSeenAt: timestamp };
      buckets.set(bucketKey, entry);
    }

    if (timestamp - entry.lastSeenAt > STRIKE_DECAY_MS) entry.strikes = 0;
    entry.lastSeenAt = timestamp;

    if (entry.blockedUntil > timestamp) {
      return {
        allowed: false,
        rateLimited: true,
        level: Math.min(entry.strikes || 1, 3),
        retryAfterMs: entry.blockedUntil - timestamp,
        profile,
        shouldWarn: timestamp - entry.lastWarnedAt >= WARN_COOLDOWN_MS,
      };
    }

    const actionKey = `${identity}:${bucket}:${String(action || '')}`;
    if (profile.duplicateWindowMs > 0) {
      const lastActionAt = recentActions.get(actionKey);
      if (lastActionAt != null && timestamp - lastActionAt <= profile.duplicateWindowMs) {
        recentActions.set(actionKey, timestamp);
        return { allowed: false, duplicateAction: true, level: 0, retryAfterMs: profile.duplicateWindowMs - (timestamp - lastActionAt), profile };
      }
      recentActions.set(actionKey, timestamp);
    }

    entry.timestamps = entry.timestamps.filter((t) => timestamp - t < profile.windowMs);
    entry.timestamps.push(timestamp);

    if (entry.timestamps.length > profile.max) {
      entry.strikes = Math.min(entry.strikes + 1, 3);
      const blockMs = entry.strikes === 1 ? 2_000 : entry.strikes === 2 ? 10_000 : 30_000;
      entry.blockedUntil = timestamp + blockMs;
      const shouldWarn = timestamp - entry.lastWarnedAt >= WARN_COOLDOWN_MS;
      if (shouldWarn) entry.lastWarnedAt = timestamp;
      return { allowed: false, rateLimited: true, level: entry.strikes, retryAfterMs: blockMs, profile, shouldWarn };
    }

    return { allowed: true, rateLimited: false, duplicateUpdate: false, duplicateAction: false, level: 0, retryAfterMs: 0, profile };
  }

  function reset() {
    buckets.clear();
    seenUpdates.clear();
    recentActions.clear();
  }

  return { consume, reset, get sizes() { return { buckets: buckets.size, seenUpdates: seenUpdates.size, recentActions: recentActions.size }; } };
}

module.exports = { PROFILES, classifyAction, getActionIdentity, createRateLimiter };
