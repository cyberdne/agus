'use strict';

const crypto = require('crypto');

/**
 * Deterministic, compact callback token for callback_data values whose
 * canonical identifier may be longer than Telegram's 64-byte limit.
 *
 * The token is intentionally content-derived rather than positional, so it
 * remains stable across restarts and registry growth. The canonical source of
 * truth stays the original identifier in source/registry; callers resolve the
 * token back to that identifier before touching business logic.
 */
function contentToken(value) {
  return crypto.createHash('sha1').update(String(value || '')).digest('hex').slice(0, 10);
}

module.exports = { contentToken };
