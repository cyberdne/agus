const LEVELS = Object.freeze({ debug: 10, info: 20, warn: 30, error: 40 });

function timestamp() {
  return new Date().toISOString();
}

function currentLevel() {
  const raw = String(process.env.LOG_LEVEL || 'info').trim().toLowerCase();
  return Object.prototype.hasOwnProperty.call(LEVELS, raw) ? raw : 'info';
}

function shouldLog(level) {
  return LEVELS[level] >= LEVELS[currentLevel()];
}

function redactString(value) {
  let text = String(value);
  // Remove common credential/key assignments without altering ordinary numeric IDs.
  text = text.replace(/(bot[_ -]?token|api[_ -]?hash|api[_ -]?key|password|otp|one[_ -]?time[_ -]?code|session[_ -]?string|access[_ -]?token|secret|credential)\s*[:=]\s*([^\s,;]+)/gi, '$1=[REDACTED]');
  // Do not print common Telegram bot-token-shaped secrets if an exception/log includes one verbatim.
  text = text.replace(/\b\d{6,12}:[A-Za-z0-9_-]{20,}\b/g, '[REDACTED_TELEGRAM_TOKEN]');
  return text;
}

function sanitize(value, seen = new WeakSet()) {
  if (typeof value === 'string') return redactString(value);
  if (value == null || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'bigint') return value;
  if (value instanceof Error) {
    return {
      name: redactString(value.name || 'Error'),
      message: redactString(value.message || String(value)),
      ...(value.stack ? { stack: redactString(value.stack) } : {}),
    };
  }
  if (typeof value !== 'object') return redactString(value);
  if (seen.has(value)) return '[Circular]';
  seen.add(value);
  if (Array.isArray(value)) return value.map((item) => sanitize(item, seen));
  const out = {};
  for (const [key, item] of Object.entries(value)) {
    if (/^(bot_?token|api_?hash|api_?key|password|otp|one_?time_?code|session|session_?string|access_?token|secret|credential)$/i.test(key)) {
      out[key] = '[REDACTED]';
    } else {
      out[key] = sanitize(item, seen);
    }
  }
  return out;
}

function write(level, method, args) {
  if (!shouldLog(level)) return;
  const prefix = `[${level.toUpperCase()}] ${timestamp()} -`;
  const safeArgs = args.map((arg) => {
    const safe = sanitize(arg);
    if (safe && typeof safe === 'object') {
      try { return JSON.stringify(safe); } catch (_) { return '[Unserializable]'; }
    }
    return safe;
  });
  console[method](prefix, ...safeArgs);
}

const logger = {
  debug(...args) { write('debug', 'log', args); },
  info(...args) { write('info', 'log', args); },
  warn(...args) { write('warn', 'warn', args); },
  error(...args) { write('error', 'error', args); },
  getLevel() { return currentLevel(); },
};

module.exports = logger;
