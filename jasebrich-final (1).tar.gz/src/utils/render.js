const logger = require('./logger');
const screenState = require('../state/screenState');

const NOT_MODIFIED_RE = /message is not modified/i;
const EDIT_FALLBACK_RE = /message (?:can't|cannot) be edited|message to edit not found|message is too old|MESSAGE_ID_INVALID|there is no text in the message to edit|there is no caption in the message to edit/i;

// Telegram callback messages are not necessarily text messages. A callback can
// originate from a photo/video/document/animation/etc. with a caption. Editing
// such a message with editMessageText produces "there is no text in the
// message to edit". The renderer must choose the Telegram edit primitive from
// the actual message type instead of assuming every callback owns text.
const CAPTION_MEDIA_FIELDS = Object.freeze([
  'photo',
  'video',
  'document',
  'animation',
  'audio',
  'voice',
]);

function getCallbackMessage(ctx) {
  return ctx && ctx.callbackQuery && ctx.callbackQuery.message
    ? ctx.callbackQuery.message
    : null;
}

function isCaptionMediaMessage(message) {
  return Boolean(message) && CAPTION_MEDIA_FIELDS.some((field) => {
    const value = message[field];
    return Array.isArray(value) ? value.length > 0 : Boolean(value);
  });
}

function isTextMessage(message) {
  return Boolean(message) && typeof message.text === 'string';
}

function hasReplyKeyboard(options = {}) {
  return Boolean(options && options.reply_markup && options.reply_markup.keyboard);
}

function getEditMode(message) {
  if (isTextMessage(message)) return 'text';
  if (isCaptionMediaMessage(message)) return 'caption';
  return null;
}

/**
 * Rendering contract used by the bot:
 *
 * 1. Reply-keyboard update -> ALWAYS send a new message.
 * 2. Normal command/text   -> ALWAYS send a new message.
 * 3. Inline callback       -> edit the callback-owning message using the
 *    Telegram API primitive matching its actual message type.
 *
 * A callback message that is neither editable text nor supported caption media
 * is not force-edited. It falls back to a fresh message only for Telegram
 * errors that explicitly mean the target cannot be edited.
 */
async function renderScreen(ctx, text, options = {}, explicitFeature) {
  const chatId = ctx.chat && ctx.chat.id;
  const isCallback = Boolean(ctx.callbackQuery) && !ctx.__adminReply;
  const feature = explicitFeature !== undefined ? explicitFeature : inferFeature(ctx);

  if (!isCallback || hasReplyKeyboard(options)) {
    const sent = await ctx.reply(text, options);
    if (chatId && sent && sent.message_id) {
      screenState.set(chatId, sent.message_id, feature);
    }
    return sent;
  }

  const sourceMessage = getCallbackMessage(ctx);
  const editMode = getEditMode(sourceMessage);

  // Service/unsupported messages do not expose editable text/caption. Do not
  // call editMessageText blindly; a new screen is the only safe rendering
  // operation in this case.
  if (!editMode) {
    const sent = await ctx.reply(text, options);
    if (chatId && sent && sent.message_id) screenState.set(chatId, sent.message_id, feature);
    return sent;
  }

  try {
    if (editMode === 'caption') {
      await ctx.editMessageCaption(text, options);
    } else {
      await ctx.editMessageText(text, options);
    }

    if (chatId && sourceMessage && sourceMessage.message_id) {
      screenState.set(chatId, sourceMessage.message_id, feature);
    }
    return;
  } catch (err) {
    const desc = String((err && err.description) || (err && err.message) || '');
    if (NOT_MODIFIED_RE.test(desc)) return;

    // Only target-editability failures are recoverable by rendering a new
    // screen. Entity/Markdown/database/programming errors must propagate so
    // the normal error handler can report/log the real root cause.
    if (EDIT_FALLBACK_RE.test(String(desc))) {
      logger.warn(`Callback message tidak dapat diedit (${editMode}); fallback ke message baru: ${desc}`);
      const sent = await ctx.reply(text, options);
      if (chatId && sent && sent.message_id) screenState.set(chatId, sent.message_id, feature);
      return sent;
    }

    logger.error(`Inline callback message edit failed (${editMode}): ${desc}`);
    throw err;
  }
}

function inferFeature(ctx) {
  if (ctx.callbackQuery && ctx.callbackQuery.data) return ctx.callbackQuery.data;
  if (ctx.message && typeof ctx.message.text === 'string') return ctx.message.text;
  return null;
}

/**
 * Renders a reply-keyboard screen. For a repeated entry into the SAME
 * feature, reuse the tracked bot screen when Telegram allows editing it;
 * this prevents one user action from accumulating duplicate submenu
 * messages. The reply keyboard itself is intentionally not passed to
 * editMessageText because Telegram's edit API accepts InlineKeyboardMarkup,
 * not ReplyKeyboardMarkup. The already-active reply keyboard remains the
 * user's navigation surface until another message replaces it.
 *
 * The optional featureName is deliberately separate from message_effect_id
 * so existing callers remain backward compatible.
 */
async function renderWithReplyKeyboard(ctx, text, options = {}, effectId = null, featureName = null) {
  const chatId = ctx.chat && ctx.chat.id;
  const finalOptions = { ...options };
  if (effectId && ctx.chat && ctx.chat.type === 'private') {
    finalOptions.message_effect_id = effectId;
  }

  if (featureName && chatId && !ctx.callbackQuery) {
    const tracked = screenState.get(chatId);
    if (tracked && tracked.feature === featureName && tracked.messageId) {
      const editOptions = { ...finalOptions };
      delete editOptions.reply_markup;
      try {
        await ctx.telegram.editMessageText(chatId, tracked.messageId, undefined, text, editOptions);
        return { message_id: tracked.messageId, reused: true };
      } catch (err) {
        const desc = String((err && err.description) || (err && err.message) || '');
        // Telegram's MESSAGE_NOT_MODIFIED is a successful no-op for a
        // refresh: the authoritative state was read, but the rendered text
        // and existing reply keyboard are already identical. Never create a
        // replacement message for this condition.
        if (NOT_MODIFIED_RE.test(desc)) return { message_id: tracked.messageId, reused: true, notModified: true };
        if (!EDIT_FALLBACK_RE.test(desc)) {
          logger.error(`Reply-keyboard screen edit failed (${featureName}): ${desc}`);
          throw err;
        }
        logger.warn(`Reply-keyboard screen ${featureName} tidak dapat diedit; membuat screen baru: ${desc}`);
      }
    }
  }

  const sent = await ctx.reply(text, finalOptions);
  if (chatId && sent && sent.message_id) {
    screenState.set(chatId, sent.message_id, featureName);
  }
  return sent;
}

module.exports = {
  renderScreen,
  renderWithReplyKeyboard,
  isCaptionMediaMessage,
  isTextMessage,
  getEditMode,
};
