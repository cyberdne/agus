/**
 * Double-tap guard for step-navigation buttons (Kembali / Lewati).
 *
 * Kembali is NOT idempotent (each tap moves one step back), so the same
 * physical tap delivered twice — a double tap, or a Telegram retry — must not
 * skip a step. An identical nav label from the same user inside the window is
 * treated as a duplicate. Memory is bounded (stale entries are pruned).
 */
const WINDOW_MS = 700;
const MAX_ENTRIES = 5000;
const last = new Map();

function isDuplicateNav(userId, label, now = Date.now()) {
  const prev = last.get(userId);
  last.set(userId, { label, at: now });
  if (last.size > MAX_ENTRIES) {
    for (const [k, v] of last) if (now - v.at > 60_000) last.delete(k);
  }
  return Boolean(prev && prev.label === label && now - prev.at < WINDOW_MS);
}

function reset() { last.clear(); }

module.exports = { isDuplicateNav, reset, WINDOW_MS };
