const { Markup } = require('telegraf');
const { replyButton, button } = require('../utils/buttons');
const { MENU, PANEL_FEATURE, CALLBACK } = require('../constants/menu');

// `active` reflects the userbot's real promotion-runtime status (see
// userbotRuntime.isAutoPromosiActive) — never a locally-remembered click.
// Exactly one of the two labels is shown at a time, and both route to the
// SAME handler (see PANEL_FEATURE.START/STOP wiring in index.js); the
// handler itself re-checks the real runtime status before acting, so the
// action taken never depends on which label happened to be tapped.
function panelMainKeyboard(active = false) {
  // CANONICAL layout for every controlled userbot, regardless of asset kind.
  // Product/plan differences are enforced by Feature Access at the handler
  // boundary, not by changing keyboard structure or button positions.
  return Markup.keyboard([
    [active ? replyButton.danger(PANEL_FEATURE.STOP) : replyButton.success(PANEL_FEATURE.START)],
    [replyButton.primary(PANEL_FEATURE.BASE_REPLY), replyButton.primary(PANEL_FEATURE.STORE), replyButton.primary(PANEL_FEATURE.EXTRA)],
    [replyButton.primary(PANEL_FEATURE.MESSAGE), replyButton.primary(PANEL_FEATURE.GROUP), replyButton.primary(PANEL_FEATURE.DELAY)],
    [replyButton.success(PANEL_FEATURE.GUIDE)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

function baseReplyKeyboard() {
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.REPLY_TOGGLE)],
    [replyButton.success(PANEL_FEATURE.ADD_REPLY), replyButton.danger(PANEL_FEATURE.DELETE_REPLY)],
    [replyButton.primary(PANEL_FEATURE.GLOBAL_SETTINGS), replyButton.primary(PANEL_FEATURE.WTB_TIMER)],
    [replyButton.success(PANEL_FEATURE.REPLY_LIST)],
    [replyButton.primary(PANEL_FEATURE.AUTO_REACT), replyButton.danger(PANEL_FEATURE.CHANNEL_DISABLE)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

// Shown instead of the screen's normal keyboard whenever the panel is
// waiting for free-text input (Tambah Reply, Atur Jeda, dsb). Gives the
// user a single tap to bail out instead of having to type "Kembali"/
// "Batal" by hand. The label goes through replyButton.danger(), so it
// is registered in Admin Panel -> Settings -> Custom Icon Tombol like
// every other button and its emoji can be swapped there.
function panelCancelKeyboard(label = MENU.BATAL) {
  return Markup.keyboard([[replyButton.danger(label)]]).resize();
}

// Keyboard of a panel input step: Kembali (previous step / the screen the
// wizard was opened from, state kept where still valid) + Batal (abort the
// whole wizard). Not one-time, so the exit path survives every retry.
function panelInputKeyboard() {
  return Markup.keyboard([[replyButton.primary(MENU.KEMBALI), replyButton.danger(MENU.BATAL)]]).resize();
}

// `active` reflects the persisted panel_settings.auto_react value (the
// real source of truth — see panelConfig.getSettings), never a
// locally-remembered click. Exactly one of the two labels is shown at a
// time, and both route to their own dedicated handler (see
// PANEL_FEATURE.AUTO_REACT_ENABLE/DISABLE wiring in index.js), each of
// which re-persists + re-renders based on the actual saved state, so the
// menu can never show "Nonaktifkan" while the stored config is off (or
// vice versa).
function autoReactKeyboard(active) {
  return Markup.keyboard([
    [active ? replyButton.danger(PANEL_FEATURE.AUTO_REACT_DISABLE) : replyButton.success(PANEL_FEATURE.AUTO_REACT_ENABLE)],
    [replyButton.primary(PANEL_FEATURE.AUTO_REACT_CHANGE)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

// Submenu Watermark (Fitur Ekstra). The toggle label mirrors the persisted
// watermark_enabled flag, same pattern as autoReactKeyboard: exactly one of
// Aktifkan / Nonaktifkan is shown and each re-checks the saved state.
function watermarkKeyboard(active) {
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.WATERMARK_SET)],
    [active ? replyButton.danger(PANEL_FEATURE.WATERMARK_DISABLE) : replyButton.success(PANEL_FEATURE.WATERMARK_ENABLE)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

// Submenu Timer (Fitur Ekstra): same toggle pattern as watermarkKeyboard.
function timerKeyboard(active) {
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.TIMER_SET)],
    [active ? replyButton.danger(PANEL_FEATURE.TIMER_DISABLE) : replyButton.success(PANEL_FEATURE.TIMER_ENABLE)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

// Submenu Backup Token (Fitur Ekstra): status + generate with an explicit
// confirm step. Token itself is never shown here (stored as hash only).
function backupTokenKeyboard() {
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.BACKUP_TOKEN_NEW)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

function backupTokenConfirmKeyboard() {
  return Markup.keyboard([
    [replyButton.danger(PANEL_FEATURE.BACKUP_TOKEN_CONFIRM)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

function globalSettingsKeyboard() {
  return Markup.keyboard([
    [replyButton.primary('✏️ Ganti Teks / Media'), replyButton.primary('🎯 Ganti Target Channel')],
    [replyButton.primary('🚫 Ganti Banned Words'), replyButton.primary('🔢 Maks 70 Karakter')],
    [replyButton.primary('🔗 Filter Tanpa Link'), replyButton.primary('👤 Filter Tanpa Username')],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

function messageKeyboard() {
  // Compact mobile layout: two action buttons per row, with Back centered
  // on its own row. This changes presentation only; every label and its
  // existing reply-keyboard route remains untouched.
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.MESSAGE_TEXT_MEDIA), replyButton.primary(PANEL_FEATURE.MESSAGE_FORWARD)],
    [replyButton.success(PANEL_FEATURE.MESSAGE_VIEW), replyButton.danger(PANEL_FEATURE.MESSAGE_DELETE)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

function groupKeyboard() {
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.TOPIC_GROUP)],
    [replyButton.success(PANEL_FEATURE.ADD_GROUP), replyButton.danger(PANEL_FEATURE.DELETE_GROUP)],
    [replyButton.primary(PANEL_FEATURE.GROUP_LIST)],
    [replyButton.primary(PANEL_FEATURE.JOIN_GROUP), replyButton.danger(PANEL_FEATURE.LEAVE_GROUP)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

// "❌ Hapus Grup" list: one button per currently-saved target group, plus
// "Hapus Semua". Callback data carries the real panel_groups.id (see
// CALLBACK.PANEL_GROUP_DEL) — never the label text or the row's position —
// so selection is unambiguous even if two groups share a display title.
function groupListPaginationKeyboard(userbotId, page, totalPages) {
  const safePage = Math.max(0, Number(page) || 0);
  const safeTotal = Math.max(1, Number(totalPages) || 1);
  const rows = [];
  const nav = [];
  // `iconKey` is a stable semantic identity for Custom Icon Tombol. The
  // visible label intentionally keeps the established arrow glyphs for the
  // default UI, but changing/adding those glyphs must never orphan the
  // configured Premium custom emoji. Legacy configurations saved against the
  // full rendered label are still resolved by buttonIconConfig's compatible
  // candidate lookup.
  if (safePage > 0) nav.push(button.primary('◀️ Sebelumnya', CALLBACK.PANEL_GROUP_LIST_PAGE(userbotId, safePage - 1), { iconKey: 'Sebelumnya' }));
  if (safePage < safeTotal - 1) nav.push(button.primary('Berikutnya ▶️', CALLBACK.PANEL_GROUP_LIST_PAGE(userbotId, safePage + 1), { iconKey: 'Berikutnya' }));
  if (nav.length) rows.push(nav);
  rows.push([button.primary('🔄 Refresh', CALLBACK.PANEL_GROUP_LIST_REFRESH(userbotId, safePage), { iconKey: 'Refresh' })]);
  rows.push([button.danger('↩️ Kembali', CALLBACK.PANEL_GROUP_LIST_BACK, { iconKey: 'Kembali' })]);
  return Markup.inlineKeyboard(rows);
}

function groupDeleteListKeyboard(rows, page = 0, totalPages = 1, userbotId = null) {
  const rowsOut = rows.map((g) => [button.danger(`${g.title || g.target}`, CALLBACK.PANEL_GROUP_DEL(g.id, page), { customizable: false })]);
  const nav = [];
  if (Number(page) > 0 && userbotId != null) nav.push(button.primary('◀️ Sebelumnya', CALLBACK.PANEL_GROUP_DEL_PAGE(userbotId, Number(page) - 1), { iconKey: 'Sebelumnya' }));
  if (Number(page) < Number(totalPages) - 1 && userbotId != null) nav.push(button.primary('Berikutnya ▶️', CALLBACK.PANEL_GROUP_DEL_PAGE(userbotId, Number(page) + 1), { iconKey: 'Berikutnya' }));
  if (nav.length) rowsOut.push(nav);
  rowsOut.push([button.danger('🗑️ Hapus Semua', CALLBACK.PANEL_GROUP_DELALL)]);
  rowsOut.push([button.primary(MENU.KEMBALI, CALLBACK.PANEL_GROUP_DELCANCEL)]);
  return Markup.inlineKeyboard(rowsOut);
}

function groupLeavePaginationKeyboard(rows, page, totalPages, userbotId) {
  const rowsOut = rows.map((g) => [button.danger(`${g.title || g.target}${g.reason ? ` — ${g.reason}` : ''}`, CALLBACK.PANEL_GROUP_LEAVE(userbotId, g.id), { customizable: false })]);
  const nav = [];
  if (page > 0) nav.push(button.primary('◀️ Sebelumnya', CALLBACK.PANEL_GROUP_LEAVE_PAGE(userbotId, page - 1), { iconKey: 'Sebelumnya' }));
  if (page < totalPages - 1) nav.push(button.primary('Berikutnya ▶️', CALLBACK.PANEL_GROUP_LEAVE_PAGE(userbotId, page + 1), { iconKey: 'Berikutnya' }));
  if (nav.length) rowsOut.push(nav);
  rowsOut.push([button.primary('🔄 Refresh', CALLBACK.PANEL_GROUP_LEAVE_REFRESH(userbotId, page), { iconKey: 'Refresh' })]);
  rowsOut.push([button.primary(MENU.KEMBALI, CALLBACK.PANEL_GROUP_LEAVE_BACK, { iconKey: 'Kembali' })]);
  return Markup.inlineKeyboard(rowsOut);
}
function groupDeleteConfirmKeyboard(id, page = 0) {
  return Markup.inlineKeyboard([
    [button.danger('✅ Ya, Hapus', CALLBACK.PANEL_GROUP_DELCONFIRM(id, page))],
    [button.primary('❌ Batal', CALLBACK.PANEL_GROUP_DELCANCEL)],
  ]);
}
function groupDeleteAllConfirmKeyboard() {
  return Markup.inlineKeyboard([
    [button.danger('✅ Ya, Hapus Semua', CALLBACK.PANEL_GROUP_DELALLCONFIRM)],
    [button.primary('❌ Batal', CALLBACK.PANEL_GROUP_DELCANCEL)],
  ]);
}

function delayKeyboard() {
  return Markup.keyboard([
    [replyButton.primary(PANEL_FEATURE.GROUP_DELAY)],
    [replyButton.primary(PANEL_FEATURE.ROUND_DELAY)],
    [replyButton.primary(PANEL_FEATURE.SMART_DELAY)],
    [replyButton.danger(MENU.KEMBALI, { customizable: false })],
  ]).resize();
}

function extraKeyboard(isAdmin = false) {
  const rows = [
    [replyButton.primary(PANEL_FEATURE.BROADCAST_PM), replyButton.primary(PANEL_FEATURE.PM_PERMIT)],
    [replyButton.primary(PANEL_FEATURE.TIMER), replyButton.primary(PANEL_FEATURE.BACKUP_TOKEN)],
    [replyButton.primary(PANEL_FEATURE.CUSTOM_WM), replyButton.primary(PANEL_FEATURE.CHECK_TOKEN)],
    [replyButton.success(PANEL_FEATURE.TRANSFER_UBOT), replyButton.danger(PANEL_FEATURE.RESET_DATA)],
  ];
  if (isAdmin) rows.splice(1, 0, [replyButton.primary(PANEL_FEATURE.ADMIN_PANEL)]);
  rows.push([replyButton.danger(MENU.KEMBALI, { customizable: false })]);
  return Markup.keyboard(rows).resize();
}

function assetButtonLabel(kind, row) {
  const packageName = row && (row.package_name || row.label);
  const fallback = kind === 'owned' ? 'Userbot' : 'Jaseb';
  const id = row && row.id != null ? row.id : '-';
  return `${packageName || fallback} #${id}`;
}

function panelSelectAssetKeyboard(assets) {
  const rows = [];
  // Dynamic per-userbot rows (a.label/#a.id) — never customizable, each
  // one would otherwise become its own permanent entry in the picker.
  for (const a of assets.owned) rows.push([replyButton.primary(assetButtonLabel('owned', a), { customizable: false })]);
  for (const a of (assets.leased || [])) rows.push([replyButton.primary(assetButtonLabel('pool', a), { customizable: false })]);
  rows.push([replyButton.danger(MENU.KEMBALI, { customizable: false })]);
  return Markup.keyboard(rows).resize();
}

// Must be a FUNCTION (not built once at require time) — see the
// matching note on buildCategoryPurchaseKeyboard() in main.keyboard.js
// for why: "🛒 Beli Userbot / Jaseb" below is a customizable button,
// and a static object would freeze whatever icon existed at startup
// forever, ignoring any later Custom Icon Tombol change.
function panelNoAssetKeyboard() {
  return Markup.inlineKeyboard([
    [button.success('🛒 Beli Userbot / Jaseb', CALLBACK.STORE_HOME)],
  ]);
}

function panelModeInlineKeyboard(kind, id) {
  return Markup.inlineKeyboard([
    [button.primary('🔀 Berurutan (Sequential)', CALLBACK.PANEL_MODE(kind, id, 'sequential'))],
    [button.primary('🎲 Acak (Random)', CALLBACK.PANEL_MODE(kind, id, 'random'))],
  ]);
}

module.exports = {
  panelMainKeyboard,
  panelCancelKeyboard,
  panelInputKeyboard,
  baseReplyKeyboard,
  messageKeyboard,
  groupKeyboard,
  groupDeleteListKeyboard,
  groupLeavePaginationKeyboard,
  groupDeleteConfirmKeyboard,
  groupDeleteAllConfirmKeyboard,
  groupListPaginationKeyboard,
  delayKeyboard,
  globalSettingsKeyboard,
  autoReactKeyboard,
  watermarkKeyboard,
  timerKeyboard,
  backupTokenKeyboard,
  backupTokenConfirmKeyboard,
  extraKeyboard,
  panelSelectAssetKeyboard,
  panelNoAssetKeyboard,
  panelModeInlineKeyboard,
  assetButtonLabel,
};
