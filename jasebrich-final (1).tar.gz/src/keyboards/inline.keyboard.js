const { Markup } = require('telegraf');
const { button } = require('../utils/buttons');
const { CALLBACK } = require('../constants/menu');
const { CATEGORIES, formatRupiah } = require('../services/product.service');
const premiumEmojiConfig = require('../services/premiumEmojiConfig.service');

// Kept only for compatibility with older imports. The current purchase flow
// shows the canonical policy exactly once immediately before payment.
function storeCategoryPolicyKeyboard(category) {
  return Markup.inlineKeyboard([
    [button.success('⭐ Lanjut', CALLBACK.STORE_CATEGORY(category))],
    [button.danger('🔙 Kembali', CALLBACK.STORE_HOME, { customizable: false })],
  ]);
}

// Product list, shown 2-per-row and colored by garansi status (blue =
// non-garansi, green = bergaransi) — matches the "Pilih Paket" grid.
// Price isn't repeated on the button; it's already listed in the text
// above (name — price/bln), same as the reference layout.
function storeCategoryEntryCallback(category, origin = 'store') {
  if (category === CATEGORIES.USERBOT || category === CATEGORIES.JASEB) return CALLBACK.STORE_CATEGORY(category, origin);
  return CALLBACK.STORE_CATEGORY(category, origin);
}

function storeProductListKeyboard(category, products, mode, origin = 'store') {
  const rows = [];
  const buttons = products.map((p) => {
    // Warranty is already shown in the product list/detail text. Do not use
    // the warranty emoji as a button prefix: admins may configure it as `✅`,
    // which is universally read as a selected checkbox. Package buttons are
    // selection controls, so their labels must not visually imply selection.
    // Custom emoji remains supported in the surrounding product text and
    // order/policy screens without coupling a warranty badge to selection.
    const label = `${p.name}`;
    const productCategory = (p.category === CATEGORIES.USERBOT || p.category === CATEGORIES.JASEB)
      ? p.category
      : null;
    if (!productCategory) throw new Error(`Produk #${p.id} tidak memiliki kategori pembelian yang valid.`);
    const makeButton = p.garansi ? button.success : button.primary;
    return makeButton(
      label,
      CALLBACK.STORE_PRODUCT(p.id, 1, productCategory, mode, origin),
      { disableCustomIcon: true, customizable: false }
    );
  });

  // Telegram renders button widths client-side; avoid forcing two labels into
  // one row when either label is long. A compact short-name pair (Basic /
  // Special) still stays side-by-side, while long/custom product names become
  // one-per-row instead of relying on device-specific pixel assumptions.
  for (let i = 0; i < buttons.length; i += 2) {
    const first = buttons[i];
    const second = buttons[i + 1];
    const firstLen = Array.from(String(first.text || '')).length;
    const secondLen = second ? Array.from(String(second.text || '')).length : 0;
    if (second && firstLen <= 18 && secondLen <= 18) rows.push([first, second]);
    else {
      rows.push([first]);
      if (second) rows.push([second]);
    }
  }
  const backCallback = origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME;
  rows.push([button.danger('🔙 Kembali', backCallback, { customizable: false })]);
  return Markup.inlineKeyboard(rows);
}

// Product detail / quantity picker (mirrors "Kurang / 1 Bulan / Tambah").
// `mode` ('renewal' or undefined) threads through so "Batal" returns to
// the correct category screen and the pay step tags the order correctly.
function storeProductDetailKeyboard(product, qty, mode, origin = 'store') {
  const backCategory = mode === 'renewal' ? CATEGORIES.RENEWAL : product.category;
  return Markup.inlineKeyboard([
    [
      button.primary('➖ Kurang', CALLBACK.STORE_QTY(product.id, qty, -1, backCategory, mode, origin)),
      button.primary(`${qty} Bulan`, CALLBACK.STORE_QTY(product.id, qty, 0, backCategory, mode, origin)),
      button.success('➕ Tambah', CALLBACK.STORE_QTY(product.id, qty, 1, backCategory, mode, origin)),
    ],
    [button.success('💳 Lanjut Bayar', CALLBACK.STORE_POLICY(product.id, qty, backCategory, mode, origin))],
    [button.danger('🔙 Kembali', storeCategoryEntryCallback(backCategory, origin), { customizable: false })],
  ]);
}

function storePolicyKeyboard(product, qty, mode, origin = 'store') {
  const category = mode === 'renewal' ? CATEGORIES.RENEWAL : product.category;
  const cfg = premiumEmojiConfig.configForGaransi(product.garansi);
  return Markup.inlineKeyboard([
    [button.success(
      cfg.customEmojiId ? 'Saya Setuju & Lanjutkan' : `${cfg.icon} Saya Setuju & Lanjutkan`,
      CALLBACK.STORE_PAY(product.id, qty, category, mode, origin),
      { iconCustomEmojiId: cfg.customEmojiId, customizable: false }
    )],
    [button.danger('🔙 Kembali', CALLBACK.STORE_PRODUCT(product.id, qty, category, mode, origin), { customizable: false })],
  ]);
}

function storePaymentKeyboard(orderId) {
  return Markup.inlineKeyboard([
    [button.success('✅ Saya Sudah Bayar', CALLBACK.STORE_PAID(orderId))],
    [button.danger('❌ Batal', CALLBACK.STORE_CANCEL(orderId), { customizable: false })],
  ]);
}

function storeCancelConfirmationKeyboard(orderId) {
  return Markup.inlineKeyboard([
    [button.danger('⚠️ Ya, Batalkan Order', CALLBACK.STORE_CANCEL_YES(orderId), { customizable: false })],
    [button.primary('Tidak', CALLBACK.STORE_CANCEL_NO(orderId), { customizable: false })],
  ]);
}

function storePendingOrderRecoveryKeyboard(orders) {
  const rows = [];
  let cancellableCount = 0;
  for (const order of Array.isArray(orders) ? orders : []) {
    if (order.status === 'pending') {
      cancellableCount += 1;
      rows.push([
        button.success(`💳 Lanjutkan #${order.id}`, CALLBACK.STORE_RESUME(order.id), { customizable: false }),
        button.danger(`❌ Batal #${order.id}`, CALLBACK.STORE_CANCEL(order.id), { customizable: false }),
      ]);
    } else if (order.status === 'awaiting_confirmation') {
      rows.push([
        button.primary(`⏳ Menunggu Verifikasi #${order.id}`, CALLBACK.STORE_STATUS(order.id), { customizable: false }),
      ]);
    }
  }
  if (cancellableCount > 1) {
    rows.push([button.danger('❌ Batalkan Semua Order', CALLBACK.STORE_CANCEL_ALL, { customizable: false })]);
  }
  return Markup.inlineKeyboard(rows);
}

function storeCancelAllConfirmationKeyboard() {
  return Markup.inlineKeyboard([
    [button.danger('⚠️ Ya, Batalkan Semua', CALLBACK.STORE_CANCEL_ALL_YES, { customizable: false })],
    [button.primary('Tidak', CALLBACK.STORE_CANCEL_ALL_NO, { customizable: false })],
  ]);
}

// Shown on a category detail screen — goes back to the Store screen
// itself (not all the way home), consistent with every other submenu.
//
// IMPORTANT: must be a FUNCTION, not a keyboard object built once at
// module-require time (see main.keyboard.js#buildBackKeyboard for the
// full explanation). A plain `const storeCategoryBackKeyboard =
// Markup.inlineKeyboard(...)` would resolve button.danger(...) exactly
// once at require time and bake whatever Custom Icon Tombol icon
// existed then into every screen that uses it, forever — the "needs a
// restart" bug. Calling this fresh on every render fixes that.
function buildStoreCategoryBackKeyboard(backCallback = CALLBACK.STORE_HOME) {
  const destination = backCallback || CALLBACK.STORE_HOME;
  return Markup.inlineKeyboard([
    [button.danger('🔙 Kembali', destination, { customizable: false })],
  ]);
}

// One button per active userbot the user controls (owned + leased),
// leading to that asset's toggle screen.
function panelAssetListKeyboard(assets) {
  const rows = [];
  // Dynamic per-asset rows (a.label/#a.id) — never customizable.
  for (const a of assets.owned) {
    rows.push([button.primary(`🤖 ${a.label || 'Userbot'} #${a.id}`, CALLBACK.PANEL_ASSET('owned', a.id), { customizable: false })]);
  }
  for (const a of assets.leased) {
    rows.push([button.primary(`🔥 ${a.label || 'Jaseb'} #${a.id}`, CALLBACK.PANEL_ASSET('pool', a.id), { customizable: false })]);
  }
  rows.push([button.danger('🔙 Kembali', CALLBACK.NAV_HOME, { customizable: false })]);
  return Markup.inlineKeyboard(rows);
}

module.exports = {
  storeCategoryPolicyKeyboard,
  storeCategoryEntryCallback,
  storeProductListKeyboard,
  storeProductDetailKeyboard,
  storePolicyKeyboard,
  storePaymentKeyboard,
  storeCancelConfirmationKeyboard,
  storePendingOrderRecoveryKeyboard,
  storeCancelAllConfirmationKeyboard,
  storeCategoryBackKeyboard: buildStoreCategoryBackKeyboard,
  panelAssetListKeyboard,
};
