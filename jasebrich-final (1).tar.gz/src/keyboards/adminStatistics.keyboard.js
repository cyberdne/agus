const { Markup } = require('telegraf');
const { button } = require('../utils/buttons');
const { ADMIN_CALLBACK } = require('../constants/admin.callback');
const { STATISTICS_SECTIONS } = require('../constants/statistics');

function adminStatisticsKeyboard() {
  const rows = [];
  for (let i = 0; i < STATISTICS_SECTIONS.length; i += 2) {
    rows.push(STATISTICS_SECTIONS.slice(i, i + 2).map(([label, section]) =>
      button.primary(label, ADMIN_CALLBACK.STATISTICS_SECTION(section), { customizable: false })
    ));
  }
  rows.push([button.primary('🔄 Muat Ulang', ADMIN_CALLBACK.STATISTICS_REFRESH, { customizable: false })]);
  rows.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.PANEL_HOME, { customizable: false })]);
  return Markup.inlineKeyboard(rows);
}

function adminStatisticsSectionKeyboard(section) {
  return Markup.inlineKeyboard([
    [button.primary('🔄 Refresh', ADMIN_CALLBACK.STATISTICS_SECTION_REFRESH(section), { customizable: false })],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.STATISTICS_HOME, { customizable: false })],
  ]);
}

module.exports = { adminStatisticsKeyboard, adminStatisticsSectionKeyboard, STATISTICS_SECTIONS };
