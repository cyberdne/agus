const { Markup } = require('telegraf');
const { MENU } = require('../constants/menu');
const { replyButton } = require('../utils/buttons');
const { CATEGORY_LABEL } = require('../services/product.service');

// Colors follow function, per project convention (see utils/buttons.js):
// primary = normal navigation, secondary = back/neutral (no color).
//
// mainKeyboard is a function of `isAdmin` so admins automatically get
// an extra "🔧 Admin Panel" button — no need to type /admin manually.
// It's also a function of `hasClaimedTrial` so the "🎁 Claim Trial"
// button disappears for good once a user has claimed their one-time
// free trial (see database/repositories/user.repository.js#hasClaimedTrial).
function mainKeyboard(isAdmin = false, hasClaimedTrial = false, hasUserbot = false) {
  // The caller passes this after checking the current Telegram user.
  hasUserbot = Boolean(hasUserbot);
  const rows = [
    [replyButton.primary(MENU.BUAT_UBOT), replyButton.primary(MENU.STORE)],
    [replyButton.success(MENU.KLAIM_TOKEN)],
    [replyButton.primary(MENU.PANDUAN_BUAT), replyButton.primary(MENU.FITUR_UNGGULAN)],
  ];

  // Kontrol Panel is deliberately hidden unless the current user owns
  // at least one active userbot. The handler also enforces this server-side.
  if (hasUserbot) rows.push([replyButton.primary(MENU.KONTROL_PANEL)]);

  if (!hasClaimedTrial) {
    rows.push([replyButton.success(MENU.CLAIM_TRIAL)]);
  }

  if (isAdmin) {
    rows.push([replyButton.primary(MENU.ADMIN_PANEL)]);
  }

  return Markup.keyboard(rows).resize();
}

// Generic back navigation, not a "fitur" — never customizable.
//
// IMPORTANT: must be a FUNCTION, not a keyboard object built once at
// module-require time — same reasoning as buildCategoryPurchaseKeyboard
// below. A plain `const backKeyboard = Markup.keyboard(...)` resolves
// replyButton.danger(...) exactly once, the moment this file is first
// required, and bakes whatever Custom Icon Tombol icon existed (or
// didn't) at that instant into this object forever. Every screen using
// it would then keep showing that stale icon no matter what an admin
// sets later — the exact "needs a restart" bug this helper exists to
// avoid. Calling this fresh on every render is what makes admin-set
// icons actually take effect immediately, with zero restart.
function buildBackKeyboard() {
  return Markup.keyboard([[replyButton.danger(MENU.KEMBALI, { customizable: false })]]).resize();
}

// Category-purchase reply keyboard — one full-width button per row
// ("Beli Userbot" / "Beli Jaseb" / "Batal"), matching the reference
// bot's layout exactly. Shared by both the Store front screen and the
// "🤖 Buat Userbot" -> "Diperlukan Langganan" prompt, since they're
// both entry points into the same category -> S&K -> catalog flow
// (see handlers/store.handler.js) and must stay visually in sync.
//
// IMPORTANT: this must be a FUNCTION, not a keyboard object built once
// at module-require time. `replyButton.success(...)` below resolves
// any saved Custom Icon Tombol icon (buttonIconConfig.getButtonConfig)
// the instant it runs — if that ran once at startup (as a plain
// `const ... = Markup.keyboard([...])`), the icon lookup would happen
// before an admin ever gets a chance to set one (and, on top of that,
// possibly before the database is even ready), and it would silently
// be baked into this object forever: every screen using it would keep
// showing the OLD icon (or no icon) no matter what the admin sets
// later via Custom Icon Tombol. Calling this fresh on every render
// (see call sites) is what makes admin-set icons actually take effect.
// `hasUserbot`: when the caller already owns an active userbot, the
// "🤖 Beli Userbot" row is replaced with "🔄 Perpanjang Langganan" —
// buying another userbot from scratch doesn't make sense once you own
// one; extending the existing one does. "Beli Jaseb" is untouched:
// Jaseb (leased pool userbot) purchases can stack independently of
// userbot ownership. See handlers/store.handler.js for how the
// renewal flow itself works (same product/qty/pay screens, tagged
// with mode 'renewal').
function buildCategoryPurchaseKeyboard(hasUserbot = false) {
  return Markup.keyboard([
    [replyButton.success(hasUserbot ? MENU.PERPANJANG_LANGGANAN : CATEGORY_LABEL.userbot)],
    [replyButton.success(CATEGORY_LABEL.jaseb)],
    // Generic cancel, not a "fitur" — never customizable.
    [replyButton.danger(MENU.BATAL, { customizable: false })],
  ]).resize();
}

module.exports = {
  mainKeyboard,
  backKeyboard: buildBackKeyboard,
  storeKeyboard: buildCategoryPurchaseKeyboard,
  subscriptionRequiredKeyboard: buildCategoryPurchaseKeyboard,
};
