const { Markup } = require('telegraf');
const { button, replyButton, validateCallbackData } = require('../utils/buttons');
const { ADMIN_CALLBACK } = require('../constants/admin.callback');
const { MENU } = require('../constants/menu');
const featureAccess = require('../services/featureAccess.service');
const { navSpec, CANCEL_LABEL } = require('../constants/adminInputFlows');

// This file mixes fixed top-level menu entries (Admin Panel home,
// Settings home, feature sub-homes) with per-row dynamic listings (a
// user's name/id, a product's name, a stock item's id). Per current
// product decision, EVERY button anywhere in the bot is registered and
// customizable in Admin Panel -> Settings -> Custom Icon Tombol — no
// exceptions, dynamic labels included — so `button`/`replyButton` here
// are just the plain helpers from utils/buttons.js. `staticButton` /
// `staticReplyButton` are kept as aliases only so the call sites below
// don't need renaming.
const staticButton = button;
const staticReplyButton = replyButton;

/**
 * Admin keyboard policy
 * ---------------------
 * Reply keyboard  : menu/navigation/actions. A tap sends a new message.
 * Inline keyboard : selections/confirmations only. A tap edits the current
 *                    bot message whenever Telegram allows it.
 *
 * Telegram supports primary/success/danger styles on reply keyboard buttons
 * as well as inline buttons. See https://core.telegram.org/bots/api.
 */

const adminPanelKeyboard = () => Markup.keyboard([
  [staticReplyButton.primary('👥 Users'), staticReplyButton.primary('🤖 Userbot')],
  [staticReplyButton.primary('🛒 Commerce'), staticReplyButton.primary('💳 Order & Payment')],
  [staticReplyButton.primary('📢 Notifications'), staticReplyButton.primary('📊 Statistics')],
  [staticReplyButton.primary('⚙️ Settings')],
  [staticReplyButton.primary('🏠 Menu Utama')],
]).resize();

const PAGE_SIZE = 10;

// ---------- User Management ----------

function userListKeyboard(users, page, totalCount, searchQuery = null) {
  // User records are selections -> inline.
  const rows = users.map((u) => [
    button.primary(
      `${u.is_banned ? '🚫 ' : ''}${u.first_name || u.username || u.telegram_id} (${u.telegram_id})`,
      ADMIN_CALLBACK.USER_VIEW(u.telegram_id)
    ),
  ]);

  // Pagination is also a selection, so it remains inline.
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
  const navRow = [];
  if (page > 0) navRow.push(button.primary('⬅️ Prev', ADMIN_CALLBACK.USER_LIST(page - 1)));
  navRow.push(button.primary(`${page + 1}/${totalPages}`, ADMIN_CALLBACK.USER_LIST(page)));
  if (page < totalPages - 1) navRow.push(button.primary('Next ➡️', ADMIN_CALLBACK.USER_LIST(page + 1)));
  if (navRow.length) rows.push(navRow);

  // Menu actions/navigation -> reply keyboard.
  const replyRows = [
    [replyButton.primary('🔍 Cari User'), replyButton.success('➕ Tambah User')],
    [replyButton.danger('🔙 Kembali')],
  ];
  if (searchQuery) replyRows.splice(1, 0, [replyButton.danger(`❌ Hapus Filter: ${searchQuery}`)]);

  // Return a combined markup is impossible: ReplyKeyboardMarkup and
  // InlineKeyboardMarkup cannot coexist on one message. Therefore the list
  // screen intentionally uses inline only for the actual user/page choices;
  // actions are exposed by the persistent admin reply keyboard.
  return Markup.inlineKeyboard(rows);
}

function userSearchResultKeyboard(users, page, totalCount, query) {
  const rows = users.map((u) => [
    button.primary(
      `${u.is_banned ? '🚫 ' : ''}${u.first_name || u.username || u.telegram_id} (${u.telegram_id})`,
      ADMIN_CALLBACK.USER_VIEW(u.telegram_id)
    ),
  ]);

  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
  const navRow = [];
  if (page > 0) navRow.push(button.primary('⬅️ Prev', ADMIN_CALLBACK.USER_SEARCH_PAGE(page - 1)));
  navRow.push(button.primary(`${page + 1}/${totalPages}`, ADMIN_CALLBACK.USER_SEARCH_PAGE(page)));
  if (page < totalPages - 1) navRow.push(button.primary('Next ➡️', ADMIN_CALLBACK.USER_SEARCH_PAGE(page + 1)));
  if (navRow.length) rows.push(navRow);
  return Markup.inlineKeyboard(rows);
}

function userDetailKeyboard(user) {
  const id = Number(user.telegram_id);
  const rows = [
    [user.is_banned ? replyButton.success(`✅ Unban User #${id}`) : replyButton.danger(`🚫 Ban User #${id}`)],
    [replyButton.danger(`🗑️ Hapus User #${id}`)],
  ];
  if (user.trial_claimed_at) rows.push([replyButton.primary(`🔁 Reset Trial User #${id}`)]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

function userBanReasonSkipKeyboard(telegramId) {
  // Explicit choice: inline.
  return Markup.inlineKeyboard([
    [button.primary('⏭️ Tanpa Alasan', ADMIN_CALLBACK.USER_BAN_REASON_SKIP(telegramId))],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.USER_VIEW(telegramId))],
  ]);
}

function userDeleteConfirmKeyboard(user) {
  return Markup.inlineKeyboard([
    [button.danger('⚠️ Ya, Hapus', ADMIN_CALLBACK.USER_DEL(user.telegram_id))],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.USER_VIEW(user.telegram_id))],
  ]);
}


// ---------- Admin Transactions ----------
function transactionListKeyboard(rows, page = 0, totalCount = 0) {
  const out = rows.map((o) => [button.primary(`#${o.id} • ${o.product_name || 'Produk dihapus'} • ${o.status}`, ADMIN_CALLBACK.TRANSACTION_VIEW(o.id))]);
  const totalPages = Math.max(1, Math.ceil(Number(totalCount || 0) / PAGE_SIZE));
  const nav = [];
  if (page > 0) nav.push(button.primary('⬅️ Prev', ADMIN_CALLBACK.TRANSACTIONS_LIST(page - 1)));
  nav.push(button.primary(`${Math.min(page + 1, totalPages)}/${totalPages}`, ADMIN_CALLBACK.TRANSACTIONS_LIST(page)));
  if (page < totalPages - 1) nav.push(button.primary('Next ➡️', ADMIN_CALLBACK.TRANSACTIONS_LIST(page + 1)));
  out.push(nav);
  out.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.PANEL_HOME)]);
  return Markup.inlineKeyboard(out);
}

function transactionDetailKeyboard(order) {
  const id = Number(order?.id || 0);
  const rows = [];
  if (order && order.payment_proof_file_id) rows.push([replyButton.primary(`🧾 Lihat Bukti Pembayaran #${id}`)]);
  if (order && ['awaiting_confirmation','paid'].includes(order.status)) {
    rows.push([replyButton.success(`✅ Approve Order #${id}`), replyButton.danger(`❌ Reject Order #${id}`)]);
  }
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

function transactionProofKeyboard(id) {
  return Markup.inlineKeyboard([[button.primary('🔙 Kembali', ADMIN_CALLBACK.TRANSACTION_VIEW(id))]]);
}

// ---------- Product Management ----------

// Category is a selection -> inline.
function productHomeKeyboard() {
  return Markup.inlineKeyboard([
    [staticButton.primary('🤖 Userbot', ADMIN_CALLBACK.PRODUCT_CAT('userbot'))],
    [staticButton.primary('🔥 Jaseb', ADMIN_CALLBACK.PRODUCT_CAT('jaseb'))],
  ]);
}

function productListKeyboard(category, products, page, totalCount) {
  const rows = products.map((p) => [
    button.primary(`${p.is_active ? '✅' : '⛔'} ${p.name}`, ADMIN_CALLBACK.PRODUCT_VIEW(p.id)),
  ]);

  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
  const navRow = [];
  if (page > 0) navRow.push(button.primary('⬅️ Prev', ADMIN_CALLBACK.PRODUCT_LIST(category, page - 1)));
  navRow.push(button.primary(`${page + 1}/${totalPages}`, ADMIN_CALLBACK.PRODUCT_LIST(category, page)));
  if (page < totalPages - 1) navRow.push(button.primary('Next ➡️', ADMIN_CALLBACK.PRODUCT_LIST(category, page + 1)));
  if (navRow.length) rows.push(navRow);
  return Markup.inlineKeyboard(rows);
}

function productDetailKeyboard(product) {
  const id = Number(product.id);
  return Markup.keyboard([
    [replyButton.primary(`✏️ Edit Produk #${id}`)],
    [product.is_active ? replyButton.danger(`⛔ Nonaktifkan Produk #${id}`) : replyButton.success(`✅ Aktifkan Produk #${id}`)],
    [replyButton.danger(`🗃️ Arsipkan Produk #${id}`)],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

function productDeleteConfirmKeyboard(product) {
  return Markup.inlineKeyboard([
    [button.danger('⚠️ Ya, Nonaktifkan', ADMIN_CALLBACK.PRODUCT_DEL(product.id))],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.PRODUCT_VIEW(product.id))],
  ]);
}

// Add Product wizard — garansi is a Ya/Tidak choice -> inline.
function productAddGaransiKeyboard() {
  return Markup.inlineKeyboard([
    [
      button.success('✅ Ya', ADMIN_CALLBACK.PRODUCT_ADD_GARANSI('ya')),
      button.danger('🚫 Tidak', ADMIN_CALLBACK.PRODUCT_ADD_GARANSI('tidak')),
    ],
    [button.danger('❌ Batal', ADMIN_CALLBACK.PRODUCT_CANCEL)],
  ]);
}

// Add Product wizard — deskripsi step has an explicit skip choice -> inline,
// text input itself still comes from the persistent Cancel reply keyboard.
function productAddDescSkipKeyboard() {
  return Markup.inlineKeyboard([[button.primary('⏭️ Lewati Deskripsi', ADMIN_CALLBACK.PRODUCT_ADD_DESC_SKIP)]]);
}

// Edit Product — field picker is a selection -> inline.
function productEditFieldKeyboard(product) {
  const id = Number(product.id);
  return Markup.keyboard([
    [replyButton.primary(`✏️ Nama Produk #${id}`)],
    [replyButton.primary(`📝 Deskripsi Produk #${id}`)],
    [replyButton.primary(`💰 Harga Produk #${id}`)],
    [replyButton.primary(`⏳ Durasi Produk #${id}`)],
    [replyButton.primary(`🛡️ Garansi Produk #${id}`)],
    [replyButton.primary(`🔐 Feature Access Produk #${id}`)],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

// Edit Product — garansi is a Ya/Tidak choice -> inline, applied immediately.
function productEditGaransiKeyboard(product) {
  return Markup.inlineKeyboard([
    [
      button.success('✅ Ya', ADMIN_CALLBACK.PRODUCT_EDIT_GARANSI(product.id, 'ya')),
      button.danger('🚫 Tidak', ADMIN_CALLBACK.PRODUCT_EDIT_GARANSI(product.id, 'tidak')),
    ],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.PRODUCT_VIEW(product.id))],
  ]);
}

// Edit Product — deskripsi step: skip = keep typing a new one via text, or
// clear it entirely via this button.
function productEditDescClearKeyboard(product) {
  return Markup.inlineKeyboard([[button.danger('🗑️ Kosongkan Deskripsi', ADMIN_CALLBACK.PRODUCT_EDIT_DESC_SKIP(product.id))]]);
}

// Feature Access checklist — shared renderer for both the Add wizard's
// final step and Edit Product's staged editor. `toggleCallback(featureId)`
// and the trailing action button(s) differ between the two callers.
//
// IMPORTANT: these rows are built as PLAIN inline-button objects, NOT via
// `button.primary(...)`. That helper runs every label through Custom Icon
// Tombol (see utils/buttons.js#applyStyle -> buttonIconConfig.service.js),
// which looks the button up by its label with the leading emoji run
// stripped (normalizeLabel). Feature labels here (e.g. "📝 Atur Pesan",
// "👥 Atur Grup", "📄 Broadcast PM", "🛡️ PM Permit", "🗑️ Reset Data")
// are IDENTICAL, once their emoji is stripped, to the real static panel
// menu buttons of the same name (MENU.MESSAGE/GROUP/BROADCAST_PM/
// PM_PERMIT/RESET_DATA in constants/menu.js). If an admin has ever set a
// custom icon for one of those real menu buttons, Custom Icon Tombol
// would match on that same normalized key and REPLACE this checklist
// button's whole text with "<custom icon> <label>" — silently discarding
// the "☑️/⬜" checkbox prefix we just added, and doing so only for
// whichever features happen to collide. That is exactly the bug reported:
// some checklist rows render with no checkbox at all, so admins can't
// tell (or reliably toggle) whether that feature is selected.
// This checklist is a stateful control, not a customizable static label —
// it must always show its own live checkbox — so it deliberately bypasses
// the icon-customization pipeline entirely.
function productFeatureChecklistKeyboard(selectedIds, toggleCallback, actionRow) {
  const selected = new Set(selectedIds || []);
  const rows = featureAccess.listFeatures().map((f) => [
    {
      text: `${selected.has(f.id) ? '☑️' : '⬜'} ${f.label}`,
      callback_data: validateCallbackData(toggleCallback(f.id), `feature access ${f.id}`),
      style: 'primary',
    },
  ]);
  return Markup.inlineKeyboard([...rows, ...actionRow]);
}

function productAddFeatureChecklistKeyboard(selectedIds) {
  return productFeatureChecklistKeyboard(selectedIds, ADMIN_CALLBACK.PRODUCT_ADD_FEATURE_TOGGLE, [
    [button.success('✅ Simpan & Buat Produk', ADMIN_CALLBACK.PRODUCT_ADD_FEATURE_DONE)],
    [button.danger('⏭️ Lewati (Akses Penuh)', ADMIN_CALLBACK.PRODUCT_ADD_FEATURE_SKIP)],
  ]);
}

function productEditFeatureChecklistKeyboard(product, selectedIds) {
  return productFeatureChecklistKeyboard(
    selectedIds,
    (featureId) => ADMIN_CALLBACK.PRODUCT_EDIT_FEATURE_TOGGLE(product.id, featureId),
    [
      [button.success('✅ Simpan Perubahan', ADMIN_CALLBACK.PRODUCT_EDIT_FEATURE_SAVE(product.id))],
      [button.danger('❌ Batal', ADMIN_CALLBACK.PRODUCT_EDIT_FEATURE_CANCEL(product.id))],
    ]
  );
}

// Trial -> Akses Fitur Trial checklist. Same shared checklist renderer as
// Product Feature Access (same registry, same checkbox rendering rules —
// see productFeatureChecklistKeyboard's doc above), staged the same way:
// toggle freely, then explicit Simpan/Batal. "Izinkan Semua Fitur" is the
// dedicated action for TASK 32 (explicitly restore NULL/unrestricted,
// distinct from checking every box which would save an ARRAY, not NULL).
function trialFeatureChecklistKeyboard(selectedIds) {
  return productFeatureChecklistKeyboard(selectedIds, ADMIN_CALLBACK.TRIAL_FEATURES_TOGGLE, [
    [button.success('💾 Simpan', ADMIN_CALLBACK.TRIAL_FEATURES_SAVE)],
    [button.primary('🔓 Izinkan Semua Fitur', ADMIN_CALLBACK.TRIAL_FEATURES_RESET)],
    [button.danger('❌ Batal', ADMIN_CALLBACK.TRIAL_FEATURES_CANCEL)],
  ]);
}

// ---------- Input flows ----------

function adminTextInputCancelKeyboard(cancelCallback) {
  const labels = {
    [ADMIN_CALLBACK.USER_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.PRODUCT_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.PAYMENT_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.POOL_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.START_STICKER_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.TRIAL_SETTINGS_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.TRIAL_FEATURES_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.PREMIUM_EMOJI_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.CUSTOM_SUBMENU_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.JOIN_GATE_CANCEL]: '❌ Batal',
    [ADMIN_CALLBACK.SUBEXT_CANCEL]: '❌ Batal',
  };
  return Markup.keyboard([[replyButton.danger('❌ Batal')]]).resize();
}

/**
 * Context-aware reply keyboard for ANY admin input step, built from the
 * flow registry (src/constants/adminInputFlows.js): optional
 * "Kontak Saya" / "Lewati", then standard "Kembali" + "Batal".
 * Not one-time: the exit path must survive every retry.
 */
function adminInputKeyboard(state) {
  const rows = navSpec(state).map((row) =>
    row.map((b) => {
      if (b.type === 'contact') return replyButton.contactRequest(b.label);
      if (b.type === 'skip') return replyButton.primary(b.label);
      if (b.type === 'back') return replyButton.primary(b.label);
      return replyButton.danger(CANCEL_LABEL);
    })
  );
  if (!rows.length) return adminTextInputCancelKeyboard();
  return Markup.keyboard(rows).resize();
}

// ---------- Payment ----------

function paymentHomeKeyboard() {
  return Markup.keyboard([
    [staticReplyButton.primary('🖼️ Set Gambar QRIS'), staticReplyButton.primary('📝 Set Catatan QRIS')],
    [staticReplyButton.primary('🏦 Set Info Rekening/E-Wallet')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

// ---------- Userbot Pool ----------

function poolAddMethodKeyboard() {
  return Markup.inlineKeyboard([
    [button.primary('📱 Tambah via Nomor Telepon', ADMIN_CALLBACK.POOL_ADD_PHONE)],
    [button.success('🔑 Tambah via Session String', ADMIN_CALLBACK.POOL_ADD_SESSION)],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.POOL_HOME), button.danger('❌ Batal', ADMIN_CALLBACK.POOL_CANCEL)],
  ]);
}

function poolPhoneInputKeyboard() {
  return Markup.keyboard([
    [replyButton.contactRequest('💬 Kontak Saya')],
    [replyButton.primary('🔙 Kembali'), replyButton.danger('❌ Batal')],
  ]).resize();
}

function poolSessionInputKeyboard() {
  return Markup.keyboard([
    [replyButton.primary('🔙 Kembali'), replyButton.danger('❌ Batal')],
  ]).resize();
}

function poolHomeKeyboard(poolList) {
  // Selecting a stock row is NEVER destructive. Delete has its own explicit
  // confirmation callback and is only offered from the detail screen.
  const rows = poolList.map((p) => [
    button.primary(
      `${p.status === 'available' ? '🟢' : p.status === 'assigned' ? '🟡' : p.status === 'reserved' ? '🟠' : '⚪'} ${p.label} (#${p.id})`,
      ADMIN_CALLBACK.POOL_VIEW(p.id)
    ),
  ]);
  if (!rows.length) rows.push([button.primary('📭 Belum ada stok', ADMIN_CALLBACK.POOL_HOME)]);
  return Markup.inlineKeyboard(rows);
}

function poolDetailKeyboard(id, canDelete = false) {
  const rows = [];
  if (canDelete) rows.push([replyButton.danger(`🗑️ Hapus Stok #${Number(id)}`)]);
  rows.push([replyButton.primary(`🔄 Refresh Stok #${Number(id)}`)]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

function poolDeleteConfirmKeyboard(id) {
  return Markup.inlineKeyboard([
    [button.danger('⚠️ Ya, Hapus', ADMIN_CALLBACK.POOL_DEL(id))],
    [button.primary('🔙 Kembali', ADMIN_CALLBACK.POOL_VIEW(id))],
  ]);
}

function poolHomeReplyKeyboard() {
  return Markup.keyboard([
    [staticReplyButton.success('➕ Tambah Stok Userbot')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}


function userListActionKeyboard(searchQuery = null) {
  const rows = [
    [staticReplyButton.primary('🔍 Cari User'), staticReplyButton.success('➕ Tambah User')],
  ];
  if (searchQuery) rows.push([replyButton.danger(`❌ Hapus Filter: ${searchQuery}`)]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

function userSearchActionKeyboard() {
  return Markup.keyboard([
    [staticReplyButton.primary('🔍 Cari User')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

function productListActionKeyboard(category) {
  const addLabel = category === 'userbot' ? '➕ Tambah Produk Userbot' : '➕ Tambah Produk Jaseb';
  return Markup.keyboard([
    [replyButton.success(addLabel)],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

function poolHomeActionKeyboard() {
  return Markup.keyboard([
    [staticReplyButton.success('➕ Tambah Stok Userbot')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

// ---------- Settings ----------

const settingsKeyboard = () => Markup.keyboard([
  [staticReplyButton.primary('🎨 Custom Submenu'), staticReplyButton.primary('🎬 Sticker /start')],
  [staticReplyButton.primary('🎁 Durasi Trial'), staticReplyButton.primary('💎 Emoji Premium')],
  [staticReplyButton.primary('📢 Wajib Join')],
  [staticReplyButton.success('🎨 Custom Icon Tombol')],
  [staticReplyButton.primary('💾 Backup Pengaturan')],
  [replyButton.danger('🔙 Kembali')],
]).resize();

function notificationHomeKeyboard() {
  return Markup.keyboard([
    [staticReplyButton.primary('🆕 Log Registrasi'), staticReplyButton.primary('💳 Log Transaksi')],
    [staticReplyButton.primary('🧾 Testimoni')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

function notificationRegistrationKeyboard(current) {
  const rows = [
    [replyButton.primary('📢 Atur Channel Registrasi')],
  ];
  if (current) rows.push([replyButton.danger('🗑️ Reset Channel Registrasi')]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

function testimonialHomeKeyboard(current, enabled = true) {
  const rows = [
    [replyButton.primary(enabled ? '🔴 Matikan Testimoni' : '🟢 Nyalakan Testimoni')],
    [replyButton.primary('📢 Atur Channel Testimoni')],
    [replyButton.primary('🎨 Custom Testimoni'), replyButton.primary('🔘 Atur Tombol')],
    [replyButton.primary('🖼️ Atur Gambar')],
    [replyButton.primary('👁️ Preview Testimoni')],
  ];
  if (current) rows.push([replyButton.danger('♻️ Reset Pengaturan')]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

function notificationTransactionKeyboard(current, duration) {
  const rows = [
    [replyButton.primary('📢 Atur Channel Transaksi')],
    [replyButton.primary('⏱️ Durasi Aktif')],
  ];
  if (current) rows.push([replyButton.danger('🗑️ Reset Channel Transaksi')]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}


// ---------- Wajib Join / Join Gate ----------

function joinGateSettingsHomeKeyboard(config) {
  // Group controls by purpose: status/action first, configuration second,
  // destructive actions last, navigation always at the bottom.
  const rows = [
    [
      config.enabled
        ? replyButton.danger('🔴 Nonaktifkan Wajib Join')
        : replyButton.success('🟢 Aktifkan Wajib Join'),
    ],
    [
      staticReplyButton.primary('📢 Set Channel Wajib'),
      staticReplyButton.primary('💬 Set Grup Opsional'),
    ],
  ];

  const removeRow = [];
  if (config.channelId) removeRow.push(replyButton.danger('🗑️ Hapus Channel Wajib'));
  if (config.groupId) removeRow.push(replyButton.danger('🗑️ Hapus Grup Opsional'));
  if (removeRow.length) rows.push(removeRow);

  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

// ---------- Sticker /start ----------

function startStickerHomeKeyboard(hasSticker) {
  const rows = [[replyButton.primary(hasSticker ? '🔁 Ganti Sticker' : '➕ Set Sticker')]];
  if (hasSticker) rows.push([replyButton.danger('🗑️ Hapus Sticker')]);
  rows.push([replyButton.danger('🔙 Kembali')]);
  return Markup.keyboard(rows).resize();
}

// ---------- Durasi Trial ----------

const trialSettingsHomeKeyboard = () => Markup.keyboard([
  [staticReplyButton.primary('✏️ Ubah Durasi')],
  [staticReplyButton.primary('🔐 Akses Fitur Trial')],
  [replyButton.danger('🔙 Kembali')],
]).resize();

const premiumEmojiHomeKeyboard = () => Markup.keyboard([
  [staticReplyButton.primary('⭐ Ubah Emoji Bergaransi')],
  [staticReplyButton.primary('💎 Ubah Emoji Non-Garansi')],
  [replyButton.danger('🔙 Kembali')],
]).resize();

// Submenu entries are selections -> inline.
function customSubmenuListKeyboard(submenus, { page = 0, totalPages = 1 } = {}) {
  const rows = submenus.map((s) => [
    button.primary(`${s.hasCustom ? '✅ ' : ''}${s.feature ? `${s.feature} › ` : ''}${s.label}`, ADMIN_CALLBACK.CUSTOM_SUBMENU_SELECT(s.id)),
  ]);
  if (totalPages > 1) {
    const nav = [];
    if (page > 0) nav.push(button.primary('◀️ Sebelumnya', ADMIN_CALLBACK.CUSTOM_SUBMENU_PAGE(page - 1)));
    if (page < totalPages - 1) nav.push(button.primary('▶️ Berikutnya', ADMIN_CALLBACK.CUSTOM_SUBMENU_PAGE(page + 1)));
    if (nav.length) rows.push(nav);
  }
  rows.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.SETTINGS_OPEN)]);
  return Markup.inlineKeyboard(rows);
}

// Once a submenu is selected, its action choices stay inline so the screen can be edited in place.
function customSubmenuStatusKeyboard(submenuId) {
  return Markup.inlineKeyboard([
    [button.primary('✏️ Edit', ADMIN_CALLBACK.CUSTOM_SUBMENU_EDIT(submenuId))],
    [button.primary('👁️ Preview', ADMIN_CALLBACK.CUSTOM_SUBMENU_PREVIEW(submenuId))],
    [button.danger('♻️ Reset Default', ADMIN_CALLBACK.CUSTOM_SUBMENU_RESET(submenuId))],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.CUSTOM_SUBMENU_LIST)],
  ]);
}

function customSubmenuInputCancelKeyboard() {
  return Markup.keyboard([[replyButton.primary('🔙 Kembali'), replyButton.danger('❌ Batal')]]).resize();
}

// Preview confirmation is a choice -> inline.
function customSubmenuPreviewKeyboard(submenuId) {
  return Markup.inlineKeyboard([
    [button.success('✅ Simpan', ADMIN_CALLBACK.CUSTOM_SUBMENU_SAVE(submenuId))],
    [button.primary('✏️ Kirim Ulang', ADMIN_CALLBACK.CUSTOM_SUBMENU_RESEND(submenuId))],
    [button.danger('❌ Batal', ADMIN_CALLBACK.CUSTOM_SUBMENU_CANCEL)],
  ]);
}

function customSubmenuPreviewBackKeyboard(submenuId) {
  return Markup.inlineKeyboard([
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.CUSTOM_SUBMENU_SELECT(submenuId))],
  ]);
}

function customSubmenuResetConfirmKeyboard(submenuId) {
  return Markup.inlineKeyboard([
    [button.danger('⚠️ Ya, Reset', ADMIN_CALLBACK.CUSTOM_SUBMENU_RESET_CONFIRM(submenuId))],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.CUSTOM_SUBMENU_SELECT(submenuId))],
  ]);
}

module.exports = {
  adminPanelKeyboard,
  transactionListKeyboard,
  transactionDetailKeyboard,
  transactionProofKeyboard,
  settingsKeyboard,
  notificationHomeKeyboard,
  notificationRegistrationKeyboard,
  notificationTransactionKeyboard,
  testimonialHomeKeyboard,
  joinGateSettingsHomeKeyboard,
  startStickerHomeKeyboard,
  trialSettingsHomeKeyboard,
  premiumEmojiHomeKeyboard,
  customSubmenuListKeyboard,
  customSubmenuStatusKeyboard,
  customSubmenuInputCancelKeyboard,
  customSubmenuPreviewKeyboard,
  customSubmenuPreviewBackKeyboard,
  customSubmenuResetConfirmKeyboard,
  PAGE_SIZE,
  userListKeyboard,
  userDetailKeyboard,
  userDeleteConfirmKeyboard,
  userBanReasonSkipKeyboard,
  userSearchResultKeyboard,
  productHomeKeyboard,
  productListKeyboard,
  productListActionKeyboard,
  userListActionKeyboard,
  userSearchActionKeyboard,
  productDetailKeyboard,
  productDeleteConfirmKeyboard,
  productAddGaransiKeyboard,
  productAddDescSkipKeyboard,
  productEditFieldKeyboard,
  productEditGaransiKeyboard,
  productEditDescClearKeyboard,
  productAddFeatureChecklistKeyboard,
  productEditFeatureChecklistKeyboard,
  trialFeatureChecklistKeyboard,
  adminTextInputCancelKeyboard,
  adminInputKeyboard,
  paymentHomeKeyboard,
  poolAddMethodKeyboard,
  poolPhoneInputKeyboard,
  poolSessionInputKeyboard,
  poolHomeKeyboard,
  poolDetailKeyboard,
  poolDeleteConfirmKeyboard,
  poolHomeActionKeyboard,
};
