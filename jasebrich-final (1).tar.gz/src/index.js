const { Telegraf } = require('telegraf');
const { config, validateConfig } = require('./config');
const { initDatabase } = require('./database');
const logger = require('./utils/logger');
const { MENU, CALLBACK } = require('./constants/menu');
const { CATEGORY_LABEL } = require('./services/product.service');
const { ADMIN_CALLBACK } = require('./constants/admin.callback');
const {
  STATISTICS_SECTION_CALLBACK_PATTERN,
  STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN,
} = require('./constants/statistics');
const { startScheduler, stopScheduler } = require('./scheduler');

const { startHandler } = require('./handlers/start.handler');
const { backToMainHandler, navHomeCallback } = require('./handlers/menu.handler');
const {
  storeHandler,
  storeHomeCallback,
  storeCategoryCallback,
  storeUserbotCallback,
  storeJasebCallback,
  storeCategoryPolicyHandler,
  storeGaransiCallback,
  storeProductCallback,
  storeQtyCallback,
  storePolicyCallback,
  storePayCallback,
  storePaidCallback,
  storeResumeCallback,
  storeOrderStatusCallback,
  storeCancelAllCallback,
  storeCancelAllYesCallback,
  storeCancelAllNoCallback,
  storeCancelYesCallback,
  storeCancelNoCallback,
  showPaymentProofCancelConfirmation,
  handlePaymentProofPhoto,
  handlePaymentProofDocument,
  handlePaymentProofVideo,
  storeCancelCallback,
} = require('./handlers/store.handler');
const { ubotHandler } = require('./handlers/ubot.handler');const {
  panelHandler, panelAssetInlineCallback,
  homePanelHandler, baseReplyHandler, messageHandler, groupHandler, delayHandler, extraHandler, guideHandler: panelGuideHandler,
  startHandler: panelStartHandler, replyToggleHandler, addReplyHandler, deleteReplyHandler, globalSettingsHandler, wtbTimerHandler,
  replyListHandler, autoResetHandler, autoReactHandler, autoReactEnableHandler, autoReactDisableHandler, autoReactChangeHandler, channelDisableHandler, globalTextHandler, globalTargetChannelHandler, globalBannedHandler, globalMaxCharsHandler, globalFilterLinkHandler, globalFilterUsernameHandler, textMediaHandler, forwardHandler, viewMessageHandler, deleteMessageHandler, topicGroupHandler,
  addGroupHandler, deleteGroupHandler, groupListHandler, joinGroupHandler, leaveGroupHandler, groupDelayHandler, roundDelayHandler, smartDelayToggleHandler,
  groupDeleteSelectCallback, groupDeleteConfirmCallback, groupDeleteAllCallback, groupDeleteAllConfirmCallback, groupDeleteCancelCallback, groupDeletePageCallback, groupListPageCallback, groupListRefreshCallback, groupListBackCallback, groupLeavePageCallback, groupLeaveRefreshCallback, groupLeaveSelectCallback, groupLeaveBackCallback, groupLeaveAllCallback,
  broadcastPmHandler, pmPermitHandler: panelPmPermitHandler, adminPanelHandler: panelAdminHandler, timerHandler: panelTimerHandler,
  backupTokenHandler, customWmHandler, watermarkHandler, watermarkEnableHandler, watermarkDisableHandler, timerSetHandler, timerEnableHandler, timerDisableHandler, backupTokenNewHandler, backupTokenConfirmHandler, checkTokenHandler, transferHandler: panelTransferUbotHandler, resetDataHandler, handleMediaInput, promotionStatusHandler, promotionStatusRefreshHandler, promotionStatusRefreshInlineCallback, promotionStatusStartInlineCallback, promotionStatusStopInlineCallback, promotionStatusBackInlineCallback,
  requireFeature: requirePanelFeature,
} = require('./handlers/panel.handler');
const { featuresHandler } = require('./handlers/features.handler');
const { claimTrialHandler, trialAgreeHandler, trialTermsAgreeHandler, trialCancelHandler, TRIAL_AGREE, TRIAL_TERMS_AGREE, TRIAL_CANCEL } = require('./handlers/trial.handler');
const { klaimTokenHandler } = require('./handlers/token.handler');
const { guideHandler } = require('./handlers/guide.handler');
const { expiredHandler } = require('./handlers/expired.handler');
const { PANEL_FEATURE } = require('./constants/menu');

const { requireAdmin } = require('./middlewares/admin.middleware');
const { banGuardMiddleware } = require('./middlewares/banGuard.middleware');
const { floodGuardMiddleware } = require('./middlewares/floodGuard.middleware');
const { userResponseTpl } = require('./services/userResponseTemplate.service');
const { getSafeErrorContent } = require('./utils/errors');
const { ensureUserMiddleware } = require('./middlewares/ensureUser.middleware');
const { joinGateMiddleware } = require('./middlewares/joinGate.middleware');
const { customSubmenuTextMiddleware } = require('./middlewares/customSubmenuText.middleware');
const { ubotLoginTextMiddleware } = require('./middlewares/ubotLoginText.middleware');
const { tokenClaimTextMiddleware } = require('./middlewares/tokenClaimText.middleware');
const { panelTextMiddleware } = require('./middlewares/panelText.middleware');
const { navigationCancellationMiddleware } = require('./middlewares/navigationCancellation.middleware');
const { adminReplyMiddleware } = require('./middlewares/adminReply.middleware');
const { adminBroadcastMiddleware } = require('./middlewares/adminBroadcast.middleware');
const {
  adminFlowTextMiddleware,
  adminFlowDocumentMiddleware,
  adminFlowPhotoMiddleware,
  adminFlowStickerMiddleware,
  adminFlowMismatchMiddleware,
} = require('./middlewares/adminFlow.middleware');

const {
  adminPanelHandler, adminPanelCallback,
  adminUsersCategoryCallback, adminUserbotCategoryCallback, adminCommerceCategoryCallback,
  adminOrdersCategoryCallback, adminNotificationsCategoryCallback, adminStatisticsCategoryCallback,
  adminSettingsCategoryCallback,
} = require('./handlers/admin/adminPanel.handler');
const { statisticsHandler, statisticsCallback, statisticsRefreshCallback, statisticsSectionCallback, statisticsSectionRefreshCallback } = require('./handlers/admin/statistics.handler');
const pingHandler = require('./handlers/ping.handler');
const {
  notificationHomeCallback,
  notificationRegistrationHomeCallback,
  notificationTransactionHomeCallback,
  notificationSetRegistrationChannelCallback,
  notificationSetTransactionChannelCallback,
  notificationSetDurationCallback,
  notificationResetRegistrationCallback,
  notificationResetTransactionCallback,
  notificationCancelCallback,
} = require('./handlers/admin/notification.handler');
const testimonialAdmin = require('./handlers/admin/testimonial.handler');
require('./services/testimonial.service'); // registers notification.testimonial in Custom Submenu
const { panelUbotHomeCallback, panelUbotSelectCallback } = require('./handlers/admin/panelUbot.handler');
const broadcastAdmin = require('./handlers/admin/broadcast.handler');
const reminderAdmin = require('./handlers/admin/reminder.handler');
const { settingsCallback } = require('./handlers/admin/settings.handler');
const {
  buttonIconsHomeCallback,
  buttonIconsResetCallback,
  buttonIconsCancelCallback,
  buttonIconsPickPageCallback,
  buttonIconsPickSelectCallback,
  buttonIconsPickSetCallback,
  buttonIconsPickRemoveCallback,
} = require('./handlers/admin/buttonIcons.handler');
const {
  settingsBackupHomeCallback,
  settingsBackupExportCallback,
  settingsBackupImportCallback,
} = require('./handlers/admin/settingsBackup.handler');
const autoBackupAdmin = require('./handlers/admin/autoBackup.handler');
const systemHealthAdmin = require('./handlers/admin/systemHealth.handler');
const ubotNotifyHandler = require('./handlers/ubotNotify.handler');
const {
  joinGateHomeCallback,
  joinGateToggleCallback,
  joinGateSetChannelCallback,
  joinGateSetGroupCallback,
  joinGateRemoveChannelCallback,
  joinGateRemoveGroupCallback,
  joinGateCancelCallback,
} = require('./handlers/admin/joinGateSettings.handler');
const {
  customSubmenuListCallback,
  customSubmenuPageCallback,
  customSubmenuSelectCallback,
  customSubmenuEditCallback,
  customSubmenuResendCallback,
  customSubmenuPreviewCallback,
  customSubmenuSaveCallback,
  customSubmenuResetCallback,
  customSubmenuResetConfirmCallback,
  customSubmenuCancelCallback,
} = require('./handlers/admin/customSubmenu.handler');

const {
  startStickerHomeCallback,
  startStickerSetCallback,
  startStickerRemoveCallback,
  startStickerCancelCallback,
} = require('./handlers/admin/startSticker.handler');

const {
  trialSettingsHomeCallback,
  trialSettingsSetCallback,
  trialSettingsCancelCallback,
  trialFeaturesHomeCallback,
  trialFeaturesToggleCallback,
  trialFeaturesSaveCallback,
  trialFeaturesResetCallback,
  trialFeaturesCancelCallback,
} = require('./handlers/admin/trialSettings.handler');

const {
  premiumEmojiHomeCallback,
  premiumEmojiSetGaransiCallback,
  premiumEmojiSetNonGaransiCallback,
  premiumEmojiCancelCallback,
} = require('./handlers/admin/premiumEmoji.handler');


const {
  userListCallback,
  userSearchCallback,
  userSearchResultsCallback,
  userSearchClearCallback,
  userAddCallback,
  userCancelCallback,
  userViewCallback,
  userResetTrialCallback,
  userBanCallback,
  userBanReasonSkipCallback,
  userUnbanCallback,
  userDeleteConfirmCallback,
  userDeleteCallback,
} = require('./handlers/admin/userManagement.handler');

const {
  productHomeCallback,
  productCatCallback,
  productListCallback,
  productViewCallback,
  productAddCallback,
  productAddGaransiCallback,
  productAddDescSkipCallback,
  productAddFeatureToggleCallback,
  productAddFeatureDoneCallback,
  productAddFeatureSkipCallback,
  productEditCallback,
  productEditFieldCallback,
  productEditGaransiCallback,
  productEditDescSkipCallback,
  productEditFeatureToggleCallback,
  productEditFeatureSaveCallback,
  productEditFeatureCancelCallback,
  productToggleCallback,
  productDeleteConfirmCallback,
  productDeleteCallback,
  productCancelCallback,
} = require('./handlers/admin/productManagement.handler');

const {
  paymentHomeCallback,
  paymentSetQrisCallback,
  paymentSetNoteCallback,
  paymentSetBankCallback,
  paymentCancelCallback,
} = require('./handlers/admin/paymentManagement.handler');

const {
  poolHomeCallback,
  poolAddCallback,
  poolAddPhoneCallback,
  poolAddSessionCallback,
  poolViewCallback,
  poolDeleteConfirmCallback,
  poolDeleteCallback,
  poolCancelCallback,
} = require('./handlers/admin/poolManagement.handler');

const { adminOrderConfirmCallback, adminOrderRejectCallback } = require('./handlers/admin/orderConfirm.handler');
const { transactionHomeCallback, transactionListCallback, transactionViewCallback, transactionProofCallback, transactionApproveCallback, transactionRejectCallback } = require('./handlers/admin/transaction.handler');
const subExt = require('./handlers/admin/subscriptionExtend.handler');
const { subscriptionRenewCallback } = require('./handlers/subscription.handler');
const userbotLifecycle = require('./services/userbotLifecycle.service');

const userbotRuntime = require('./services/userbotRuntime.service');
const joinGateService = require('./services/joinGate.service');
const {
  isEntityTextInvalidError,
  isFormattingPayload,
  buildHtmlFallbackPayload,
  extractApiErrorMessage,
} = require('./utils/telegramFormatting');

// Fatal-process policy. Request-local failures are handled by Telegraf's
// bot.catch() and safeHandler(). A truly unhandled asynchronous rejection or
// uncaught exception means the process can no longer be trusted as healthy.
// We therefore log it, attempt a best-effort graceful shutdown, and exit
// non-zero so an EXTERNAL process manager may restart it when configured.
// This bot never self-restarts or spawns a supervisor.
let runningBot = null;
let fatalShutdownPromise = null;

async function shutdownAfterFatal(signal, reason) {
  if (fatalShutdownPromise) return fatalShutdownPromise;
  fatalShutdownPromise = (async () => {
    logger.error(`${signal}: process entering fatal shutdown.`, reason);
    try { stopScheduler(); } catch (err) { logger.error('Fatal shutdown scheduler stop failed:', err); }
    try { await userbotRuntime.shutdownAll(); } catch (err) { logger.error('Fatal shutdown userbot runtime failed:', err); }
    try {
      if (runningBot) runningBot.stop(signal);
    } catch (err) {
      logger.error('Fatal shutdown bot stop failed:', err);
    }
  })();
  return fatalShutdownPromise;
}

process.on('unhandledRejection', (reason) => {
  shutdownAfterFatal('UNHANDLED_REJECTION', reason)
    .finally(() => { process.exitCode = 1; process.exit(1); });
});

process.on('uncaughtException', (err) => {
  shutdownAfterFatal('UNCAUGHT_EXCEPTION', err && err.stack ? err.stack : err)
    .finally(() => { process.exitCode = 1; process.exit(1); });
});

function main() {
  const configErrors = validateConfig();
  if (configErrors.length > 0) {
    configErrors.forEach((err) => logger.error(err));
    process.exit(1);
  }

  initDatabase();
  try {
    const orphanMediaRemoved = require('./services/panelConfig.service').cleanupOrphanMedia();
    if (orphanMediaRemoved) logger.info(`Removed ${orphanMediaRemoved} orphan panel media file(s).`);
  } catch (err) {
    logger.warn(`Panel media orphan cleanup gagal: ${err.message}`);
  }

  // Restart recovery: an order left at 'processing' by a crashed/killed
  // process (claimed via claimForProcessing but never reached a final
  // status) is reverted to 'paid' so it can be retried — same pattern
  // as userbotRuntime.bootstrapAll() below for runtime state. Must run
  // once right after the DB is ready and before the bot starts taking
  // new admin-confirm taps against these same rows.
  require('./services/order.service').expireStaleOrders();
  require('./services/order.service').reclaimStaleProcessingOrders();

  const bot = new Telegraf(config.botToken);
  runningBot = bot;

  // Track whether an update already produced a user-visible response. The
  // global bot.catch fallback uses this flag to avoid replying twice when a
  // handler has already answered successfully.
  bot.use(async (ctx, next) => {
    if (ctx.state && ctx.state.__jasebResponseTrackerInstalled) return next();
    ctx.state = ctx.state || {};
    ctx.state.__jasebResponseTrackerInstalled = true;
    ctx.state.__responseSent = false;

    const wrapResponse = (methodName) => {
      if (typeof ctx[methodName] !== 'function') return;
      const original = ctx[methodName].bind(ctx);
      ctx[methodName] = async (...args) => {
        const result = await original(...args);
        ctx.state.__responseSent = true;
        return result;
      };
    };
    ['reply', 'replyWithPhoto', 'replyWithVideo', 'replyWithDocument', 'replyWithSticker', 'editMessageText', 'editMessageCaption', 'editMessageMedia'].forEach(wrapResponse);
    return next();
  });

  // Telegram can return 400 ENTITY_TEXT_INVALID when a MessageEntity range
  // no longer matches the outgoing UTF-16 text. This is especially easy to
  // trigger after placeholder expansion or with complex custom/premium emoji.
  // Keep the original entity path first; only when Telegram rejects it do we
  // serialize the exact same entities to Telegram HTML and retry. A final
  // plain-text retry guarantees the user's flow never becomes a dead end.
  const originalCallApi = bot.telegram.callApi.bind(bot.telegram);
  bot.telegram.callApi = async (method, payload = {}, ...rest) => {
    try {
      return await originalCallApi(method, payload, ...rest);
    } catch (err) {
      if (!isFormattingPayload(payload) || !isEntityTextInvalidError(err)) throw err;

      const fallbackPayload = buildHtmlFallbackPayload(payload);
      try {
        logger.warn(`Telegram rejected MessageEntity payload for ${method}; retrying with HTML serialization: ${extractApiErrorMessage(err)}`);
        return await originalCallApi(method, fallbackPayload, ...rest);
      } catch (fallbackErr) {
        logger.warn(`HTML formatting fallback also failed for ${method}; retrying plain text: ${extractApiErrorMessage(fallbackErr)}`);
        const plainPayload = { ...payload };
        delete plainPayload.entities;
        delete plainPayload.caption_entities;
        delete plainPayload.parse_mode;
        try {
          return await originalCallApi(method, plainPayload, ...rest);
        } catch (plainErr) {
          // Preserve the original Telegram failure context because it is the
          // error that identifies the entity problem the application detected.
          logger.error(`Telegram formatting fallback failed for ${method}: ${extractApiErrorMessage(plainErr)}`);
          throw err;
        }
      }
    }
  };
const buttonIconConfig = require('./services/buttonIconConfig.service');

  // PERMANENT fix for "Perintah tidak dikenali" on customized buttons —
  // see buttonIconConfig.service.js#registerStaticLabels for the root
  // cause (a capped, evictable routing registry that can silently drop
  // ANY button, static or dynamic, once the bot has generated enough
  // one-off dynamic labels over its lifetime).
  //
  // Rather than hand-maintain a list of "every static label that
  // exists" (which breaks again the moment a future feature adds a
  // new bot.hears() call and someone forgets to also list it), every
  // string trigger ever passed to bot.hears() is protected
  // AUTOMATICALLY, right here, by wrapping bot.hears() itself. This
  // makes the fix self-maintaining and permanent: it can never go
  // stale, because it has nothing to keep in sync — any bot.hears()
  // call anywhere in this file (present or added later) is covered
  // the moment it's registered, with zero extra code at the call site.
  // Purely additive: does not change what any handler does, only
  // guarantees its trigger text can always be routed back to it.
  const originalHears = bot.hears.bind(bot);
  bot.hears = (triggers, ...handlers) => {
    const list = Array.isArray(triggers) ? triggers : [triggers];
    const stringTriggers = list.filter((t) => typeof t === 'string');
    if (stringTriggers.length) buttonIconConfig.registerStaticLabels(stringTriggers);
    return originalHears(triggers, ...handlers);
  };

  // Ensures a `users` row exists for whoever is interacting, before
  // ANY command/handler/middleware below (including /start itself)
  // sees ctx.from. Must be the very first bot.use() — see
  // ensureUser.middleware.js for why this was required (Coba Gratis /
  // trial FK crash for users with no row yet).
  bot.use(ensureUserMiddleware());

  // BAN MUST run before every user-facing command/handler. Telegraf executes
  // middleware/handlers in registration order, so anything registered before
  // this guard would bypass it unless that handler performs its own explicit
  // ban check. Keep ensureUser first because banGuard needs a canonical users row.
  // Admins are explicitly exempted inside banGuardMiddleware(), then /admin
  // still enforces its own requireAdmin() authorization.
  bot.use(banGuardMiddleware());

  // Blunt per-user burst protection for the whole bot (see
  // floodGuard.middleware.js) — after ban/admin exemption, before any
  // handler that touches the DB or a userbot's GramJS connection.
  bot.use(floodGuardMiddleware());

  // Join gate MUST be registered before command/callback handlers so the
  // registration order cannot accidentally create an ungated entry point.
  // Admins are bypassed inside the middleware; the explicit retry callback
  // is also allowed through so it can perform a fresh membership check.
  bot.use(joinGateMiddleware());

  // Commands
  // Deep links from Testimoni CTA buttons. Plain /start (no payload) stays exactly startHandler.
  bot.start((ctx, next) => {
    const payload = String(ctx.startPayload || '').trim().toLowerCase();
    if (payload === 'store' || payload === 'renewal') return storeHandler(ctx, next);
    return startHandler(ctx, next);
  });
  bot.command('ping', pingHandler);
  bot.command('expired', expiredHandler);
  bot.command('masaaktif', expiredHandler);
  bot.command('admin', requireAdmin(adminPanelHandler));

  bot.use(async (ctx, next) => {
  if (ctx.updateType === 'message' && ctx.message && typeof ctx.message.text === 'string') {
    const original = ctx.message.text.trim();

    // Reply keyboards are message-based: after an icon is customized,
    // Telegram sends the CUSTOMIZED text back (for Premium custom emoji it
    // may even be just the plain label because the native icon lives in
    // `icon_custom_emoji_id`). Every button created by utils/buttons.js is
    // registered with its original handler-facing label, so resolve it
    // before any bot.hears()/text-flow middleware runs.
    const customizedButton = buttonIconConfig.resolveIncomingButtonLabel(original);
    if (customizedButton) {
      ctx.message.text = customizedButton;
    } else {
      // Backward-compatible fallback for labels from older databases/builds
      // that were stored before the exact-label routing registry existed.
      // Include the persisted auto-discovered button registry as well as the
      // static constants. This is the important compatibility path for
      // buttons introduced by newer features (including dynamic admin
      // product actions) and for databases created before the v2 routing
      // registry existed. Native Telegram custom-emoji icons can return only
      // the plain semantic label, so findDefaultLabel() also performs a
      // semantic-label match.
      const labels = buttonIconConfig.getKnownLabels().concat(
        Object.values(MENU),
        Object.values(PANEL_FEATURE || {}),
        Object.values(CATEGORY_LABEL)
      );
      const canonical = buttonIconConfig.findDefaultLabel(original, labels);
      if (canonical) ctx.message.text = canonical;
    }
  }
  return next();
});

  // Navigation always cancels any stale input/wizard state before the
  // destination feature is allowed to handle the same button press.
  bot.use(navigationCancellationMiddleware());

  // Text/photo interceptors — MUST run before bot.hears()/bot.on('text')
  // so mid-flow input (custom submenu editing, userbot phone/OTP,
  // admin product/payment/pool wizards) never falls through to a
  // menu-button match or the "unrecognized command" fallback.
  // Admin Panel reply buttons must be recognized before text-flow middlewares,
  // otherwise a cancel/navigation button could be mistaken for wizard input.
  bot.use(adminReplyMiddleware());
  bot.use(adminBroadcastMiddleware());
  bot.use(customSubmenuTextMiddleware());
  bot.use(adminFlowTextMiddleware());
  bot.use(adminFlowDocumentMiddleware());
  bot.use(ubotLoginTextMiddleware());
  bot.use(tokenClaimTextMiddleware());
  bot.use(panelTextMiddleware());
  bot.on('photo', async (ctx, next) => {
    try {
      if (await handlePaymentProofPhoto(ctx)) return;
    } catch (err) {
      logger.error('Payment proof photo error:', err && err.message ? err.message : err);
      { const c = userResponseTpl.paymentProofFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); }
      return;
    }
    const state = require('./state/panelState').get(ctx.from?.id);
    if (state && state.step === 'await_broadcast_pm') { try { await require('./handlers/panel.handler').handleBroadcastMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    if (state && state.step === 'await_message_media') { try { await handleMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    return next();
  });
  bot.on('video', async (ctx, next) => {
    try {
      if (await handlePaymentProofVideo(ctx)) return;
    } catch (err) {
      logger.error('Payment proof video error:', err && err.message ? err.message : err);
      { const c = userResponseTpl.paymentProofFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); }
      return;
    }
    const state = require('./state/panelState').get(ctx.from?.id);
    if (state && state.step === 'await_broadcast_pm') { try { await require('./handlers/panel.handler').handleBroadcastMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    if (state && state.step === 'await_message_media') { try { await handleMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    return next();
  });
  bot.on('document', async (ctx, next) => {
    try {
      if (await handlePaymentProofDocument(ctx)) return;
    } catch (err) {
      logger.error('Payment proof document error:', err && err.message ? err.message : err);
      { const c = userResponseTpl.paymentProofFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); }
      return;
    }
    const state = require('./state/panelState').get(ctx.from?.id);
    if (state && state.step === 'await_broadcast_pm') { try { await require('./handlers/panel.handler').handleBroadcastMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    if (state && state.step === 'await_message_media') { try { await handleMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    return next();
  });
  for (const mediaType of ['audio','animation','voice','sticker']) {
    bot.on(mediaType, async (ctx, next) => {
      const state = require('./state/panelState').get(ctx.from?.id);
      if (state && state.step === 'await_broadcast_pm') { try { await require('./handlers/panel.handler').handleBroadcastMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
    if (state && state.step === 'await_message_media') { try { await handleMediaInput(ctx, state); return; } catch (e) { logger.error('Panel media input error:', e && e.message ? e.message : e); { const c = userResponseTpl.mediaProcessFailed.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); } return; } }
      return next();
    });
  }
  bot.on('photo', adminFlowPhotoMiddleware());
  bot.on('sticker', adminFlowStickerMiddleware());
  // Wrong-type input inside an admin input step (photo where text is expected,
  // etc.) is answered with the step's own keyboard rather than dropped.
  bot.use(adminFlowMismatchMiddleware());

  // Reply keyboard (main navigation)
  bot.hears(MENU.STORE, storeHandler);
  bot.hears(CATEGORY_LABEL.userbot, storeCategoryPolicyHandler);
  bot.hears(CATEGORY_LABEL.jaseb, storeCategoryPolicyHandler);
  bot.hears(MENU.PERPANJANG_LANGGANAN, storeCategoryPolicyHandler);
  bot.hears(MENU.BUAT_UBOT, ubotHandler);
  bot.hears(MENU.KONTROL_PANEL, panelHandler);
  bot.hears(MENU.FITUR_UNGGULAN, featuresHandler);
  bot.hears(MENU.CLAIM_TRIAL, claimTrialHandler);
  bot.hears(TRIAL_AGREE, trialAgreeHandler);
  bot.hears(TRIAL_TERMS_AGREE, trialTermsAgreeHandler);
  bot.hears(TRIAL_CANCEL, trialCancelHandler);
  bot.hears(MENU.KLAIM_TOKEN, klaimTokenHandler);
  bot.hears(MENU.PANDUAN_BUAT, guideHandler);
  bot.hears(MENU.KEMBALI, backToMainHandler);
  bot.hears(MENU.BATAL, backToMainHandler);
  bot.hears(MENU.ADMIN_PANEL, requireAdmin(adminPanelHandler));
  bot.hears(MENU.ADMIN_STATISTICS, requireAdmin(statisticsHandler));
  bot.hears('👥 Users', requireAdmin(adminUsersCategoryCallback));
  bot.hears('🤖 Userbot', requireAdmin(adminUserbotCategoryCallback));
  bot.hears('🛒 Commerce', requireAdmin(adminCommerceCategoryCallback));
  bot.hears('💳 Order & Payment', requireAdmin(adminOrdersCategoryCallback));
  bot.hears('📢 Notifications', requireAdmin(adminNotificationsCategoryCallback));
  bot.hears('📊 Statistics', requireAdmin(adminStatisticsCategoryCallback));
  bot.hears('⚙️ Settings', requireAdmin(adminSettingsCategoryCallback));
  bot.hears('⚙️ Configuration', requireAdmin(settingsCallback));
  bot.hears('🧾 Transaksi', requireAdmin(transactionHomeCallback));

  // Kontrol Panel — layout follows the reference screenshots. Each handler
  // below is wrapped in requirePanelFeature(id, handler) — the real
  // backend authorization gate (see handlers/panel.handler.js#requireFeature)
  // — right at Telegraf's own dispatch table, so no reply-keyboard label,
  // old callback, or direct command can reach the handler body without
  // going through product feature-entitlement first.
  // Start/Stop are matched ignoring a leading emoji: Telegram may deliver the
  // reply-keyboard label without its icon (e.g. "Stop" for "⏹️ Stop"), which an
  // exact bot.hears(label) never matches -> "Perintah tidak dikenali".
  const labelTrigger = (label) => {
    const semantic = buttonIconConfig.normalizeLabel(label);
    const esc = semantic.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`^(?:[\\p{Extended_Pictographic}\\uFE0F\\u200D]+\\s*)*${esc}\\s*$`, 'u');
  };
  bot.hears(labelTrigger(PANEL_FEATURE.START), requirePanelFeature('auto_promosi', panelStartHandler));
  bot.hears(labelTrigger(PANEL_FEATURE.STOP), requirePanelFeature('auto_promosi', panelStartHandler));
  bot.hears(PANEL_FEATURE.PROMOTION_STATUS, requirePanelFeature('auto_promosi', promotionStatusHandler));
  bot.hears(PANEL_FEATURE.BASE_REPLY, requirePanelFeature('base_reply', baseReplyHandler));
  // Extra is an umbrella screen containing separately-entitled capabilities;
  // individual action handlers below perform the authoritative feature check.
  bot.hears(PANEL_FEATURE.EXTRA, extraHandler);
  bot.hears(PANEL_FEATURE.MESSAGE, requirePanelFeature('message_settings', messageHandler));
  bot.hears(PANEL_FEATURE.GROUP, requirePanelFeature('group_settings', groupHandler));
  bot.hears(PANEL_FEATURE.DELAY, requirePanelFeature('delay_settings', delayHandler));
  bot.hears(PANEL_FEATURE.GUIDE, panelGuideHandler);
  bot.hears(PANEL_FEATURE.REPLY_TOGGLE, requirePanelFeature('base_reply', replyToggleHandler));
  bot.hears(PANEL_FEATURE.ADD_REPLY, requirePanelFeature('base_reply', addReplyHandler));
  bot.hears(PANEL_FEATURE.DELETE_REPLY, requirePanelFeature('base_reply', deleteReplyHandler));
  bot.hears(PANEL_FEATURE.GLOBAL_SETTINGS, requirePanelFeature('base_reply', globalSettingsHandler));
  bot.hears(PANEL_FEATURE.WTB_TIMER, requirePanelFeature('base_reply', wtbTimerHandler));
  bot.hears(PANEL_FEATURE.REPLY_LIST, requirePanelFeature('base_reply', replyListHandler));
  bot.hears(PANEL_FEATURE.AUTO_REACT, requirePanelFeature('base_reply', autoReactHandler));
  bot.hears(PANEL_FEATURE.AUTO_REACT_ENABLE, requirePanelFeature('base_reply', autoReactEnableHandler));
  bot.hears(PANEL_FEATURE.AUTO_REACT_DISABLE, requirePanelFeature('base_reply', autoReactDisableHandler));
  bot.hears(PANEL_FEATURE.AUTO_REACT_CHANGE, requirePanelFeature('base_reply', autoReactChangeHandler));
  bot.hears('🏠 Kembali', backToMainHandler);
  bot.hears('✏️ Ganti Teks / Media', requirePanelFeature('base_reply', globalTextHandler));
  bot.hears('🎯 Ganti Target Channel', requirePanelFeature('base_reply', globalTargetChannelHandler));
  bot.hears('🚫 Ganti Banned Words', requirePanelFeature('base_reply', globalBannedHandler));
  bot.hears('🔢 Maks 70 Karakter', requirePanelFeature('base_reply', globalMaxCharsHandler));
  bot.hears('🔗 Filter Tanpa Link', requirePanelFeature('base_reply', globalFilterLinkHandler));
  bot.hears('👤 Filter Tanpa Username', requirePanelFeature('base_reply', globalFilterUsernameHandler));
  bot.hears(PANEL_FEATURE.AUTO_RESET, requirePanelFeature('base_reply', autoResetHandler));
  bot.hears(PANEL_FEATURE.CHANNEL_DISABLE, requirePanelFeature('base_reply', channelDisableHandler));
  bot.hears(PANEL_FEATURE.MESSAGE_TEXT_MEDIA, requirePanelFeature('message_settings', textMediaHandler));
  bot.hears(PANEL_FEATURE.MESSAGE_FORWARD, requirePanelFeature('message_settings', forwardHandler));
  bot.hears(PANEL_FEATURE.MESSAGE_VIEW, requirePanelFeature('message_settings', viewMessageHandler));
  bot.hears(PANEL_FEATURE.MESSAGE_DELETE, requirePanelFeature('message_settings', deleteMessageHandler));
  bot.hears(PANEL_FEATURE.TOPIC_GROUP, requirePanelFeature('group_settings', topicGroupHandler));
  bot.hears(PANEL_FEATURE.ADD_GROUP, requirePanelFeature('group_settings', addGroupHandler));
  bot.hears(PANEL_FEATURE.DELETE_GROUP, requirePanelFeature('group_settings', deleteGroupHandler));
  bot.hears(PANEL_FEATURE.GROUP_LIST, requirePanelFeature('group_settings', groupListHandler));
  bot.hears(PANEL_FEATURE.JOIN_GROUP, requirePanelFeature('group_settings', joinGroupHandler));
  bot.hears(PANEL_FEATURE.LEAVE_GROUP, requirePanelFeature('group_settings', leaveGroupHandler));
  bot.hears(PANEL_FEATURE.GROUP_DELAY, requirePanelFeature('delay_settings', groupDelayHandler));
  bot.hears(PANEL_FEATURE.ROUND_DELAY, requirePanelFeature('delay_settings', roundDelayHandler));
  bot.hears(PANEL_FEATURE.SMART_DELAY, requirePanelFeature('delay_settings', smartDelayToggleHandler));
  bot.hears(PANEL_FEATURE.BROADCAST_PM, requirePanelFeature('broadcast_pm', broadcastPmHandler));
  bot.hears(PANEL_FEATURE.PM_PERMIT, requirePanelFeature('pm_permit', panelPmPermitHandler));
  bot.hears(PANEL_FEATURE.ADMIN_PANEL, panelAdminHandler);
  bot.hears(PANEL_FEATURE.TIMER, requirePanelFeature('timer', panelTimerHandler));
  bot.hears(PANEL_FEATURE.TIMER_SET, requirePanelFeature('timer', timerSetHandler));
  bot.hears(PANEL_FEATURE.TIMER_ENABLE, requirePanelFeature('timer', timerEnableHandler));
  bot.hears(PANEL_FEATURE.TIMER_DISABLE, requirePanelFeature('timer', timerDisableHandler));
  bot.hears(PANEL_FEATURE.BACKUP_TOKEN, backupTokenHandler);
  bot.hears(PANEL_FEATURE.BACKUP_TOKEN_NEW, backupTokenNewHandler);
  bot.hears(PANEL_FEATURE.BACKUP_TOKEN_CONFIRM, backupTokenConfirmHandler);
  bot.hears(PANEL_FEATURE.CUSTOM_WM, requirePanelFeature('custom_wm', watermarkHandler));
  bot.hears(PANEL_FEATURE.WATERMARK_SET, requirePanelFeature('custom_wm', customWmHandler));
  bot.hears(PANEL_FEATURE.WATERMARK_ENABLE, requirePanelFeature('custom_wm', watermarkEnableHandler));
  bot.hears(PANEL_FEATURE.WATERMARK_DISABLE, requirePanelFeature('custom_wm', watermarkDisableHandler));
  bot.hears(PANEL_FEATURE.CHECK_TOKEN, checkTokenHandler);
  bot.hears(PANEL_FEATURE.TRANSFER_UBOT, requirePanelFeature('transfer_ubot', panelTransferUbotHandler));
  bot.hears(PANEL_FEATURE.RESET_DATA, requirePanelFeature('reset_data', resetDataHandler));
  bot.hears('🏠 Menu Utama', backToMainHandler);

  // ---- Inline keyboard callbacks: navigation ----
  bot.action(CALLBACK.NAV_HOME, navHomeCallback);

  // ---- Store ----
  bot.action(CALLBACK.STORE_HOME, storeHomeCallback);
  bot.action(CALLBACK.STORE_USERBOT, storeUserbotCallback);
  bot.action(CALLBACK.STORE_JASEB, storeJasebCallback);
  bot.action(/^store:cat:/, storeCategoryCallback);
  bot.action(/^store:garansi:/, storeGaransiCallback);
  bot.action(/^store:prod:/, storeProductCallback);
  bot.action(/^store:qty:/, storeQtyCallback);
  bot.action(/^store:policy:/, storePolicyCallback);
  bot.action(/^store:pay:/, storePayCallback);
  bot.action(/^store:paid:/, storePaidCallback);
  bot.action(/^store:resume:/, storeResumeCallback);
  bot.action(/^store:status:/, storeOrderStatusCallback);
  bot.action(CALLBACK.STORE_CANCEL_ALL, storeCancelAllCallback);
  bot.action(CALLBACK.STORE_CANCEL_ALL_YES, storeCancelAllYesCallback);
  bot.action(CALLBACK.STORE_CANCEL_ALL_NO, storeCancelAllNoCallback);
  bot.action(/^store:cancel_yes:/, storeCancelYesCallback);
  bot.action(/^store:cancel_no:/, storeCancelNoCallback);
  bot.action(/^store:cancel:/, storeCancelCallback);

  // ---- Kontrol Panel ----
  bot.action(/^panel:asset:/, panelAssetInlineCallback);
  bot.action(/^panel:promotion:refresh:(owned|pool):\d+$/, requirePanelFeature('auto_promosi', promotionStatusRefreshInlineCallback));
  bot.action(/^panel:promotion:start:(owned|pool):\d+$/, requirePanelFeature('auto_promosi', promotionStatusStartInlineCallback));
  bot.action(/^panel:promotion:stop:(owned|pool):\d+$/, requirePanelFeature('auto_promosi', promotionStatusStopInlineCallback));
  bot.action(/^panel:promotion:back:(owned|pool):\d+$/, promotionStatusBackInlineCallback);
  // ---- Kontrol Panel -> Atur Grup -> Hapus Grup (button-driven delete) ----
  bot.action(/^panelgrp:del:\d+:\d+$/, requirePanelFeature('group_settings', groupDeleteSelectCallback));
  bot.action(/^panelgrp:delpage:\d+:\d+$/, requirePanelFeature('group_settings', groupDeletePageCallback));
  bot.action(/^panelgrp:leavepage:\d+:\d+$/, requirePanelFeature('group_settings', groupLeavePageCallback));
  bot.action(/^panelgrp:leaverefresh:\d+:\d+$/, requirePanelFeature('group_settings', groupLeaveRefreshCallback));
  bot.action(/^panelgrp:leave:\d+:-?\d+$/, requirePanelFeature('group_settings', groupLeaveSelectCallback));
  bot.action(/^panelgrp:leaveall:\d+$/, requirePanelFeature('group_settings', groupLeaveAllCallback));
  bot.action('panelgrp:leaveback', requirePanelFeature('group_settings', groupLeaveBackCallback));
  bot.action(/^panelgrp:list:\d+:\d+$/, requirePanelFeature('group_settings', groupListPageCallback));
  bot.action(/^panelgrp:listrefresh:\d+:\d+$/, requirePanelFeature('group_settings', groupListRefreshCallback));
  bot.action(/^panelgrp:listback$/, requirePanelFeature('group_settings', groupListBackCallback));
  bot.action(/^panelgrp:delconfirm:\d+:\d+$/, requirePanelFeature('group_settings', groupDeleteConfirmCallback));
  bot.action('panelgrp:delall', requirePanelFeature('group_settings', groupDeleteAllCallback));
  bot.action('panelgrp:delallconfirm', requirePanelFeature('group_settings', groupDeleteAllConfirmCallback));
  bot.action('panelgrp:delcancel', requirePanelFeature('group_settings', groupDeleteCancelCallback));

  // ---- Admin Panel -> Settings -> Custom Submenu ----
  bot.action('admin:panel', requireAdmin(adminPanelCallback));
  bot.action(ADMIN_CALLBACK.STATISTICS_HOME, requireAdmin(statisticsCallback));
  bot.action(ADMIN_CALLBACK.STATISTICS_REFRESH, requireAdmin(statisticsRefreshCallback));
  bot.action(STATISTICS_SECTION_CALLBACK_PATTERN, requireAdmin(statisticsSectionCallback));
  bot.action(STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN, requireAdmin(statisticsSectionRefreshCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_HOME, requireAdmin(notificationHomeCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_REGISTRATION_HOME, requireAdmin(notificationRegistrationHomeCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TRANSACTION_HOME, requireAdmin(notificationTransactionHomeCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_SET_REGISTRATION_CHANNEL, requireAdmin(notificationSetRegistrationChannelCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_RESET_REGISTRATION_CHANNEL, requireAdmin(notificationResetRegistrationCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_SET_TRANSACTION_CHANNEL, requireAdmin(notificationSetTransactionChannelCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_RESET_TRANSACTION_CHANNEL, requireAdmin(notificationResetTransactionCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_SET_TRANSACTION_DURATION, requireAdmin(notificationSetDurationCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_CANCEL, requireAdmin(notificationCancelCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_HOME, requireAdmin(testimonialAdmin.testimonialHomeCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_SET_CHANNEL, requireAdmin(testimonialAdmin.testimonialSetChannelCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_SET_BUTTONS, requireAdmin(testimonialAdmin.testimonialSetButtonsCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_CUSTOM, requireAdmin(testimonialAdmin.testimonialCustomCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_PREVIEW, requireAdmin(testimonialAdmin.testimonialPreviewCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_SET_IMAGE, requireAdmin(testimonialAdmin.testimonialSetImageCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_TOGGLE, requireAdmin(testimonialAdmin.testimonialToggleCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_RESET, requireAdmin(testimonialAdmin.testimonialResetCallback));
  bot.action(ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_CANCEL, requireAdmin(testimonialAdmin.testimonialCancelCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_HOME, requireAdmin(broadcastAdmin.broadcastHomeCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_CREATE, requireAdmin(broadcastAdmin.broadcastCreateCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_PREVIEW, requireAdmin(broadcastAdmin.broadcastPreviewCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_ADD_BUTTONS, requireAdmin(broadcastAdmin.broadcastAddButtonsCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_CONFIRM, requireAdmin(broadcastAdmin.broadcastConfirmCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_CANCEL, requireAdmin(broadcastAdmin.broadcastCancelCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_HISTORY, requireAdmin(broadcastAdmin.broadcastHistoryCallback));
  bot.action(ADMIN_CALLBACK.BROADCAST_STATUS, requireAdmin(broadcastAdmin.broadcastStatusCallback));
  bot.action(/^broadcast:draft:-?\d+:\d+$/, requireAdmin(broadcastAdmin.broadcastDraftActionCallback));
  bot.action(/^broadcast:action:\d+:\d+$/, broadcastAdmin.broadcastActionCallback);
  bot.action(ADMIN_CALLBACK.REMINDER_HOME, requireAdmin(reminderAdmin.reminderHomeCallback));
  bot.action(ADMIN_CALLBACK.REMINDER_TOGGLE, requireAdmin(reminderAdmin.reminderToggleCallback));
  bot.action(ADMIN_CALLBACK.REMINDER_SET_THRESHOLDS, requireAdmin(reminderAdmin.reminderSetThresholdsCallback));
  bot.action(ADMIN_CALLBACK.REMINDER_MANUAL_HOME, requireAdmin(reminderAdmin.reminderManualHomeCallback));
  bot.action(/^adminreminder:manual:\d+$/, requireAdmin(reminderAdmin.reminderManualSelectCallback));
  bot.action(/^adminreminder:confirm:\d+:[0-9a-f]{8}$/, requireAdmin(reminderAdmin.reminderManualConfirmCallback));
  bot.action(ADMIN_CALLBACK.REMINDER_CANCEL, requireAdmin(reminderAdmin.reminderCancelCallback));
  bot.action(ADMIN_CALLBACK.PANEL_UBOT_HOME, requireAdmin(panelUbotHomeCallback));
  bot.action(/^adminpanelubot:select:/, requireAdmin(panelUbotSelectCallback));
  bot.action('settings:open', requireAdmin(settingsCallback));
  bot.action(ADMIN_CALLBACK.BUTTON_ICONS_HOME, requireAdmin(buttonIconsHomeCallback));
  bot.action(ADMIN_CALLBACK.BUTTON_ICONS_RESET, requireAdmin(buttonIconsResetCallback));
  bot.action(ADMIN_CALLBACK.BUTTON_ICONS_CANCEL, requireAdmin(buttonIconsCancelCallback));
  bot.action(/^button_icons:pick:(\d+)$/, requireAdmin(buttonIconsPickPageCallback));
  // Tokens are content-derived hashes (see
  // buttonIconConfig.service.js#labelToken), not positional indices —
  // hex, fixed length 10.
  bot.action(/^button_icons:pickselect:([0-9a-f]{10})$/, requireAdmin(buttonIconsPickSelectCallback));
  bot.action(/^button_icons:pickset:([0-9a-f]{10})$/, requireAdmin(buttonIconsPickSetCallback));
  bot.action(/^button_icons:pickremove:([0-9a-f]{10})$/, requireAdmin(buttonIconsPickRemoveCallback));
  bot.action(ADMIN_CALLBACK.SETTINGS_BACKUP_HOME, requireAdmin(settingsBackupHomeCallback));
  bot.action(ADMIN_CALLBACK.SETTINGS_BACKUP_EXPORT, requireAdmin(settingsBackupExportCallback));
  bot.action(ADMIN_CALLBACK.AUTO_BACKUP_HOME, requireAdmin(autoBackupAdmin.autoBackupHomeCallback));
  bot.action(ADMIN_CALLBACK.AUTO_BACKUP_TOGGLE, requireAdmin(autoBackupAdmin.autoBackupToggleCallback));
  bot.action(ADMIN_CALLBACK.AUTO_BACKUP_INTERVAL, requireAdmin(autoBackupAdmin.autoBackupIntervalCallback));
  bot.action(ADMIN_CALLBACK.AUTO_BACKUP_RETENTION, requireAdmin(autoBackupAdmin.autoBackupRetentionCallback));
  bot.action(ADMIN_CALLBACK.AUTO_BACKUP_SEND, requireAdmin(autoBackupAdmin.autoBackupSendCallback));
  bot.action(ADMIN_CALLBACK.AUTO_BACKUP_RUN, requireAdmin(autoBackupAdmin.autoBackupRunCallback));
  bot.action(ADMIN_CALLBACK.SYSTEM_HEALTH_HOME, requireAdmin(systemHealthAdmin.systemHealthHomeCallback));
  bot.action(ADMIN_CALLBACK.SYSTEM_HEALTH_TOGGLE, requireAdmin(systemHealthAdmin.systemHealthToggleCallback));
  bot.action(ADMIN_CALLBACK.SYSTEM_HEALTH_HEARTBEAT, requireAdmin(systemHealthAdmin.systemHealthHeartbeatCallback));
  bot.action(ADMIN_CALLBACK.SYSTEM_HEALTH_CHECK, requireAdmin(systemHealthAdmin.systemHealthCheckCallback));
  bot.action(/^panel:notify:(owned|pool):(\d+)$/, ubotNotifyHandler.notifyScreenCallback);
  bot.action(/^panel:notify:toggle:(owned|pool):(\d+):(channel_bot|channel_saved|channel_owner|on_success|on_fail|on_flood)$/, ubotNotifyHandler.notifyToggleCallback);
  bot.action(ADMIN_CALLBACK.SETTINGS_BACKUP_IMPORT, requireAdmin(settingsBackupImportCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_HOME, requireAdmin(joinGateHomeCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_TOGGLE, requireAdmin(joinGateToggleCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_SET_CHANNEL, requireAdmin(joinGateSetChannelCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_SET_GROUP, requireAdmin(joinGateSetGroupCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_REMOVE_CHANNEL, requireAdmin(joinGateRemoveChannelCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_REMOVE_GROUP, requireAdmin(joinGateRemoveGroupCallback));
  bot.action(ADMIN_CALLBACK.JOIN_GATE_CANCEL, requireAdmin(joinGateCancelCallback));
  bot.action('join_gate:retry', async (ctx) => {
    const allowed = await joinGateService.ensureAccess(ctx);
    if (!allowed) {
      { const c = userResponseTpl.joinNotDetected.getContent(ctx); await ctx.answerCbQuery(c.text, { show_alert: false }); }
      await joinGateService.sendGateMessage(ctx);
      return;
    }
    { const c = userResponseTpl.joinVerified.getContent(ctx); await ctx.answerCbQuery(c.text, { show_alert: false }); }
    try { await ctx.deleteMessage(); } catch (_) {}
    await startHandler(ctx);
  });
  bot.action('custom_submenu:list', requireAdmin(customSubmenuListCallback));
  bot.action(/^custom_submenu:page:(\d+)$/, requireAdmin(customSubmenuPageCallback));
  bot.action(/^custom_submenu:select:(.+)$/, requireAdmin(customSubmenuSelectCallback));
  bot.action(/^custom_submenu:edit:(.+)$/, requireAdmin(customSubmenuEditCallback));
  bot.action(/^custom_submenu:resend:(.+)$/, requireAdmin(customSubmenuResendCallback));
  bot.action(/^custom_submenu:preview:(.+)$/, requireAdmin(customSubmenuPreviewCallback));
  bot.action(/^custom_submenu:save:(.+)$/, requireAdmin(customSubmenuSaveCallback));
  bot.action(/^custom_submenu:reset_confirm:(.+)$/, requireAdmin(customSubmenuResetConfirmCallback));
  bot.action(/^custom_submenu:reset:(.+)$/, requireAdmin(customSubmenuResetCallback));
  bot.action('custom_submenu:cancel', requireAdmin(customSubmenuCancelCallback));
  bot.action(ADMIN_CALLBACK.START_STICKER_HOME, requireAdmin(startStickerHomeCallback));
  bot.action(ADMIN_CALLBACK.START_STICKER_SET, requireAdmin(startStickerSetCallback));
  bot.action(ADMIN_CALLBACK.START_STICKER_REMOVE, requireAdmin(startStickerRemoveCallback));
  bot.action(ADMIN_CALLBACK.START_STICKER_CANCEL, requireAdmin(startStickerCancelCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_SETTINGS_HOME, requireAdmin(trialSettingsHomeCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_SETTINGS_SET, requireAdmin(trialSettingsSetCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_SETTINGS_CANCEL, requireAdmin(trialSettingsCancelCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_FEATURES_HOME, requireAdmin(trialFeaturesHomeCallback));
  bot.action(/^trial_settings:feattoggle:/, requireAdmin(trialFeaturesToggleCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_FEATURES_SAVE, requireAdmin(trialFeaturesSaveCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_FEATURES_RESET, requireAdmin(trialFeaturesResetCallback));
  bot.action(ADMIN_CALLBACK.TRIAL_FEATURES_CANCEL, requireAdmin(trialFeaturesCancelCallback));
  bot.action(ADMIN_CALLBACK.PREMIUM_EMOJI_HOME, requireAdmin(premiumEmojiHomeCallback));
  bot.action(ADMIN_CALLBACK.PREMIUM_EMOJI_SET_GARANSI, requireAdmin(premiumEmojiSetGaransiCallback));
  bot.action(ADMIN_CALLBACK.PREMIUM_EMOJI_SET_NONGARANSI, requireAdmin(premiumEmojiSetNonGaransiCallback));
  bot.action(ADMIN_CALLBACK.PREMIUM_EMOJI_CANCEL, requireAdmin(premiumEmojiCancelCallback));

  // ---- Admin Panel -> User Management ----
  bot.action('adminuser:search', requireAdmin(userSearchCallback));
  bot.action(/^adminuser:searchpage:\d+$/, requireAdmin(userSearchResultsCallback));
  // Legacy callback pattern is intentionally retained for old messages; the
  // handler now resolves the query from per-admin state rather than carrying
  // an unbounded user-provided string inside callback_data.
  bot.action(/^adminuser:searchres:/, requireAdmin(userSearchResultsCallback));
  bot.action('adminuser:searchclear', requireAdmin(userSearchClearCallback));
  bot.action('adminuser:add', requireAdmin(userAddCallback));
  bot.action('adminuser:cancel', requireAdmin(userCancelCallback));
  bot.action(/^adminuser:list:/, requireAdmin(userListCallback));
  bot.action(/^adminuser:view:/, requireAdmin(userViewCallback));
  bot.action(/^adminuser:resettrial:/, requireAdmin(userResetTrialCallback));
  bot.action(/^adminuser:banskip:/, requireAdmin(userBanReasonSkipCallback));
  bot.action(/^adminuser:ban:/, requireAdmin(userBanCallback));
  bot.action(/^adminuser:unban:/, requireAdmin(userUnbanCallback));
  bot.action(/^adminuser:delconfirm:/, requireAdmin(userDeleteConfirmCallback));
  bot.action(/^adminuser:del:/, requireAdmin(userDeleteCallback));

  // ---- Admin Panel -> Produk Management ----
  bot.action(ADMIN_CALLBACK.PRODUCT_HOME, requireAdmin(productHomeCallback));
  bot.action(/^adminproduct:cat:/, requireAdmin(productCatCallback));
  bot.action(/^adminproduct:list:/, requireAdmin(productListCallback));
  bot.action(/^adminproduct:view:/, requireAdmin(productViewCallback));
  bot.action(/^adminproduct:add:/, requireAdmin(productAddCallback));
  bot.action(/^adminproduct:addgaransi:/, requireAdmin(productAddGaransiCallback));
  bot.action(ADMIN_CALLBACK.PRODUCT_ADD_DESC_SKIP, requireAdmin(productAddDescSkipCallback));
  bot.action(/^adminproduct:addfeat:/, requireAdmin(productAddFeatureToggleCallback));
  bot.action(ADMIN_CALLBACK.PRODUCT_ADD_FEATURE_DONE, requireAdmin(productAddFeatureDoneCallback));
  bot.action(ADMIN_CALLBACK.PRODUCT_ADD_FEATURE_SKIP, requireAdmin(productAddFeatureSkipCallback));
  bot.action(/^adminproduct:edit:/, requireAdmin(productEditCallback));
  bot.action(/^adminproduct:editfield:/, requireAdmin(productEditFieldCallback));
  bot.action(/^adminproduct:editgaransi:/, requireAdmin(productEditGaransiCallback));
  bot.action(/^adminproduct:editdescskip:/, requireAdmin(productEditDescSkipCallback));
  bot.action(/^adminproduct:editfeatsave:/, requireAdmin(productEditFeatureSaveCallback));
  bot.action(/^adminproduct:editfeatcancel:/, requireAdmin(productEditFeatureCancelCallback));
  bot.action(/^adminproduct:editfeat:/, requireAdmin(productEditFeatureToggleCallback));
  bot.action(/^adminproduct:toggle:/, requireAdmin(productToggleCallback));
  bot.action(/^adminproduct:delconfirm:/, requireAdmin(productDeleteConfirmCallback));
  bot.action(/^adminproduct:del:/, requireAdmin(productDeleteCallback));
  bot.action(ADMIN_CALLBACK.PRODUCT_CANCEL, requireAdmin(productCancelCallback));

  // ---- Admin Panel -> Payment ----
  bot.action(ADMIN_CALLBACK.PAYMENT_HOME, requireAdmin(paymentHomeCallback));
  bot.action(ADMIN_CALLBACK.PAYMENT_SET_QRIS, requireAdmin(paymentSetQrisCallback));
  bot.action(ADMIN_CALLBACK.PAYMENT_SET_NOTE, requireAdmin(paymentSetNoteCallback));
  bot.action(ADMIN_CALLBACK.PAYMENT_SET_BANK, requireAdmin(paymentSetBankCallback));
  bot.action(ADMIN_CALLBACK.PAYMENT_CANCEL, requireAdmin(paymentCancelCallback));

  // ---- Admin Panel -> Produk Management -> Stok Userbot Jaseb ----
  bot.action(ADMIN_CALLBACK.POOL_HOME, requireAdmin(poolHomeCallback));
  bot.action(ADMIN_CALLBACK.POOL_ADD, requireAdmin(poolAddCallback));
  bot.action(ADMIN_CALLBACK.POOL_ADD_PHONE, requireAdmin(poolAddPhoneCallback));
  bot.action(ADMIN_CALLBACK.POOL_ADD_SESSION, requireAdmin(poolAddSessionCallback));
  bot.action(/^adminpool:view:\d+$/, requireAdmin(poolViewCallback));
  bot.action(/^adminpool:delconfirm:\d+$/, requireAdmin(poolDeleteConfirmCallback));
  bot.action(/^adminpool:del:\d+$/, requireAdmin(poolDeleteCallback));
  bot.action(ADMIN_CALLBACK.POOL_CANCEL, requireAdmin(poolCancelCallback));

  // ---- Admin Panel -> Transaksi ----
  bot.action(ADMIN_CALLBACK.TRANSACTIONS_HOME, requireAdmin(transactionHomeCallback));
  bot.action(/^admintrx:list:\d+$/, requireAdmin(transactionListCallback));
  bot.action(/^admintrx:view:\d+$/, requireAdmin(transactionViewCallback));
  bot.action(/^admintrx:proof:\d+$/, requireAdmin(transactionProofCallback));
  bot.action(/^admintrx:approve:\d+$/, requireAdmin(transactionApproveCallback));
  bot.action(/^admintrx:reject:\d+$/, requireAdmin(transactionRejectCallback));

  // ---- Admin Panel -> Settings -> Perpanjang Langganan Userbot ----
  bot.action(ADMIN_CALLBACK.SUBEXT_HOME, requireAdmin(subExt.subextHomeCallback));
  bot.action(/^subext:list:/, requireAdmin(subExt.subextListCallback));
  bot.action(/^subext:sel:\d+$/, requireAdmin(subExt.subextSelectCallback));
  bot.action(/^subext:pick:\d+:\d+$/, requireAdmin(subExt.subextPickCallback));
  bot.action(/^subext:custom:\d+$/, requireAdmin(subExt.subextCustomCallback));
  bot.action(/^subext:go:\d+:\d+:[0-9a-f]{8}$/, requireAdmin(subExt.subextGoCallback));
  bot.action(ADMIN_CALLBACK.SUBEXT_CANCEL, requireAdmin(subExt.subextCancelCallback));

  // ---- User renewal entry (stable id; emoji/label independent) ----
  bot.action(/^subscription:renew:\d+$/, subscriptionRenewCallback);

  // ---- Order confirmation (sent to admins when a buyer marks "Sudah Bayar") ----
  bot.action(/^adminorder:confirm:/, requireAdmin(adminOrderConfirmCallback));
  bot.action(/^adminorder:reject:/, requireAdmin(adminOrderRejectCallback));

  // Fallback for unrecognized text/input so the bot never appears "stuck"
  bot.on('text', async (ctx) => {
    { const c = userResponseTpl.unknownCommand.getContent(ctx); await ctx.reply(c.text, require('./services/custom-submenu.service').buildReplyOptions(c)); }
    logger.warn(`Unhandled text from user ${ctx.from.id}: "${ctx.message.text}"`);
  });

  // Global error handler — never crash, never leak internals. Most handlers
  // are wrapped by safeHandler, but this catches failures thrown by middleware
  // or routing before/around the final handler. The response tracker prevents
  // a duplicate generic message after a successful user-visible reply.
  bot.catch(async (err, ctx) => {
    logger.error(`Unhandled error for update ${ctx.updateType}:`, err);
    if (ctx.state?.__responseSent) return;
    if (typeof ctx.reply !== 'function') return;
    try {
      { const safe = getSafeErrorContent(ctx); await ctx.reply(safe.text, safe.options); }
    } catch (replyErr) {
      logger.error('Global error fallback reply failed:', replyErr);
    }
  });

  let shutdownPromise = null;
  const shutdown = (signal) => {
    if (shutdownPromise) return shutdownPromise;
    shutdownPromise = (async () => {
      logger.info(`Received ${signal}, shutting down...`);
      stopScheduler();
      try {
        await userbotRuntime.shutdownAll();
      } catch (err) {
        logger.error('Userbot runtime shutdown error:', err && err.message ? err.message : err);
      }
      try {
        bot.stop(signal);
      } catch (err) {
        logger.error('Bot stop failed:', err && err.message ? err.message : err);
      }
    })();
    return shutdownPromise;
  };

  process.once('SIGINT', () => shutdown('SIGINT').finally(() => process.exit(0)));
  process.once('SIGTERM', () => shutdown('SIGTERM').finally(() => process.exit(0)));

  bot
    .launch()
    .then(async () => {
      logger.info('Bot started');
      userbotLifecycle.setTelegram(bot.telegram);
      startScheduler(bot.telegram);
      // Restart recovery: ACTIVE rows are restored from the DB, EXPIRED rows
      // are never started (runtime liveness is derived from expires_at).
      try {
        await userbotRuntime.bootstrapAll();
      } catch (err) {
        logger.error('Userbot runtime bootstrap failed:', err && err.message ? err.message : err);
      }
    })
    .catch((err) => {
      logger.error('Failed to start bot:', err && err.message ? err.message : err);
      process.exit(1);
    });
}

if (require.main === module) {
  main();
}

module.exports = { main };
