/**
 * Single source of truth for ADMIN input-mode navigation.
 *
 * Every adminState.action that waits for user input is described here:
 *
 *   kind     what the step accepts (text | contact | photo | sticker | document)
 *   cancel   legacy/internal cancellation route key; UI always renders MENU.BATAL
 *   prev     previous WIZARD STEP (Kembali -> that step, state preserved)
 *   parent   screen Kembali returns to when there is no previous step
 *   skip     label of an optional-step "Lewati" button (optional fields only)
 *   contact  true when the step offers the "Kontak Saya" request button
 *   dropLogin true when leaving the step must cancel a pending GramJS login
 *
 * Semantics (never conflated):
 *   Batal   = abort the whole operation, clear state, go to the parent.
 *   Kembali = one step back; prior valid data stays in state.
 *   Lewati  = only where the business logic allows an empty value.
 *
 * This module is pure data (no telegraf/db imports) so it is unit-testable.
 */
const { ADMIN_CALLBACK: C } = require('./admin.callback');
const { MENU } = require('./menu');

const BACK_LABEL = MENU.KEMBALI;
const CANCEL_LABEL = MENU.BATAL;
const SKIP_DESC_LABEL = '⏭️ Lewati Deskripsi';
const SKIP_REASON_LABEL = '⏭️ Lewati Alasan';

const CANCEL = {
  product: '❌ Batal Produk',
  payment: '❌ Batal Payment',
  pool: '❌ Batal Stok',
  sticker: '❌ Batal Sticker',
  trial: '❌ Batal Durasi',
  trialFeatures: '❌ Batal Akses Fitur',
  emoji: '❌ Batal Emoji',
  joinGate: '❌ Batal Wajib Join',
  user: '❌ Batal User',
  subext: '❌ Batal Perpanjang',
  notification: '❌ Batal Notifikasi',
  buttonIcon: '❌ Batal Custom Icon',
  backup: '❌ Batal Import',
  custom: '❌ Batal Custom Submenu',
  broadcast: '❌ Batal Broadcast',
  reminder: '❌ Batal Reminder',
};

const FLOWS = {
  // ---- Product: add wizard (name -> price -> duration -> garansi -> desc -> features)
  admin_product_add_name: { kind: 'text', cancel: CANCEL.product, parent: (s) => C.PRODUCT_CAT(s.category) },
  admin_product_add_price: { kind: 'text', cancel: CANCEL.product, prev: 'admin_product_add_name' },
  admin_product_add_duration: { kind: 'text', cancel: CANCEL.product, prev: 'admin_product_add_price' },
  admin_product_add_garansi: { kind: 'choice', cancel: CANCEL.product, prev: 'admin_product_add_duration' },
  admin_product_add_desc: { kind: 'text', cancel: CANCEL.product, prev: 'admin_product_add_garansi', skip: SKIP_DESC_LABEL },
  admin_product_add_features: { kind: 'choice', cancel: CANCEL.product, prev: 'admin_product_add_desc' },
  // ---- Product: edit
  admin_product_edit_value: { kind: 'text', cancel: CANCEL.product, parent: (s) => C.PRODUCT_EDIT(s.productId) },
  admin_product_edit_features: { kind: 'choice', cancel: CANCEL.product, parent: (s) => C.PRODUCT_EDIT(s.productId) },
  // ---- Payment
  admin_payment_qris_photo: { kind: 'photo', cancel: CANCEL.payment, parent: () => C.PAYMENT_HOME },
  admin_payment_note: { kind: 'text', cancel: CANCEL.payment, parent: () => C.PAYMENT_HOME },
  admin_payment_bank: { kind: 'text', cancel: CANCEL.payment, parent: () => C.PAYMENT_HOME },
  // ---- Userbot pool onboarding (method -> label -> phone/session -> otp -> [2fa])
  admin_pool_method: { kind: 'choice', cancel: CANCEL.pool, parent: () => C.POOL_HOME },
  admin_pool_label: { kind: 'text', cancel: CANCEL.pool, prev: 'admin_pool_method' },
  admin_pool_phone: { kind: 'text', cancel: CANCEL.pool, prev: 'admin_pool_label', contact: true },
  admin_pool_session: { kind: 'text', cancel: CANCEL.pool, prev: 'admin_pool_method' },
  admin_pool_otp: { kind: 'text', cancel: CANCEL.pool, prev: 'admin_pool_phone', dropLogin: true },
  admin_pool_password: { kind: 'text', cancel: CANCEL.pool, prev: 'admin_pool_phone', dropLogin: true },
  // ---- User management
  admin_user_search: { kind: 'text', cancel: CANCEL.user, parent: () => C.USER_LIST(0) },
  admin_user_add: { kind: 'text', cancel: CANCEL.user, parent: () => C.USER_LIST(0) },
  admin_user_ban_reason: { kind: 'text', cancel: CANCEL.user, skip: SKIP_REASON_LABEL, parent: (s) => C.USER_VIEW(s.telegramId) },
  // ---- Settings
  admin_start_sticker: { kind: 'sticker', cancel: CANCEL.sticker, parent: () => C.START_STICKER_HOME },
  admin_trial_duration: { kind: 'text', cancel: CANCEL.trial, parent: () => C.TRIAL_SETTINGS_HOME },
  admin_trial_features: { kind: 'choice', cancel: CANCEL.trialFeatures, parent: () => C.TRIAL_SETTINGS_HOME },
  admin_premium_emoji_garansi: { kind: 'text', cancel: CANCEL.emoji, parent: () => C.PREMIUM_EMOJI_HOME },
  admin_premium_emoji_nongaransi: { kind: 'text', cancel: CANCEL.emoji, parent: () => C.PREMIUM_EMOJI_HOME },
  admin_join_gate_channel: { kind: 'text', cancel: CANCEL.joinGate, parent: () => C.JOIN_GATE_HOME },
  admin_join_gate_group: { kind: 'text', cancel: CANCEL.joinGate, parent: () => C.JOIN_GATE_HOME },
  admin_button_icon_set: { kind: 'text', cancel: CANCEL.buttonIcon, parent: (s) => C.BUTTON_ICONS_PICK_SELECT(s.token) },
  admin_settings_backup_import: { kind: 'document', cancel: CANCEL.backup, parent: () => C.SETTINGS_BACKUP_HOME },
  admin_subext_custom: { kind: 'text', cancel: CANCEL.subext, parent: (s) => C.SUBEXT_SELECT(s.userbotId) },
  admin_notification_registration_channel: { kind: 'text', cancel: CANCEL.notification, parent: () => C.NOTIFICATION_REGISTRATION_HOME },
  admin_notification_transaction_channel: { kind: 'text', cancel: CANCEL.notification, parent: () => C.NOTIFICATION_TRANSACTION_HOME },
  admin_notification_transaction_duration: { kind: 'text', cancel: CANCEL.notification, parent: () => C.NOTIFICATION_TRANSACTION_HOME },
  admin_notification_testimonial_channel: { kind: 'text', cancel: CANCEL.notification, parent: () => C.NOTIFICATION_TESTIMONIAL_HOME },
  admin_notification_testimonial_buttons: { kind: 'text', cancel: CANCEL.notification, parent: () => C.NOTIFICATION_TESTIMONIAL_HOME },
  admin_notification_testimonial_image: { kind: 'photo', cancel: CANCEL.notification, parent: () => C.NOTIFICATION_TESTIMONIAL_HOME },
  // ---- Custom submenu (returnTo decides the screen, see resolveCustomParent)
  waiting_for_custom_text: { kind: 'text', cancel: CANCEL.custom, parent: (s) => resolveCustomParent(s) },
  previewing: { kind: 'choice', cancel: CANCEL.custom, prev: 'waiting_for_custom_text' },
  admin_broadcast_content: { kind: 'content', cancel: CANCEL.broadcast, parent: () => C.BROADCAST_HOME },
  admin_broadcast_buttons: { kind: 'text', cancel: CANCEL.broadcast, parent: () => C.BROADCAST_HOME },
  admin_reminder_thresholds: { kind: 'text', cancel: CANCEL.reminder, parent: () => C.REMINDER_HOME },
};

function resolveCustomParent(state) {
  return state && state.returnTo === 'status' && state.submenuId
    ? C.CUSTOM_SUBMENU_SELECT(state.submenuId)
    : C.CUSTOM_SUBMENU_LIST;
}

function getFlow(action) {
  return Object.prototype.hasOwnProperty.call(FLOWS, action) ? FLOWS[action] : null;
}

/**
 * Buttons (in render order) for a step. Pure: returns descriptors, the
 * keyboard module turns them into replyButton.* with icon resolution.
 */
function navSpec(state) {
  const flow = state && getFlow(state.action);
  if (!flow) return [];
  const rows = [];
  if (flow.contact) rows.push([{ type: 'contact', label: '💬 Kontak Saya' }]);
  if (flow.skip) rows.push([{ type: 'skip', label: flow.skip }]);
  rows.push([{ type: 'back', label: BACK_LABEL }, { type: 'cancel', label: CANCEL_LABEL }]);
  return rows;
}

/** Stable signature of the reply keyboard a step shows (for change detection). */
function navSignature(state) {
  return JSON.stringify(navSpec(state));
}

/**
 * Resolve what "Kembali" must do for the current state.
 *   { kind: 'step',   action, dropLogin }   -> re-enter previous wizard step
 *   { kind: 'parent', callback, dropLogin } -> go to parent screen, clear state
 *   null                                    -> state is not a known input step
 */
function resolveBack(state) {
  const flow = state && getFlow(state.action);
  if (!flow) return null;
  if (flow.prev) return { kind: 'step', action: flow.prev, dropLogin: Boolean(flow.dropLogin) };
  return { kind: 'parent', callback: flow.parent(state), dropLogin: Boolean(flow.dropLogin) };
}

/** Where Batal returns to (the routes themselves live in adminReply). */
function cancelLabelFor(state) {
  const flow = state && getFlow(state.action);
  return flow ? flow.cancel : null;
}

module.exports = { FLOWS, BACK_LABEL, CANCEL_LABEL, SKIP_DESC_LABEL, SKIP_REASON_LABEL, getFlow, navSpec, navSignature, resolveBack, cancelLabelFor };
