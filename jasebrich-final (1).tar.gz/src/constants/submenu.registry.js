/**
 * Runtime registry for every editable user-facing message/submenu.
 * The existing Custom Submenu storage is intentionally reused: each entry is
 * a stable template context, not a second template engine.
 */
const { contentToken } = require('../utils/callbackToken');

const registry = [];

function defaultMaxLengthForMessageType(messageType) {
  switch (String(messageType || 'text')) {
    case 'callback_alert': return 200;
    case 'caption':
    case 'caption_or_text': return 1024;
    default: return 4096;
  }
}

function normalizeEntry(entry) {
  if (!entry || !entry.id || !entry.label) {
    throw new Error('submenuRegistry.register requires { id, label }');
  }
  const normalized = {
    scope: 'USER',
    feature: 'Umum',
    messageType: 'text',
    editable: true,
    supportedPlaceholders: [],
    defaultValue: null,
    parseMode: 'Markdown',
    ...entry,
  };

  if (normalized.defaultValue == null) {
    throw new Error(`submenuRegistry entry "${normalized.id}" must define a real defaultValue`);
  }
  if (normalized.editable !== false && normalized.scope === 'USER' && typeof normalized.defaultValue !== 'string' && typeof normalized.defaultValue !== 'function') {
    throw new Error(`submenuRegistry entry "${normalized.id}" has an invalid defaultValue`);
  }

  const requestedMax = normalized.maxLength;
  const maxLength = requestedMax == null
    ? defaultMaxLengthForMessageType(normalized.messageType)
    : Number(requestedMax);
  if (!Number.isInteger(maxLength) || maxLength <= 0) {
    throw new Error(`submenuRegistry entry "${normalized.id}" has invalid maxLength: ${requestedMax}`);
  }

  normalized.maxLength = maxLength;
  normalized.supportedPlaceholders = Array.isArray(normalized.supportedPlaceholders)
    ? normalized.supportedPlaceholders.map((x) => String(x).replace(/^\{|\}$/g, ''))
    : [];
  return normalized;
}

function register(entry) {
  const normalized = normalizeEntry(entry);
  if (registry.some((s) => s.id === normalized.id)) return;
  const token = contentToken(normalized.id);
  const collision = registry.find((s) => contentToken(s.id) === token && s.id !== normalized.id);
  if (collision) {
    throw new Error(`submenuRegistry callback token collision between "${collision.id}" and "${normalized.id}".`);
  }
  registry.push(normalized);
}
function getAll({ scope = null } = {}) {
  const rows = [...registry];
  return scope ? rows.filter((entry) => entry.scope === scope) : rows;
}
function getById(id) { return registry.find((s) => s.id === id) || null; }
function exists(id) { return registry.some((s) => s.id === id); }

/**
 * Resolve both canonical submenu ids (legacy callbacks) and compact
 * content-derived callback tokens (current callbacks). The registry is the
 * source of truth, so no mutable runtime token map is required.
 */
function resolveCallbackId(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const direct = getById(raw);
  if (direct) return direct.id;
  const match = registry.find((entry) => contentToken(entry.id) === raw);
  return match ? match.id : null;
}

function getCallbackToken(id) {
  const entry = getById(id);
  if (!entry) return null;
  return contentToken(entry.id);
}

module.exports = { register, getAll, getById, exists, resolveCallbackId, getCallbackToken, defaultMaxLengthForMessageType };
