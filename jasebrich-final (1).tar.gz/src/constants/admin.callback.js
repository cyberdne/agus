const { contentToken } = require('../utils/callbackToken');

// Callback naming convention: namespace:action[:id]
const ADMIN_CALLBACK = {
  PANEL_HOME: 'admin:panel',
  STATISTICS_HOME: 'admin:statistics',
  STATISTICS_REFRESH: 'admin:statistics:refresh',
  STATISTICS_SECTION: (section) => `admin:statistics:section:${section}`,
  STATISTICS_SECTION_REFRESH: (section) => `admin:statistics:section:${section}:refresh`,

  NOTIFICATION_HOME: 'notification:home',
  NOTIFICATION_REGISTRATION_HOME: 'notification:registration',
  NOTIFICATION_TRANSACTION_HOME: 'notification:transaction',
  NOTIFICATION_SET_REGISTRATION_CHANNEL: 'notification:set_registration_channel',
  NOTIFICATION_RESET_REGISTRATION_CHANNEL: 'notification:reset_registration_channel',
  NOTIFICATION_SET_TRANSACTION_CHANNEL: 'notification:set_transaction_channel',
  NOTIFICATION_RESET_TRANSACTION_CHANNEL: 'notification:reset_transaction_channel',
  NOTIFICATION_SET_TRANSACTION_DURATION: 'notification:set_transaction_duration',
  NOTIFICATION_CANCEL: 'notification:cancel',
  NOTIFICATION_TESTIMONIAL_HOME: 'notification:testimonial',
  NOTIFICATION_TESTIMONIAL_SET_CHANNEL: 'notification:testimonial_set_channel',
  NOTIFICATION_TESTIMONIAL_SET_BUTTONS: 'notification:testimonial_set_buttons',
  NOTIFICATION_TESTIMONIAL_SET_IMAGE: 'notification:testimonial_set_image',
  NOTIFICATION_TESTIMONIAL_TOGGLE: 'notification:testimonial_toggle',
  NOTIFICATION_TESTIMONIAL_CUSTOM: 'notification:testimonial_custom',
  NOTIFICATION_TESTIMONIAL_PREVIEW: 'notification:testimonial_preview',
  NOTIFICATION_TESTIMONIAL_RESET: 'notification:testimonial_reset',
  NOTIFICATION_TESTIMONIAL_CANCEL: 'notification:testimonial_cancel',

  SETTINGS_OPEN: 'settings:open',
  BUTTON_ICONS_HOME: 'button_icons:home',
  BUTTON_ICONS_SET: 'button_icons:set',
  BUTTON_ICONS_RESET: 'button_icons:reset',
  BUTTON_ICONS_CANCEL: 'button_icons:cancel',
  // Practical "pick a button, then just send the emoji" flow — the
  // picker callback uses stable content-derived tokens rather than mutable
  // positional indexes.
  BUTTON_ICONS_PICK_PAGE: (page = 0) => `button_icons:pick:${page}`,
  // Carries a stable content-derived token (see
  // buttonIconConfig.service.js#labelToken), NOT a positional array
  // index — see that file for why a positional index is unsafe here.
  BUTTON_ICONS_PICK_SELECT: (token) => `button_icons:pickselect:${token}`,
  BUTTON_ICONS_PICK_SET: (token) => `button_icons:pickset:${token}`,
  BUTTON_ICONS_PICK_REMOVE: (token) => `button_icons:pickremove:${token}`,

  JOIN_GATE_HOME: 'join_gate:home',
  JOIN_GATE_TOGGLE: 'join_gate:toggle',
  JOIN_GATE_SET_CHANNEL: 'join_gate:set_channel',
  JOIN_GATE_SET_GROUP: 'join_gate:set_group',
  JOIN_GATE_REMOVE_CHANNEL: 'join_gate:remove_channel',
  JOIN_GATE_REMOVE_GROUP: 'join_gate:remove_group',
  JOIN_GATE_CANCEL: 'join_gate:cancel',

  CUSTOM_SUBMENU_LIST: 'custom_submenu:list',
  CUSTOM_SUBMENU_PAGE: (page = 0) => `custom_submenu:page:${page}`,
  CUSTOM_SUBMENU_SELECT: (id) => `custom_submenu:select:${contentToken(id)}`,
  CUSTOM_SUBMENU_EDIT: (id) => `custom_submenu:edit:${contentToken(id)}`,
  CUSTOM_SUBMENU_PREVIEW: (id) => `custom_submenu:preview:${contentToken(id)}`,
  CUSTOM_SUBMENU_SAVE: (id) => `custom_submenu:save:${contentToken(id)}`,
  CUSTOM_SUBMENU_RESEND: (id) => `custom_submenu:resend:${contentToken(id)}`,
  CUSTOM_SUBMENU_RESET: (id) => `custom_submenu:reset:${contentToken(id)}`,
  CUSTOM_SUBMENU_RESET_CONFIRM: (id) => `custom_submenu:reset_confirm:${contentToken(id)}`,
  CUSTOM_SUBMENU_CANCEL: 'custom_submenu:cancel',

  START_STICKER_HOME: 'start_sticker:home',
  START_STICKER_SET: 'start_sticker:set',
  START_STICKER_REMOVE: 'start_sticker:remove',
  START_STICKER_CANCEL: 'start_sticker:cancel',

  TRIAL_SETTINGS_HOME: 'trial_settings:home',
  TRIAL_SETTINGS_SET: 'trial_settings:set',
  TRIAL_SETTINGS_CANCEL: 'trial_settings:cancel',
  // --- Trial -> Feature Access (staged: toggle freely, then explicit
  // Save/Cancel — same shape as PRODUCT_EDIT_FEATURE_* below).
  TRIAL_FEATURES_HOME: 'trial_settings:features',
  TRIAL_FEATURES_TOGGLE: (featureId) => `trial_settings:feattoggle:${featureId}`,
  TRIAL_FEATURES_SAVE: 'trial_settings:featsave',
  TRIAL_FEATURES_CANCEL: 'trial_settings:featcancel',
  TRIAL_FEATURES_RESET: 'trial_settings:featreset',

  PREMIUM_EMOJI_HOME: 'premium_emoji:home',
  PREMIUM_EMOJI_SET_GARANSI: 'premium_emoji:set_garansi',
  PREMIUM_EMOJI_SET_NONGARANSI: 'premium_emoji:set_nongaransi',
  PREMIUM_EMOJI_CANCEL: 'premium_emoji:cancel',

  SETTINGS_BACKUP_HOME: 'settings_backup:home',
  SETTINGS_BACKUP_EXPORT: 'settings_backup:export',
  SETTINGS_BACKUP_IMPORT: 'settings_backup:import',
  AUTO_BACKUP_HOME: 'settings_backup:auto',
  AUTO_BACKUP_TOGGLE: 'settings_backup:auto:toggle',
  AUTO_BACKUP_INTERVAL: 'settings_backup:auto:interval',
  AUTO_BACKUP_RETENTION: 'settings_backup:auto:retention',
  AUTO_BACKUP_SEND: 'settings_backup:auto:send',
  AUTO_BACKUP_RUN: 'settings_backup:auto:run',
  SYSTEM_HEALTH_HOME: 'settings_backup:health',
  SYSTEM_HEALTH_TOGGLE: 'settings_backup:health:toggle',
  SYSTEM_HEALTH_HEARTBEAT: 'settings_backup:health:heartbeat',
  SYSTEM_HEALTH_CHECK: 'settings_backup:health:check',
  // --- User Management ---
  USER_LIST: (page = 0) => `adminuser:list:${page}`,
  USER_VIEW: (telegramId) => `adminuser:view:${telegramId}`,
  USER_BAN: (telegramId) => `adminuser:ban:${telegramId}`,
  USER_BAN_REASON_SKIP: (telegramId) => `adminuser:banskip:${telegramId}`,
  USER_UNBAN: (telegramId) => `adminuser:unban:${telegramId}`,
  USER_RESET_TRIAL: (telegramId) => `adminuser:resettrial:${telegramId}`,
  USER_DEL_CONFIRM: (telegramId) => `adminuser:delconfirm:${telegramId}`,
  USER_DEL: (telegramId) => `adminuser:del:${telegramId}`,
  USER_SEARCH: 'adminuser:search',
  USER_SEARCH_PAGE: (page = 0) => `adminuser:searchpage:${page}`,
  USER_SEARCH_RESULTS: (query, page = 0) => `adminuser:searchpage:${page}`, // legacy alias; query is now kept in adminState
  USER_SEARCH_CLEAR: 'adminuser:searchclear',
  USER_ADD: 'adminuser:add',
  USER_CANCEL: 'adminuser:cancel',

  // --- Product Management ---
  PRODUCT_HOME: 'adminproduct:home',
  PRODUCT_CAT: (cat) => `adminproduct:cat:${cat}`,
  PRODUCT_LIST: (cat, page = 0) => `adminproduct:list:${cat}:${page}`,
  PRODUCT_VIEW: (id) => `adminproduct:view:${id}`,
  PRODUCT_ADD: (cat) => `adminproduct:add:${cat}`,
  // Interactive Add Product wizard step buttons (garansi Ya/Tidak, skip
  // deskripsi) — name/harga/durasi/deskripsi are captured via text.
  PRODUCT_ADD_GARANSI: (value) => `adminproduct:addgaransi:${value}`,
  PRODUCT_ADD_DESC_SKIP: 'adminproduct:adddescskip',
  // Add Product wizard — Feature Access checklist (final step before create).
  PRODUCT_ADD_FEATURE_TOGGLE: (featureId) => `adminproduct:addfeat:${featureId}`,
  PRODUCT_ADD_FEATURE_DONE: 'adminproduct:addfeatdone',
  PRODUCT_ADD_FEATURE_SKIP: 'adminproduct:addfeatskip',
  PRODUCT_EDIT: (id) => `adminproduct:edit:${id}`,
  // Per-field edit: pick which field, then either type the new value
  // (name/description/price/duration) or pick Ya/Tidak (garansi).
  PRODUCT_EDIT_FIELD: (id, field) => `adminproduct:editfield:${id}:${field}`,
  PRODUCT_EDIT_GARANSI: (id, value) => `adminproduct:editgaransi:${id}:${value}`,
  PRODUCT_EDIT_DESC_SKIP: (id) => `adminproduct:editdescskip:${id}`,
  // Edit Product — Feature Access checklist (staged: toggle freely, then
  // explicit Save or Cancel — unlike garansi, which applies instantly).
  PRODUCT_EDIT_FEATURE_TOGGLE: (id, featureId) => `adminproduct:editfeat:${id}:${featureId}`,
  PRODUCT_EDIT_FEATURE_SAVE: (id) => `adminproduct:editfeatsave:${id}`,
  PRODUCT_EDIT_FEATURE_CANCEL: (id) => `adminproduct:editfeatcancel:${id}`,
  PRODUCT_TOGGLE: (id) => `adminproduct:toggle:${id}`,
  PRODUCT_DEL_CONFIRM: (id) => `adminproduct:delconfirm:${id}`,
  PRODUCT_DEL: (id) => `adminproduct:del:${id}`,
  PRODUCT_CANCEL: 'adminproduct:cancel',

  // --- Payment ---
  PAYMENT_HOME: 'adminpayment:home',
  PAYMENT_SET_QRIS: 'adminpayment:setqris',
  PAYMENT_SET_NOTE: 'adminpayment:setnote',
  PAYMENT_SET_BANK: 'adminpayment:setbank',
  PAYMENT_CANCEL: 'adminpayment:cancel',

  // --- Kontrol Panel access from Admin Panel (control ANY userbot) ---
  PANEL_UBOT_HOME: 'adminpanelubot:home',
  PANEL_UBOT_SELECT: (kind, id) => `adminpanelubot:select:${kind}:${id}`,

  // --- Admin Broadcast ---
  BROADCAST_HOME: 'adminbroadcast:home',
  BROADCAST_CREATE: 'adminbroadcast:create',
  BROADCAST_PREVIEW: 'adminbroadcast:preview',
  BROADCAST_ADD_BUTTONS: 'adminbroadcast:addbuttons',
  BROADCAST_CONFIRM: 'adminbroadcast:confirm',
  BROADCAST_CANCEL: 'adminbroadcast:cancel',
  BROADCAST_HISTORY: 'adminbroadcast:history',
  BROADCAST_STATUS: 'adminbroadcast:status',
  BROADCAST_DRAFT_ACTION: (adminId, index) => `broadcast:draft:${adminId}:${index}`,
  BROADCAST_ACTION: (jobId, index) => `broadcast:action:${jobId}:${index}`,

  // --- Admin Subscription Reminder ---
  REMINDER_HOME: 'adminreminder:home',
  REMINDER_TOGGLE: 'adminreminder:toggle',
  REMINDER_SET_THRESHOLDS: 'adminreminder:setthresholds',
  REMINDER_MANUAL_HOME: 'adminreminder:manual',
  REMINDER_MANUAL_SELECT: (userbotId) => `adminreminder:manual:${userbotId}`,
  REMINDER_MANUAL_CONFIRM: (userbotId, nonce) => `adminreminder:confirm:${userbotId}:${nonce}`,
  REMINDER_CANCEL: 'adminreminder:cancel',

  // --- Settings -> Perpanjang Langganan Userbot ---
  // Every id below is the stable internal userbots.id (never a label).
  // filter: a = semua, e = expired, s = aktif.
  SUBEXT_HOME: 'subext:home',
  SUBEXT_LIST: (filter = 'a', page = 0) => `subext:list:${filter}:${page}`,
  SUBEXT_SELECT: (id) => `subext:sel:${id}`,
  SUBEXT_PICK: (id, days) => `subext:pick:${id}:${days}`,
  SUBEXT_CUSTOM: (id) => `subext:custom:${id}`,
  // The trailing nonce is minted when the confirmation screen is rendered
  // and identifies ONE confirmation. Same nonce => same operation (a double
  // tap / Telegram retry is deduplicated); a fresh confirmation screen =>
  // fresh nonce => a deliberate second extension is allowed.
  SUBEXT_GO: (id, days, nonce) => `subext:go:${id}:${days}:${nonce}`,
  SUBEXT_CANCEL: 'subext:cancel',

  // --- Userbot Pool (Jaseb stock admin adds/activates) ---
  POOL_HOME: 'adminpool:home',
  POOL_LIST: (page = 0) => `adminpool:list:${page}`,
  POOL_ADD: 'adminpool:add',
  POOL_ADD_PHONE: 'adminpool:add:phone',
  POOL_ADD_SESSION: 'adminpool:add:session',
  POOL_VIEW: (id) => `adminpool:view:${id}`,
  POOL_DEL_CONFIRM: (id) => `adminpool:delconfirm:${id}`,
  POOL_DEL: (id) => `adminpool:del:${id}`,
  TRANSACTIONS_HOME: 'admintrx:home',
  TRANSACTIONS_LIST: (page = 0) => `admintrx:list:${page}`,
  TRANSACTION_VIEW: (id) => `admintrx:view:${id}`,
  TRANSACTION_PROOF: (id) => `admintrx:proof:${id}`,
  TRANSACTION_APPROVE: (id) => `admintrx:approve:${id}`,
  TRANSACTION_REJECT: (id) => `admintrx:reject:${id}`,
  POOL_CANCEL: 'adminpool:cancel',
};

module.exports = { ADMIN_CALLBACK };
