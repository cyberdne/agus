/**
 * Canonical registry for Admin Panel -> Statistik.
 *
 * Every statistics category that can be rendered by the admin UI must be
 * registered here. Keyboard generation, handler validation, and Telegraf
 * callback routing all consume this same registry so a valid category cannot
 * silently diverge between layers.
 */
const STATISTICS_SECTIONS = Object.freeze([
  Object.freeze(['👥 Users', 'users']),
  Object.freeze(['🤖 Userbot', 'userbot']),
  Object.freeze(['📦 Stok Userbot', 'stock']),
  Object.freeze(['🛒 Order', 'orders']),
  Object.freeze(['💳 Payment', 'payments']),
  Object.freeze(['📅 Subscription', 'subscription']),
  Object.freeze(['📣 Promotion', 'promotion']),
  Object.freeze(['🖥 System', 'system']),
]);

const STATISTICS_SECTION_IDS = Object.freeze(STATISTICS_SECTIONS.map(([, section]) => section));
const STATISTICS_SECTION_ID_SET = new Set(STATISTICS_SECTION_IDS);
const escapeRegExp = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const SECTION_PATTERN = STATISTICS_SECTION_IDS.map(escapeRegExp).join('|');

const STATISTICS_SECTION_CALLBACK_PATTERN = new RegExp(
  `^admin:statistics:section:(${SECTION_PATTERN})$`
);
const STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN = new RegExp(
  `^admin:statistics:section:(${SECTION_PATTERN}):refresh$`
);

function isValidStatisticsSection(section) {
  return typeof section === 'string' && STATISTICS_SECTION_ID_SET.has(section);
}

function parseStatisticsSectionCallback(data) {
  const match = STATISTICS_SECTION_CALLBACK_PATTERN.exec(String(data == null ? '' : data));
  return match ? match[1] : null;
}

function parseStatisticsSectionRefreshCallback(data) {
  const match = STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN.exec(String(data == null ? '' : data));
  return match ? match[1] : null;
}

module.exports = {
  STATISTICS_SECTIONS,
  STATISTICS_SECTION_IDS,
  isValidStatisticsSection,
  STATISTICS_SECTION_CALLBACK_PATTERN,
  STATISTICS_SECTION_REFRESH_CALLBACK_PATTERN,
  parseStatisticsSectionCallback,
  parseStatisticsSectionRefreshCallback,
};
