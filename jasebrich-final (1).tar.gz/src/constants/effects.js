/**
 * Telegram message effects — the full-screen animation that plays
 * over a message (🔥, ❤️, 🎉, etc). This is NOT the same as message
 * reactions (the little emoji badge users tap onto a message).
 *
 * Constraints (Telegram Bot API):
 * - Only usable on `sendMessage` (via the `message_effect_id` param).
 * - Only works in private chats — ignored/rejected in groups.
 * - NOT supported on `editMessageText` — the message must be freshly
 *   sent for the effect to play, which is why screens that use an
 *   effect always go through renderWithReplyKeyboard() (always sends
 *   new) rather than renderScreen() (edits in place when it can).
 */
const MESSAGE_EFFECT = {
  FIRE: '5104841245755180586',
  THUMBS_UP: '5107584321108051014',
  THUMBS_DOWN: '5104858069142078462',
  HEART: '5159385139981059251',
  PARTY: '5046509860389126442',
  POOP: '5046589136895476101',
};

// Attractive effects suitable for fresh home-menu messages. POOP and
// THUMBS_DOWN remain available for other explicit uses but are intentionally
// excluded from the home rotation.
MESSAGE_EFFECT.MAIN_MENU = Object.freeze([
  MESSAGE_EFFECT.FIRE,
  MESSAGE_EFFECT.HEART,
  MESSAGE_EFFECT.PARTY,
  MESSAGE_EFFECT.THUMBS_UP,
]);

module.exports = { MESSAGE_EFFECT };
