// Reply keyboard labels (main navigation)
const MENU = {
  STORE: '🛒 Toko',
  BUAT_UBOT: '🤖 Buat Userbot',
  KONTROL_PANEL: '🎛️ Kontrol Panel',
  FITUR_UNGGULAN: '⭐ Fitur Unggulan',
  CLAIM_TRIAL: '🎁 Coba Gratis',
  KLAIM_TOKEN: '🎫 Klaim Token',
  PANDUAN_BUAT: '📖 Panduan Buat',
  KEMBALI: '🔙 Kembali',
  BATAL: '❌ Batal',
  // Shown instead of "🤖 Beli Userbot" on the Store front screen once the
  // user already owns an active userbot — see keyboards/main.keyboard.js
  // and handlers/store.handler.js. Goes through the same replyButton
  // pipeline as every other button, so it's customizable via Admin Panel
  // -> Settings -> Custom Icon Tombol like the rest.
  PERPANJANG_LANGGANAN: '🔄 Perpanjang Langganan',
  // Only ever shown to admins — appended to the main keyboard
  // dynamically, see keyboards/main.keyboard.js.
  ADMIN_PANEL: '🔧 Admin Panel',
  ADMIN_STATISTICS: '📊 Statistik',
};

// Reply keyboard labels for the per-userbot Kontrol Panel.
// Layout mirrors the reference screenshots.
const PANEL_FEATURE = {
  START: '🚀 Mulai Promosi',
  STOP: '⏹️ Stop Promosi',
  BASE_REPLY: '💬 Base Reply',
  STORE: '🛒 Toko',
  EXTRA: '🧰 Fitur Ekstra',
  MESSAGE: '📝 Atur Pesan',
  GROUP: '👥 Atur Grup',
  DELAY: '⏱️ Atur Jeda',
  GUIDE: '📖 Panduan Pakai',
  PROMOTION_STATUS: '📊 Status Promosi',
  PROMOTION_STATUS_REFRESH: '🔄 Refresh',

  // Base Reply submenu
  REPLY_TOGGLE: '⚡ Status Reply (On/Off)',
  ADD_REPLY: '➕ Tambah Reply',
  DELETE_REPLY: '🗑️ Hapus Reply',
  GLOBAL_SETTINGS: '⚙️ Global Settings',
  WTB_TIMER: '⏰ Atur Timer WTB',
  REPLY_LIST: '📋 Daftar Reply & Settings',
  AUTO_REACT: '❤️ Auto React',
  // Auto React on/off: exactly one of these two is shown at a time (see
  // autoReactKeyboard in panelControl.keyboard.js), mirroring the
  // START/STOP pattern above. Both are stable identifiers registered
  // through utils/buttons.js -> Custom Icon Tombol, so custom emoji or
  // label edits never break routing (see index.js resolveIncomingButtonLabel).
  AUTO_REACT_ENABLE: '✅ Aktifkan',
  AUTO_REACT_DISABLE: '❌ Nonaktifkan',
  AUTO_REACT_CHANGE: '🛠️ Ubah Reaksi',
  AUTO_RESET: '🔄 Auto Reset',
  CHANNEL_DISABLE: '🚫 Channel Disable',

  // Message submenu
  MESSAGE_TEXT_MEDIA: '📄 Pesan Teks/Media',
  MESSAGE_FORWARD: '↪️ Pesan Forward',
  MESSAGE_VIEW: '👁️ Lihat Pesan',
  MESSAGE_DELETE: '🗑️ Hapus Pesan',

  // Group submenu
  TOPIC_GROUP: '🌐 Topik Grup',
  ADD_GROUP: '💡 Tambah Grup',
  DELETE_GROUP: '❌ Hapus Grup',
  GROUP_LIST: '📋 Daftar Grup',
  JOIN_GROUP: '🔗 Gabung Grup',
  LEAVE_GROUP: '👋 Keluar Grup',

  // Delay submenu
  GROUP_DELAY: '⏱️ Jeda Antar Grup',
  ROUND_DELAY: '✨ Jeda Antar Putaran',
  SMART_DELAY: '🧠 Smart Delay',

  // Extra submenu
  BROADCAST_PM: '📄 Broadcast PM',
  PM_PERMIT: '🛡️ PM Permit',
  ADMIN_PANEL: '🛠️ Panel Admin',
  TIMER: '⏰ Timer',
  TIMER_SET: '✏️ Atur Jam',
  TIMER_ENABLE: '✅ Aktifkan Timer',
  TIMER_DISABLE: '⛔ Nonaktifkan Timer',
  BACKUP_TOKEN_NEW: '🔑 Buat Token Baru',
  BACKUP_TOKEN_CONFIRM: '✅ Ya, Buat Token Baru',
  BACKUP_TOKEN: '🪽 Backup Token',
  CUSTOM_WM: '💧 Watermark',
  WATERMARK_SET: '✏️ Atur WM',
  WATERMARK_ENABLE: '✅ Aktifkan WM',
  WATERMARK_DISABLE: '⛔ Nonaktifkan WM',
  CHECK_TOKEN: '🔥 Cek Token',
  TRANSFER_UBOT: '🔄 Pindahkan Userbot',
  RESET_DATA: '🗑️ Reset Data',

  // Backward-compatible aliases used by old handlers/admin panel.
  STOP: '⏹️ Stop',
  TARGET: '🎯 Target',
  TEKS: '📝 Teks',
  MODE: '⚙️ Mode',
  JEDA: '⏱️ Jeda',
  WATERMARK: '💧 Watermark',
  TOPIC_GRUP: '📌 Topic Grup',
  COPY_SETTINGS: '📋 Copy Settings',
  RESET_UBOT: '♻️ Reset Ubot',
};

// Callback data naming convention: namespace:action[:id]
const CALLBACK = {
  NAV_HOME: 'nav:home',
  STORE_HOME: 'store:home',
  STORE_CATEGORY: (cat, origin) => `store:cat:${cat}${origin && origin !== 'store' ? ':' + origin : ''}`,
  // Explicit service entry points keep the Userbot and Jaseb catalogs visibly
  // and semantically separate. STORE_CATEGORY remains for backward-compatible
  // renewal/legacy callbacks.
  STORE_USERBOT: 'store:userbot',
  STORE_JASEB: 'store:jaseb',
  STORE_GARANSI: (garansi) => `store:garansi:${garansi ? 1 : 0}`,
  // `category` is carried explicitly through the purchase wizard so a
  // Userbot product can never inherit Jaseb pricing (or vice versa) after
  // Back/refresh/stale callback. `mode='renewal'` remains an optional trailing
  // segment for the existing renewal flow; old callbacks without category are
  // still accepted by the handler for backward compatibility.
  STORE_PRODUCT: (id, qty = 1, category, mode, origin) => `store:prod:${id}:${qty}${category ? ':' + category : ''}${mode ? ':' + mode : ''}${origin && origin !== 'store' ? ':' + origin : ''}`,
  STORE_QTY: (id, qty, delta, category, mode, origin) => `store:qty:${id}:${qty}:${delta}${category ? ':' + category : ''}${mode ? ':' + mode : ''}${origin && origin !== 'store' ? ':' + origin : ''}`,
  STORE_POLICY: (id, qty, category, mode, origin) => `store:policy:${id}:${qty}${category ? ':' + category : ''}${mode ? ':' + mode : ''}${origin && origin !== 'store' ? ':' + origin : ''}`,
  STORE_PAY: (id, qty, category, mode, origin) => `store:pay:${id}:${qty}${category ? ':' + category : ''}${mode ? ':' + mode : ''}${origin && origin !== 'store' ? ':' + origin : ''}`,
  STORE_PAID: (orderId) => `store:paid:${orderId}`,
  STORE_RESUME: (orderId) => `store:resume:${orderId}`,
  STORE_STATUS: (orderId) => `store:status:${orderId}`,
  STORE_CANCEL: (orderId) => `store:cancel:${orderId}`,
  STORE_CANCEL_YES: (orderId) => `store:cancel_yes:${orderId}`,
  STORE_CANCEL_NO: (orderId) => `store:cancel_no:${orderId}`,
  STORE_CANCEL_ALL: 'store:cancel_all',
  STORE_CANCEL_ALL_YES: 'store:cancel_all_yes',
  STORE_CANCEL_ALL_NO: 'store:cancel_all_no',
  // User-facing renewal entry point for ONE specific owned userbot. Carries
  // the stable internal userbots.id — never label text or emoji — so custom
  // button icons can never affect routing.
  SUBSCRIPTION_RENEW: (id) => `subscription:renew:${id}`,
  PANEL_HOME: 'panel:home',
  PANEL_SECTION: (id) => `panel:${id}`,
  PANEL_TOGGLE: (kind, id, flag) => `panel:toggle:${kind}:${id}:${flag}`,
  PANEL_ASSET: (kind, id) => `panel:asset:${kind}:${id}`,
  PANEL_MODE: (kind, id, value) => `panelcfg:mode:${kind}:${id}:${value}`,
  PANEL_PROMOTION_STATUS_REFRESH: (kind, id) => `panel:promotion:refresh:${kind}:${id}`,
  PANEL_PROMOTION_STATUS_START: (kind, id) => `panel:promotion:start:${kind}:${id}`,
  PANEL_PROMOTION_STATUS_STOP: (kind, id) => `panel:promotion:stop:${kind}:${id}`,
  PANEL_PROMOTION_STATUS_BACK: (kind, id) => `panel:promotion:back:${kind}:${id}`,
  PANEL_NOTIFY: (kind, id) => `panel:notify:${kind}:${id}`,
  PANEL_NOTIFY_TOGGLE: (kind, id, key) => `panel:notify:toggle:${kind}:${id}:${key}`,
  // Atur Grup -> Hapus Grup: button-driven delete flow (no manual ID typing).
  // The group row id comes straight from panel_groups.id (the real primary
  // key), never from label text or list position.
  PANEL_GROUP_DEL: (id, page = 0) => `panelgrp:del:${id}:${page}`,
  PANEL_GROUP_DELCONFIRM: (id, page = 0) => `panelgrp:delconfirm:${id}:${page}`,
  PANEL_GROUP_DELCANCEL: 'panelgrp:delcancel',
  PANEL_GROUP_DELALL: 'panelgrp:delall',
  PANEL_GROUP_DELALLCONFIRM: 'panelgrp:delallconfirm',
  PANEL_GROUP_LIST_PAGE: (userbotId, page) => `panelgrp:list:${userbotId}:${page}`,
  PANEL_GROUP_LIST_REFRESH: (userbotId, page = 0) => `panelgrp:listrefresh:${userbotId}:${page}`,
  PANEL_GROUP_LIST_BACK: 'panelgrp:listback',
  PANEL_GROUP_DEL_PAGE: (userbotId, page) => `panelgrp:delpage:${userbotId}:${page}`,
  PANEL_GROUP_LEAVE: (userbotId, targetId) => `panelgrp:leave:${userbotId}:${targetId}`,
  PANEL_GROUP_LEAVE_PAGE: (userbotId, page) => `panelgrp:leavepage:${userbotId}:${page}`,
  PANEL_GROUP_LEAVE_REFRESH: (userbotId, page = 0) => `panelgrp:leaverefresh:${userbotId}:${page}`,
  PANEL_GROUP_LEAVE_BACK: 'panelgrp:leaveback',
};

module.exports = { MENU, CALLBACK, PANEL_FEATURE };
