const { isAdminId } = require('./admin.middleware');
const adminState = require('../state/adminState');
const broadcast = require('../handlers/admin/broadcast.handler');
const logger = require('../utils/logger');

/**
 * Captures arbitrary Telegram content for the Broadcast wizard before the
 * generic admin text-flow middleware. The state action is the source of truth;
 * no message label or emoji is parsed for routing.
 */
function adminBroadcastMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    if (ctx.updateType !== 'message' || !ctx.message) return next();

    const state = adminState.get(ctx.from.id);
    if (!state || !['admin_broadcast_content', 'admin_broadcast_buttons'].includes(state.action)) {
      return next();
    }

    try {
      if (state.action === 'admin_broadcast_content') {
        if (typeof ctx.message.text === 'string' && /^❌ Batal Broadcast$/u.test(ctx.message.text.trim())) return next();
        if (typeof ctx.message.text === 'string' && /^🔙 Kembali$/u.test(ctx.message.text.trim())) return next();
        return await broadcast.handleContentInput(ctx, state);
      }
      if (typeof ctx.message.text !== 'string') {
        await ctx.reply('❌ Pada langkah tombol broadcast, kirim teks sesuai format tombol yang diminta.');
        return;
      }
      return await broadcast.handleButtonsInput(ctx, state);
    } catch (err) {
      logger.error('adminBroadcastMiddleware error:', err && err.message ? err.message : err);
      await ctx.reply('❌ Broadcast input gagal diproses. Silakan coba lagi.');
      return;
    }
  };
}

module.exports = { adminBroadcastMiddleware };
