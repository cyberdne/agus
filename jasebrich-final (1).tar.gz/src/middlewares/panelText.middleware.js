const panelState = require('../state/panelState');
const panelHandler = require('../handlers/panel.handler');
const userbotService = require('../services/userbot.service');
const { assetButtonLabel } = require('../keyboards/panelControl.keyboard');
const { MENU } = require('../constants/menu');
const logger = require('../utils/logger');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const poolRepo = require('../database/repositories/userbotPool.repository');
const poolPanelConfig = require('../services/poolPanelConfig.service');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');

function findAssetByLabel(assets, text) {
  for (const a of assets.owned) {
    if (assetButtonLabel('owned', a) === text) return { kind: 'owned', id: a.id };
  }
  for (const a of assets.leased) {
    if (assetButtonLabel('pool', a) === text) return { kind: 'pool', id: a.id };
  }
  return null;
}

/**
 * Intercepts text while the user is inside the Kontrol Panel flow:
 * picking which userbot to control, picking a source for "Copy
 * Settings", or answering one of the config wizards (Target, Teks,
 * Jeda, Timer, Watermark, Topic Grup, Transfer Ubot, Reset Ubot).
 * Must run BEFORE bot.hears()/bot.on('text') — same pattern as
 * ubotLoginText.middleware.js — so wizard replies never get swallowed
 * by a menu-button match.
 */
function panelTextMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from) return next();
    const isTextMessage = ctx.updateType === 'message' && ctx.message && typeof ctx.message.text === 'string';
    const stateEarly = panelState.get(ctx.from.id);
    function extractForwardSource(message) {
      if (!message) return null;
      const origin = message.forward_origin || null;
      const sourceChatId = origin?.chat?.id ?? message.forward_from_chat?.id ?? null;
      const sourceMessageId = origin?.message_id ?? message.forward_from_message_id ?? null;
      if (sourceChatId == null || sourceMessageId == null) return null;
      return {
        origin,
        sourceChatId,
        sourceMessageId,
        username: origin?.chat?.username ?? message.forward_from_chat?.username ?? null,
        title: origin?.chat?.title ?? message.forward_from_chat?.title ?? null,
      };
    }

    const isForwardMessage = Boolean(stateEarly && ctx.updateType === 'message' && ctx.message && (stateEarly.step === 'await_message_forward' || (stateEarly.step === 'await_broadcast_pm' && Boolean(extractForwardSource(ctx.message)))));
    if (!isTextMessage && !isForwardMessage) return next();

    if (isForwardMessage) {
      // This branch acts on the userbot straight from the stored panel state
      // (it does not go through panel.handler's selected()), so it must run the
      // same centralized ownership + subscription check itself.
      const guardedAsset = await panelHandler.guardPanelState(ctx, stateEarly);
      if (!guardedAsset) return;
      if (await panelHandler.enforceStepFeature(ctx, guardedAsset, stateEarly.step)) return;
      const m = ctx.message;
      const forwardSource = extractForwardSource(m);
      const origin = forwardSource?.origin || null;
      const sourceChatId = forwardSource?.sourceChatId ?? null;
      const sourceMessageId = forwardSource?.sourceMessageId ?? null;
      const panelKind = stateEarly.kind === 'pool' ? 'pool' : 'owned';
      const panelConfig = panelKind === 'pool' ? poolPanelConfig : require('../services/panelConfig.service');
      const assetRepo = panelKind === 'pool' ? poolRepo : ownedRepo;
      if (!sourceChatId || !sourceMessageId) {
        if(stateEarly.step==='await_broadcast_pm'){
          // Some Telegram forward origins (notably user-origin forwards) do not expose
          // the original message ID to bots. In that case, broadcast the forwarded
          // content as a copy rather than fabricating an invalid source reference.
          if(typeof m.text==='string' && m.text.trim()){
            try {
              panelConfig.setBroadcastPmMessage(stateEarly.id,{kind:'text',text:m.text,entities:Array.isArray(m.entities)?m.entities:[]});
              panelState.clearStep(ctx.from.id);
              const r=await require('../services/userbotRuntime.service').broadcastPm('owned',stateEarly.id);
              { const c = userResponseTpl.panelBroadcastCopyResult.getContent(ctx, { placeholderValues: { hasil: `${r.sent}/${r.total}${r.failed?` (${r.failed} gagal)`:''}` } }); await ctx.reply(c.text, buildReplyOptions(c)); }
            } catch(err){ logger.error('Forward copy broadcast error:', err); { const c = userResponseTpl.panelForwardProcessError.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); } }
            await panelHandler.settleAfterStep(ctx);
            return;
          }
          return;
        }
        { const c = userResponseTpl.panelForwardSourceMissing.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
        return;
      }
      try {
        if(stateEarly.step==='await_broadcast_pm'){
          panelConfig.setBroadcastPmMessage(stateEarly.id,{kind:'forward',source_chat_id:sourceChatId,source_message_id:sourceMessageId});
          panelState.clearStep(ctx.from.id);
          const r=await require('../services/userbotRuntime.service').broadcastPm('owned',stateEarly.id);
          { const c = userResponseTpl.panelBroadcastResult.getContent(ctx, { placeholderValues: { hasil: `${r.sent}/${r.total} chat private diproses${r.failed?` (${r.failed} gagal)`:''}` } }); await ctx.reply(c.text, buildReplyOptions(c)); }
        } else {
          // Real access check (and automatic join when the source has a
          // public @username) BEFORE saving — guarantees this forward
          // source can actually be sent to targets, instead of silently
          // failing later inside Auto Promosi the first time it's used.
          const username = forwardSource?.username ?? null;
          const title = forwardSource?.title ?? null;
          const userbotRuntime = require('../services/userbotRuntime.service');
          const access = await userbotRuntime.ensureForwardAccess(panelKind, stateEarly.id, { chatId: sourceChatId, messageId: sourceMessageId, username });
          panelConfig.setForwardMessage(stateEarly.id, sourceChatId, sourceMessageId);
          assetRepo.updateConfig(stateEarly.id,{watermark:null});
          panelState.clearStep(ctx.from.id);
          if (access.joined) { const c = userResponseTpl.panelForwardSavedAndJoined.getContent(ctx, { placeholderValues: { hasil: title ? `"${title}"` : 'chat sumber' } }); await ctx.reply(c.text, buildReplyOptions(c)); } else { const c = userResponseTpl.panelForwardSaved.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
        }
      } catch (err) {
        logger.error('Forward save error:', err);
        { const c = userResponseTpl.panelForwardSaveError.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
      }
      // Same rule as text input: once the step is done, land back on the
      // screen it was started from instead of leaving the Cancel keyboard up.
      await panelHandler.settleAfterStep(ctx);
      return;
    }

    // Legacy label kept for old reply keyboards. It is a true main-menu
    // navigation action and must never reopen the selected control panel.
    if (isTextMessage && ctx.message.text === '🏠 Menu Utama') {
      panelState.clear(ctx.from.id);
      return next();
    }

    // '🔙 Kembali' exits the panel completely to the bot main menu.
    if (isTextMessage && ctx.message.text === MENU.KEMBALI) {
      panelState.clear(ctx.from.id);
      return next();
    }

    const state = panelState.get(ctx.from.id);
    if (!state || !state.step) return next();

    try {
      if (state.step === 'selecting') {
        const assets = userbotService.getUserAssets(ctx.from.id);
        const match = findAssetByLabel(assets, ctx.message.text);
        if (!match) {
          { const c = userResponseTpl.panelPickerPrompt.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
          return;
        }
        await panelHandler.selectAsset(ctx, match.kind, match.id);
        return;
      }

      if (state.step === 'copy_select') {
        const assets = userbotService.getUserAssets(ctx.from.id);
        const match = findAssetByLabel(assets, ctx.message.text);
        if (!match) {
          { const c = userResponseTpl.panelPickerPrompt.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
          return;
        }
        await panelHandler.applyCopyFrom(ctx, match.kind, match.id);
        return;
      }

      const handled = await panelHandler.handleStepInput(ctx, state, ctx.message.text);
      if (handled) return;
    } catch (err) {
      logger.error('panelTextMiddleware error:', (err && err.message) || err);
      { const { getSafeErrorContent } = require('../utils/errors'); const safe = getSafeErrorContent(ctx); await ctx.reply(safe.text, safe.options); }
      return;
    }

    return next();
  };
}

module.exports = { panelTextMiddleware };
