const { MENU, PANEL_FEATURE } = require('../constants/menu');
const flowCancellation = require('../services/flowCancellation.service');
const panelState = require('../state/panelState');
const { isDuplicateNav } = require('../utils/navDebounce');
const buyerState = require('../state/buyerState');
const adminState = require('../state/adminState');
const { replyCancelled, replyNoActive } = require('../services/cancelNotice.service');

const MAIN_NAVIGATION = new Set([
  MENU.STORE, MENU.BUAT_UBOT, MENU.KONTROL_PANEL, MENU.FITUR_UNGGULAN,
  MENU.CLAIM_TRIAL, MENU.KLAIM_TOKEN, MENU.PANDUAN_BUAT, MENU.BATAL,
  MENU.ADMIN_PANEL,
]);
// Inside a panel wizard, the Batal button and /cancel are the same action.
const CANCEL_TEXTS = new Set([MENU.BATAL, '/cancel']);
// Steps that are NOT free-text wizards: the userbot picker has no Batal
// button, so Batal there keeps its global meaning (back to the main menu).
const PICKER_STEPS = new Set(['selecting', 'copy_select']);
const PANEL_NAVIGATION = new Set(Object.values(PANEL_FEATURE));
PANEL_NAVIGATION.add('🏠 Menu Utama');

async function panelBack(ctx, panel) {
  const h = require('../handlers/panel.handler');
  flowCancellation.cancelPanelStep(ctx.from.id);

  // Nested panel screens have an unambiguous parent in the current flow.
  // The root control screen additionally carries its verified entry context:
  // a normal user can return to the asset picker when it was opened from
  // there, while an admin returns to the Admin Panel -> Kontrol Panel Ubot
  // picker. No visual label is used as a routing key.
  switch (panel.screen) {
    case 'reply_global':
    case 'reply_react':
      return h.baseReplyHandler(ctx);
    case 'reply':
    case 'message':
    case 'group':
    case 'delay':
    case 'extra':
      return h.homePanelHandler(ctx);
    case 'watermark':
      // Submenu Watermark: Kembali returns to Fitur Ekstra.
      return h.extraHandler(ctx);
    case 'timer':
      // Submenu Timer: Kembali returns to Fitur Ekstra.
      return h.extraHandler(ctx);
    case 'backup_token':
      // Submenu Backup Token: Kembali returns to Fitur Ekstra.
      return h.extraHandler(ctx);
    case 'promotion_status':
      // Status Promosi is a screen — Kembali goes back to the main control
      // panel. The watcher is stopped inside homePanelHandler via stopPromotionStatusWatcher.
      h.stopPromotionStatusWatcher(ctx.from.id);
      return h.homePanelHandler(ctx);
    case 'main':
      if (panel.adminMode && panel.returnTo === 'admin_ubot_list') {
        panelState.clear(ctx.from.id);
        const { panelUbotHomeCallback } = require('../handlers/admin/panelUbot.handler');
        return panelUbotHomeCallback(ctx);
      }
      // The root userbot control screen is itself the destination entered
      // from the bot's top-level Kontrol Panel. Kembali must therefore leave
      // the entire control-panel subtree instead of re-opening the userbot
      // picker (which looks like the same screen and was the reported
      // "Kembali tetap di Control Panel" bug). Nested screens still use the
      // exact one-level parent routes handled above.
      panelState.clear(ctx.from.id);
      const { backToMainHandler } = require('../handlers/menu.handler');
      return backToMainHandler(ctx);
    default:
      return h.homePanelHandler(ctx);
  }
}

function navigationCancellationMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || ctx.updateType !== 'message' || !ctx.message || typeof ctx.message.text !== 'string') return next();
    const text = ctx.message.text.trim();
    const panel = panelState.get(ctx.from.id);
    const buyer = buyerState.get(ctx.from.id);

    // The payment screen itself is also a buyer flow. Its inline Batal button
    // already has a dedicated callback, but the persistent reply keyboard can
    // still deliver the global "❌ Batal" label. Route that label into the
    // same ownership+state-checked confirmation so leaving this screen via
    // Batal can never strand a cancellable order in the database.
    if (buyer && buyer.step === 'await_payment') {
      const h = require('../handlers/store.handler');
      if (text === MENU.BATAL || text === '/cancel') {
        if (isDuplicateNav(ctx.from.id, MENU.BATAL)) return;
        await h.showPaymentCancelConfirmation(ctx, buyer.orderId);
        return;
      }
    }

    // While the pre-payment cancellation confirmation is on screen, a reply
    // keyboard retry must not clear the state or navigate away. The inline Yes
    // / No callbacks are authoritative.
    if (buyer && buyer.step === 'await_payment_cancel_confirm') {
      if (text === MENU.KEMBALI || text === MENU.BATAL || text === '/cancel') return;
    }

    // Bulk-cancellation confirmation has the same protection.
    if (buyer && buyer.step === 'await_payment_cancel_all_confirm') {
      if (text === MENU.KEMBALI || text === MENU.BATAL || text === '/cancel') return;
    }

    // Payment-proof is a transactional input step. It deliberately exposes
    // only Batal; Kembali is not a valid transition here. Batal uses the same
    // ownership/state-checked confirmation as the inline checkout button.
    if (buyer && buyer.step === 'await_payment_proof') {
      const h = require('../handlers/store.handler');
      if (text === MENU.BATAL) {
        if (isDuplicateNav(ctx.from.id, MENU.BATAL)) return;
        await h.showPaymentProofCancelConfirmation(ctx);
        return;
      }
    }

    // While the payment-proof cancellation confirmation is on screen, a
    // repeated reply-keyboard Back/Cancel must not invoke global cancellation
    // or consume the order. The inline Yes/No callbacks are authoritative.
    if (buyer && buyer.step === 'await_payment_proof_cancel_confirm') {
      if (text === MENU.KEMBALI || text === MENU.BATAL) return;
    }

    // While a panel wizard step is waiting for input, the keyboard is
    // swapped to a single Cancel (MENU.BATAL) button — see ask() in
    // panel.handler.js. Pressing it cancels only that step and restores
    // the screen the user was on, instead of the global Batal behavior
    // (which would exit the whole panel back to the main menu).
    if (CANCEL_TEXTS.has(text) && panel && panel.step && !PICKER_STEPS.has(panel.step)) {
      const h = require('../handlers/panel.handler');
      flowCancellation.cancelPanelStep(ctx.from.id);
      await replyCancelled(ctx);
      await h.restoreScreen(ctx, panel.screen);
      return;
    }

    // Kembali while a panel INPUT step is waiting: one step back inside the
    // wizard (or the screen it was opened from) — never the whole panel.
    if (text === MENU.KEMBALI && panel && panel.step && !PICKER_STEPS.has(panel.step)) {
      if (isDuplicateNav(ctx.from.id, MENU.KEMBALI)) return;
      const h = require('../handlers/panel.handler');
      if (!(await h.guardPanelState(ctx, panel))) return;
      await h.inputBack(ctx, panel);
      return;
    }

    // Inside a panel, Kembali means "previous panel screen" when the
    // current screen has a verified parent. Otherwise it exits to the main
    // menu. Root control-panel navigation is context-aware (single-userbot,
    // multi-userbot picker, or admin userbot picker).
    if (text === MENU.KEMBALI && panel) {
      if (panel.screen === 'select' || !panel.screen) {
        flowCancellation.cancelAll(ctx.from.id);
        return next(); // main menu handler will render Home
      }
      await panelBack(ctx, panel);
      return;
    }

    if (text === '🏠 Menu Utama' && panel) {
      const active = flowCancellation.cancelOutsidePanel(ctx.from.id);
      if (active) await replyCancelled(ctx);
      flowCancellation.cancelAll(ctx.from.id);
      return next();
    }

    // Panel action buttons cancel the previous wizard, but preserve selected userbot.
    if (panel && PANEL_NAVIGATION.has(text)) {
      const active = flowCancellation.cancelOutsidePanel(ctx.from.id);
      if (active) await replyCancelled(ctx);
      if (text === PANEL_FEATURE.STORE) flowCancellation.cancelAll(ctx.from.id);
      return next();
    }

    if (text === MENU.BATAL || text === '/cancel') {
      // Admin input flows own their own context-aware cancel handlers in
      // adminReply.middleware. Do not consume this update here, otherwise the
      // admin handler never gets a chance to render its real parent and the
      // user needs a second Batal press.
      if (adminState.get(ctx.from.id)) return next();

      const buyer = buyerState.get(ctx.from.id);
      if (buyer) {
        if (isDuplicateNav(ctx.from.id, MENU.BATAL)) return;
        // This is the real buyer-flow cancellation implementation. It clears
        // only the temporary buyer/login state and renders the main menu in the
        // same interaction; it also aborts any active GramJS login.
        const { cancelFlow } = require('../handlers/ubotFlow.handler');
        if (await cancelFlow(ctx)) return;
      }

      const active = flowCancellation.cancelAll(ctx.from.id);
      if (active) {
        await replyCancelled(ctx);
        const { renderMainMenu } = require('../services/mainMenu.service');
        await renderMainMenu(ctx);
      } else if (text === MENU.BATAL) {
        await replyCancelled(ctx);
        const { renderMainMenu } = require('../services/mainMenu.service');
        await renderMainMenu(ctx);
      } else {
        await replyNoActive(ctx);
      }
      return;
    }

    if (MAIN_NAVIGATION.has(text)) {
      const active = flowCancellation.cancelAll(ctx.from.id);
      if (active) await replyCancelled(ctx);
      return next();
    }
    return next();
  };
}

module.exports = { navigationCancellationMiddleware };
