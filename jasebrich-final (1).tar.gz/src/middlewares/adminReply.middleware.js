const { isAdminId } = require('./admin.middleware');
const { ADMIN_CALLBACK } = require('../constants/admin.callback');
const { CALLBACK } = require('../constants/menu');

const {
  adminPanelHandler,
  adminUsersCategoryCallback, adminUserbotCategoryCallback, adminCommerceCategoryCallback,
  adminOrdersCategoryCallback, adminNotificationsCategoryCallback, adminStatisticsCategoryCallback,
  adminSettingsCategoryCallback,
} = require('../handlers/admin/adminPanel.handler');
const { panelUbotHomeCallback } = require('../handlers/admin/panelUbot.handler');
const { settingsCallback } = require('../handlers/admin/settings.handler');
const custom = require('../handlers/admin/customSubmenu.handler');
const sticker = require('../handlers/admin/startSticker.handler');
const trial = require('../handlers/admin/trialSettings.handler');
const premium = require('../handlers/admin/premiumEmoji.handler');
const user = require('../handlers/admin/userManagement.handler');
const product = require('../handlers/admin/productManagement.handler');
const transaction = require('../handlers/admin/transaction.handler');
const productService = require('../services/product.service');
const payment = require('../handlers/admin/paymentManagement.handler');
const pool = require('../handlers/admin/poolManagement.handler');
const { navHomeCallback } = require('../handlers/menu.handler');
const joinGate = require('../handlers/admin/joinGateSettings.handler');
const buttonIcons = require('../handlers/admin/buttonIcons.handler');
const settingsBackup = require('../handlers/admin/settingsBackup.handler');
const subExt = require('../handlers/admin/subscriptionExtend.handler');
const notification = require('../handlers/admin/notification.handler');
const testimonial = require('../handlers/admin/testimonial.handler');
const statistics = require('../handlers/admin/statistics.handler');
const broadcast = require('../handlers/admin/broadcast.handler');
const reminder = require('../handlers/admin/reminder.handler');
const flowCancellation = require('../services/flowCancellation.service');
const { replyCancelled, replyNoActive } = require('../services/cancelNotice.service');
const adminState = require('../state/adminState');
const gramjsService = require('../services/gramjs.service');
const logger = require('../utils/logger');
const { Markup } = require('telegraf');
const { replyButton } = require('../utils/buttons');
const inputFlows = require('../constants/adminInputFlows');
const buttonIconConfig = require('../services/buttonIconConfig.service');
const screenState = require('../state/screenState');
const { normalizeLabel } = buttonIconConfig;

/**
 * Reply-keyboard router for Admin Panel.
 *
 * Reply buttons are navigation/actions. They are converted to the same
 * callback-data contract used by existing handlers, but the renderer knows
 * that this update came from a reply button and therefore sends a NEW bot
 * message instead of editing an old one.
 *
 * Dynamic record selection (user/product/userbot) stays inline.
 */
const STATIC_ROUTES = new Map([
  ['👥 Users', [user.userListCallback, ADMIN_CALLBACK.USER_LIST(0)]],
  ['🤖 Userbot', [adminUserbotCategoryCallback, 'admin:category:userbot']],
  ['🛒 Commerce', [adminCommerceCategoryCallback, 'admin:category:commerce']],
  ['💳 Order & Payment', [adminOrdersCategoryCallback, 'admin:category:orders']],
  ['📢 Notifications', [adminNotificationsCategoryCallback, 'admin:category:notifications']],
  ['📊 Statistics', [statistics.statisticsCallback, ADMIN_CALLBACK.STATISTICS_HOME]],
  ['👥 User Management', [user.userListCallback, ADMIN_CALLBACK.USER_LIST(0)]],
  ['📦 Produk Management', [product.productHomeCallback, ADMIN_CALLBACK.PRODUCT_HOME]],
  ['📇 Stok Userbot Jaseb', [pool.poolHomeCallback, ADMIN_CALLBACK.POOL_HOME]],
  ['🎛️ Kontrol Panel Ubot', [panelUbotHomeCallback, ADMIN_CALLBACK.PANEL_UBOT_HOME]],
  ['💳 Payment', [payment.paymentHomeCallback, ADMIN_CALLBACK.PAYMENT_HOME]],
  ['🧾 Transaksi', [transaction.transactionHomeCallback, ADMIN_CALLBACK.TRANSACTIONS_HOME]],
  ['🔔 Notifikasi', [notification.notificationHomeCallback, ADMIN_CALLBACK.NOTIFICATION_HOME]],
  ['📣 Broadcast', [broadcast.broadcastHomeCallback, ADMIN_CALLBACK.BROADCAST_HOME]],
  ['📨 Broadcast', [broadcast.broadcastHomeCallback, ADMIN_CALLBACK.BROADCAST_HOME]],
  ['📣 Buat Broadcast', [broadcast.broadcastCreateCallback, ADMIN_CALLBACK.BROADCAST_CREATE]],
  ['📜 Riwayat Broadcast', [broadcast.broadcastHistoryCallback, ADMIN_CALLBACK.BROADCAST_HISTORY]],
  ['📊 Broadcast Berjalan', [broadcast.broadcastStatusCallback, ADMIN_CALLBACK.BROADCAST_STATUS]],
  ['⏰ Reminder', [reminder.reminderHomeCallback, ADMIN_CALLBACK.REMINDER_HOME]],
  ['⚙️ Atur Threshold', [reminder.reminderSetThresholdsCallback, ADMIN_CALLBACK.REMINDER_SET_THRESHOLDS]],
  ['📨 Reminder Manual', [reminder.reminderManualHomeCallback, ADMIN_CALLBACK.REMINDER_MANUAL_HOME]],
  ['🆕 Log Registrasi', [notification.notificationRegistrationHomeCallback, ADMIN_CALLBACK.NOTIFICATION_REGISTRATION_HOME]],
  ['💳 Log Transaksi', [notification.notificationTransactionHomeCallback, ADMIN_CALLBACK.NOTIFICATION_TRANSACTION_HOME]],
  ['🔴 Matikan Testimoni', [testimonial.testimonialToggleCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_TOGGLE]],
  ['🟢 Nyalakan Testimoni', [testimonial.testimonialToggleCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_TOGGLE]],
  ['🧾 Testimoni', [testimonial.testimonialHomeCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_HOME]],
  ['📢 Atur Channel Testimoni', [testimonial.testimonialSetChannelCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_SET_CHANNEL]],
  ['🎨 Custom Testimoni', [testimonial.testimonialCustomCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_CUSTOM]],
  ['🔘 Atur Tombol', [testimonial.testimonialSetButtonsCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_SET_BUTTONS]],
  ['🖼️ Atur Gambar', [testimonial.testimonialSetImageCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_SET_IMAGE]],
  ['👁️ Preview Testimoni', [testimonial.testimonialPreviewCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_PREVIEW]],
  ['♻️ Reset Pengaturan', [testimonial.testimonialResetCallback, ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_RESET]],
  ['📢 Atur Channel Registrasi', [notification.notificationSetRegistrationChannelCallback, ADMIN_CALLBACK.NOTIFICATION_SET_REGISTRATION_CHANNEL]],
  ['🗑️ Reset Channel Registrasi', [notification.notificationResetRegistrationCallback, ADMIN_CALLBACK.NOTIFICATION_RESET_REGISTRATION_CHANNEL]],
  ['📢 Atur Channel Transaksi', [notification.notificationSetTransactionChannelCallback, ADMIN_CALLBACK.NOTIFICATION_SET_TRANSACTION_CHANNEL]],
  ['🗑️ Reset Channel Transaksi', [notification.notificationResetTransactionCallback, ADMIN_CALLBACK.NOTIFICATION_RESET_TRANSACTION_CHANNEL]],
  ['⏱️ Durasi Aktif', [notification.notificationSetDurationCallback, ADMIN_CALLBACK.NOTIFICATION_SET_TRANSACTION_DURATION]],
  ['🔙 Kembali ke Notifikasi', [notification.notificationHomeCallback, ADMIN_CALLBACK.NOTIFICATION_HOME]],
  ['❌ Batal Notifikasi', [notification.notificationCancelCallback, ADMIN_CALLBACK.NOTIFICATION_CANCEL]],
  ['❌ Batal Broadcast', [broadcast.broadcastCancelCallback, ADMIN_CALLBACK.BROADCAST_CANCEL]],
  ['❌ Batal Reminder', [reminder.reminderCancelCallback, ADMIN_CALLBACK.REMINDER_CANCEL]],
  ['⚙️ Settings', [adminSettingsCategoryCallback, 'admin:category:settings']],
  ['⚙️ Configuration', [settingsCallback, ADMIN_CALLBACK.SETTINGS_OPEN]],
  ['📢 Wajib Join', [joinGate.joinGateHomeCallback, ADMIN_CALLBACK.JOIN_GATE_HOME]],
  ['🟢 Aktifkan Wajib Join', [joinGate.joinGateToggleCallback, ADMIN_CALLBACK.JOIN_GATE_TOGGLE]],
  ['🔴 Nonaktifkan Wajib Join', [joinGate.joinGateToggleCallback, ADMIN_CALLBACK.JOIN_GATE_TOGGLE]],
  ['📢 Set Channel Wajib', [joinGate.joinGateSetChannelCallback, ADMIN_CALLBACK.JOIN_GATE_SET_CHANNEL]],
  ['💬 Set Grup Opsional', [joinGate.joinGateSetGroupCallback, ADMIN_CALLBACK.JOIN_GATE_SET_GROUP]],
  ['🗑️ Hapus Channel Wajib', [joinGate.joinGateRemoveChannelCallback, ADMIN_CALLBACK.JOIN_GATE_REMOVE_CHANNEL]],
  ['🗑️ Hapus Grup Opsional', [joinGate.joinGateRemoveGroupCallback, ADMIN_CALLBACK.JOIN_GATE_REMOVE_GROUP]],
  ['🏠 Menu Utama', [navHomeCallback, CALLBACK.NAV_HOME]],
  ['⏳ Perpanjang Userbot', [subExt.subextHomeCallback, ADMIN_CALLBACK.SUBEXT_HOME]],
  ['❌ Batal Perpanjang', [subExt.subextCancelCallback, ADMIN_CALLBACK.SUBEXT_CANCEL]],

  ['🎨 Custom Submenu', [custom.customSubmenuListCallback, ADMIN_CALLBACK.CUSTOM_SUBMENU_LIST]],
  ['🎬 Sticker /start', [sticker.startStickerHomeCallback, ADMIN_CALLBACK.START_STICKER_HOME]],
  ['🎁 Durasi Trial', [trial.trialSettingsHomeCallback, ADMIN_CALLBACK.TRIAL_SETTINGS_HOME]],
  ['🔐 Akses Fitur Trial', [trial.trialFeaturesHomeCallback, ADMIN_CALLBACK.TRIAL_FEATURES_HOME]],
  ['❌ Batal Akses Fitur', [trial.trialFeaturesCancelCallback, ADMIN_CALLBACK.TRIAL_FEATURES_CANCEL]],
  ['💎 Emoji Premium', [premium.premiumEmojiHomeCallback, ADMIN_CALLBACK.PREMIUM_EMOJI_HOME]],
  ['🎨 Custom Icon Tombol', [buttonIcons.buttonIconsHomeCallback, ADMIN_CALLBACK.BUTTON_ICONS_HOME]],
  ['💾 Backup Pengaturan', [settingsBackup.settingsBackupHomeCallback, ADMIN_CALLBACK.SETTINGS_BACKUP_HOME]],
  ['🔙 Kembali Import', [settingsBackup.settingsBackupHomeCallback, ADMIN_CALLBACK.SETTINGS_BACKUP_HOME]],
  ['❌ Batal Custom Icon', [buttonIcons.buttonIconsCancelCallback, ADMIN_CALLBACK.BUTTON_ICONS_CANCEL]],

  ['🔙 Kembali ke Admin Panel', [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME]],
  ['🔙 Kembali ke Settings', [settingsCallback, ADMIN_CALLBACK.SETTINGS_OPEN]],
  ['🔙 Kembali ke Produk Management', [product.productHomeCallback, ADMIN_CALLBACK.PRODUCT_HOME]],

  ['➕ Set Sticker', [sticker.startStickerSetCallback, ADMIN_CALLBACK.START_STICKER_SET]],
  ['🔁 Ganti Sticker', [sticker.startStickerSetCallback, ADMIN_CALLBACK.START_STICKER_SET]],
  ['🗑️ Hapus Sticker', [sticker.startStickerRemoveCallback, ADMIN_CALLBACK.START_STICKER_REMOVE]],
  ['✏️ Ubah Durasi', [trial.trialSettingsSetCallback, ADMIN_CALLBACK.TRIAL_SETTINGS_SET]],
  ['⭐ Ubah Emoji Bergaransi', [premium.premiumEmojiSetGaransiCallback, ADMIN_CALLBACK.PREMIUM_EMOJI_SET_GARANSI]],
  ['💎 Ubah Emoji Non-Garansi', [premium.premiumEmojiSetNonGaransiCallback, ADMIN_CALLBACK.PREMIUM_EMOJI_SET_NONGARANSI]],

  ['🖼️ Set Gambar QRIS', [payment.paymentSetQrisCallback, ADMIN_CALLBACK.PAYMENT_SET_QRIS]],
  ['📝 Set Catatan QRIS', [payment.paymentSetNoteCallback, ADMIN_CALLBACK.PAYMENT_SET_NOTE]],
  ['🏦 Set Info Rekening/E-Wallet', [payment.paymentSetBankCallback, ADMIN_CALLBACK.PAYMENT_SET_BANK]],

  ['➕ Tambah Stok Userbot', [pool.poolAddCallback, ADMIN_CALLBACK.POOL_ADD]],

  ['❌ Batal User', [user.userCancelCallback, ADMIN_CALLBACK.USER_CANCEL]],
  ['❌ Batal Produk', [product.productCancelCallback, ADMIN_CALLBACK.PRODUCT_CANCEL]],
  ['❌ Batal Payment', [payment.paymentCancelCallback, ADMIN_CALLBACK.PAYMENT_CANCEL]],
  ['❌ Batal Stok', [pool.poolCancelCallback, ADMIN_CALLBACK.POOL_CANCEL]],
  ['❌ Batal Sticker', [sticker.startStickerCancelCallback, ADMIN_CALLBACK.START_STICKER_CANCEL]],
  ['❌ Batal Durasi', [trial.trialSettingsCancelCallback, ADMIN_CALLBACK.TRIAL_SETTINGS_CANCEL]],
  ['❌ Batal Emoji', [premium.premiumEmojiCancelCallback, ADMIN_CALLBACK.PREMIUM_EMOJI_CANCEL]],
  ['❌ Batal Custom Submenu', [custom.customSubmenuCancelCallback, ADMIN_CALLBACK.CUSTOM_SUBMENU_CANCEL]],
  ['❌ Batal Wajib Join', [joinGate.joinGateCancelCallback, ADMIN_CALLBACK.JOIN_GATE_CANCEL]],

  ['🔍 Cari User', [user.userSearchCallback, ADMIN_CALLBACK.USER_SEARCH]],
  ['➕ Tambah User', [user.userAddCallback, ADMIN_CALLBACK.USER_ADD]],
  ['🔙 Kembali ke User Management', [user.userListCallback, ADMIN_CALLBACK.USER_LIST(0)]],
]);

function findStaticRoute(text) {
  const exact = STATIC_ROUTES.get(text);
  if (exact) return exact;

  // Native Telegram custom-emoji button icons are visual-only. The incoming
  // reply can therefore be the semantic/plain label while STATIC_ROUTES
  // still contains the historical label with its leading emoji. Resolve the
  // route by semantic label as a second pass.
  const semantic = normalizeLabel(text);
  if (!semantic) return null;
  for (const [label, route] of STATIC_ROUTES.entries()) {
    if (normalizeLabel(label) === semantic) return route;
  }
  return null;
}

function dynamicRoute(text) {
  const t = text.trim();
  const semantic = normalizeLabel(t);

  // Product list actions carry the category in the label so a reply tap can
  // enter the existing callback handler without any extra state coupling.
  // Match both the historical `➕ ...` label and Telegram's plain text
  // response when `icon_custom_emoji_id` is used.
  if (semantic === 'Tambah Produk Userbot') {
    return [product.productAddCallback, ADMIN_CALLBACK.PRODUCT_ADD('userbot')];
  }
  if (semantic === 'Tambah Produk Jaseb') {
    return [product.productAddCallback, ADMIN_CALLBACK.PRODUCT_ADD('jaseb')];
  }

  // User detail actions carry the Telegram ID. Native custom emoji icons can
  // disappear from the returned message text, so parse the semantic label.
  let m = semantic.match(/^Ban User #(\d+)$/);
  if (m) return [user.userBanCallback, ADMIN_CALLBACK.USER_BAN(Number(m[1]))];
  m = semantic.match(/^Unban User #(\d+)$/);
  if (m) return [user.userUnbanCallback, ADMIN_CALLBACK.USER_UNBAN(Number(m[1]))];
  m = semantic.match(/^Hapus User #(\d+)$/);
  if (m) return [user.userDeleteConfirmCallback, ADMIN_CALLBACK.USER_DEL_CONFIRM(Number(m[1]))];

  // User detail actions.
  m = semantic.match(/^Reset Trial User #(\d+)$/);
  if (m) return [user.userResetTrialCallback, ADMIN_CALLBACK.USER_RESET_TRIAL(Number(m[1]))];

  // Transaction detail actions.
  m = semantic.match(/^Lihat Bukti Pembayaran #(\d+)$/);
  if (m) return [transaction.transactionProofCallback, ADMIN_CALLBACK.TRANSACTION_PROOF(Number(m[1]))];
  m = semantic.match(/^Approve Order #(\d+)$/);
  if (m) return [transaction.transactionApproveCallback, ADMIN_CALLBACK.TRANSACTION_APPROVE(Number(m[1]))];
  m = semantic.match(/^Reject Order #(\d+)$/);
  if (m) return [transaction.transactionRejectCallback, ADMIN_CALLBACK.TRANSACTION_REJECT(Number(m[1]))];

  // Product detail/edit actions.
  m = semantic.match(/^Edit Produk #(\d+)$/);
  if (m) return [product.productEditCallback, ADMIN_CALLBACK.PRODUCT_EDIT(Number(m[1]))];
  m = semantic.match(/^Nonaktifkan Produk #(\d+)$/);
  if (m) return [product.productToggleCallback, ADMIN_CALLBACK.PRODUCT_TOGGLE(Number(m[1]))];
  m = semantic.match(/^Aktifkan Produk #(\d+)$/);
  if (m) return [product.productToggleCallback, ADMIN_CALLBACK.PRODUCT_TOGGLE(Number(m[1]))];
  m = semantic.match(/^Arsipkan Produk #(\d+)$/);
  if (m) return [product.productDeleteConfirmCallback, ADMIN_CALLBACK.PRODUCT_DEL_CONFIRM(Number(m[1]))];
  // Do not use a broad product matcher: field actions are resolved below by
  // their complete labels so custom icons/plain reply text remain stable.
  const productFieldMatchers = [
    [/^Nama Produk #(\d+)$/, 'name'],
    [/^Deskripsi Produk #(\d+)$/, 'description'],
    [/^Harga Produk #(\d+)$/, 'price'],
    [/^Durasi Produk #(\d+)$/, 'duration'],
    [/^Garansi Produk #(\d+)$/, 'garansi'],
    [/^Feature Access Produk #(\d+)$/, 'features'],
  ];
  for (const [re, field] of productFieldMatchers) {
    const fm = semantic.match(re);
    if (fm) return [product.productEditFieldCallback, ADMIN_CALLBACK.PRODUCT_EDIT_FIELD(Number(fm[1]), field)];
  }

  // Pool stock detail actions.
  m = semantic.match(/^Hapus Stok #(\d+)$/);
  if (m) return [pool.poolDeleteConfirmCallback, ADMIN_CALLBACK.POOL_DEL_CONFIRM(Number(m[1]))];
  m = semantic.match(/^Refresh Stok #(\d+)$/);
  if (m) return [pool.poolViewCallback, ADMIN_CALLBACK.POOL_VIEW(Number(m[1]))];

  // Contextual filter removal.
  m = semantic.match(/^Hapus Filter:\s*(.+)$/);
  if (m) return [user.userSearchClearCallback, ADMIN_CALLBACK.USER_SEARCH_CLEAR];

  return null;
}

function makeCallbackContext(ctx, data, match = null) {
  // Telegraf's ctx.callbackQuery is a getter over ctx.update.callback_query;
  // assigning ctx.callbackQuery directly does NOT replace it. The previous
  // implementation therefore reached handlers with callbackQuery.data
  // undefined, exactly matching the error seen in the admin-panel log.
  const originalCallback = ctx.update.callback_query;
  const originalMatch = ctx.match;
  const originalAnswer = ctx.answerCbQuery;
  const originalMessage = ctx.update.message;

  ctx.__adminReply = true;
  ctx.update.callback_query = {
    id: `reply-${Date.now()}-${ctx.from.id}`,
    data,
    message: originalMessage || {
      message_id: ctx.msgId,
      chat: ctx.chat,
      from: ctx.from,
      text: ctx.message && ctx.message.text,
    },
    from: ctx.from,
  };
  // Callback handlers only need callbackQuery.message for editing/fallbacks.
  // Keep the original reply message available as callbackQuery.message.
  ctx.match = match;
  // Reply-keyboard updates have no callback query to answer.
  ctx.answerCbQuery = async () => true;

  return () => {
    if (originalCallback === undefined) delete ctx.update.callback_query;
    else ctx.update.callback_query = originalCallback;
    if (originalMessage === undefined) delete ctx.update.message;
    else ctx.update.message = originalMessage;
    ctx.match = originalMatch;
    ctx.answerCbQuery = originalAnswer;
    delete ctx.__adminReply;
  };
}


// ---------------------------------------------------------------------
// Input-mode navigation (Kembali / Lewati) — see constants/adminInputFlows
// ---------------------------------------------------------------------

// Callback data -> [handler, matcher]. Only screens that an input step may
// return to are listed; each handler is the SAME one the inline button uses.
const PARENT_ROUTES = [
  [/^adminproduct:cat:/, () => product.productCatCallback],
  [/^adminproduct:edit:\d+$/, () => product.productEditCallback],
  [/^adminpayment:home$/, () => payment.paymentHomeCallback],
  [/^adminpool:home$/, () => pool.poolHomeCallback],
  [/^adminuser:list:/, () => user.userListCallback],
  [/^adminuser:view:/, () => user.userViewCallback],
  [/^start_sticker:home$/, () => sticker.startStickerHomeCallback],
  [/^trial_settings:home$/, () => trial.trialSettingsHomeCallback],
  [/^premium_emoji:home$/, () => premium.premiumEmojiHomeCallback],
  [/^join_gate:home$/, () => joinGate.joinGateHomeCallback],
  [/^settings_backup:home$/, () => settingsBackup.settingsBackupHomeCallback],
  [/^subext:sel:\d+$/, () => subExt.subextSelectCallback],
  [/^notification:registration$/, () => notification.notificationRegistrationHomeCallback],
  [/^notification:transaction$/, () => notification.notificationTransactionHomeCallback],
  [/^adminbroadcast:home$/, () => broadcast.broadcastHomeCallback],
  [/^adminreminder:home$/, () => reminder.reminderHomeCallback],
  [/^notification:home$/, () => notification.notificationHomeCallback],
  [/^button_icons:pickselect:([0-9a-f]{10})$/, () => buttonIcons.buttonIconsPickSelectCallback],
  [/^custom_submenu:select:(.+)$/, () => custom.customSubmenuSelectCallback],
  [/^custom_submenu:list$/, () => custom.customSubmenuListCallback],
  [/^custom_submenu:resend:(.+)$/, () => custom.customSubmenuResendCallback],
];

function resolveParentRoute(data) {
  for (const [re, getHandler] of PARENT_ROUTES) {
    const m = data.match(re);
    if (m) return [getHandler(), data, m];
  }
  return null;
}

// Wizard steps a Kembali can land on: how each one is re-rendered.
const STEP_PROMPTERS = {
  admin_product_add_name: (ctx, st, from) => product.promptProductAddStep(ctx, st, from),
  admin_product_add_price: (ctx, st, from) => product.promptProductAddStep(ctx, st, from),
  admin_product_add_duration: (ctx, st, from) => product.promptProductAddStep(ctx, st, from),
  admin_product_add_garansi: (ctx, st, from) => product.promptProductAddStep(ctx, st, from),
  admin_product_add_desc: (ctx, st, from) => product.promptProductAddStep(ctx, st, from),
  admin_pool_method: (ctx, st) => pool.promptPoolMethodStep(ctx, st),
  admin_pool_label: (ctx, st) => pool.promptPoolStep(ctx, st),
  admin_pool_phone: (ctx, st) => pool.promptPoolStep(ctx, st),
  admin_pool_session: (ctx, st) => pool.promptPoolStep(ctx, st),
};

// Optional-step "Lewati": SAME callback handlers the inline buttons use.
const SKIP_ROUTES = {
  admin_product_add_desc: () => [product.productAddDescSkipCallback, ADMIN_CALLBACK.PRODUCT_ADD_DESC_SKIP],
  admin_user_ban_reason: (st) => [user.userBanReasonSkipCallback, ADMIN_CALLBACK.USER_BAN_REASON_SKIP(st.telegramId)],
};

// A reply keyboard must never be left belonging to a screen the user has
// left. If the destination screen rendered no reply keyboard of its own
// (inline-only screens), install the navigation keyboard for its area.
function fallbackNavKeyboard() {
  return Markup.removeKeyboard();
}

/**
 * Runs `fn` while recording whether any ctx.reply carried a reply keyboard.
 * Resolves to true when the screen installed its own keyboard.
 */
async function trackReplyKeyboard(ctx, fn) {
  const original = ctx.reply;
  let installed = false;
  ctx.reply = function trackedReply(text, extra, ...rest) {
    const kb = extra && extra.reply_markup;
    if (kb && (kb.keyboard || kb.remove_keyboard)) installed = true;
    return original.call(this, text, extra, ...rest);
  };
  try {
    await fn();
  } finally {
    ctx.reply = original;
  }
  return installed;
}

const { isDuplicateNav } = require('../utils/navDebounce');

function resolveGenericBackRoute(ctx) {
  const tracked = screenState.get(ctx.chat && ctx.chat.id);
  const feature = tracked && tracked.feature ? String(tracked.feature) : '';
  if (!feature) return null;

  const direct = new Map([
    ['settings:open', [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME]],
    ['notification:home', [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME]],
    ['admin:statistics', [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME]],
    ['panel:home', [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME]],
  ]);
  const exact = direct.get(feature);
  if (exact) return exact;

  if (feature === 'admin:category:users' || feature === 'admin:category:statistics') return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];
  if (/^admin:category:(userbot|commerce|orders|notifications|settings)$/.test(feature)) return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];
  if (/^admin:statistics(?::|$)/.test(feature)) return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];

  // Root feature screens must return to the category that actually opened
  // them, not to themselves. These exact routes are intentionally resolved
  // before the broader feature-prefix fallbacks below. Without this, a
  // reply-keyboard "🔙 Kembali" from e.g. Produk Management resolves
  // `adminproduct:home` back to PRODUCT_HOME and renders the same screen
  // again (the duplicate/loop visible in the Telegram evidence).
  if (feature === ADMIN_CALLBACK.PRODUCT_HOME) return [adminCommerceCategoryCallback, 'admin:category:commerce'];
  if (/^adminuser:view:\d+$/.test(feature)) return [user.userListCallback, ADMIN_CALLBACK.USER_LIST(0)];
  if (/^adminuser:list:\d+$/.test(feature)) return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];
  if (/^admin_transactions_detail:\d+$/.test(feature)) return [transaction.transactionHomeCallback, ADMIN_CALLBACK.TRANSACTIONS_HOME];
  if (feature === ADMIN_CALLBACK.BROADCAST_HOME) return [adminNotificationsCategoryCallback, 'admin:category:notifications'];
  if (feature === ADMIN_CALLBACK.REMINDER_HOME) return [adminNotificationsCategoryCallback, 'admin:category:notifications'];
  if (feature === ADMIN_CALLBACK.NOTIFICATION_HOME) return [adminNotificationsCategoryCallback, 'admin:category:notifications'];
  if (feature === ADMIN_CALLBACK.PAYMENT_HOME) return [adminOrdersCategoryCallback, 'admin:category:orders'];
  if (/^admintrx:/.test(feature)) return [adminOrdersCategoryCallback, 'admin:category:orders'];
  if (feature === ADMIN_CALLBACK.PANEL_UBOT_HOME) return [adminUserbotCategoryCallback, 'admin:category:userbot'];
  if (feature === ADMIN_CALLBACK.SUBEXT_HOME) return [adminUserbotCategoryCallback, 'admin:category:userbot'];

  if (/^adminbroadcast:/.test(feature)) return [adminNotificationsCategoryCallback, 'admin:category:notifications'];
  if (/^adminreminder:/.test(feature)) return [adminNotificationsCategoryCallback, 'admin:category:notifications'];
  if (/^notification:(registration|transaction)$/.test(feature)) return [notification.notificationHomeCallback, ADMIN_CALLBACK.NOTIFICATION_HOME];
  if (feature === ADMIN_CALLBACK.NOTIFICATION_TESTIMONIAL_HOME) return [notification.notificationHomeCallback, ADMIN_CALLBACK.NOTIFICATION_HOME];
  if (/^(start_sticker|trial_settings|premium_emoji|join_gate|settings_backup|button_icons|custom_submenu):/.test(feature)) return [settingsCallback, ADMIN_CALLBACK.SETTINGS_OPEN];
  if (/^subext:/.test(feature)) return [adminUserbotCategoryCallback, 'admin:category:userbot'];
  if (/^adminproduct:view:\d+$/.test(feature)) {
    const productId = Number(feature.split(':').pop());
    const current = productService.getById(productId);
    return current ? [product.productListCallback, ADMIN_CALLBACK.PRODUCT_LIST(current.category, 0)] : [product.productHomeCallback, ADMIN_CALLBACK.PRODUCT_HOME];
  }
  if (/^adminproduct:edit:\d+$/.test(feature)) {
    const productId = Number(feature.split(':').pop());
    return [product.productEditCallback, ADMIN_CALLBACK.PRODUCT_EDIT(productId)];
  }
  if (/^adminproduct:/.test(feature)) return [product.productHomeCallback, ADMIN_CALLBACK.PRODUCT_HOME];
  if (/^adminuser:/.test(feature)) return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];
  if (/^adminpayment:/.test(feature)) return [adminOrdersCategoryCallback, 'admin:category:orders'];
  if (/^adminpool:view:\d+$/.test(feature)) {
    const poolId = Number(feature.split(':').pop());
    return [pool.poolHomeCallback, ADMIN_CALLBACK.POOL_HOME];
  }
  if (/^adminpool:/.test(feature)) return [adminCommerceCategoryCallback, 'admin:category:commerce'];
  if (/^admintrx:/.test(feature)) return [transaction.transactionHomeCallback, ADMIN_CALLBACK.TRANSACTIONS_HOME];
  if (/^adminpanelubot:/.test(feature)) return [adminUserbotCategoryCallback, 'admin:category:userbot'];
  if (/^panel_ubot:|^panel:/.test(feature)) return [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME];
  return null;
}

async function runRoute(ctx, route) {
  const [handler, callbackData, match] = route;
  const restore = makeCallbackContext(ctx, callbackData, match);
  try {
    await handler(ctx);
  } finally {
    restore();
  }
}

/** "🔙 Kembali" inside an admin input step. */
async function handleInputBack(ctx, state) {
  const uid = ctx.from.id;
  const back = inputFlows.resolveBack(state);
  if (!back) return false;
  if (back.dropLogin) {
    // Abort the real GramJS login attempt BEFORE the state changes, so a late
    // OTP/2FA result can never finish an abandoned onboarding.
    try { gramjsService.cancelLogin(uid); } catch (_) {}
  }
  if (back.kind === 'step') {
    // Keep every already-entered valid value; only the active step changes.
    const next = { ...state, action: back.action };
    if (state.action === 'previewing') {
      // Custom submenu preview -> input step reuses the existing Resend handler.
      const route = resolveParentRoute(ADMIN_CALLBACK.CUSTOM_SUBMENU_RESEND(state.submenuId));
      adminState.clear(uid);
      await runRoute(ctx, route);
      return true;
    }
    const prompt = STEP_PROMPTERS[back.action];
    adminState.set(uid, next);
    if (prompt) await prompt(ctx, next, state.action);
    return true;
  }
  adminState.clear(uid);
  const route = resolveParentRoute(back.callback);
  if (!route) {
    logger.warn(`adminReply: no parent route for ${back.callback}`);
    await runRoute(ctx, [adminPanelHandler, ADMIN_CALLBACK.PANEL_HOME]);
    return true;
  }
  const installed = await trackReplyKeyboard(ctx, () => runRoute(ctx, route));
  if (!installed) await ctx.reply('\u2063', fallbackNavKeyboard(back.callback));
  return true;
}

/** "⏭️ Lewati …" inside an optional admin input step. */
async function handleInputSkip(ctx, state) {
  const factory = SKIP_ROUTES[state.action];
  if (!factory) return false;
  await runRoute(ctx, factory(state));
  return true;
}

function adminReplyMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    if (ctx.updateType !== 'message' || !ctx.message || typeof ctx.message.text !== 'string') {
      return next();
    }

    const text = ctx.message.text.trim();

    // Standard Kembali on a normal admin screen is context-aware. It uses the
    // last rendered screen's feature, never the visual button label, so one
    // generic label can safely navigate to different parents per admin/chat.
    if (text === inputFlows.BACK_LABEL && !adminState.get(ctx.from.id)) {
      const backRoute = resolveGenericBackRoute(ctx);
      if (backRoute) {
        if (isDuplicateNav(ctx.from.id, inputFlows.BACK_LABEL)) return;
        flowCancellation.cancelAll(ctx.from.id);
        await runRoute(ctx, backRoute);
        return;
      }
    }

    // Input-mode navigation is state-scoped: Kembali/Lewati only act while the
    // admin is actually inside a registered input step. With no such state they
    // fall through to the normal bot navigation.
    const inputState = adminState.get(ctx.from.id);
    const flow = inputState && inputFlows.getFlow(inputState.action);
    if (flow && text === inputFlows.CANCEL_LABEL) {
      const cancelRoute = findStaticRoute(flow.cancel);
      if (cancelRoute) {
        if (isDuplicateNav(ctx.from.id, inputFlows.CANCEL_LABEL)) return;
        const [handler, callbackData, match] = cancelRoute;
        const hadActiveFlow = flowCancellation.hasActiveFlow(ctx.from.id);
        flowCancellation.cancelAll(ctx.from.id);
        if (hadActiveFlow) await replyCancelled(ctx);
        const restore = makeCallbackContext(ctx, callbackData, match);
        try {
          const installed = await trackReplyKeyboard(ctx, () => handler(ctx));
          if (!installed) await ctx.reply('\u2063', fallbackNavKeyboard(callbackData));
        } finally {
          restore();
        }
        return;
      }
    }
    if (flow) {
      const nav = buttonIconConfig.findDefaultLabel(text, [inputFlows.BACK_LABEL, flow.skip].filter(Boolean));
      if (nav) {
        if (isDuplicateNav(ctx.from.id, nav)) return;
        try {
          const handled = nav === inputFlows.BACK_LABEL
            ? await handleInputBack(ctx, inputState)
            : await handleInputSkip(ctx, inputState);
          if (handled) return;
        } catch (err) {
          logger.error('adminReply input nav error:', err && err.message ? err.message : err);
          await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
          return;
        }
      }
    }

    const canonical = buttonIconConfig.findDefaultLabel(text, Array.from(STATIC_ROUTES.keys()));
    const route = findStaticRoute(canonical || text) || dynamicRoute(canonical || text);
    if (!route) return next();

    const [handler, callbackData, match] = route;

    // Every admin reply-keyboard route is navigation/action. Cancel any
    // previous admin/userbot/token/panel input before entering the new one.
    const hadActiveFlow = flowCancellation.hasActiveFlow(ctx.from.id);
    flowCancellation.cancelAll(ctx.from.id);
    if (hadActiveFlow) await replyCancelled(ctx);

    const restore = makeCallbackContext(ctx, callbackData, match);
    try {
      const installed = await trackReplyKeyboard(ctx, () => handler(ctx));
      // Batal on an input step must not leave that step's Kembali/Batal
      // keyboard on screen when the parent screen is inline-only.
      if (hadActiveFlow && !installed && inputState && flow) {
        await ctx.reply('\u2063', fallbackNavKeyboard(callbackData));
      }
    } finally {
      restore();
    }
  };
}

module.exports = { adminReplyMiddleware, resolveParentRoute, fallbackNavKeyboard, PARENT_ROUTES, STEP_PROMPTERS, SKIP_ROUTES };
