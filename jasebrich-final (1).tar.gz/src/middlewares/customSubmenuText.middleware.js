const { isAdminId } = require('./admin.middleware');
const adminState = require('../state/adminState');
const { handleIncomingCustomText } = require('../handlers/admin/customSubmenu.handler');
const logger = require('../utils/logger');
const { adminInputKeyboard } = require('../keyboards/admin.keyboard');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');

/**
 * Must be registered with bot.use() BEFORE bot.hears()/bot.on('text')
 * so it can intercept a plain text message before the reply-keyboard
 * matchers or the "unrecognized command" fallback see it. Otherwise an
 * admin typing their custom message could accidentally trigger a menu
 * button or fall through to "Perintah tidak dikenali".
 */
function customSubmenuTextMiddleware() {
  return async (ctx, next) => {
    const isTextMessage = ctx.updateType === 'message' && ctx.message && typeof ctx.message.text === 'string';

    if (!isTextMessage || !ctx.from || !isAdminId(ctx.from.id)) {
      return next();
    }

    const state = adminState.get(ctx.from.id);
    if (!state || state.action !== 'waiting_for_custom_text') {
      return next();
    }

    try {
      await handleIncomingCustomText(ctx, state);
    } catch (err) {
      logger.error('customSubmenuTextMiddleware error:', err && err.message ? err.message : err);
      const message = err && err.message ? String(err.message) : 'Gagal memproses pesan custom.';
      const content = userResponseTpl.customInputInvalid.getContent(ctx, { placeholderValues: { reason: message } });
      await ctx.reply(content.text, { ...buildReplyOptions(content), ...adminInputKeyboard(adminState.get(ctx.from.id) || state) });
    }
    // Intentionally not calling next() — this text was consumed as
    // custom-submenu input, not a menu command.
  };
}

module.exports = { customSubmenuTextMiddleware };
