const buyerState = require('../state/buyerState');
const ubotFlow = require('../handlers/ubotFlow.handler');
const logger = require('../utils/logger');
const { MENU } = require('../constants/menu');
const { isDuplicateNav } = require('../utils/navDebounce');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');

/**
 * Intercepts text/contact messages while a buyer is mid-flow
 * activating an owned userbot (phone -> OTP -> optional 2FA
 * password). Must run BEFORE bot.hears()/bot.on('text') — same
 * pattern as customSubmenuText.middleware.js — so a manually-typed
 * phone number or OTP code never gets swallowed by a menu-button
 * match or the "unrecognized command" fallback.
 */
function ubotLoginTextMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from) return next();

    const isTextMessage = ctx.updateType === 'message' && ctx.message && typeof ctx.message.text === 'string';
    const isContactMessage = ctx.updateType === 'message' && ctx.message && ctx.message.contact;

    if (!isTextMessage && !isContactMessage) return next();

    // Both /cancel and the visible Batal reply button must cancel the
    // same flow. The pending userbot record is intentionally preserved so
    // the user can resume it later from "🤖 Buat Userbot".
    if (isTextMessage && ['/cancel', MENU.BATAL].includes(ctx.message.text.trim())) {
      const handled = await ubotFlow.cancelFlow(ctx);
      if (handled) return; // consumed
      return next();
    }

    const state = buyerState.get(ctx.from.id);
    if (!state) return next();

    const WIZARD_STEPS = ['await_phone', 'await_otp', 'await_password'];
    if (isTextMessage && ctx.message.text.trim() === MENU.KEMBALI && WIZARD_STEPS.includes(state.step)) {
      // Kembali steps back ONE step; a duplicate delivery must not step twice.
      if (isDuplicateNav(ctx.from.id, MENU.KEMBALI)) return;
      try {
        if (await ubotFlow.backFlow(ctx)) return;
      } catch (err) {
        logger.error('ubotLogin back error:', err && err.message ? err.message : err);
        { const c = userResponseTpl.ubotGenericError.getContent(ctx); await ctx.reply(c.text, { ...buildReplyOptions(c), ...ubotFlow.keyboardForStep(state.step) }); }
        return;
      }
    }

    // Contact shared while a code/password is expected: answer in place, keep the step.
    if (isContactMessage && WIZARD_STEPS.includes(state.step) && state.step !== 'await_phone') {
      { const c = userResponseTpl.contactNotNeeded.getContent(ctx); await ctx.reply(c.text, { ...buildReplyOptions(c), ...ubotFlow.keyboardForStep(state.step) }); }
      return;
    }

    try {
      if (isContactMessage && state.step === 'trial_contact') {
        // Trial flow intentionally requires Telegram's own contact-share
        // button, and only accepts the user's own contact.
        if (Number(ctx.message.contact.user_id) !== Number(ctx.from.id)) {
          { const c = userResponseTpl.contactOwnRequired.getContent(ctx); await ctx.reply(c.text, { ...buildReplyOptions(c), ...ubotFlow.phoneKeyboard() }); }
          return;
        }
        await ubotFlow.handlePhoneInput(ctx, { ...state, flow: 'trial' }, ctx.message.contact.phone_number);
        return;
      }
      if (isTextMessage && state.step === 'trial_contact') {
        { const c = userResponseTpl.contactPrompt.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
        return;
      }
      if (isContactMessage && state.step === 'await_phone') {
        if (Number(ctx.message.contact.user_id) !== Number(ctx.from.id)) {
          { const c = userResponseTpl.contactWrongAccount.getContent(ctx); await ctx.reply(c.text, { ...buildReplyOptions(c), ...ubotFlow.phoneKeyboard() }); }
          return;
        }
        await ubotFlow.handlePhoneInput(ctx, state, ctx.message.contact.phone_number);
        return;
      }
      if (isTextMessage && state.step === 'await_phone') {
        await ubotFlow.handlePhoneInput(ctx, state, ctx.message.text);
        return;
      }
      if (isTextMessage && state.step === 'await_otp') {
        await ubotFlow.handleOtpInput(ctx, state, ctx.message.text);
        return;
      }
      if (isTextMessage && state.step === 'await_password') {
        await ubotFlow.handlePasswordInput(ctx, state, ctx.message.text);
        return;
      }
    } catch (err) {
      logger.error('ubotLoginTextMiddleware error:', err && err.message ? err.message : err);
      { const { getSafeErrorContent } = require('../utils/errors'); const safe = getSafeErrorContent(ctx); await ctx.reply(safe.text, WIZARD_STEPS.includes(state.step) ? { ...safe.options, ...ubotFlow.keyboardForStep(state.step) } : safe.options); }
      return;
    }

    return next();
  };
}

module.exports = { ubotLoginTextMiddleware };
