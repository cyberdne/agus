const { config } = require('../config');
const logger = require('../utils/logger');

/**
 * True if the given Telegram user id is listed in ADMIN_IDS.
 */
function isAdminId(telegramId) {
  return config.adminIds.includes(telegramId);
}

/**
 * Wrap a handler so it only runs for admins. Non-admins are silently
 * ignored (no error leaked, no hint that an admin-only action exists).
 * Every admin-only command/action MUST go through this — a hidden
 * button alone is not access control.
 */
function requireAdmin(handler) {
  return async (ctx, ...rest) => {
    const telegramId = ctx.from && ctx.from.id;

    if (!telegramId || !isAdminId(telegramId)) {
      if (ctx.answerCbQuery) {
        try {
          await ctx.answerCbQuery();
        } catch (err) {
          // ignore — best effort only
        }
      }
      logger.warn(`Blocked non-admin access attempt by user ${telegramId}`);
      return;
    }

    return handler(ctx, ...rest);
  };
}

module.exports = { isAdminId, requireAdmin };
