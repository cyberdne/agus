const userRepo = require('../database/repositories/user.repository');
const { isAdminId } = require('./admin.middleware');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');

/**
 * Blocks banned users from any interaction except seeing why. Admins
 * are never blocked by this even if a stale record marks them banned.
 */
function banGuardMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from) return next();
    if (isAdminId(ctx.from.id)) return next();

    if (userRepo.isBanned(ctx.from.id)) {
      if (ctx.answerCbQuery) {
        try {
          { const c = userResponseTpl.banCallback.getContent(ctx); await ctx.answerCbQuery(c.text, { show_alert: true }); }
        } catch (err) {
          // best effort
        }
      } else if (ctx.reply) {
        { const c = userResponseTpl.banMessage.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
      }
      return;
    }

    return next();
  };
}

module.exports = { banGuardMiddleware };
