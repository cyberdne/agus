const { isAdminId } = require('./admin.middleware');
const joinGateService = require('../services/joinGate.service');
const logger = require('../utils/logger');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');

/**
 * Blocks newly-created/unverified users until they join the required
 * channel. Admins are always allowed through so the owner cannot lock
 * themselves out while configuring the gate.
 */
function joinGateMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || isAdminId(ctx.from.id)) return next();

    // Callback retry is allowed through so it can perform a fresh
    // membership check and render a verified state transition. All normal
    // commands, text handlers and callbacks are protected because this
    // middleware is registered before those entry points in index.js.
    if (ctx.updateType === 'callback_query' && ctx.callbackQuery?.data === 'join_gate:retry') {
      return next();
    }

    try {
      const allowed = await joinGateService.ensureAccess(ctx);
      if (allowed) return next();
      await joinGateService.sendGateMessage(ctx);
    } catch (err) {
      logger.error(`Join gate middleware error for ${ctx.from.id}: ${err.message}`);
      { const c = userResponseTpl.joinGateError.getContent(ctx); await ctx.reply(c.text, buildReplyOptions(c)); }
    }
  };
}

module.exports = { joinGateMiddleware };
