const tokenClaimState = require('../state/tokenClaimState');
const tokenHandler = require('../handlers/token.handler');
const logger = require('../utils/logger');
const { MENU } = require('../constants/menu');
const { isDuplicateNav } = require('../utils/navDebounce');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');

/**
 * Intercepts text messages while a user is mid-flow typing their
 * Token Login (see handlers/token.handler.js#klaimTokenHandler). Must
 * run BEFORE bot.hears()/bot.on('text') — same pattern as
 * ubotLoginText.middleware.js — so a manually-typed token code never
 * gets swallowed by a menu-button match or the "unrecognized command"
 * fallback, and so "❌ Batal" cancels the flow instead of falling
 * through to the normal Batal handler mid-input.
 */
function tokenClaimTextMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from) return next();

    const isTextMessage = ctx.updateType === 'message' && ctx.message && typeof ctx.message.text === 'string';
    if (!isTextMessage) return next();

    const state = tokenClaimState.get(ctx.from.id);
    if (!state) return next();

    const text = ctx.message.text.trim();
    if (text === '/cancel' || text === '❌ Batal') {
      await tokenHandler.cancelClaim(ctx);
      return;
    }

    // Kembali is navigation, never a token candidate.
    if (text === MENU.KEMBALI && state.step === 'await_token') {
      if (isDuplicateNav(ctx.from.id, MENU.KEMBALI)) return;
      await tokenHandler.backFromClaim(ctx);
      return;
    }

    if (state.step === 'await_token') {
      try {
        await tokenHandler.handleTokenInput(ctx, text);
      } catch (err) {
        logger.error('tokenClaimTextMiddleware error:', err && err.message ? err.message : err);
        { const c = userResponseTpl.tokenProcessError.getContent(ctx); await ctx.reply(c.text, { ...buildReplyOptions(c), ...tokenHandler.claimKeyboardMarkup() }); }
      }
      return;
    }

    return next();
  };
}

module.exports = { tokenClaimTextMiddleware };
