'use strict';

const { isAdminId } = require('./admin.middleware');
const logger = require('../utils/logger');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const { buildReplyOptions } = require('../services/custom-submenu.service');
const { createRateLimiter, getActionIdentity } = require('../utils/interactionRateLimiter');

/**
 * Production inbound anti-flood layer.
 *
 * This is intentionally NOT a single global threshold. Navigation, heavy
 * userbot operations, authentication, transactions, and admin operations have
 * separate buckets so a normal menu burst cannot consume the same allowance
 * as a DB/GramJS-heavy action. Duplicate Telegram updates and rapid repeats of
 * the exact same navigation action are handled as idempotency/dedup cases,
 * rather than being reported as abuse.
 */
const limiter = createRateLimiter();

function floodGuardMiddleware() {
  return async (ctx, next) => {
    const telegramId = ctx.from && ctx.from.id;
    if (!telegramId) return next();

    const admin = isAdminId(telegramId);
    const { action, bucket, kind } = getActionIdentity(ctx, admin);
    const result = limiter.consume({
      userId: telegramId,
      chatId: ctx.chat && ctx.chat.id,
      action,
      bucket,
      updateId: ctx.update && ctx.update.update_id,
    });

    if (result.allowed) return next();

    // Telegram callback spinners must always be cleared, even for duplicate
    // delivery. A silent drop is appropriate for ordinary repeated messages.
    if (kind === 'callback' && typeof ctx.answerCbQuery === 'function') {
      try {
        if (result.rateLimited) {
          if (!result.shouldWarn) {
            await ctx.answerCbQuery('', { show_alert: false });
            return;
          }
          const content = userResponseTpl.rateLimitedCallback.getContent(ctx);
          await ctx.answerCbQuery(content.text, { show_alert: false });
        } else {
          await ctx.answerCbQuery('', { show_alert: false });
        }
      } catch (_) { /* best effort: the original action is intentionally not dispatched */ }
    } else if (result.rateLimited && result.shouldWarn && typeof ctx.reply === 'function') {
      try {
        const content = userResponseTpl.rateLimited.getContent(ctx);
        await ctx.reply(content.text, buildReplyOptions(content));
      } catch (err) {
        logger.warn('Flood guard warning reply failed:', err && err.message ? err.message : err);
      }
    }

    logger.warn(
      `Flood guard blocked user=${telegramId} bucket=${bucket} ` +
      `level=${result.level || 0} reason=${result.duplicateUpdate ? 'duplicate_update' : result.duplicateAction ? 'duplicate_action' : 'rate_limit'}`
    );
    return;
  };
}

module.exports = { floodGuardMiddleware, limiter };
