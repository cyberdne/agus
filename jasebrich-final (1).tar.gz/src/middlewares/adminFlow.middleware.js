const adminState = require('../state/adminState');
const { isAdminId } = require('./admin.middleware');
const productMgmt = require('../handlers/admin/productManagement.handler');
const paymentMgmt = require('../handlers/admin/paymentManagement.handler');
const poolMgmt = require('../handlers/admin/poolManagement.handler');
const userMgmt = require('../handlers/admin/userManagement.handler');
const startStickerMgmt = require('../handlers/admin/startSticker.handler');
const trialSettingsMgmt = require('../handlers/admin/trialSettings.handler');
const premiumEmojiMgmt = require('../handlers/admin/premiumEmoji.handler');
const joinGateMgmt = require('../handlers/admin/joinGateSettings.handler');
const logger = require('../utils/logger');
const buttonIconsMgmt = require('../handlers/admin/buttonIcons.handler');
const settingsBackupMgmt = require('../handlers/admin/settingsBackup.handler');
const subExtMgmt = require('../handlers/admin/subscriptionExtend.handler');
const notificationMgmt = require('../handlers/admin/notification.handler');
const testimonialMgmt = require('../handlers/admin/testimonial.handler');
const reminderMgmt = require('../handlers/admin/reminder.handler');
const inputFlows = require('../constants/adminInputFlows');
const { adminInputKeyboard } = require('../keyboards/admin.keyboard');

const TEXT_HANDLERS = {
  admin_product_add_name: productMgmt.handleProductAddNameText,
  admin_product_add_price: productMgmt.handleProductAddPriceText,
  admin_product_add_duration: productMgmt.handleProductAddDurationText,
  admin_product_add_garansi: productMgmt.handleProductAddGaransiText,
  admin_product_add_desc: productMgmt.handleProductAddDescText,
  admin_product_add_features: productMgmt.handleProductAddFeaturesText,
  admin_product_edit_value: productMgmt.handleProductEditValueText,
  admin_product_edit_features: productMgmt.handleProductEditFeaturesText,
  admin_payment_note: paymentMgmt.handlePaymentText,
  admin_payment_bank: paymentMgmt.handlePaymentText,
  admin_pool_label: poolMgmt.handlePoolLabelText,
  admin_pool_phone: poolMgmt.handlePoolPhoneText,
  admin_pool_session: poolMgmt.handlePoolSessionText,
  admin_pool_otp: poolMgmt.handlePoolOtpText,
  admin_pool_password: poolMgmt.handlePoolPasswordText,
  admin_user_search: userMgmt.handleUserSearchText,
  admin_user_add: userMgmt.handleUserAddText,
  admin_user_ban_reason: userMgmt.handleUserBanReasonText,
  admin_trial_duration: trialSettingsMgmt.handleTrialDurationText,
  admin_trial_features: trialSettingsMgmt.handleTrialFeaturesText,
  admin_premium_emoji_garansi: premiumEmojiMgmt.handlePremiumEmojiText,
  admin_premium_emoji_nongaransi: premiumEmojiMgmt.handlePremiumEmojiText,
  admin_join_gate_channel: joinGateMgmt.handleJoinGateText,
  admin_join_gate_group: joinGateMgmt.handleJoinGateText,
  admin_button_icon_set: buttonIconsMgmt.handleButtonIconText,
  admin_subext_custom: subExtMgmt.handleSubextCustomText,
  admin_notification_registration_channel: notificationMgmt.handleNotificationText,
  admin_notification_transaction_channel: notificationMgmt.handleNotificationText,
  admin_notification_transaction_duration: notificationMgmt.handleNotificationText,
  admin_notification_testimonial_channel: testimonialMgmt.handleTestimonialText,
  admin_notification_testimonial_buttons: testimonialMgmt.handleTestimonialText,
  admin_reminder_thresholds: reminderMgmt.handleReminderText,
};


/**
 * Retry UX: while an input step is active, every plain "❌ ..." reply a
 * handler sends (invalid phone/OTP/number/emoji/channel, generic failure...)
 * carries the SAME step's keyboard, so the user never loses Kembali/Batal
 * after a mistake. Applies only while adminState is still on the SAME step —
 * once a handler advances/clears the state, later replies are untouched — and
 * never overrides a keyboard/inline markup a handler chose explicitly.
 */
async function withRetryKeyboard(ctx, state, fn) {
  const original = ctx.reply;
  ctx.reply = function stepReply(text, extra, ...rest) {
    const current = adminState.get(ctx.from.id);
    const stillOnStep = current && current.action === state.action;
    const isError = typeof text === 'string' && text.trimStart().startsWith('❌');
    if (stillOnStep && isError && !(extra && extra.reply_markup)) {
      return original.call(this, text, { ...(extra || {}), ...adminInputKeyboard(current) }, ...rest);
    }
    return original.call(this, text, extra, ...rest);
  };
  try {
    return await fn();
  } finally {
    ctx.reply = original;
  }
}

function messageKind(msg) {
  if (!msg) return 'other';
  if (typeof msg.text === 'string') return 'text';
  if (msg.contact) return 'contact';
  if (msg.photo) return 'photo';
  if (msg.sticker) return 'sticker';
  if (msg.document) return 'document';
  return 'other';
}

const KIND_HINT = {
  text: 'pesan teks',
  photo: 'foto (kirim sebagai foto, bukan file)',
  sticker: 'sticker',
  document: 'file dokumen',
};

/**
 * Wrong-type input in an input step (e.g. a photo where text is expected, or
 * text where a sticker is expected) is answered in place with the step's own
 * keyboard, instead of being silently dropped or hitting the global fallback.
 */
function acceptedKinds(flow) {
  if (flow.kind === 'photo' || flow.kind === 'sticker' || flow.kind === 'document') return [flow.kind];
  if (flow.kind === 'choice') return [];
  return flow.contact ? ['text', 'contact'] : ['text'];
}

function adminFlowMismatchMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    if (ctx.updateType !== 'message' || !ctx.message) return next();
    const state = adminState.get(ctx.from.id);
    const flow = state && inputFlows.getFlow(state.action);
    if (!flow) return next();
    const kind = messageKind(ctx.message);
    if (kind === 'other') return next();
    if (acceptedKinds(flow).includes(kind)) return next();
    const expected = flow.kind === 'choice'
      ? 'Gunakan tombol pilihan di layar sebelumnya.'
      : `Kirim ${KIND_HINT[flow.kind] || 'input yang diminta'}.`;
    await ctx.reply(`❌ Input tidak sesuai. ${expected}`, adminInputKeyboard(state));
  };
}

/**
 * Admin-only text wizards (Product add/edit, Payment note/bank,
 * Userbot Pool onboarding). Must run BEFORE bot.hears()/bot.on('text')
 * — same pattern as customSubmenuText.middleware.js — so a typed
 * value never falls through to a menu-button match or the
 * "unrecognized command" fallback.
 */
function adminFlowTextMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    if (ctx.updateType !== 'message' || !ctx.message) return next();

    const state = adminState.get(ctx.from.id);
    if (!state) return next();

    if (ctx.message.contact && state.action === 'admin_pool_phone') {
      try {
        await withRetryKeyboard(ctx, state, () => poolMgmt.handlePoolPhoneContact(ctx, state));
      } catch (err) {
        logger.error('adminFlow contact error:', err && err.message ? err.message : err);
        await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
      }
      return;
    }

    if (typeof ctx.message.text !== 'string') return next();
    const handler = TEXT_HANDLERS[state.action];
    if (!handler) {
      // Photo/sticker/document steps have no text handler: answer in place
      // (with the step keyboard) instead of falling to the global fallback.
      const flow = inputFlows.getFlow(state.action);
      if (flow && ['photo', 'sticker', 'document'].includes(flow.kind)) {
        await ctx.reply(`❌ Input tidak sesuai. Kirim ${KIND_HINT[flow.kind]}.`, adminInputKeyboard(state));
        return;
      }
      if (flow && flow.kind === 'choice') {
        await ctx.reply('❌ Gunakan tombol pilihan di layar sebelumnya.', adminInputKeyboard(state));
        return;
      }
      return next();
    }

    try {
      await withRetryKeyboard(ctx, state, () => handler(ctx, state));
    } catch (err) {
      logger.error('adminFlowTextMiddleware error:', err && err.message ? err.message : err);
      await withRetryKeyboard(ctx, state, () => ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.'));
    }
  };
}

/** Admin-only QRIS photo capture. Registered via bot.on('photo', ...). */
/** Admin-only settings backup JSON capture. */
function adminFlowDocumentMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    const state = adminState.get(ctx.from.id);
    if (!state || state.action !== 'admin_settings_backup_import') return next();

    try {
      const handled = await withRetryKeyboard(ctx, state, () => settingsBackupMgmt.handleSettingsBackupDocument(ctx, state));
      if (handled) return;
    } catch (err) {
      logger.error('adminFlowDocumentMiddleware error:', err && err.message ? err.message : err);
      await ctx.reply('❌ Terjadi kesalahan saat membaca backup.');
      return;
    }

    return next();
  };
}

function adminFlowPhotoMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    const state = adminState.get(ctx.from.id);
    if (!state || !['admin_payment_qris_photo', 'admin_notification_testimonial_image'].includes(state.action)) return next();

    try {
      if (state.action === 'admin_notification_testimonial_image') {
        await withRetryKeyboard(ctx, state, () => testimonialMgmt.handleTestimonialPhoto(ctx, state));
        return;
      }
      await withRetryKeyboard(ctx, state, () => paymentMgmt.handlePaymentPhoto(ctx, state));
    } catch (err) {
      logger.error('adminFlowPhotoMiddleware error:', err && err.message ? err.message : err);
      await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
    }
  };
}

/** Admin-only /start sticker capture. Registered via bot.on('sticker', ...). */
function adminFlowStickerMiddleware() {
  return async (ctx, next) => {
    if (!ctx.from || !isAdminId(ctx.from.id)) return next();
    const state = adminState.get(ctx.from.id);
    if (!state || state.action !== 'admin_start_sticker') return next();

    try {
      await withRetryKeyboard(ctx, state, () => startStickerMgmt.handleStartStickerSticker(ctx, state));
    } catch (err) {
      logger.error('adminFlowStickerMiddleware error:', err && err.message ? err.message : err);
      await ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
    }
  };
}

module.exports = { withRetryKeyboard, adminFlowMismatchMiddleware, acceptedKinds, messageKind, adminFlowTextMiddleware, adminFlowDocumentMiddleware, adminFlowPhotoMiddleware, adminFlowStickerMiddleware };
