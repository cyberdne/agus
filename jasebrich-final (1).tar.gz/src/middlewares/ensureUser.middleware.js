const userRepository = require('../database/repositories/user.repository');
const notificationService = require('../services/notification.service');
const logger = require('../utils/logger');

/**
 * Guarantees a `users` row exists for `ctx.from` before any other
 * handler/middleware runs.
 *
 * Root cause this fixes: `bot.start(startHandler)` is the only place
 * that used to call `upsertFromTelegramUser`, because it's registered
 * before all middleware in index.js. Every other entry point (menu
 * buttons, "🏠 Menu Utama", "🎁 Coba Gratis", inline callbacks, etc.)
 * only ever SELECTs the user row — it's never guaranteed to exist,
 * e.g. after an admin "Reset Data"/delete, a restored DB, or any user
 * whose row is otherwise missing while their Telegram session/menu
 * state is still alive.
 *
 * Concretely this broke "Coba Gratis": `userbots.user_id` has
 * `FOREIGN KEY (user_id) REFERENCES users(telegram_id)`, so
 * `createTrialOwned()` throws `FOREIGN KEY constraint failed` the
 * moment such a user accepts the trial policy, which the generic
 * `safeHandler` catch then surfaces as "❌ Terjadi kesalahan saat
 * memproses permintaan." — exactly the error users hit tapping
 * Coba Gratis. The same missing-row FK failure is latent for orders/
 * subscriptions too, since those also reference users(telegram_id).
 *
 * Registered as the very first bot.use(), before ban guard/join gate,
 * so every downstream check (isBanned, hasClaimedTrial, join gate,
 * order/trial creation, ...) always sees a real row. Upsert is cheap
 * (single indexed UPSERT-by-telegram_id) and idempotent, so running it
 * on every update is safe.
 */
function ensureUserMiddleware() {
  return async (ctx, next) => {
    if (ctx.from) {
      try {
        const ensured = userRepository.ensureFromTelegramUser(ctx.from);
        if (ensured.created) {
          // Registration is already committed before this delivery attempt.
          // A Telegram API failure must never roll back the canonical user row.
          notificationService.sendRegistrationNotification(ctx.telegram, ensured.user).catch((err) => {
            logger.warn(`Registration notification async failure for ${ctx.from.id}: ${(err && err.message) || err}`);
          });
        }
      } catch (err) {
        logger.error(`ensureUserMiddleware failed for ${ctx.from.id}: ${err.message}`);
        // Fail closed: downstream handlers must never mutate orders, trials,
        // subscriptions, or userbots without a canonical users row.
        throw err;
      }
    }
    return next();
  };
}

module.exports = { ensureUserMiddleware };
