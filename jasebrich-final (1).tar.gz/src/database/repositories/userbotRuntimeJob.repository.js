const crypto = require('crypto');
const { getDb } = require('../index');

const JOB_TYPE_AUTO_PROMOSI = 'auto_promosi';
const RECOVERABLE_STATUSES = new Set(['running', 'failed']);

function jobKey(kind, id, type = JOB_TYPE_AUTO_PROMOSI) {
  return `${String(kind)}:${Number(id)}:${String(type)}`;
}

function parse(row) {
  if (!row) return null;
  return {
    ...row,
    cursor: Number.isInteger(Number(row.cursor)) ? Number(row.cursor) : 0,
  };
}

function find(kind, id, type = JOB_TYPE_AUTO_PROMOSI) {
  return parse(getDb().prepare(`
    SELECT * FROM userbot_runtime_jobs
     WHERE owner_kind = ? AND owner_id = ? AND job_type = ?
  `).get(String(kind), Number(id), String(type)));
}

function isRecoverable(job) {
  return Boolean(job && RECOVERABLE_STATUSES.has(String(job.status)) && job.cycle_id);
}

function startCycle(kind, id, { cursor = 0, cursorKey = null, worksetHash = null, nextRunAt = null, totalTargets = 0 } = {}) {
  const now = new Date().toISOString();
  const current = find(kind, id);
  const cycleId = crypto.randomUUID();
  const cycleNumber = Math.max(1, Number(current?.cycle_number || 0) + 1);
  const key = jobKey(kind, id);
  getDb().prepare(`
    INSERT INTO userbot_runtime_jobs
      (job_key, owner_kind, owner_id, job_type, status, cursor, cursor_key,
       cycle_id, workset_hash, next_run_at, started_at, heartbeat_at, updated_at, last_error,
       total_targets, processed_targets, successful_targets, failed_targets, blocked_targets, removed_targets,
       sent_count, failed_count, cycle_number, last_activity_at)
    VALUES (?, ?, ?, ?, 'running', ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 0, 0, 0, 0, 0, 0, 0, ?, ?)
    ON CONFLICT(job_key) DO UPDATE SET
      status='running', cursor=excluded.cursor, cursor_key=excluded.cursor_key, cycle_id=excluded.cycle_id,
      workset_hash=excluded.workset_hash, next_run_at=excluded.next_run_at, started_at=excluded.started_at,
      heartbeat_at=excluded.heartbeat_at, updated_at=excluded.updated_at, last_error=NULL,
      total_targets=excluded.total_targets, processed_targets=0, successful_targets=0, failed_targets=0,
      blocked_targets=0, removed_targets=0, sent_count=0, failed_count=0, cycle_number=excluded.cycle_number,
      last_activity_at=excluded.last_activity_at
  `).run(
    key, String(kind), Number(id), JOB_TYPE_AUTO_PROMOSI, Math.max(0, Number(cursor) || 0),
    cursorKey == null ? null : String(cursorKey), cycleId, worksetHash == null ? null : String(worksetHash),
    nextRunAt == null ? null : String(nextRunAt), now, now, now, Math.max(0, Number(totalTargets) || 0), cycleNumber, now
  );
  return find(kind, id);
}

function ensureRecoverableCycle(kind, id, { firstCursorKey = null, worksetHash = null, totalTargets = 0 } = {}) {
  const current = find(kind, id);
  if (isRecoverable(current) && (!worksetHash || !current.workset_hash || current.workset_hash === String(worksetHash))) {
    return { job: current, resumed: true };
  }
  return { job: startCycle(kind, id, { cursor: 0, cursorKey: firstCursorKey, worksetHash, totalTargets }), resumed: false };
}

function checkpoint(kind, id, cycleId, { cursor, cursorKey, nextRunAt = null } = {}) {
  const now = new Date().toISOString();
  const result = getDb().prepare(`
    UPDATE userbot_runtime_jobs
       SET cursor = ?,
           cursor_key = ?,
           next_run_at = ?,
           heartbeat_at = ?,
           updated_at = ?,
           status = 'running',
           last_error = NULL
     WHERE owner_kind = ? AND owner_id = ? AND job_type = ?
       AND status = 'running' AND cycle_id = ?
  `).run(
    Math.max(0, Number(cursor) || 0),
    cursorKey == null ? null : String(cursorKey),
    nextRunAt == null ? null : String(nextRunAt),
    now,
    now,
    String(kind),
    Number(id),
    JOB_TYPE_AUTO_PROMOSI,
    String(cycleId),
  );
  return result.changes === 1;
}

function recordTargetResult(kind, id, cycleId, { success = false, blocked = false, removed = false, sentCount = 0, failedCount = 0 } = {}) {
  const now = new Date().toISOString();
  return getDb().prepare(`
    UPDATE userbot_runtime_jobs
       SET processed_targets = processed_targets + 1,
           successful_targets = successful_targets + ?,
           failed_targets = failed_targets + ?,
           blocked_targets = blocked_targets + ?,
           removed_targets = removed_targets + ?,
           sent_count = sent_count + ?,
           failed_count = failed_count + ?,
           heartbeat_at = ?, updated_at = ?, last_activity_at = ?, status = 'running'
     WHERE owner_kind = ? AND owner_id = ? AND job_type = ? AND status = 'running' AND cycle_id = ?
  `).run(success ? 1 : 0, success ? 0 : 1, blocked ? 1 : 0, removed ? 1 : 0,
    Math.max(0, Number(sentCount) || 0), Math.max(0, Number(failedCount) || 0), now, now, now,
    String(kind), Number(id), JOB_TYPE_AUTO_PROMOSI, String(cycleId)).changes === 1;
}

function updateActivity(kind, id, cycleId) {
  const now = new Date().toISOString();
  return getDb().prepare(`UPDATE userbot_runtime_jobs SET heartbeat_at=?, updated_at=?, last_activity_at=?
    WHERE owner_kind=? AND owner_id=? AND job_type=? AND status='running' AND cycle_id=?`)
    .run(now, now, now, String(kind), Number(id), JOB_TYPE_AUTO_PROMOSI, String(cycleId)).changes === 1;
}

function findTargetHealthByTarget(kind, id, target) {
  return getDb().prepare('SELECT * FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target=? ORDER BY id DESC LIMIT 1')
    .get(String(kind), Number(id), String(target));
}
function findTargetHealth(kind, id, targetKey) {
  return getDb().prepare('SELECT * FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target_key=?')
    .get(String(kind), Number(id), String(targetKey));
}
function upsertTargetHealth(kind, id, { targetKey, target, status, error = null }) {
  const key = String(targetKey);
  const current = findTargetHealth(kind, id, key);
  const failureCount = current ? Number(current.failure_count || 0) + (status === 'unusable' ? 1 : 0) : (status === 'unusable' ? 1 : 0);
  const now = new Date().toISOString();
  getDb().prepare(`INSERT INTO userbot_promotion_target_health
    (owner_kind,owner_id,target_key,target,status,last_checked_at,last_error,failure_count,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?)
    ON CONFLICT(owner_kind,owner_id,target_key) DO UPDATE SET target=excluded.target,status=excluded.status,
      last_checked_at=excluded.last_checked_at,last_error=excluded.last_error,failure_count=excluded.failure_count,updated_at=excluded.updated_at`)
    .run(String(kind), Number(id), key, String(target), String(status), now, error ? String(error).slice(0,1000) : null, failureCount, now);
  return findTargetHealth(kind, id, key);
}
function listTargetHealth(kind, id) {
  return getDb().prepare('SELECT * FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? ORDER BY id ASC')
    .all(String(kind), Number(id));
}
function clearTargetHealth(kind, id, targetKey = null) {
  if (targetKey == null) return getDb().prepare('DELETE FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=?').run(String(kind), Number(id)).changes;
  return getDb().prepare('DELETE FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target_key=?').run(String(kind), Number(id), String(targetKey)).changes;
}

function heartbeat(kind, id, cycleId) {
  return getDb().prepare(`
    UPDATE userbot_runtime_jobs
       SET heartbeat_at = ?, updated_at = ?
     WHERE owner_kind = ? AND owner_id = ? AND job_type = ?
       AND status = 'running' AND cycle_id = ?
  `).run(
    new Date().toISOString(),
    new Date().toISOString(),
    String(kind),
    Number(id),
    JOB_TYPE_AUTO_PROMOSI,
    String(cycleId),
  ).changes === 1;
}

function complete(kind, id, cycleId, { nextRunAt = null } = {}) {
  const now = new Date().toISOString();
  return getDb().prepare(`
    UPDATE userbot_runtime_jobs
       SET status = 'idle',
           cursor = 0,
           cursor_key = NULL,
           next_run_at = ?,
           heartbeat_at = ?,
           updated_at = ?,
           last_error = NULL
     WHERE owner_kind = ? AND owner_id = ? AND job_type = ?
       AND status = 'running' AND cycle_id = ?
  `).run(
    nextRunAt == null ? null : String(nextRunAt),
    now,
    now,
    String(kind),
    Number(id),
    JOB_TYPE_AUTO_PROMOSI,
    String(cycleId),
  ).changes === 1;
}

function markFailed(kind, id, cycleId, error) {
  return getDb().prepare(`
    UPDATE userbot_runtime_jobs
       SET status = 'failed', heartbeat_at = ?, updated_at = ?, last_error = ?
     WHERE owner_kind = ? AND owner_id = ? AND job_type = ?
       AND status = 'running' AND cycle_id = ?
  `).run(
    new Date().toISOString(),
    new Date().toISOString(),
    String(error || 'runtime job failed').slice(0, 1000),
    String(kind),
    Number(id),
    JOB_TYPE_AUTO_PROMOSI,
    String(cycleId),
  ).changes === 1;
}

function cancel(kind, id, reason = 'cancelled') {
  return getDb().prepare(`
    INSERT INTO userbot_runtime_jobs
      (job_key, owner_kind, owner_id, job_type, status, cursor, updated_at, last_error)
    VALUES (?, ?, ?, ?, 'cancelled', 0, ?, ?)
    ON CONFLICT(job_key) DO UPDATE SET
      status='cancelled',
      cursor=0,
      cursor_key=NULL,
      cycle_id=NULL,
      workset_hash=NULL,
      next_run_at=NULL,
      heartbeat_at=NULL,
      started_at=NULL,
      total_targets=0,
      processed_targets=0,
      successful_targets=0,
      failed_targets=0,
      blocked_targets=0,
      removed_targets=0,
      sent_count=0,
      failed_count=0,
      cycle_number=0,
      last_activity_at=NULL,
      updated_at=excluded.updated_at,
      last_error=excluded.last_error
  `).run(
    jobKey(kind, id),
    String(kind),
    Number(id),
    JOB_TYPE_AUTO_PROMOSI,
    new Date().toISOString(),
    String(reason || 'cancelled').slice(0, 1000),
  ).changes === 1;
}

function listRecoverable() {
  return getDb().prepare(`
    SELECT * FROM userbot_runtime_jobs
     WHERE job_type = ? AND status IN ('running','failed')
     ORDER BY owner_kind ASC, owner_id ASC
  `).all(JOB_TYPE_AUTO_PROMOSI).map(parse);
}

module.exports = {
  JOB_TYPE_AUTO_PROMOSI,
  jobKey,
  find,
  isRecoverable,
  startCycle,
  ensureRecoverableCycle,
  checkpoint,
  heartbeat,
  complete,
  markFailed,
  recordTargetResult,
  updateActivity,
  findTargetHealth,
  findTargetHealthByTarget,
  upsertTargetHealth,
  listTargetHealth,
  clearTargetHealth,
  cancel,
  listRecoverable,
};
