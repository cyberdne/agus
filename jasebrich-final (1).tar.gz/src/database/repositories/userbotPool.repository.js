const { getDb } = require('../index');
const sessionStore = require('../../utils/userbotSessionStorage');

function hydrate(row) { return sessionStore.hydrateRow(row, 'pool', getDb()); }
function hydrateRows(rows) { return sessionStore.hydrateRows(rows, 'pool', getDb()); }


// These are the real persisted Kontrol Panel defaults declared in schema.js.
// Assignment paths use the SAME reset in their atomic UPDATE, so a stock
// userbot that was being used for admin promotion can be leased safely without
// leaking its prior runtime/panel configuration to the buyer.
const RESET_CONFIG_SQL = `
  target = NULL,
  broadcast_text = NULL,
  broadcast_text_entities = '[]',
  broadcast_kind = 'text',
  broadcast_source_chat_id = NULL,
  broadcast_source_message_id = NULL,
  wtb_replies = '[]',
  mode = 'sequential',
  delay_seconds = 5,
  timer_config = NULL,
  timer_enabled = 1,
  watermark = NULL,
  watermark_enabled = 1,
  topic_grup = NULL,
  pm_permit_text = NULL,
  wtb_timer = NULL,
  wtb_auto_reset_minutes = 1440,
  channel_disabled = 0,
  wtb_target_channel = NULL,
  wtb_banned_words = '',
  wtb_max_chars = 0,
  wtb_filter_links = 0,
  wtb_filter_usernames = 0,
  auto_react = 0,
  auto_react_emoji = '❤️',
  delay_max_seconds = NULL,
  round_delay_seconds = 3600,
  auto_promosi = 0,
  wtb_reply = 0,
  pm_permit = 0
`;

function findById(id) {
  return hydrate(getDb().prepare(`SELECT userbot_pool.*, COALESCE(users.is_banned, 0) AS owner_is_banned FROM userbot_pool LEFT JOIN users ON users.telegram_id = userbot_pool.assigned_user_id WHERE userbot_pool.id = ?`).get(id));
}

function listAvailable() {
  return hydrateRows(getDb().prepare("SELECT * FROM userbot_pool WHERE status = 'available' ORDER BY id ASC").all());
}

function listAvailableForPurchase() {
  releaseReservationsForClosedOrders();
  return hydrateRows(getDb()
    .prepare("SELECT * FROM userbot_pool WHERE status = 'available' AND telegram_userbot_id IS NOT NULL ORDER BY id ASC")
    .all()).filter((row) => Boolean(row.session_string));
}

function countAvailableForPurchase() {
  releaseReservationsForClosedOrders();
  const db = getDb();
  const persistedCount = Number(db.prepare(
    "SELECT COUNT(*) AS count FROM userbot_pool WHERE status = 'available' AND telegram_userbot_id IS NOT NULL"
  ).get().count || 0);
  if (persistedCount === 0) return 0;
  return hydrateRows(db
    .prepare("SELECT * FROM userbot_pool WHERE status = 'available' AND telegram_userbot_id IS NOT NULL ORDER BY id ASC")
    .all()).filter((row) => Boolean(row.session_string)).length;
}

function listAssignedToUser(telegramId) {
  return hydrateRows(getDb()
    .prepare("SELECT * FROM userbot_pool WHERE status = 'assigned' AND assigned_user_id = ? ORDER BY id ASC")
    .all(telegramId));
}

/** "Klaim Token": look up a leased pool userbot by its "Token Garansi" (see assign()). */
function findByToken(token) {
  return hydrate(getDb().prepare('SELECT * FROM userbot_pool WHERE token = ?').get(token));
}

function listAll() {
  return hydrateRows(getDb().prepare('SELECT * FROM userbot_pool ORDER BY id DESC').all());
}

function listExpired(nowIso) {
  return hydrateRows(getDb()
    .prepare("SELECT * FROM userbot_pool WHERE status = 'assigned' AND expires_at IS NOT NULL AND expires_at <= ?")
    .all(nowIso));
}

function normalizePhoneForIdentity(phone) {
  const value = String(phone || '').trim();
  return value || null;
}

function findByTelegramUserbotId(telegramUserbotId) {
  const id = Number(telegramUserbotId);
  if (!Number.isSafeInteger(id) || id <= 0) return null;
  return hydrate(getDb().prepare('SELECT * FROM userbot_pool WHERE telegram_userbot_id = ? LIMIT 1').get(id));
}

function findExistingAcrossUserbotTables(telegramUserbotId, phone = null) {
  const db = getDb();
  const id = Number(telegramUserbotId);
  if (Number.isSafeInteger(id) && id > 0) {
    const pool = db.prepare('SELECT id, label, status, telegram_userbot_id FROM userbot_pool WHERE telegram_userbot_id = ? LIMIT 1').get(id);
    if (pool) return { source: 'pool', ...pool };
    const owned = db.prepare('SELECT id, label, status, telegram_userbot_id FROM userbots WHERE telegram_userbot_id = ? LIMIT 1').get(id);
    if (owned) return { source: 'owned', ...owned };
  }
  const normalizedPhone = normalizePhoneForIdentity(phone);
  if (!normalizedPhone) return null;
  const pool = db.prepare('SELECT id, label, status, telegram_userbot_id FROM userbot_pool WHERE phone = ? LIMIT 1').get(normalizedPhone);
  if (pool) return { source: 'pool', ...pool };
  const owned = db.prepare('SELECT id, label, status, telegram_userbot_id FROM userbots WHERE phone = ? LIMIT 1').get(normalizedPhone);
  if (owned) return { source: 'owned', ...owned };
  return null;
}

function create({ label, phone, sessionString, telegramUserbotId }) {
  const db = getDb();
  const normalizedId = telegramUserbotId == null ? null : Number(telegramUserbotId);
  if (normalizedId != null && (!Number.isSafeInteger(normalizedId) || normalizedId <= 0)) {
    throw Object.assign(new Error('Telegram userbot ID tidak valid.'), { code: 'INVALID_USERBOT_ID' });
  }

  let insertedId = null;
  const tx = db.transaction(() => {
    if (normalizedId != null) {
      const duplicate = db.prepare(`
        SELECT 'pool' AS source, id, label, status, telegram_userbot_id
        FROM userbot_pool WHERE telegram_userbot_id = ?
        UNION ALL
        SELECT 'owned' AS source, id, label, status, telegram_userbot_id
        FROM userbots WHERE telegram_userbot_id = ?
        LIMIT 1
      `).get(normalizedId, normalizedId);
      if (duplicate) {
        throw Object.assign(new Error('Akun Telegram tersebut sudah terdaftar sebagai userbot/stok.'), {
          code: 'DUPLICATE_USERBOT',
          duplicate,
        });
      }
    }
    const normalizedPhone = normalizePhoneForIdentity(phone);
    if (normalizedPhone) {
      const duplicatePhone = db.prepare(`
        SELECT 'pool' AS source, id, label, status, telegram_userbot_id
        FROM userbot_pool WHERE phone = ?
        UNION ALL
        SELECT 'owned' AS source, id, label, status, telegram_userbot_id
        FROM userbots WHERE phone = ?
        LIMIT 1
      `).get(normalizedPhone, normalizedPhone);
      if (duplicatePhone) {
        throw Object.assign(new Error('Nomor Telegram tersebut sudah terdaftar sebagai userbot/stok.'), {
          code: 'DUPLICATE_USERBOT',
          duplicate: duplicatePhone,
        });
      }
    }

    const result = db.prepare(`
      INSERT INTO userbot_pool (label, phone, session_string, telegram_userbot_id, status)
      VALUES (?, ?, NULL, ?, 'available')
    `).run(label, normalizedPhone, normalizedId);
    insertedId = Number(result.lastInsertRowid);
    sessionStore.writeSession('pool', insertedId, sessionString);
    const stored = sessionStore.readSession('pool', insertedId);
    if (!stored || stored !== String(sessionString).trim()) {
      throw new Error('Session file verification failed after stock insertion.');
    }
  });

  try {
    tx();
  } catch (err) {
    if (insertedId != null) {
      try { sessionStore.deleteSession('pool', insertedId); } catch (cleanupErr) {
        err.message += `; cleanup session file failed: ${cleanupErr.message}`;
      }
    }
    throw err;
  }
  return findById(insertedId);
}

// Only flips a row that is STILL 'available' at the moment of the UPDATE —
// returns null (not the row) if another caller already claimed it first,
// so assignPoolToBuyer() can move on to the next candidate instead of
// silently overwriting someone else's assignment. Single UPDATE statement,
// so this check-and-set is atomic under better-sqlite3's synchronous
// execution model.
function assign(id, { userId, orderId, expiresAt, token }) {
  const result = getDb()
    .prepare(`
      UPDATE userbot_pool
      SET status = 'assigned', assigned_user_id = ?, assigned_order_id = ?, expires_at = ?, token = ?,
          reservation_order_id = NULL, reservation_expires_at = NULL,
          ${RESET_CONFIG_SQL},
          updated_at = datetime('now')
      WHERE id = ? AND status = 'available'
    `)
    .run(userId, orderId, expiresAt, token || null, id);
  return result.changes > 0 ? findById(id) : null;
}

function reserveForOrder(orderId, reservationExpiresAt) {
  if (!Number.isInteger(Number(orderId)) || Number(orderId) <= 0) return null;
  const candidate = listAvailableForPurchase()[0];
  if (!candidate) return null;
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'reserved', reservation_order_id = ?, reservation_expires_at = ?, updated_at = datetime('now')
    WHERE id = ? AND status = 'available'
  `).run(orderId, reservationExpiresAt, candidate.id);
  if (result.changes !== 1) return null;
  return findReservedByOrder(orderId);
}

function findReservedByOrder(orderId) {
  return hydrate(getDb().prepare("SELECT * FROM userbot_pool WHERE reservation_order_id = ? AND status = 'reserved' ORDER BY id ASC LIMIT 1").get(orderId));
}

function assignReservedToBuyer(orderId, { userId, expiresAt, token }) {
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'assigned', assigned_user_id = ?, assigned_order_id = ?, expires_at = ?, token = ?,
        reservation_order_id = NULL, reservation_expires_at = NULL,
        ${RESET_CONFIG_SQL},
        updated_at = datetime('now')
    WHERE status = 'reserved' AND reservation_order_id = ?
      AND reservation_expires_at IS NOT NULL AND datetime(reservation_expires_at) > datetime('now')
  `).run(userId, orderId, expiresAt, token || null, orderId);
  return result.changes === 1 ? hydrate(getDb().prepare("SELECT * FROM userbot_pool WHERE assigned_order_id = ? AND assigned_user_id = ? ORDER BY id DESC LIMIT 1").get(orderId, userId)) : null;
}

function releaseReservationByOrder(orderId) {
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'available', reservation_order_id = NULL, reservation_expires_at = NULL,
        ${RESET_CONFIG_SQL}, updated_at = datetime('now')
    WHERE status = 'reserved' AND reservation_order_id = ?
  `).run(orderId);
  return result.changes;
}

function releaseReservationsForUser(userId) {
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'available', reservation_order_id = NULL, reservation_expires_at = NULL,
        ${RESET_CONFIG_SQL}, updated_at = datetime('now')
    WHERE status = 'reserved' AND reservation_order_id IN (
      SELECT id FROM orders WHERE user_id = ? AND status IN ('cancelled','expired')
    )
  `).run(userId);
  return result.changes;
}

function releaseReservationsForClosedOrders() {
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'available', reservation_order_id = NULL, reservation_expires_at = NULL,
        ${RESET_CONFIG_SQL}, updated_at = datetime('now')
    WHERE status = 'reserved' AND (
      reservation_order_id IS NULL
      OR NOT EXISTS (SELECT 1 FROM orders o WHERE o.id = userbot_pool.reservation_order_id)
      OR EXISTS (SELECT 1 FROM orders o WHERE o.id = userbot_pool.reservation_order_id AND o.status IN ('cancelled','expired','fulfilled','rejected'))
      OR (reservation_expires_at IS NOT NULL AND datetime(reservation_expires_at) <= datetime('now'))
    )
  `).run();
  return result.changes;
}

function returnToPool(id) {
  getDb()
    .prepare(`
      UPDATE userbot_pool
      SET status = 'available', assigned_user_id = NULL, assigned_order_id = NULL, expires_at = NULL,
          reservation_order_id = NULL, reservation_expires_at = NULL,
          ${RESET_CONFIG_SQL}, updated_at = datetime('now')
      WHERE id = ?
    `)
    .run(id);
  return findById(id);
}

// Expiry return is conditional on the exact lease that was observed. The
// runtime teardown is performed BEFORE this mutation; this CAS prevents a
// delayed expiry worker from returning a row that has since been reassigned.
function returnExpiredToPool(id, expectedExpiresAt, nowIso) {
  const result = getDb()
    .prepare(`
      UPDATE userbot_pool
      SET status = 'available', assigned_user_id = NULL, assigned_order_id = NULL, expires_at = NULL,
          reservation_order_id = NULL, reservation_expires_at = NULL,
          ${RESET_CONFIG_SQL}, updated_at = datetime('now')
      WHERE id = ? AND status = 'assigned' AND expires_at = ? AND expires_at <= ?
    `)
    .run(id, expectedExpiresAt, nowIso);
  return result.changes === 1 ? findById(id) : null;
}

/** Admin revoke while still leased (garansi violation) — keeps assigned_user_id/token so "Klaim Token" can still find it. */
function disable(id) {
  getDb().prepare("UPDATE userbot_pool SET status = 'disabled', updated_at = datetime('now') WHERE id = ?").run(id);
  return findById(id);
}

/** "Klaim Token" -> Garansi Akses: restores access after disable() above. */
function reactivate(id) {
  getDb().prepare("UPDATE userbot_pool SET status = 'assigned', updated_at = datetime('now') WHERE id = ?").run(id);
  return findById(id);
}

function setFlags(id, { autoPromosi, wtbReply, pmPermit }) {
  const current = findById(id);
  if (!current) return null;
  getDb()
    .prepare("UPDATE userbot_pool SET auto_promosi = ?, wtb_reply = ?, pm_permit = ?, updated_at = datetime('now') WHERE id = ?")
    .run(
      autoPromosi !== undefined ? (autoPromosi ? 1 : 0) : current.auto_promosi,
      wtbReply !== undefined ? (wtbReply ? 1 : 0) : current.wtb_reply,
      pmPermit !== undefined ? (pmPermit ? 1 : 0) : current.pm_permit,
      id
    );
  return findById(id);
}

/** Kontrol Panel base config fields plus persisted Forward metadata and per-pool Base Reply JSON. */
function updateConfig(id, fields) {
  const current = findById(id);
  if (!current) return null;
  const next = {
    target: fields.target !== undefined ? fields.target : current.target,
    broadcast_text: fields.broadcast_text !== undefined ? fields.broadcast_text : current.broadcast_text,
    broadcast_text_entities: fields.broadcast_text_entities !== undefined ? fields.broadcast_text_entities : (current.broadcast_text_entities || '[]'),
    broadcast_kind: fields.broadcast_kind !== undefined ? fields.broadcast_kind : (current.broadcast_kind || 'text'),
    broadcast_source_chat_id: fields.broadcast_source_chat_id !== undefined ? fields.broadcast_source_chat_id : (current.broadcast_source_chat_id || null),
    broadcast_source_message_id: fields.broadcast_source_message_id !== undefined ? fields.broadcast_source_message_id : (current.broadcast_source_message_id || null),
    wtb_replies: fields.wtb_replies !== undefined ? fields.wtb_replies : (current.wtb_replies || '[]'),
    mode: fields.mode !== undefined ? fields.mode : current.mode,
    delay_seconds: fields.delay_seconds !== undefined ? fields.delay_seconds : current.delay_seconds,
    timer_config: fields.timer_config !== undefined ? fields.timer_config : current.timer_config,
    timer_enabled: fields.timer_enabled !== undefined ? (fields.timer_enabled ? 1 : 0) : (current.timer_enabled === 0 ? 0 : 1),
    watermark: fields.watermark !== undefined ? fields.watermark : current.watermark,
    watermark_enabled: fields.watermark_enabled !== undefined ? (fields.watermark_enabled ? 1 : 0) : (current.watermark_enabled === 0 ? 0 : 1),
    topic_grup: fields.topic_grup !== undefined ? fields.topic_grup : current.topic_grup,
  };
  getDb()
    .prepare(
      `UPDATE userbot_pool SET target = ?, broadcast_text = ?, broadcast_text_entities = ?, broadcast_kind = ?, broadcast_source_chat_id = ?, broadcast_source_message_id = ?, wtb_replies = ?, mode = ?, delay_seconds = ?, timer_config = ?, timer_enabled = ?, watermark = ?, watermark_enabled = ?, topic_grup = ?, updated_at = datetime('now') WHERE id = ?`
    )
    .run(next.target, next.broadcast_text, next.broadcast_text_entities, next.broadcast_kind, next.broadcast_source_chat_id, next.broadcast_source_message_id, next.wtb_replies, next.mode, next.delay_seconds, next.timer_config, next.timer_enabled, next.watermark, next.watermark_enabled, next.topic_grup, id);
  return findById(id);
}

/** Resets everything Kontrol Panel controls back to defaults (used by "Reset Ubot"). */
function resetConfig(id) {
  getDb()
    .prepare(`UPDATE userbot_pool SET ${RESET_CONFIG_SQL}, updated_at = datetime('now') WHERE id = ?`)
    .run(id);
  return findById(id);
}


/**
 * Atomically replace an invalid assigned lease with a still-available stock
 * userbot. The buyer identity, order identity and EXACT expiry timestamp are
 * carried over unchanged; only the leased pool row/token/runtime asset changes.
 * The candidate's full Control Panel configuration is reset in the same DB
 * transaction so promotional stock can be reassigned without leaking settings.
 */
function replaceInvalidAssignment(oldId, newId, { token }) {
  const db = getDb();
  const tx = db.transaction(() => {
    const old = db.prepare('SELECT * FROM userbot_pool WHERE id = ?').get(oldId);
    const candidate = db.prepare('SELECT * FROM userbot_pool WHERE id = ?').get(newId);
    if (!old || old.status !== 'assigned' || !old.assigned_user_id || !old.expires_at) return null;
    if (!candidate || candidate.status !== 'available' || candidate.telegram_userbot_id == null) return null;

    const oldOut = db.prepare(`
      UPDATE userbot_pool
      SET status = 'disabled', token = NULL, ${RESET_CONFIG_SQL}, updated_at = datetime('now')
      WHERE id = ? AND status = 'assigned' AND assigned_user_id = ? AND assigned_order_id IS ? AND expires_at = ? AND expires_at > datetime('now')
    `).run(old.id, old.assigned_user_id, old.assigned_order_id == null ? null : old.assigned_order_id, old.expires_at);
    if (oldOut.changes !== 1) return null;

    const newOut = db.prepare(`
      UPDATE userbot_pool
      SET status = 'assigned', assigned_user_id = ?, assigned_order_id = ?, expires_at = ?, token = ?,
          reservation_order_id = NULL, reservation_expires_at = NULL,
          ${RESET_CONFIG_SQL}, updated_at = datetime('now')
      WHERE id = ? AND status = 'available'
    `).run(old.assigned_user_id, old.assigned_order_id, old.expires_at, token || null, candidate.id);
    if (newOut.changes !== 1) throw new Error(`Pool replacement race untuk candidate #${candidate.id}`);

    let orderRefChanged = false;
    if (old.assigned_order_id != null) {
      const orderOut = db.prepare(`
        UPDATE orders
        SET fulfillment_ref = ?, updated_at = datetime('now')
        WHERE id = ? AND category = 'jaseb' AND status = 'fulfilled' AND fulfillment_ref = ?
      `).run(candidate.id, old.assigned_order_id, old.id);
      orderRefChanged = orderOut.changes === 1;
    }

    return {
      oldId: old.id,
      newId: candidate.id,
      userId: old.assigned_user_id,
      orderId: old.assigned_order_id,
      expiresAt: old.expires_at,
      orderRefChanged,
    };
  });
  return tx();
}

/** Disable an assigned lease whose Telegram session is known dead. Keeps ownership/order/expiry for audit, but removes the token so stale access cannot be revived. */
function disableInvalidAssignment(id) {
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'disabled', token = NULL, ${RESET_CONFIG_SQL}, updated_at = datetime('now')
    WHERE id = ? AND status = 'assigned'
  `).run(id);
  return result.changes === 1;
}

/** Disable an available stock row whose persisted Telegram session is known dead. */
function disableAvailableInvalid(id) {
  const result = getDb().prepare(`
    UPDATE userbot_pool
    SET status = 'disabled', ${RESET_CONFIG_SQL}, updated_at = datetime('now')
    WHERE id = ? AND status = 'available'
  `).run(id);
  return result.changes === 1;
}

/** Every leased pool userbot that is live and has at least one automation flag on — used to rebuild the runtime at boot. */
function listAutomatedAssigned() {
  return hydrateRows(getDb()
    .prepare(
      "SELECT * FROM userbot_pool WHERE status = 'assigned' AND (auto_promosi = 1 OR wtb_reply = 1 OR pm_permit = 1)"
    )
    .all()).filter((row) => Boolean(row.session_string));
}

function remove(id) {
  const result = getDb().prepare(`
    DELETE FROM userbot_pool
    WHERE id = ?
      AND status IN ('available','disabled')
      AND reservation_order_id IS NULL
      AND assigned_order_id IS NULL
      AND assigned_user_id IS NULL
  `).run(id);
  if (result.changes === 1) sessionStore.deleteSession('pool', id);
  return result.changes === 1;
}

function disableAllFlagsForUser(userId) {
  getDb()
    .prepare("UPDATE userbot_pool SET auto_promosi = 0, wtb_reply = 0, pm_permit = 0 WHERE assigned_user_id = ? AND status = 'assigned'")
    .run(userId);
}

module.exports = {
  findById,
  listAvailable,
  listAvailableForPurchase,
  countAvailableForPurchase,
  listAssignedToUser,
  findByToken,
  listAll,
  listExpired,
  findByTelegramUserbotId,
  findExistingAcrossUserbotTables,
  create,
  assign,
  reserveForOrder,
  findReservedByOrder,
  assignReservedToBuyer,
  releaseReservationByOrder,
  releaseReservationsForUser,
  releaseReservationsForClosedOrders,
  returnToPool,
  returnExpiredToPool,
  disable,
  reactivate,
  setFlags,
  updateConfig,
  resetConfig,
  replaceInvalidAssignment,
  disableInvalidAssignment,
  disableAvailableInvalid,
  listAutomatedAssigned,
  remove,
  disableAllFlagsForUser,
};
