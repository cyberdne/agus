const { getDb } = require('../index');

/**
 * Audit trail for owned-userbot subscription changes.
 * operation_id is UNIQUE: inserting the same operation twice is a no-op,
 * which is the persistence-level guarantee behind idempotent extensions.
 */

function findByOperationId(operationId) {
  return getDb().prepare('SELECT * FROM userbot_subscription_events WHERE operation_id = ?').get(operationId);
}

/** @returns {boolean} true if this call created the row, false if operation_id already existed. */
function insertIgnore(ev) {
  const res = getDb()
    .prepare(
      `INSERT OR IGNORE INTO userbot_subscription_events
         (operation_id, action, userbot_id, owner_user_id, admin_id, order_id,
          previous_status, previous_expiry, extension_days, new_status, new_expiry, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      ev.operationId,
      ev.action,
      ev.userbotId,
      ev.ownerUserId ?? null,
      ev.adminId ?? null,
      ev.orderId ?? null,
      ev.previousStatus ?? null,
      ev.previousExpiry ?? null,
      ev.extensionDays ?? null,
      ev.newStatus ?? null,
      ev.newExpiry ?? null,
      ev.createdAt
    );
  return res.changes === 1;
}

function listByUserbot(userbotId, limit = 20) {
  return getDb()
    .prepare('SELECT * FROM userbot_subscription_events WHERE userbot_id = ? ORDER BY id DESC LIMIT ?')
    .all(userbotId, limit);
}

module.exports = { findByOperationId, insertIgnore, listByUserbot };
