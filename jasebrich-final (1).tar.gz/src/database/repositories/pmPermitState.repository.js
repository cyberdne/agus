/**
 * Persistent PM Permit interaction/idempotency state.
 *
 * One row per (ownerKind, ownerId, peerId). This is what lets PM Permit
 * survive a process restart and stay correct under concurrent events for
 * the same peer, without ever relying on an in-memory Map or a
 * setTimeout-based delay.
 *
 * The important primitive is `tryClaim`: it does a single atomic
 * INSERT ... ON CONFLICT DO NOTHING against the UNIQUE(owner_kind,
 * owner_id, peer_id) index. better-sqlite3 executes this synchronously
 * against a single underlying connection, so when two "new PM" events for
 * the same peer are handled back-to-back (including interleaved via
 * async/await around the network send), only the first INSERT can ever
 * actually insert a row — the second necessarily observes the row already
 * existing. That is the whole idempotency guarantee; no locking flag in
 * application code can race around it.
 */
const { getDb } = require('../index');

const STALE_PENDING_MS = 2 * 60 * 1000; // abandoned in-flight claim recovery window

function find(ownerKind, ownerId, peerId) {
  return getDb()
    .prepare('SELECT * FROM pm_permit_state WHERE owner_kind = ? AND owner_id = ? AND peer_id = ?')
    .get(ownerKind, ownerId, String(peerId));
}

/**
 * Attempt to claim the right to send PM Permit to this peer.
 *
 * Returns one of:
 *  - { claimed: true }              -> caller may proceed to send now.
 *  - { claimed: false, reason }     -> caller must NOT send.
 *      reason: 'sent' | 'skipped' | 'pending'
 *
 * A brand-new peer gets a fresh 'pending' row inserted atomically. After a
 * successful response, last_responded_at defines a persistent rolling 24-hour
 * window. A pending claim with no successful response can be reclaimed after
 * STALE_PENDING_MS so a crash does not permanently block the peer.
 */
function tryClaim(ownerKind, ownerId, peerId) {
  const db = getDb();
  const pid = String(peerId);
  const insert = db.prepare(
    `INSERT INTO pm_permit_state (owner_kind, owner_id, peer_id, status, first_seen_at, updated_at, last_responded_at)
     VALUES (?, ?, ?, 'pending', datetime('now'), datetime('now'), NULL)
     ON CONFLICT(owner_kind, owner_id, peer_id) DO NOTHING`
  ).run(ownerKind, ownerId, pid);
  if (insert.changes > 0) return { claimed: true };

  const row = find(ownerKind, ownerId, pid);
  if (!row) return { claimed: false, reason: 'pending' };
  if (row.status === 'skipped') return { claimed: false, reason: 'skipped' };

  // PM Permit uses a persistent rolling 24-hour window. The timestamp is
  // stored in SQLite/UTC, so process restarts do not reset the window and
  // two concurrent events cannot both claim the same peer.
  const eligible = !row.last_responded_at || Number(db.prepare(
    `SELECT CASE WHEN datetime(?) <= datetime('now', '-24 hours') THEN 1 ELSE 0 END AS eligible`
  ).get(row.last_responded_at).eligible) === 1;
  if (!eligible) return { claimed: false, reason: 'sent' };

  const now = new Date().toISOString();
  const reclaim = db.prepare(
    `UPDATE pm_permit_state
        SET status='pending', updated_at=?
      WHERE owner_kind=? AND owner_id=? AND peer_id=?
        AND status != 'skipped'
        AND (last_responded_at IS NULL OR datetime(last_responded_at) <= datetime('now', '-24 hours'))`
  ).run(now, ownerKind, ownerId, pid);
  if (reclaim.changes > 0) return { claimed: true };

  // Another concurrent handler won the claim after our read. Fail closed.
  return { claimed: false, reason: 'pending' };
}

/** Mark a claimed peer as successfully delivered. Never sent again after this. */
function markSent(ownerKind, ownerId, peerId) {
  getDb()
    .prepare(
      `UPDATE pm_permit_state SET status = 'sent', updated_at = datetime('now'), last_responded_at = datetime('now')
       WHERE owner_kind = ? AND owner_id = ? AND peer_id = ?`
    )
    .run(ownerKind, ownerId, String(peerId));
}

/** Mark a claimed peer as permanently undeliverable (blocked/deleted/privacy). Never retried. */
function markSkipped(ownerKind, ownerId, peerId) {
  getDb()
    .prepare(
      `UPDATE pm_permit_state SET status = 'skipped', updated_at = datetime('now')
       WHERE owner_kind = ? AND owner_id = ? AND peer_id = ?`
    )
    .run(ownerKind, ownerId, String(peerId));
}

/**
 * Release a claim after a transient failure (FloodWait/network/RPC hiccup)
 * so a future message from the same peer is allowed to try again. The row
 * itself (and its first_seen_at) is kept, only the status is rewound.
 */
function releaseClaim(ownerKind, ownerId, peerId) {
  getDb()
    .prepare(
      `UPDATE pm_permit_state SET status = 'pending', updated_at = datetime('now', '-1000 seconds')
       WHERE owner_kind = ? AND owner_id = ? AND peer_id = ? AND status = 'pending'`
    )
    .run(ownerKind, ownerId, String(peerId));
}

/** Has this peer ever been claimed/processed for this userbot at all (any status)? */
function hasBeenProcessed(ownerKind, ownerId, peerId) {
  return Boolean(find(ownerKind, ownerId, peerId));
}

/** Used by resetAll()/teardown flows that wipe a userbot's panel config. */
function clearForOwner(ownerKind, ownerId) {
  return getDb()
    .prepare('DELETE FROM pm_permit_state WHERE owner_kind = ? AND owner_id = ?')
    .run(ownerKind, ownerId).changes;
}

module.exports = { find, tryClaim, markSent, markSkipped, releaseClaim, hasBeenProcessed, clearForOwner };
