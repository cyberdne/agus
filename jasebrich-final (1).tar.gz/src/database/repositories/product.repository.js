const { getDb } = require('../index');

function findById(id) {
  return getDb().prepare('SELECT * FROM products WHERE id = ?').get(id);
}

function listByCategory(category, { activeOnly = true } = {}) {
  const db = getDb();
  if (activeOnly) {
    return db
      .prepare('SELECT * FROM products WHERE category = ? AND is_active = 1 ORDER BY sort_order ASC, id ASC')
      .all(category);
  }
  return db
    .prepare('SELECT * FROM products WHERE category = ? ORDER BY sort_order ASC, id ASC')
    .all(category);
}

// Cross-category listing, split by the garansi flag — powers the
// "Spesial Bergaransi" / "Spesial Non-Garansi" store front screen.
function listByGaransi(garansi, { activeOnly = true } = {}) {
  const db = getDb();
  const garansiVal = garansi ? 1 : 0;
  if (activeOnly) {
    return db
      .prepare('SELECT * FROM products WHERE garansi = ? AND is_active = 1 ORDER BY sort_order ASC, id ASC')
      .all(garansiVal);
  }
  return db
    .prepare('SELECT * FROM products WHERE garansi = ? ORDER BY sort_order ASC, id ASC')
    .all(garansiVal);
}

function listPage(category, offset, limit) {
  return getDb()
    .prepare('SELECT * FROM products WHERE category = ? ORDER BY id DESC LIMIT ? OFFSET ?')
    .all(category, limit, offset);
}

function countByCategory(category) {
  const row = getDb().prepare('SELECT COUNT(*) AS c FROM products WHERE category = ?').get(category);
  return row.c;
}

function create({ category, name, description, price, durationDays, garansi, featureAccess }) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO products (category, name, description, price, duration_days, garansi, feature_access)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const result = stmt.run(
    category,
    name,
    description || null,
    price,
    durationDays,
    garansi ? 1 : 0,
    featureAccess === undefined ? null : featureAccess
  );
  return findById(result.lastInsertRowid);
}

function update(id, fields) {
  const db = getDb();
  const current = findById(id);
  if (!current) return null;
  const merged = { ...current, ...fields };
  db.prepare(`
    UPDATE products
    SET name = ?, description = ?, price = ?, duration_days = ?, garansi = ?, is_active = ?, feature_access = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(
    merged.name,
    merged.description || null,
    merged.price,
    merged.duration_days,
    merged.garansi ? 1 : 0,
    merged.is_active ? 1 : 0,
    merged.feature_access === undefined ? null : merged.feature_access,
    id
  );
  return findById(id);
}

function toggleActive(id) {
  const db = getDb();
  const current = findById(id);
  if (!current) return null;
  db.prepare("UPDATE products SET is_active = ?, updated_at = datetime('now') WHERE id = ?").run(
    current.is_active ? 0 : 1,
    id
  );
  return findById(id);
}

function remove(id) {
  const result = getDb().prepare(
    `UPDATE products
        SET is_active = 0,
            updated_at = datetime('now')
      WHERE id = ?`
  ).run(id);
  return result.changes === 1;
}

module.exports = {
  findById,
  listByCategory,
  listByGaransi,
  listPage,
  countByCategory,
  create,
  update,
  toggleActive,
  remove,
};
