const { getDb } = require('../index');
const sessionStore = require('../../utils/userbotSessionStorage');

function hydrate(row) { return sessionStore.hydrateRow(row, 'userbot', getDb()); }
function hydrateRows(rows) { return sessionStore.hydrateRows(rows, 'userbot', getDb()); }

function findById(id) {
  return hydrate(getDb().prepare(`SELECT userbots.*, COALESCE(users.is_banned, 0) AS owner_is_banned FROM userbots LEFT JOIN users ON users.telegram_id = userbots.user_id WHERE userbots.id = ?`).get(id));
}

function listAll() {
  return hydrateRows(getDb().prepare('SELECT * FROM userbots ORDER BY id DESC').all());
}

function listByUser(userId) {
  return hydrateRows(getDb().prepare('SELECT * FROM userbots WHERE user_id = ? ORDER BY id DESC').all(userId));
}

/**
 * Backup Token lookup by the SHA-256 of the token (utils/tokenCodec.js). The
 * partial UNIQUE index idx_userbots_token_hash guarantees at most one userbot
 * per token hash, so this can never resolve to two userbots.
 */
function findByTokenHash(tokenHash) {
  return hydrate(getDb().prepare('SELECT * FROM userbots WHERE token_hash = ?').get(tokenHash));
}

function listExpiredTrials(nowIso) {
  return hydrateRows(getDb()
    .prepare(
      "SELECT * FROM userbots WHERE label = '🎁 Trial Userbot' AND status IN ('pending_otp', 'active') AND expires_at IS NOT NULL AND expires_at <= ? ORDER BY id ASC"
    )
    .all(nowIso));
}

function deleteById(id) {
  const result = getDb().prepare('DELETE FROM userbots WHERE id = ?').run(id);
  if (result.changes === 1) sessionStore.deleteSession('userbot', id);
  return result.changes === 1;
}

function listActiveByUser(userId) {
  return hydrateRows(getDb()
    .prepare("SELECT * FROM userbots WHERE user_id = ? AND status = 'active' ORDER BY id DESC")
    .all(userId));
}

function updatePhone(id, phone) {
  const result = getDb()
    .prepare('UPDATE userbots SET phone = ?, updated_at = ? WHERE id = ?')
    .run(phone || null, new Date().toISOString(), id);
  return result.changes === 1 ? findById(id) : null;
}

function create({ userId, label, phone, orderId, expiresAt }) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO userbots (user_id, label, phone, order_id, status, expires_at)
    VALUES (?, ?, ?, ?, 'pending_otp', ?)
  `);
  const result = stmt.run(userId, label || null, phone || null, orderId || null, expiresAt || null);
  return findById(result.lastInsertRowid);
}

/**
 * Activation stores the Telegram StringSession in the canonical .txt file.
 * The legacy SQLite session_string column is explicitly left NULL.
 */
function activate(id, { sessionString, telegramUserbotId, tokenHash, expiresAt }) {
  const db = getDb();
  sessionStore.writeSession('userbot', id, sessionString);
  try {
    const result = db
      .prepare(`
        UPDATE userbots
        SET status = 'active', session_string = NULL, telegram_userbot_id = ?,
            token_hash = ?, token_generation = token_generation + 1, token_rotated_at = ?, token = NULL,
            activated_at = datetime('now'),
            expires_at = CASE WHEN ? IS NOT NULL THEN ? ELSE expires_at END
        WHERE id = ?
      `)
      .run(
        telegramUserbotId || null,
        tokenHash || null,
        new Date().toISOString(),
        expiresAt || null,
        expiresAt || null,
        id
      );
    if (result.changes !== 1) throw new Error(`Userbot #${id} tidak ditemukan saat aktivasi.`);
  } catch (err) {
    try { sessionStore.deleteSession('userbot', id); } catch (_) {}
    throw err;
  }
  return findById(id);
}

/**
 * Replaces the Backup Token hash with compare-and-swap on token_generation.
 * Returns true only for the caller that performed the rotation; a concurrent
 * or replayed rotation matches 0 rows and returns false, so one token can
 * never be rotated/consumed twice. Callers run this inside a transaction that
 * also retires the previous hash (services/backupToken.service.js).
 */
function rotateToken(id, { expectedGeneration, tokenHash, rotatedAt }) {
  const res = getDb()
    .prepare(
      `UPDATE userbots
          SET token_hash = ?, token_generation = token_generation + 1, token_rotated_at = ?, token = NULL
        WHERE id = ? AND token_generation = ?`
    )
    .run(tokenHash, rotatedAt, id, expectedGeneration);
  return res.changes === 1;
}

/**
 * LOW-LEVEL: overwrite expires_at with a caller-computed ISO timestamp.
 * Bypasses status/audit/idempotency bookkeeping on purpose (it is only a
 * raw column write) — every real subscription change MUST go through
 * services/subscription.service.js#extend() instead.
 */
function extendExpiry(id, expiresAt) {
  getDb().prepare('UPDATE userbots SET expires_at = ? WHERE id = ?').run(expiresAt, id);
  return findById(id);
}

function setFlags(id, { autoPromosi, wtbReply, pmPermit }) {
  const current = findById(id);
  if (!current) return null;
  getDb()
    .prepare('UPDATE userbots SET auto_promosi = ?, wtb_reply = ?, pm_permit = ? WHERE id = ?')
    .run(
      autoPromosi !== undefined ? (autoPromosi ? 1 : 0) : current.auto_promosi,
      wtbReply !== undefined ? (wtbReply ? 1 : 0) : current.wtb_reply,
      pmPermit !== undefined ? (pmPermit ? 1 : 0) : current.pm_permit,
      id
    );
  return findById(id);
}

/** Every owned userbot that is live and has at least one automation flag on — used to rebuild the runtime at boot. */
function listAutomatedActive() {
  return hydrateRows(getDb()
    .prepare(
      "SELECT * FROM userbots WHERE status = 'active' AND (auto_promosi = 1 OR wtb_reply = 1 OR pm_permit = 1)"
    )
    .all()).filter((row) => Boolean(row.session_string));
}

/** Kontrol Panel base config fields: target, broadcast_text, mode, delay_seconds, timer_config, watermark, topic_grup */
function updateConfig(id, fields) {
  const current = findById(id);
  if (!current) return null;
  const next = {
    target: fields.target !== undefined ? fields.target : current.target,
    broadcast_text: fields.broadcast_text !== undefined ? fields.broadcast_text : current.broadcast_text,
    mode: fields.mode !== undefined ? fields.mode : current.mode,
    delay_seconds: fields.delay_seconds !== undefined ? fields.delay_seconds : current.delay_seconds,
    timer_config: fields.timer_config !== undefined ? fields.timer_config : current.timer_config,
    timer_enabled: fields.timer_enabled !== undefined ? (fields.timer_enabled ? 1 : 0) : (current.timer_enabled === 0 ? 0 : 1),
    watermark: fields.watermark !== undefined ? fields.watermark : current.watermark,
    watermark_enabled: fields.watermark_enabled !== undefined ? (fields.watermark_enabled ? 1 : 0) : (current.watermark_enabled === 0 ? 0 : 1),
    topic_grup: fields.topic_grup !== undefined ? fields.topic_grup : current.topic_grup,
  };
  getDb()
    .prepare(
      `UPDATE userbots SET target = ?, broadcast_text = ?, mode = ?, delay_seconds = ?, timer_config = ?, timer_enabled = ?, watermark = ?, watermark_enabled = ?, topic_grup = ? WHERE id = ?`
    )
    .run(next.target, next.broadcast_text, next.mode, next.delay_seconds, next.timer_config, next.timer_enabled, next.watermark, next.watermark_enabled, next.topic_grup, id);
  return findById(id);
}

/** Resets everything Kontrol Panel controls back to defaults (used by "Reset Ubot"). */
function resetConfig(id) {
  getDb()
    .prepare(
      `UPDATE userbots SET target = NULL, broadcast_text = NULL, mode = 'sequential', delay_seconds = 5,
       timer_config = NULL, timer_enabled = 1, watermark = NULL, watermark_enabled = 1, topic_grup = NULL,
       auto_promosi = 0, wtb_reply = 0, pm_permit = 0 WHERE id = ?`
    )
    .run(id);
  return findById(id);
}

/**
 * "Transfer Ubot" — moves ownership of an owned userbot to a different buyer
 * (by Telegram ID) AND installs the new owner's Backup Token hash in the SAME
 * statement, so ownership and token can never be observed out of step.
 * Guarded by the expected current owner and token generation (compare-and-swap):
 * returns true only if the userbot still belonged to expectedOwnerId with the
 * expected token generation. Callers run it inside a transaction that also
 * retires the previous owner's token (services/backupToken.service.js).
 */
function transferOwner(id, newUserId, { expectedOwnerId, expectedGeneration, tokenHash, rotatedAt }) {
  const res = getDb()
    .prepare(
      `UPDATE userbots
          SET user_id = ?, auto_promosi = 0, wtb_reply = 0, pm_permit = 0,
              token_hash = ?, token_generation = token_generation + 1, token_rotated_at = ?, token = NULL
        WHERE id = ? AND user_id = ? AND token_generation = ?`
    )
    .run(newUserId, tokenHash, rotatedAt, id, expectedOwnerId, expectedGeneration);
  return res.changes === 1;
}

/** Owned userbots a buyer can still renew: activated (has/had a live session) and not revoked. */
function listRenewableByUser(userId) {
  return hydrateRows(getDb()
    .prepare("SELECT * FROM userbots WHERE user_id = ? AND status IN ('active', 'expired') ORDER BY id DESC")
    .all(userId));
}

/** Everything the scheduler must look at: active rows that carry an expiry. */
function listActiveExpiringByMaxThreshold(nowIso, maxExpiryIso, limit = 2000) {
  return hydrateRows(getDb().prepare(
    `SELECT * FROM userbots
      WHERE status IN ('active', 'expired')
        AND expires_at IS NOT NULL
        AND expires_at > ?
        AND expires_at <= ?
      ORDER BY expires_at ASC, id ASC
      LIMIT ?`
  ).all(nowIso, maxExpiryIso, Math.max(1, Math.min(10000, Number(limit) || 2000))));
}

function listActiveWithExpiry() {
  return hydrateRows(getDb()
    .prepare("SELECT * FROM userbots WHERE status = 'active' AND expires_at IS NOT NULL ORDER BY id ASC")
    .all());
}

/** Admin "Perpanjang Langganan Userbot" list: every activated userbot + owner display info. */
function listForSubscriptionAdmin() {
  return hydrateRows(getDb()
    .prepare(
      `SELECT u.*, us.username AS owner_username, us.first_name AS owner_first_name
         FROM userbots u
         LEFT JOIN users us ON us.telegram_id = u.user_id
        WHERE u.status IN ('active', 'expired')
        ORDER BY u.id DESC`
    )
    .all());
}

/** Why the runtime is intentionally stopped (SUBSCRIPTION_EXPIRED | SESSION_INVALID | null). */
function setRuntimeStopReason(id, reason) {
  return getDb()
    .prepare("UPDATE userbots SET runtime_stop_reason = ?, updated_at = ? WHERE id = ?")
    .run(reason || null, new Date().toISOString(), id).changes;
}

/**
 * Flags a live session as invalid exactly once (compare-and-swap) so the
 * owner is notified a single time. Subscription status is NOT touched.
 * Returns true only for the caller that performed the transition.
 */
function markSessionInvalid(id) {
  const res = getDb()
    .prepare(
      `UPDATE userbots SET runtime_stop_reason = 'SESSION_INVALID', updated_at = ?
        WHERE id = ? AND status = 'active'
          AND (runtime_stop_reason IS NULL OR runtime_stop_reason != 'SESSION_INVALID')`
    )
    .run(new Date().toISOString(), id);
  return res.changes === 1;
}

/**
 * Re-authentication: swap in a freshly-authorized session for an existing
 * userbot WITHOUT touching subscription, token, configuration or status.
 * The session itself lives in the canonical .txt file.
 */
function replaceSession(id, { sessionString, telegramUserbotId }) {
  const db = getDb();
  const previous = sessionStore.readSession('userbot', id);
  sessionStore.writeSession('userbot', id, sessionString);
  try {
    const result = db
      .prepare(
        `UPDATE userbots SET session_string = NULL, telegram_userbot_id = COALESCE(?, telegram_userbot_id),
                runtime_stop_reason = CASE WHEN runtime_stop_reason = 'SESSION_INVALID' THEN NULL ELSE runtime_stop_reason END,
                updated_at = ?
          WHERE id = ?`
      )
      .run(telegramUserbotId || null, new Date().toISOString(), id);
    if (result.changes !== 1) throw new Error(`Userbot #${id} tidak ditemukan saat mengganti session.`);
  } catch (err) {
    try {
      if (previous) sessionStore.writeSession('userbot', id, previous);
      else sessionStore.deleteSession('userbot', id);
    } catch (rollbackErr) {
      err.message += `; rollback session file gagal: ${rollbackErr.message}`;
    }
    throw err;
  }
  return findById(id);
}

function revoke(id) {
  getDb().prepare("UPDATE userbots SET status = 'revoked' WHERE id = ?").run(id);
}

/** "Klaim Token" -> Garansi Akses: restores access after an admin revoke (see revoke() above). */
function reactivate(id) {
  getDb().prepare("UPDATE userbots SET status = 'active' WHERE id = ?").run(id);
  return findById(id);
}

function disableAllFlagsForUser(userId) {
  getDb()
    .prepare("UPDATE userbots SET auto_promosi = 0, wtb_reply = 0, pm_permit = 0 WHERE user_id = ? AND status = 'active'")
    .run(userId);
}

function deleteByUser(userId) {
  const db = getDb();
  const rows = db.prepare('SELECT id FROM userbots WHERE user_id = ?').all(userId);
  const result = db.prepare('DELETE FROM userbots WHERE user_id = ?').run(userId);
  if (result.changes) {
    for (const row of rows) {
      try { sessionStore.deleteSession('userbot', row.id); } catch (_) {}
    }
  }
  return result.changes;
}

module.exports = {
  findById,
  listAll,
  listByUser,
  findByTokenHash,
  listActiveByUser,
  listExpiredTrials,
  deleteById,
  create,
  updatePhone,
  activate,
  rotateToken,
  extendExpiry,
  listRenewableByUser,
  listActiveWithExpiry,
  listActiveExpiringByMaxThreshold,
  listForSubscriptionAdmin,
  setRuntimeStopReason,
  markSessionInvalid,
  replaceSession,
  setFlags,
  updateConfig,
  resetConfig,
  transferOwner,
  listAutomatedActive,
  revoke,
  reactivate,
  disableAllFlagsForUser,
  deleteByUser,
};
