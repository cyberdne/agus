const { getDb } = require('../index');

function parseJob(row) {
  if (!row) return null;
  let payload = {};
  let buttons = [];
  try { payload = JSON.parse(row.payload_json || '{}') || {}; } catch (_) {}
  try { buttons = JSON.parse(row.buttons_json || '[]') || []; } catch (_) {}
  return { ...row, payload, buttons };
}

function createJob({ adminId, sourceChatId, sourceMessageId, payload, buttons, targetCount, targetMaxUserId, idempotencyKey }) {
  const db = getDb();
  const result = db.prepare(`
    INSERT OR IGNORE INTO broadcast_jobs
      (admin_id, source_chat_id, source_message_id, payload_json, buttons_json, target_count, target_max_user_id, idempotency_key)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    Number(adminId), String(sourceChatId), Number(sourceMessageId),
    JSON.stringify(payload || {}), JSON.stringify(Array.isArray(buttons) ? buttons : []),
    Number(targetCount || 0), targetMaxUserId == null ? null : Number(targetMaxUserId), String(idempotencyKey)
  );
  return result.changes === 1
    ? parseJob(db.prepare('SELECT * FROM broadcast_jobs WHERE id = last_insert_rowid()').get())
    : parseJob(db.prepare('SELECT * FROM broadcast_jobs WHERE idempotency_key = ?').get(String(idempotencyKey)));
}

function initializeTargetSnapshot(jobId, targetCount, targetMaxUserId) {
  return getDb().prepare(`
    UPDATE broadcast_jobs
       SET target_count = ?,
           target_max_user_id = ?,
           updated_at = datetime('now')
     WHERE id = ?
       AND target_max_user_id IS NULL
  `).run(Number(targetCount || 0), Number(targetMaxUserId || 0), Number(jobId)).changes === 1;
}

function findById(id) { return parseJob(getDb().prepare('SELECT * FROM broadcast_jobs WHERE id = ?').get(Number(id))); }
function findByIdempotency(key) { return parseJob(getDb().prepare('SELECT * FROM broadcast_jobs WHERE idempotency_key = ?').get(String(key))); }

function listHistory(limit = 15) {
  const n = Math.max(1, Math.min(100, Number(limit) || 15));
  return getDb().prepare('SELECT * FROM broadcast_jobs ORDER BY id DESC LIMIT ?').all(n).map(parseJob);
}

function listRunnableJobs() {
  return getDb().prepare("SELECT * FROM broadcast_jobs WHERE status IN ('queued','running') ORDER BY id ASC").all().map(parseJob);
}

function markRunning(id) {
  const res = getDb().prepare(`
    UPDATE broadcast_jobs
       SET status = 'running',
           started_at = COALESCE(started_at, datetime('now')),
           updated_at = datetime('now'),
           last_error = NULL
     WHERE id = ? AND status IN ('queued','running')
  `).run(Number(id));
  return res.changes === 1;
}

function setCounts(id, { success, failed, skipped, retries, target }) {
  getDb().prepare(`
    UPDATE broadcast_jobs
       SET success_count = ?, fail_count = ?, skipped_count = ?, retry_count = ?, target_count = COALESCE(?, target_count), updated_at = datetime('now')
     WHERE id = ?
  `).run(Number(success), Number(failed), Number(skipped), Number(retries), target == null ? null : Number(target), Number(id));
}

function complete(id, status, lastError = null) {
  getDb().prepare(`
    UPDATE broadcast_jobs
       SET status = ?, completed_at = datetime('now'), updated_at = datetime('now'), last_error = ?
     WHERE id = ?
  `).run(String(status), lastError ? String(lastError).slice(0, 1000) : null, Number(id));
}

function createDelivery(jobId, userId) {
  const result = getDb().prepare(`
    INSERT OR IGNORE INTO broadcast_deliveries (job_id, user_id)
    VALUES (?, ?)
  `).run(Number(jobId), Number(userId));
  return result.changes === 1;
}

function claimDelivery(jobId, userId, claimToken, maxAttempts = 5) {
  const result = getDb().prepare(`
    UPDATE broadcast_deliveries
       SET status = 'sending', claim_token = ?, claimed_at = datetime('now'), attempts = attempts + 1, updated_at = datetime('now')
     WHERE job_id = ? AND user_id = ? AND status IN ('pending','failed') AND attempts < ?
  `).run(String(claimToken), Number(jobId), Number(userId), Math.max(1, Math.min(20, Number(maxAttempts) || 5)));
  return result.changes === 1;
}

function getDelivery(jobId, userId) {
  return getDb().prepare('SELECT * FROM broadcast_deliveries WHERE job_id = ? AND user_id = ?').get(Number(jobId), Number(userId));
}

function markSent(jobId, userId, claimToken) {
  return getDb().prepare(`
    UPDATE broadcast_deliveries
       SET status = 'sent', sent_at = datetime('now'), claim_token = NULL, claimed_at = NULL, last_error = NULL, updated_at = datetime('now')
     WHERE job_id = ? AND user_id = ? AND status = 'sending' AND claim_token = ?
  `).run(Number(jobId), Number(userId), String(claimToken)).changes === 1;
}

function markSkipped(jobId, userId, claimToken, error = null) {
  return getDb().prepare(`
    UPDATE broadcast_deliveries
       SET status = 'skipped', claim_token = NULL, claimed_at = NULL, last_error = ?, updated_at = datetime('now')
     WHERE job_id = ? AND user_id = ? AND status = 'sending' AND claim_token = ?
  `).run(error ? String(error).slice(0, 1000) : null, Number(jobId), Number(userId), String(claimToken)).changes === 1;
}

function markFailed(jobId, userId, claimToken, error = null) {
  return getDb().prepare(`
    UPDATE broadcast_deliveries
       SET status = 'failed', claim_token = NULL, claimed_at = NULL, last_error = ?, updated_at = datetime('now')
     WHERE job_id = ? AND user_id = ? AND status = 'sending' AND claim_token = ?
  `).run(error ? String(error).slice(0, 1000) : null, Number(jobId), Number(userId), String(claimToken)).changes === 1;
}

/** Conservative crash recovery: an ambiguous Telegram request is never re-sent automatically. */
function quarantineStaleSending(staleMinutes = 20) {
  const minutes = Math.max(5, Math.min(180, Number(staleMinutes) || 20));
  return getDb().prepare(`
    UPDATE broadcast_deliveries
       SET status = 'skipped',
           claim_token = NULL,
           claimed_at = NULL,
           last_error = COALESCE(last_error, 'Hasil pengiriman tidak diketahui setelah proses terhenti; tidak dikirim ulang otomatis.'),
           updated_at = datetime('now')
     WHERE status = 'sending'
       AND claimed_at IS NOT NULL
       AND datetime(claimed_at) < datetime('now', ?)
  `).run(`-${minutes} minutes`).changes;
}

function countDeliveryStates(jobId) {
  const rows = getDb().prepare(`SELECT status, COUNT(*) AS c FROM broadcast_deliveries WHERE job_id = ? GROUP BY status`).all(Number(jobId));
  const out = { pending: 0, sending: 0, sent: 0, failed: 0, skipped: 0 };
  for (const row of rows) out[row.status] = Number(row.c || 0);
  return out;
}

module.exports = {
  createJob, findById, findByIdempotency, listHistory, listRunnableJobs,
  markRunning, setCounts, complete,
  initializeTargetSnapshot,
  createDelivery, claimDelivery, getDelivery, markSent, markSkipped, markFailed,
  quarantineStaleSending, countDeliveryStates,
};
