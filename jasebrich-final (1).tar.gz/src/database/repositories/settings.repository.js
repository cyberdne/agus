const { getDb } = require('../index');

function get(key) {
  const row = getDb().prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

function set(key, value) {
  getDb()
    .prepare(`
      INSERT INTO settings (key, value) VALUES (?, ?)
      ON CONFLICT(key) DO UPDATE SET value = excluded.value
    `)
    .run(key, value);

  // Keep the on-disk settings snapshot fresh after every change, so
  // whatever the admin configures (emoji, button icons, and anything
  // else stored here in the future) is automatically included the next
  // time this project folder is zipped up and re-uploaded — no manual
  // export step. Lazy-required to avoid a require() cycle (the
  // portability service itself reads settings via this file).
  try {
    require('../../services/settingsPortability.service').exportToFile();
  } catch (_) {
    // Never let snapshotting break an actual settings write.
  }
}

function getAll() {
  const rows = getDb().prepare('SELECT key, value FROM settings').all();
  const out = {};
  for (const row of rows) out[row.key] = row.value;
  return out;
}

// Bulk upsert used by the settings-portability import (see
// src/services/settingsPortability.service.js). Runs in one transaction
// so a large snapshot import is fast and atomic.
function setMany(obj) {
  const entries = Object.entries(obj || {});
  if (!entries.length) return;
  const stmt = getDb().prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `);
  const tx = getDb().transaction((rows) => {
    for (const [key, value] of rows) stmt.run(key, value);
  });
  tx(entries);
}

module.exports = { get, set, getAll, setMany };
