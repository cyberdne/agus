const { getDb } = require('../index');

function get(key) {
  const row = getDb().prepare('SELECT value FROM payment_config WHERE key = ?').get(key);
  return row ? row.value : null;
}

function set(key, value) {
  getDb()
    .prepare(`
      INSERT INTO payment_config (key, value, updated_at) VALUES (?, ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')
    `)
    .run(key, value);

  try {
    require('../../services/settingsPortability.service').exportToFile();
  } catch (_) {
    // A settings write must never fail because snapshotting is unavailable.
  }
}

module.exports = { get, set };
