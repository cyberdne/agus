const { getDb } = require('../index');

/**
 * Ledger of RETIRED Backup Token hashes (see schema.js userbot_token_history).
 * Only hashes are stored — never a plaintext token. token_hash is UNIQUE, so
 * retiring the same hash twice is a harmless no-op.
 */

function findRetiredByHash(tokenHash) {
  return getDb().prepare('SELECT * FROM userbot_token_history WHERE token_hash = ?').get(tokenHash);
}

/** @returns {boolean} true if this call recorded the retirement, false if that hash was already retired. */
function retire({ tokenHash, userbotId, generation, reason, retiredAt }) {
  const res = getDb()
    .prepare(
      `INSERT OR IGNORE INTO userbot_token_history (token_hash, userbot_id, generation, reason, retired_at)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(tokenHash, userbotId, generation || 0, reason, retiredAt);
  return res.changes === 1;
}

function listByUserbot(userbotId, limit = 20) {
  return getDb()
    .prepare('SELECT * FROM userbot_token_history WHERE userbot_id = ? ORDER BY id DESC LIMIT ?')
    .all(userbotId, limit);
}

module.exports = { findRetiredByHash, retire, listByUserbot };
