const { getDb } = require('../index');

function find(ownerKind, ownerId, chatId, ruleId) {
  return getDb().prepare(`SELECT * FROM base_reply_cooldowns
    WHERE owner_kind=? AND owner_id=? AND chat_id=? AND rule_id=?`)
    .get(String(ownerKind), Number(ownerId), String(chatId), String(ruleId));
}

function tryClaim(ownerKind, ownerId, chatId, ruleId, cooldownMs, nowMs = Date.now()) {
  const db = getDb();
  const key = [String(ownerKind), Number(ownerId), String(chatId), String(ruleId)];
  const inserted = db.prepare(`INSERT INTO base_reply_cooldowns
    (owner_kind,owner_id,chat_id,rule_id,status,claimed_at_ms,last_sent_at_ms,updated_at)
    VALUES (?,?,?,?, 'pending',?,?,datetime('now')) ON CONFLICT(owner_kind,owner_id,chat_id,rule_id) DO NOTHING`)
    .run(...key, nowMs, null);
  if (inserted.changes === 1) return { claimed: true, row: find(...key) };

  const row = find(...key);
  if (!row) return { claimed: false, reason: 'missing' };
  const safeCooldown = Number.isFinite(Number(cooldownMs)) && Number(cooldownMs) >= 0 ? Number(cooldownMs) : 0;
  if (row.status === 'pending') {
    const claimedAt = Number(row.claimed_at_ms);
    if (Number.isFinite(claimedAt) && nowMs - claimedAt < safeCooldown) return { claimed: false, reason: 'pending' };
  }
  if (row.status === 'sent') {
    const last = Number(row.last_sent_at_ms);
    if (Number.isFinite(last) && nowMs < last + safeCooldown) return { claimed: false, reason: 'cooldown' };
  }
  const reclaimed = db.prepare(`UPDATE base_reply_cooldowns
    SET status='pending', claimed_at_ms=?, updated_at=datetime('now')
    WHERE owner_kind=? AND owner_id=? AND chat_id=? AND rule_id=?
      AND ((status='pending' AND claimed_at_ms <= ?) OR
           (status='sent' AND (last_sent_at_ms IS NULL OR last_sent_at_ms <= ?)))`).run(
    nowMs, ...key, nowMs - safeCooldown, nowMs - safeCooldown);
  if (reclaimed.changes === 1) return { claimed: true, row: find(...key) };
  return { claimed: false, reason: 'race' };
}

function markSent(ownerKind, ownerId, chatId, ruleId, sentAtMs = Date.now()) {
  return getDb().prepare(`UPDATE base_reply_cooldowns
    SET status='sent', last_sent_at_ms=?, claimed_at_ms=?, updated_at=datetime('now')
    WHERE owner_kind=? AND owner_id=? AND chat_id=? AND rule_id=? AND status='pending'`)
    .run(sentAtMs, sentAtMs, String(ownerKind), Number(ownerId), String(chatId), String(ruleId)).changes === 1;
}

function release(ownerKind, ownerId, chatId, ruleId) {
  return getDb().prepare(`DELETE FROM base_reply_cooldowns
    WHERE owner_kind=? AND owner_id=? AND chat_id=? AND rule_id=? AND status='pending'`)
    .run(String(ownerKind), Number(ownerId), String(chatId), String(ruleId)).changes;
}

function clearForOwner(ownerKind, ownerId) {
  return getDb().prepare('DELETE FROM base_reply_cooldowns WHERE owner_kind=? AND owner_id=?')
    .run(String(ownerKind), Number(ownerId)).changes;
}

module.exports = { find, tryClaim, markSent, release, clearForOwner };
