const { getDb } = require('../index');

function getConfig() {
  return getDb().prepare('SELECT * FROM subscription_reminder_settings WHERE id = 1').get();
}
function setEnabled(enabled) { getDb().prepare("UPDATE subscription_reminder_settings SET enabled = ?, updated_at = datetime('now') WHERE id = 1").run(enabled ? 1 : 0); }
function setThresholds(values) { getDb().prepare("UPDATE subscription_reminder_settings SET thresholds_minutes = ?, updated_at = datetime('now') WHERE id = 1").run(JSON.stringify(values)); }

function ensureEvent(eventKey, { eventType, row, threshold }) {
  getDb().prepare(`
    INSERT OR IGNORE INTO subscription_reminder_events
      (event_key, event_type, userbot_id, owner_user_id, sub_version, expires_at, threshold_minutes)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(String(eventKey), String(eventType || 'automatic'), Number(row.id), Number(row.user_id), Number(row.sub_version || 0), String(row.expires_at), threshold == null ? null : Number(threshold));
}

function claimEvent(eventKey, token) {
  const result = getDb().prepare(`
    UPDATE subscription_reminder_events
       SET status = 'sending', claim_token = ?, claimed_at = datetime('now'), attempts = attempts + 1, updated_at = datetime('now')
     WHERE event_key = ?
       AND status IN ('pending','failed')
  `).run(String(token), String(eventKey));
  return result.changes === 1;
}
function markSent(eventKey, token) {
  return getDb().prepare(`UPDATE subscription_reminder_events SET status='sent', claim_token=NULL, claimed_at=NULL, sent_at=datetime('now'), last_error=NULL, updated_at=datetime('now') WHERE event_key=? AND status='sending' AND claim_token=?`).run(String(eventKey), String(token)).changes === 1;
}
function markFailed(eventKey, token, error) {
  return getDb().prepare(`UPDATE subscription_reminder_events SET status='failed', claim_token=NULL, claimed_at=NULL, last_error=?, updated_at=datetime('now') WHERE event_key=? AND status='sending' AND claim_token=?`).run(String(error || '').slice(0,1000), String(eventKey), String(token)).changes === 1;
}
function markSkipped(eventKey, token, error) {
  return getDb().prepare(`UPDATE subscription_reminder_events SET status='skipped', claim_token=NULL, claimed_at=NULL, last_error=?, updated_at=datetime('now') WHERE event_key=? AND status='sending' AND claim_token=?`).run(String(error || '').slice(0,1000), String(eventKey), String(token)).changes === 1;
}
function getEvent(eventKey) { return getDb().prepare('SELECT * FROM subscription_reminder_events WHERE event_key = ?').get(String(eventKey)); }
function listPendingExpiry(limit = 100) {
  return getDb().prepare(`SELECT e.*, u.status AS userbot_status
    FROM subscription_reminder_events e
    JOIN userbots u ON u.id = e.userbot_id
   WHERE e.event_type = 'expiry' AND e.status IN ('pending','failed') AND u.status = 'expired'
   ORDER BY e.id ASC LIMIT ?`).all(Math.max(1, Math.min(1000, Number(limit) || 100)));
}


function markExhausted(eventKey, error) {
  return getDb().prepare(`UPDATE subscription_reminder_events SET status='skipped', claim_token=NULL, claimed_at=NULL, last_error=?, updated_at=datetime('now') WHERE event_key=? AND status IN ('pending','failed')`).run(String(error || 'Batas percobaan reminder tercapai.').slice(0,1000), String(eventKey)).changes === 1;
}

function quarantineStaleSending(staleMinutes = 20) {
  const minutes = Math.max(5, Math.min(180, Number(staleMinutes) || 20));
  // A Telegram send may have reached the user immediately before a process
  // crash. The delivery outcome is then ambiguous; never auto-retry an
  // ambiguous request because that can duplicate a reminder.
  return getDb().prepare(`UPDATE subscription_reminder_events SET status='skipped', claim_token=NULL, claimed_at=NULL, last_error=COALESCE(last_error,'Reminder job terputus sebelum hasil diketahui; tidak dikirim ulang otomatis.'), updated_at=datetime('now') WHERE status='sending' AND claimed_at IS NOT NULL AND datetime(claimed_at) < datetime('now', ?)`).run(`-${minutes} minutes`).changes;
}

module.exports = { getConfig, setEnabled, setThresholds, ensureEvent, claimEvent, markSent, markFailed, markSkipped, markExhausted, getEvent, listPendingExpiry, quarantineStaleSending };

function insertRun({ status, sent = 0, skipped = 0, failed = 0, attempted = 0, durationMs = 0, error = null }) {
  const db = getDb();
  db.prepare('INSERT INTO subscription_reminder_runs (status, sent, skipped, failed, attempted, duration_ms, error) VALUES (?,?,?,?,?,?,?)')
    .run(String(status), Number(sent) || 0, Number(skipped) || 0, Number(failed) || 0, Number(attempted) || 0, Number(durationMs) || 0, error ? String(error).slice(0, 500) : null);
  // Keep the log bounded; the admin only needs recent cycles.
  db.prepare('DELETE FROM subscription_reminder_runs WHERE id NOT IN (SELECT id FROM subscription_reminder_runs ORDER BY id DESC LIMIT 200)').run();
}

function lastRun() {
  return getDb().prepare('SELECT * FROM subscription_reminder_runs ORDER BY id DESC LIMIT 1').get();
}

Object.assign(module.exports, { insertRun, lastRun });
