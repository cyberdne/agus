const { getDb } = require('../index');

function findBySubmenuId(submenuId) {
  const db = getDb();
  return db.prepare('SELECT * FROM submenu_customizations WHERE submenu_id = ?').get(submenuId);
}

/**
 * Insert or overwrite the custom content for a submenu.
 * contentEntities is stored as a JSON string, verbatim.
 */
function upsert(submenuId, contentText, contentEntitiesJson, updatedBy) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO submenu_customizations (submenu_id, content_text, content_entities, updated_by, created_at, updated_at)
    VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
    ON CONFLICT(submenu_id) DO UPDATE SET
      content_text = excluded.content_text,
      content_entities = excluded.content_entities,
      updated_by = excluded.updated_by,
      updated_at = datetime('now')
  `);
  stmt.run(submenuId, contentText, contentEntitiesJson, updatedBy);
  return findBySubmenuId(submenuId);
}

function deleteBySubmenuId(submenuId) {
  const db = getDb();
  db.prepare('DELETE FROM submenu_customizations WHERE submenu_id = ?').run(submenuId);
}

/**
 * Move an existing customization between two stable template contexts without
 * rewriting its payload. Used only for an audited legacy-key migration.
 * Returns the destination row when moved, otherwise null.
 */
function moveIfDestinationMissing(fromSubmenuId, toSubmenuId) {
  const db = getDb();
  const transaction = db.transaction(() => {
    const source = db.prepare('SELECT * FROM submenu_customizations WHERE submenu_id = ?').get(fromSubmenuId);
    if (!source) return null;
    const target = db.prepare('SELECT 1 AS present FROM submenu_customizations WHERE submenu_id = ? LIMIT 1').get(toSubmenuId);
    if (target) return null;
    db.prepare(`
      INSERT INTO submenu_customizations
        (submenu_id, content_text, content_entities, updated_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      toSubmenuId,
      source.content_text,
      source.content_entities || '[]',
      source.updated_by,
      source.created_at || new Date().toISOString(),
      source.updated_at || new Date().toISOString(),
    );
    db.prepare('DELETE FROM submenu_customizations WHERE submenu_id = ?').run(fromSubmenuId);
    return db.prepare('SELECT * FROM submenu_customizations WHERE submenu_id = ?').get(toSubmenuId);
  });
  return transaction();
}

module.exports = { findBySubmenuId, upsert, deleteBySubmenuId, moveIfDestinationMissing };
