const crypto = require('crypto');
const { getDb } = require('../index');

function findById(id) {
  return getDb().prepare('SELECT * FROM orders WHERE id = ?').get(id);
}

function findOpenOrdersByUser(userId, nowIso = null) {
  const db = getDb();
  const anchor = nowIso ? new Date(nowIso).toISOString() : null;
  const whereNow = anchor ? 'datetime(?)' : "datetime('now')";
  return (anchor
    ? db.prepare(`
        SELECT * FROM orders
        WHERE user_id = ?
          AND status IN ('pending','awaiting_confirmation')
          AND expires_at IS NOT NULL
          AND datetime(expires_at) > ${whereNow}
        ORDER BY id DESC
      `).all(userId, anchor)
    : db.prepare(`
        SELECT * FROM orders
        WHERE user_id = ?
          AND status IN ('pending','awaiting_confirmation')
          AND expires_at IS NOT NULL
          AND datetime(expires_at) > datetime('now')
        ORDER BY id DESC
      `).all(userId));
}

function findOpenByUser(userId) {
  return findOpenOrdersByUser(userId)[0] || null;
}

function create({ userId, productId, category, catalogCategory, qty, targetUserbotId }) {
  const db = getDb();
  const expectedCatalogCategory = catalogCategory || category;
  // Re-read the active product inside the same atomic INSERT that creates the
  // order. The UI/callback may carry a stale price, so the database row is the
  // sole authority for product name, unit price and duration at commit time.
  // The NOT EXISTS predicate also makes the one-open-order-per-user rule
  // concurrency-safe instead of relying on in-memory debounce.
  const result = db.prepare(`
    INSERT INTO orders (user_id, product_id, category, product_name, qty, unit_price, total_price, duration_days, status, target_userbot_id, created_at, expires_at)
    SELECT ?, p.id, ?, p.name, ?, p.price, p.price * ?, p.duration_days * ?, 'pending', ?, datetime('now'), datetime('now', '+1 hour')
    FROM products p
    WHERE p.id = ? AND p.is_active = 1 AND p.category = ?
      AND NOT EXISTS (
        SELECT 1 FROM orders WHERE user_id = ? AND status IN ('pending','awaiting_confirmation') AND expires_at IS NOT NULL AND datetime(expires_at) > datetime('now')
      )
  `).run(userId, category, qty, qty, qty, targetUserbotId || null, productId, expectedCatalogCategory, userId);
  return result.changes > 0 ? findById(result.lastInsertRowid) : null;
}

function setStatus(id, status) {
  if (status === 'awaiting_confirmation') {
    const result = getDb().prepare(`
      UPDATE orders
      SET status = ?, updated_at = datetime('now')
      WHERE id = ?
        AND status = 'pending'
        AND expires_at IS NOT NULL
        AND datetime(expires_at) > datetime('now')
    `).run(status, id);
    return result.changes > 0 ? findById(id) : null;
  }
  getDb().prepare("UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, id);
  return findById(id);
}

function markPaymentProofRequested(id, userId) {
  const result = getDb().prepare(`
    UPDATE orders
    SET payment_proof_requested_at = COALESCE(payment_proof_requested_at, datetime('now')),
        updated_at = datetime('now')
    WHERE id = ?
      AND user_id = ?
      AND status = 'pending'
      AND expires_at IS NOT NULL
      AND datetime(expires_at) > datetime('now')
  `).run(id, userId);
  return result.changes > 0 ? findById(id) : null;
}

function findPendingPaymentProofByUser(userId) {
  return getDb().prepare(`
    SELECT * FROM orders
    WHERE user_id = ?
      AND status = 'pending'
      AND expires_at IS NOT NULL
      AND datetime(expires_at) > datetime('now')
      AND payment_proof_requested_at IS NOT NULL
      AND payment_proof_file_id IS NULL
    ORDER BY id DESC
    LIMIT 1
  `).get(userId);
}

function submitPaymentProof({ id, userId, proofType, fileId, caption, entities, receivedAt, durationMinutes, expiresAt }) {
  const result = getDb().prepare(`
    UPDATE orders
    SET status = 'awaiting_confirmation',
        payment_proof_type = ?,
        payment_proof_file_id = ?,
        payment_proof_caption = ?,
        payment_proof_entities = ?,
        payment_proof_received_at = ?,
        transaction_notification_duration_minutes = ?,
        transaction_notification_expires_at = ?,
        transaction_notification_status = 'pending',
        transaction_notification_claim_token = NULL,
        transaction_notification_claimed_at = NULL,
        updated_at = datetime('now')
    WHERE id = ?
      AND user_id = ?
      AND status = 'pending'
      AND expires_at IS NOT NULL
      AND datetime(expires_at) > datetime('now')
      AND payment_proof_requested_at IS NOT NULL
      AND payment_proof_file_id IS NULL
  `).run(
    proofType,
    fileId,
    caption || null,
    entities || '[]',
    receivedAt,
    durationMinutes,
    expiresAt,
    id,
    userId,
  );
  return result.changes > 0 ? findById(id) : null;
}

function claimTransactionNotification(id, claimToken, staleMinutes = 10) {
  const minutes = Number(staleMinutes);
  if (!Number.isFinite(minutes) || minutes <= 0) throw new Error(`Invalid transaction notification stale window: ${staleMinutes}`);
  const result = getDb().prepare(`
    UPDATE orders
    SET transaction_notification_claim_token = ?,
        transaction_notification_claimed_at = datetime('now')
    WHERE id = ?
      AND status = 'awaiting_confirmation'
      AND expires_at IS NOT NULL
      AND datetime(expires_at) > datetime('now')
      AND payment_proof_file_id IS NOT NULL
      AND transaction_notification_message_id IS NULL
      AND transaction_notification_status IN ('pending', 'none')
      AND (
        transaction_notification_claimed_at IS NULL
        OR datetime(transaction_notification_claimed_at) < datetime('now', ?)
      )
  `).run(claimToken, id, `-${minutes} minutes`);
  return result.changes > 0;
}

function recordTransactionNotification({ id, claimToken, chatId, messageId, mediaType }) {
  const result = getDb().prepare(`
    UPDATE orders
    SET transaction_notification_chat_id = ?,
        transaction_notification_message_id = ?,
        transaction_notification_media_type = ?,
        transaction_notification_status = 'sent',
        transaction_notification_claim_token = NULL,
        transaction_notification_claimed_at = NULL,
        updated_at = datetime('now')
    WHERE id = ? AND transaction_notification_claim_token = ?
  `).run(String(chatId), messageId, mediaType, id, claimToken);
  return result.changes > 0;
}

function releaseTransactionNotificationClaim(id, claimToken, status = 'pending') {
  const result = getDb().prepare(`
    UPDATE orders
    SET transaction_notification_status = ?,
        transaction_notification_claim_token = NULL,
        transaction_notification_claimed_at = NULL,
        updated_at = datetime('now')
    WHERE id = ? AND transaction_notification_claim_token = ?
  `).run(status, id, claimToken);
  return result.changes > 0;
}

function setTransactionNotificationProjectionStatus(id, status, actorId = null) {
  const result = getDb().prepare(`
    UPDATE orders
    SET transaction_notification_status = ?,
        notification_actor_id = COALESCE(?, notification_actor_id),
        transaction_notification_claim_token = NULL,
        transaction_notification_claimed_at = NULL,
        updated_at = datetime('now')
    WHERE id = ?
  `).run(status, actorId, id);
  return result.changes > 0;
}

function listAwaitingWithTransactionNotifications(limit = 100) {
  return getDb().prepare(`
    SELECT * FROM orders
    WHERE status = 'awaiting_confirmation'
      AND payment_proof_file_id IS NOT NULL
      AND transaction_notification_status IN ('pending', 'sent', 'unavailable', 'final_pending')
    ORDER BY id ASC
    LIMIT ?
  `).all(limit);
}

function listTransactionNotificationsFinalPending(limit = 100) {
  return getDb().prepare(`
    SELECT * FROM orders
    WHERE status IN ('fulfilled', 'cancelled', 'rejected', 'paid', 'processing')
      AND transaction_notification_message_id IS NOT NULL
      AND transaction_notification_status = 'final_pending'
    ORDER BY id ASC
    LIMIT ?
  `).all(limit);
}

function setFulfillment(id, fulfillmentRef, claimToken = null) {
  const db = getDb();
  if (claimToken) {
    const result = db
      .prepare("UPDATE orders SET fulfillment_ref = ?, status = 'fulfilled', updated_at = datetime('now'), processing_started_at = NULL, processing_heartbeat_at = NULL, processing_claim_token = NULL WHERE id = ? AND status = 'processing' AND processing_claim_token = ?")
      .run(fulfillmentRef, id, claimToken);
    return result.changes > 0;
  }

  db
    .prepare("UPDATE orders SET fulfillment_ref = ?, status = 'fulfilled', updated_at = datetime('now'), processing_started_at = NULL, processing_heartbeat_at = NULL, processing_claim_token = NULL WHERE id = ?")
    .run(fulfillmentRef, id);
  return findById(id);
}

// Atomic compare-and-swap claim used by fulfillOrder() to make order
// confirmation idempotent/race-safe: a double-tap of "✅ Konfirmasi Bayar"
// (or two admins tapping near-simultaneously) must never process the same
// order twice. Only 'awaiting_confirmation' (first confirm) or 'paid'
// (retry after a recoverable failure, e.g. out-of-stock) may be claimed;
// 'processing' (already in flight) and 'fulfilled' (already done) cannot.
// This is a single UPDATE statement, so better-sqlite3's synchronous
// execution makes the check-and-set atomic — no window for a second caller
// to slip in between reading the status and setting it.
function claimForProcessing(id) {
  const claimToken = crypto.randomUUID();
  const result = getDb()
    .prepare("UPDATE orders SET status = 'processing', updated_at = datetime('now'), processing_started_at = datetime('now'), processing_heartbeat_at = datetime('now'), processing_claim_token = ? WHERE id = ? AND status IN ('awaiting_confirmation','paid') AND expires_at IS NOT NULL AND datetime(expires_at) > datetime('now')")
    .run(claimToken, id);
  return result.changes > 0 ? claimToken : null;
}

// Refreshes the processing lease only when the caller still owns the exact
// claim token. Recovery therefore cannot reclaim a live fulfillment that is
// regularly heartbeating, and an old worker cannot revive a claim after it has
// already been recovered/reclaimed by another process.
function touchProcessing(id, claimToken) {
  if (!claimToken) return false;
  const result = getDb()
    .prepare("UPDATE orders SET updated_at = datetime('now'), processing_heartbeat_at = datetime('now') WHERE id = ? AND status = 'processing' AND processing_claim_token = ?")
    .run(id, claimToken);
  return result.changes > 0;
}

// Releases a processing claim only if its owner still holds the token. This
// prevents a stale worker's catch/failure path from overwriting a fresh retry
// that may already have reclaimed and re-claimed the same order.
function releaseProcessingClaim(id, claimToken, nextStatus = 'paid') {
  if (!claimToken) return false;
  const db = getDb();
  const result = db
    .prepare(`
      UPDATE orders
      SET status = CASE
          WHEN expires_at IS NOT NULL AND datetime(expires_at) <= datetime('now') THEN 'expired'
          ELSE ?
        END,
        updated_at = datetime('now'),
        processing_started_at = NULL,
        processing_heartbeat_at = NULL,
        processing_claim_token = NULL
      WHERE id = ? AND status = 'processing' AND processing_claim_token = ?
    `)
    .run(nextStatus, id, claimToken);
  return result.changes > 0;
}

// Atomic, ownership- and status-scoped cancel used by the buyer-facing
// "❌ Batal" callback (store:cancel:<orderId>). Telegram callback data is
// untrusted input, so orderId alone must never be enough to mutate an
// order — this single UPDATE only ever touches a row that BOTH belongs
// to the requesting Telegram user AND is still in the one status a buyer
// is actually allowed to self-cancel from ('pending', i.e. before "Saya
// Sudah Bayar" hands it to admin review). better-sqlite3's synchronous
// execution makes the ownership+status check and the write atomic, the
// same pattern as claimForProcessing() above.
function cancelOwnedPending(id, userId) {
  const result = getDb()
    .prepare("UPDATE orders SET status = 'cancelled', updated_at = datetime('now') WHERE id = ? AND user_id = ? AND status = 'pending' AND expires_at IS NOT NULL AND datetime(expires_at) > datetime('now')")
    .run(id, userId);
  return result.changes > 0;
}

/**
 * Legacy-safe recovery for users who already have more than one abandoned
 * pre-payment order from before the one-open-order database guard existed.
 * Only buyer-cancellable `pending` rows are touched; orders that already have
 * submitted payment proof (`awaiting_confirmation`) are deliberately left to
 * the existing admin verification/rejection lifecycle. The WHERE clause is
 * the ownership+state guard, and one UPDATE makes the bulk action atomic.
 */
function cancelAllOwnedPending(userId) {
  const result = getDb()
    .prepare("UPDATE orders SET status = 'cancelled', updated_at = datetime('now') WHERE user_id = ? AND status = 'pending' AND expires_at IS NOT NULL AND datetime(expires_at) > datetime('now')")
    .run(userId);
  return result.changes;
}

// Atomic recovery for orders left at 'processing' by a crashed/restarted
// process (see order.service.js#reclaimStaleProcessingOrders for the
// full rationale). A single conditional UPDATE enforces both the
// processing status and the dedicated heartbeat age, so a live claim with
// a fresh heartbeat cannot be reclaimed while final statuses are untouched.
// Re-running recovery is idempotent because a reclaimed row leaves
// 'processing' and its lease metadata is cleared. SQLite's own clock
// (datetime('now', ...)) is used for the age comparison.
function reclaimStaleProcessing(staleMinutes, nowIso = null) {
  const minutes = Number(staleMinutes);
  if (!Number.isFinite(minutes) || minutes <= 0) throw new Error(`Invalid stale processing threshold: ${staleMinutes}`);

  let anchor = nowIso;
  if (anchor !== null && anchor !== undefined) {
    const parsed = new Date(anchor);
    if (Number.isNaN(parsed.getTime())) throw new Error(`Invalid recovery clock timestamp: ${nowIso}`);
    anchor = parsed.toISOString();
  }

  const db = getDb();
  if (!anchor) anchor = db.prepare("SELECT datetime('now') AS now").get().now;

  const stalePredicate = `((processing_heartbeat_at IS NOT NULL AND datetime(processing_heartbeat_at) < datetime(?, ?)) OR
    (processing_heartbeat_at IS NULL AND processing_started_at IS NOT NULL AND datetime(processing_started_at) < datetime(?, ?)) OR
    (processing_heartbeat_at IS NULL AND processing_started_at IS NULL AND processing_claim_token IS NULL AND updated_at IS NOT NULL AND datetime(updated_at) < datetime(?, ?)))`;

  const result = db
    .prepare(
      "UPDATE orders SET status = CASE WHEN expires_at IS NOT NULL AND datetime(expires_at) <= datetime(?) THEN 'expired' ELSE 'paid' END, " +
      "processing_started_at = NULL, processing_heartbeat_at = NULL, processing_claim_token = NULL, updated_at = datetime('now') " +
      "WHERE status = 'processing' AND " + stalePredicate
    )
    .run(anchor, anchor, `-${minutes} minutes`, anchor, `-${minutes} minutes`, anchor, `-${minutes} minutes`);
  return result.changes;
}

function expireOrderIfDue(id, nowIso = null) {
  let anchor = nowIso;
  if (anchor !== null && anchor !== undefined) {
    const parsed = new Date(anchor);
    if (Number.isNaN(parsed.getTime())) throw new Error(`Invalid order expiration clock timestamp: ${nowIso}`);
    anchor = parsed.toISOString();
  }
  const db = getDb();
  if (!anchor) anchor = db.prepare("SELECT datetime('now') AS now").get().now;
  const result = db.prepare(`
    UPDATE orders
    SET status = 'expired',
        updated_at = datetime('now'),
        processing_started_at = NULL,
        processing_heartbeat_at = NULL,
        processing_claim_token = NULL
    WHERE id = ?
      AND status IN ('pending','awaiting_confirmation','paid')
      AND expires_at IS NOT NULL
      AND datetime(expires_at) <= datetime(?)
  `).run(id, anchor);
  return result.changes > 0;
}

function expireStaleOrders(nowIso = null) {
  let anchor = nowIso;
  if (anchor !== null && anchor !== undefined) {
    const parsed = new Date(anchor);
    if (Number.isNaN(parsed.getTime())) throw new Error(`Invalid order expiration clock timestamp: ${nowIso}`);
    anchor = parsed.toISOString();
  }
  const db = getDb();
  if (!anchor) anchor = db.prepare("SELECT datetime('now') AS now").get().now;
  const result = db.prepare(`
    UPDATE orders
    SET status = 'expired', updated_at = datetime('now')
    WHERE status IN ('pending','awaiting_confirmation','paid')
      AND expires_at IS NOT NULL
      AND datetime(expires_at) <= datetime(?)
  `).run(anchor);
  return result.changes;
}

function listPendingConfirmation() {
  return getDb()
    .prepare(`
      SELECT * FROM orders
      WHERE status = 'awaiting_confirmation'
        AND expires_at IS NOT NULL
        AND datetime(expires_at) > datetime('now')
      ORDER BY id ASC
    `)
    .all();
}

function listExpiredWithTransactionNotifications(limit = 100) {
  return getDb().prepare(`
    SELECT * FROM orders
    WHERE status = 'expired'
      AND transaction_notification_message_id IS NOT NULL
      AND transaction_notification_status IN ('pending','sent','unavailable','final_pending')
    ORDER BY id ASC
    LIMIT ?
  `).all(limit);
}

function countForAdmin(status = null) {
  const allowed = new Set(['pending','awaiting_confirmation','paid','processing','fulfilled','rejected','cancelled','expired']);
  if (status && !allowed.has(status)) throw new Error(`Invalid order status filter: ${status}`);
  return status
    ? getDb().prepare('SELECT COUNT(*) AS c FROM orders WHERE status = ?').get(status).c
    : getDb().prepare('SELECT COUNT(*) AS c FROM orders').get().c;
}

function listForAdmin({ offset = 0, limit = 10, status = null } = {}) {
  const off = Number.isInteger(Number(offset)) && Number(offset) >= 0 ? Number(offset) : 0;
  const lim = Number.isInteger(Number(limit)) && Number(limit) > 0 && Number(limit) <= 100 ? Number(limit) : 10;
  const allowed = new Set(['pending','awaiting_confirmation','paid','processing','fulfilled','rejected','cancelled','expired']);
  if (status && !allowed.has(status)) throw new Error(`Invalid order status filter: ${status}`);
  const where = status ? 'WHERE o.status = ?' : '';
  const params = status ? [status, lim, off] : [lim, off];
  return getDb().prepare(`
    SELECT o.*, u.username AS user_username, u.first_name AS user_first_name, u.last_name AS user_last_name,
           p.name AS current_product_name, p.category AS current_product_category, p.is_active AS current_product_active
    FROM orders o
    LEFT JOIN users u ON u.telegram_id = o.user_id
    LEFT JOIN products p ON p.id = o.product_id
    ${where}
    ORDER BY o.id DESC
    LIMIT ? OFFSET ?
  `).all(...params);
}

function listByUser(telegramId) {
  return getDb().prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC').all(telegramId);
}

function countByUser(telegramId) {
  return getDb().prepare('SELECT COUNT(*) AS c FROM orders WHERE user_id = ?').get(telegramId).c;
}

/** Sum of orders actually paid (status 'paid' or 'fulfilled') for a user — real revenue, not pending/cancelled. */
function sumPaidByUser(telegramId) {
  const row = getDb()
    .prepare(`SELECT COALESCE(SUM(total_price), 0) AS s FROM orders WHERE user_id = ? AND status IN ('paid', 'fulfilled')`)
    .get(telegramId);
  return row.s;
}

function deleteByUser(telegramId) {
  getDb().prepare('DELETE FROM orders WHERE user_id = ?').run(telegramId);
}

/** Number of orders referencing a product — used by Product Management to
 * warn before retiring a catalog row. */
function countByProduct(productId) {
  const row = getDb().prepare('SELECT COUNT(*) AS c FROM orders WHERE product_id = ?').get(productId);
  return row.c;
}

module.exports = {
  findById,
  findOpenOrdersByUser,
  findOpenByUser,
  create,
  setStatus,
  markPaymentProofRequested,
  findPendingPaymentProofByUser,
  submitPaymentProof,
  claimTransactionNotification,
  recordTransactionNotification,
  releaseTransactionNotificationClaim,
  setTransactionNotificationProjectionStatus,
  listAwaitingWithTransactionNotifications,
  listTransactionNotificationsFinalPending,
  setFulfillment,
  claimForProcessing,
  touchProcessing,
  releaseProcessingClaim,
  cancelOwnedPending,
  cancelAllOwnedPending,
  reclaimStaleProcessing,
  expireOrderIfDue,
  expireStaleOrders,
  listExpiredWithTransactionNotifications,
  listPendingConfirmation,
  listByUser,
  countByUser,
  countForAdmin,
  listForAdmin,
  sumPaidByUser,
  deleteByUser,
  countByProduct,
};
