const { getDb } = require('../index');

function findByTelegramId(telegramId) {
  const db = getDb();
  return db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(telegramId);
}

function create({ telegramId, username, firstName, lastName }) {
  const db = getDb();
  // Explicitly set join_gate_verified=0 for genuinely new users.
  // Existing databases were migrated with DEFAULT 1 so legacy users are
  // grandfathered in, but SQLite's ALTER TABLE cannot change that default.
  const stmt = db.prepare(`
    INSERT INTO users (telegram_id, username, first_name, last_name, join_gate_verified)
    VALUES (?, ?, ?, ?, 0)
  `);
  const result = stmt.run(telegramId, username || null, firstName || null, lastName || null);
  return findByTelegramId(telegramId) || { id: result.lastInsertRowid };
}

function update(telegramId, { username, firstName, lastName }) {
  const db = getDb();
  const stmt = db.prepare(`
    UPDATE users
    SET username = ?, first_name = ?, last_name = ?, updated_at = datetime('now')
    WHERE telegram_id = ?
  `);
  stmt.run(username || null, firstName || null, lastName || null, telegramId);
  return findByTelegramId(telegramId);
}

/**
 * Ensure a user row exists for this Telegram user, creating or
 * refreshing it as needed. Returns the user row.
 */
function ensureFromTelegramUser(telegramUser) {
  const existing = findByTelegramId(telegramUser.id);
  if (existing) {
    return {
      user: update(telegramUser.id, {
        username: telegramUser.username,
        firstName: telegramUser.first_name,
        lastName: telegramUser.last_name,
      }),
      created: false,
    };
  }

  try {
    return {
      user: create({
        telegramId: telegramUser.id,
        username: telegramUser.username,
        firstName: telegramUser.first_name,
        lastName: telegramUser.last_name,
      }),
      created: true,
    };
  } catch (err) {
    // Concurrent/replayed Telegram updates can race on the UNIQUE telegram_id.
    // The winning row is canonical; the losing request becomes a normal update.
    if (!/UNIQUE constraint failed.*users\.telegram_id/i.test(String(err && err.message))) throw err;
    return {
      user: update(telegramUser.id, {
        username: telegramUser.username,
        firstName: telegramUser.first_name,
        lastName: telegramUser.last_name,
      }),
      created: false,
    };
  }
}

function upsertFromTelegramUser(telegramUser) {
  return ensureFromTelegramUser(telegramUser).user;
}

function claimRegistrationNotification(telegramId, claimToken, staleMinutes = 10) {
  const minutes = Number(staleMinutes);
  if (!Number.isFinite(minutes) || minutes <= 0) throw new Error(`Invalid registration notification stale window: ${staleMinutes}`);
  const result = getDb().prepare(`
    UPDATE users
    SET registration_notification_claim_token = ?,
        registration_notification_claimed_at = datetime('now')
    WHERE telegram_id = ?
      AND registration_notification_sent_at IS NULL
      AND (
        registration_notification_claimed_at IS NULL
        OR datetime(registration_notification_claimed_at) < datetime('now', ?)
      )
  `).run(claimToken, telegramId, `-${minutes} minutes`);
  return result.changes > 0;
}

function completeRegistrationNotification(telegramId, claimToken, messageId) {
  const result = getDb().prepare(`
    UPDATE users
    SET registration_notification_sent_at = datetime('now'),
        registration_notification_message_id = ?,
        registration_notification_claim_token = NULL,
        registration_notification_claimed_at = NULL,
        updated_at = datetime('now')
    WHERE telegram_id = ?
      AND registration_notification_sent_at IS NULL
      AND registration_notification_claim_token = ?
  `).run(messageId, telegramId, claimToken);
  return result.changes > 0;
}

function releaseRegistrationNotificationClaim(telegramId, claimToken) {
  const result = getDb().prepare(`
    UPDATE users
    SET registration_notification_claim_token = NULL,
        registration_notification_claimed_at = NULL
    WHERE telegram_id = ? AND registration_notification_claim_token = ?
  `).run(telegramId, claimToken);
  return result.changes > 0;
}

function listPage(offset, limit) {
  const db = getDb();
  return db.prepare('SELECT * FROM users ORDER BY id DESC LIMIT ? OFFSET ?').all(limit, offset);
}

function listBroadcastRecipientPage(afterId = 0, limit = 500) {
  const db = getDb();
  const safeAfter = Number.isInteger(Number(afterId)) && Number(afterId) >= 0 ? Number(afterId) : 0;
  const safeLimit = Math.max(1, Math.min(1000, Number(limit) || 500));
  return db.prepare(
    `SELECT id, telegram_id FROM users
      WHERE id > ? AND COALESCE(is_banned, 0) = 0
      ORDER BY id ASC LIMIT ?`
  ).all(safeAfter, safeLimit);
}

function listBroadcastRecipientSnapshotPage(afterId = 0, limit = 500, maxUserId = null) {
  const db = getDb();
  const safeAfter = Number.isInteger(Number(afterId)) && Number(afterId) >= 0 ? Number(afterId) : 0;
  const safeLimit = Math.max(1, Math.min(1000, Number(limit) || 500));
  const safeMax = maxUserId == null ? null : (Number.isInteger(Number(maxUserId)) && Number(maxUserId) > 0 ? Number(maxUserId) : 0);
  if (safeMax == null) return listBroadcastRecipientPage(safeAfter, safeLimit);
  return db.prepare(
    `SELECT id, telegram_id FROM users
      WHERE id > ? AND id <= ? AND COALESCE(is_banned, 0) = 0
      ORDER BY id ASC LIMIT ?`
  ).all(safeAfter, safeMax, safeLimit);
}

function getBroadcastRecipientSnapshot() {
  const row = getDb().prepare(`
    SELECT COUNT(*) AS count, COALESCE(MAX(id), 0) AS max_user_id
      FROM users
     WHERE COALESCE(is_banned, 0) = 0
  `).get();
  return { count: Number(row.count || 0), maxUserId: Number(row.max_user_id || 0) };
}

function countBroadcastRecipients() {
  return Number(getDb().prepare(`SELECT COUNT(*) AS c FROM users WHERE COALESCE(is_banned, 0) = 0`).get().c || 0);
}

function count() {
  const db = getDb();
  return db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
}

/**
 * Search by exact numeric Telegram ID, or a case-insensitive
 * substring match against username/first_name/last_name.
 */
function search(query, offset, limit) {
  const db = getDb();
  const numericId = /^\d+$/.test(query) ? Number(query) : null;
  const like = `%${query.replace(/[%_]/g, '\\$&')}%`;

  if (numericId !== null) {
    return db
      .prepare(
        `SELECT * FROM users
         WHERE telegram_id = ? OR username LIKE ? ESCAPE '\\' OR first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\'
         ORDER BY id DESC LIMIT ? OFFSET ?`
      )
      .all(numericId, like, like, like, limit, offset);
  }

  return db
    .prepare(
      `SELECT * FROM users
       WHERE username LIKE ? ESCAPE '\\' OR first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\'
       ORDER BY id DESC LIMIT ? OFFSET ?`
    )
    .all(like, like, like, limit, offset);
}

function searchCount(query) {
  const db = getDb();
  const numericId = /^\d+$/.test(query) ? Number(query) : null;
  const like = `%${query.replace(/[%_]/g, '\\$&')}%`;

  if (numericId !== null) {
    return db
      .prepare(
        `SELECT COUNT(*) AS c FROM users
         WHERE telegram_id = ? OR username LIKE ? ESCAPE '\\' OR first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\'`
      )
      .get(numericId, like, like, like).c;
  }

  return db
    .prepare(
      `SELECT COUNT(*) AS c FROM users
       WHERE username LIKE ? ESCAPE '\\' OR first_name LIKE ? ESCAPE '\\' OR last_name LIKE ? ESCAPE '\\'`
    )
    .get(like, like, like).c;
}

function setBanned(telegramId, banned, reason) {
  const db = getDb();
  db.prepare(`
    UPDATE users
    SET is_banned = ?, banned_at = CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END,
        banned_reason = ?, updated_at = datetime('now')
    WHERE telegram_id = ?
  `).run(banned ? 1 : 0, banned ? 1 : 0, banned ? (reason || null) : null, telegramId);
  return findByTelegramId(telegramId);
}

function isBanned(telegramId) {
  const row = findByTelegramId(telegramId);
  return Boolean(row && row.is_banned);
}

/** Whether this user has already claimed the free trial (once per lifetime). */
function markJoinGateVerified(telegramId) {
  const db = getDb();
  db.prepare("UPDATE users SET join_gate_verified = 1, updated_at = datetime('now') WHERE telegram_id = ?").run(telegramId);
  return findByTelegramId(telegramId);
}

function hasClaimedTrial(telegramId) {
  const row = findByTelegramId(telegramId);
  return Boolean(row && row.trial_claimed_at);
}

function markTrialClaimed(telegramId) {
  const db = getDb();
  db.prepare(`
    UPDATE users
    SET trial_claimed_at = datetime('now'), updated_at = datetime('now')
    WHERE telegram_id = ?
  `).run(telegramId);
  return findByTelegramId(telegramId);
}

/**
 * Admin safety net (audit.txt finding #6): lets support give a user back
 * their one-time free trial, for cases the automatic fix (trial_claimed_at
 * only set on successful activation) doesn't cover — e.g. a trial that WAS
 * genuinely activated but the user never actually got to use it for some
 * other reason. Manual, admin-triggered only; nothing resets this on its
 * own.
 */
function resetTrialClaim(telegramId) {
  const db = getDb();
  db.prepare(`
    UPDATE users
    SET trial_claimed_at = NULL, updated_at = datetime('now')
    WHERE telegram_id = ?
  `).run(telegramId);
  return findByTelegramId(telegramId);
}

function remove(telegramId) {
  const db = getDb();
  db.prepare('DELETE FROM users WHERE telegram_id = ?').run(telegramId);
}

module.exports = {
  findByTelegramId,
  create,
  update,
  upsertFromTelegramUser,
  ensureFromTelegramUser,
  claimRegistrationNotification,
  completeRegistrationNotification,
  releaseRegistrationNotificationClaim,
  listPage,
  count,
  listBroadcastRecipientPage,
  listBroadcastRecipientSnapshotPage,
  getBroadcastRecipientSnapshot,
  countBroadcastRecipients,
  search,
  searchCount,
  setBanned,
  isBanned,
  hasClaimedTrial,
  markJoinGateVerified,
  markTrialClaimed,
  resetTrialClaim,
  remove,
};
