// Canonical SQL schema for the JASEB runtime. The application uses these
// tables across registration, store/order/payment, notification, userbot,
// subscription/trial, feature-access, recovery-token, panel, and customization
// flows; additive migrations in database/index.js keep older databases compatible.

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE NOT NULL,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  join_gate_verified INTEGER NOT NULL DEFAULT 0,
  registration_notification_sent_at TEXT,
  registration_notification_message_id INTEGER,
  registration_notification_claim_token TEXT,
  registration_notification_claimed_at TEXT
);

-- 'owned' userbots = buyer's own Telegram account, logged in via
-- phone/OTP (GramJS) after buying a "Beli Userbot" product.
CREATE TABLE IF NOT EXISTS userbots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  label TEXT,
  phone TEXT,
  session_string TEXT, -- LEGACY ONLY: current StringSession storage is data/userbot_sessions/*.txt
  telegram_userbot_id INTEGER,
  status TEXT DEFAULT 'inactive', -- inactive | pending_otp | active | expired | revoked
  auto_promosi INTEGER NOT NULL DEFAULT 0,
  wtb_reply INTEGER NOT NULL DEFAULT 0,
  pm_permit INTEGER NOT NULL DEFAULT 0,
  -- Kontrol Panel base config fields (Target/Teks/Mode/Jeda/Timer/Watermark/Topic Grup)
  target TEXT,
  broadcast_text TEXT,
  mode TEXT NOT NULL DEFAULT 'sequential', -- sequential | random
  delay_seconds INTEGER NOT NULL DEFAULT 5,
  timer_config TEXT,
  timer_enabled INTEGER NOT NULL DEFAULT 1,
  watermark TEXT,
  watermark_enabled INTEGER NOT NULL DEFAULT 1,
  topic_grup TEXT,
  order_id INTEGER,
  activated_at TEXT,
  expires_at TEXT,
  token TEXT, -- LEGACY plaintext "Token Garansi". No longer written; existing values are hashed into token_hash and cleared at startup (see database/index.js).
  -- Backup Token (recovery credential for THIS userbot). Only the SHA-256 of
  -- the token is stored (utils/tokenCodec.js). token_generation is bumped on
  -- every issue/rotation and is the compare-and-swap guard that makes rotation
  -- (regenerate, use-for-recovery, ownership transfer) atomic and un-replayable.
  -- Retired hashes live in userbot_token_history so an old token can be told
  -- apart from one that never existed. See services/backupToken.service.js.
  token_hash TEXT,
  token_generation INTEGER NOT NULL DEFAULT 0,
  token_rotated_at TEXT,
  -- Subscription/runtime bookkeeping (see services/subscription.service.js).
  -- status is the SUBSCRIPTION lifecycle (pending_otp | active | expired | revoked);
  -- runtime_stop_reason explains why the runtime is intentionally stopped
  -- (SUBSCRIPTION_EXPIRED | SESSION_INVALID | NULL) and is deliberately a
  -- separate column so "subscription expired" and "Telegram session invalid"
  -- can never be conflated. sub_version is bumped on every subscription
  -- change and is used for compare-and-swap updates.
  runtime_stop_reason TEXT,
  expired_at TEXT,
  sub_version INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  -- user_id here is the buyer's Telegram ID (see all call sites: order.user_id,
  -- ctx.from.id), not the internal users.id autoincrement — so this must
  -- reference the UNIQUE telegram_id column, not the primary key.
  FOREIGN KEY (user_id) REFERENCES users(telegram_id)
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  plan TEXT,
  status TEXT DEFAULT 'inactive',
  expires_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(telegram_id)
);

-- Store catalog. category: 'userbot' (buyer's own account) or
-- 'jaseb' (admin-provisioned account leased to buyer).
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL DEFAULT 'jaseb', -- 'userbot' | 'jaseb'
  name TEXT NOT NULL,
  description TEXT,
  price INTEGER NOT NULL DEFAULT 0,   -- price per 1 "unit" (1 bulan)
  duration_days INTEGER NOT NULL DEFAULT 30,
  garansi INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  -- JSON array of feature ids (see services/featureAccess.service.js
  -- FEATURE_REGISTRY) this product entitles a buyer to use. NULL = not
  -- configured -> unrestricted (full access), so every product created
  -- before this feature shipped keeps working exactly as before.
  feature_access TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,       -- telegram_id of buyer
  product_id INTEGER,
  category TEXT NOT NULL DEFAULT 'jaseb',
  product_name TEXT,
  qty INTEGER NOT NULL DEFAULT 1, -- number of "bulan" units purchased
  unit_price INTEGER NOT NULL DEFAULT 0,
  total_price INTEGER NOT NULL DEFAULT 0,
  duration_days INTEGER NOT NULL DEFAULT 30, -- total leased duration (qty * product.duration_days)
  status TEXT DEFAULT 'pending', -- pending | awaiting_confirmation | paid | processing | fulfilled | rejected | cancelled | expired
  fulfillment_ref INTEGER,       -- id of userbots row (owned) or userbot_pool row (jaseb) once fulfilled
  target_userbot_id INTEGER,     -- renewal orders: the owned userbots.id the buyer chose to extend
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT,                -- absolute per-order expiration: created_at + 1 hour
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  -- Processing lease bookkeeping: updated_at remains the general row timestamp;
  -- these fields make an in-flight claim explicit and give recovery a dedicated
  -- heartbeat/identity so a legitimate long-running fulfillment is not inferred
  -- stale merely because some unrelated row update policy changed.
  processing_started_at TEXT,
  processing_heartbeat_at TEXT,
  processing_claim_token TEXT,
  payment_proof_requested_at TEXT,
  payment_proof_type TEXT,
  payment_proof_file_id TEXT,
  payment_proof_caption TEXT,
  payment_proof_entities TEXT NOT NULL DEFAULT '[]',
  payment_proof_received_at TEXT,
  transaction_notification_duration_minutes INTEGER,
  transaction_notification_expires_at TEXT,
  transaction_notification_chat_id TEXT,
  transaction_notification_message_id INTEGER,
  transaction_notification_media_type TEXT,
  transaction_notification_status TEXT NOT NULL DEFAULT 'none',
  transaction_notification_claim_token TEXT,
  transaction_notification_claimed_at TEXT,
  notification_actor_id INTEGER,
  FOREIGN KEY (user_id) REFERENCES users(telegram_id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Pool of userbots ADMIN has added/activated, leased out to "Beli
-- Jaseb" buyers for the duration of their order, then returned.
CREATE TABLE IF NOT EXISTS userbot_pool (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT NOT NULL,
  phone TEXT,
  session_string TEXT,
  telegram_userbot_id INTEGER,
  status TEXT NOT NULL DEFAULT 'available', -- available | reserved | assigned | disabled
  assigned_user_id INTEGER,   -- telegram_id of current lessee
  assigned_order_id INTEGER,
  reservation_order_id INTEGER,
  reservation_expires_at TEXT,
  auto_promosi INTEGER NOT NULL DEFAULT 0,
  wtb_reply INTEGER NOT NULL DEFAULT 0,
  pm_permit INTEGER NOT NULL DEFAULT 0,
  -- Kontrol Panel base config fields (Target/Teks/Mode/Jeda/Timer/Watermark/Topic Grup)
  target TEXT,
  broadcast_text TEXT,
  broadcast_text_entities TEXT NOT NULL DEFAULT '[]',
  broadcast_kind TEXT NOT NULL DEFAULT 'text',
  broadcast_source_chat_id TEXT,
  broadcast_source_message_id INTEGER,
  wtb_replies TEXT NOT NULL DEFAULT '[]',
  mode TEXT NOT NULL DEFAULT 'sequential', -- sequential | random
  delay_seconds INTEGER NOT NULL DEFAULT 5,
  timer_config TEXT,
  timer_enabled INTEGER NOT NULL DEFAULT 1,
  watermark TEXT,
  watermark_enabled INTEGER NOT NULL DEFAULT 1,
  topic_grup TEXT,
  pm_permit_text TEXT,
  wtb_timer TEXT,
  wtb_auto_reset_minutes INTEGER NOT NULL DEFAULT 1440,
  channel_disabled INTEGER NOT NULL DEFAULT 0,
  wtb_target_channel TEXT,
  wtb_banned_words TEXT NOT NULL DEFAULT '',
  wtb_max_chars INTEGER NOT NULL DEFAULT 0,
  wtb_filter_links INTEGER NOT NULL DEFAULT 0,
  wtb_filter_usernames INTEGER NOT NULL DEFAULT 0,
  auto_react INTEGER NOT NULL DEFAULT 0,
  auto_react_emoji TEXT NOT NULL DEFAULT '❤️',
  delay_max_seconds INTEGER,
  round_delay_seconds INTEGER NOT NULL DEFAULT 3600,
  expires_at TEXT,
  token TEXT, -- "Token Garansi" shown on activation, re-viewable via Klaim Token
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Single-row-per-key store for payment configuration (QRIS image
-- file_id, QRIS text/nominal note, bank/e-wallet info, etc).
CREATE TABLE IF NOT EXISTS panel_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userbot_id INTEGER NOT NULL,
  target TEXT NOT NULL,
  title TEXT,
  topic_id INTEGER,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(userbot_id, target),
  FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS panel_messages (
  userbot_id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'text',
  text TEXT,
  media_path TEXT,
  media_type TEXT,
  source_chat_id TEXT,
  source_message_id INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  entities TEXT NOT NULL DEFAULT '[]',
  caption_entities TEXT NOT NULL DEFAULT '[]',
  file_name TEXT,
  FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS panel_wtb_replies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  userbot_id INTEGER NOT NULL,
  keywords TEXT NOT NULL,
  response TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS testimonial_deliveries (
  order_id INTEGER PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'none',
  claim_token TEXT,
  claimed_at TEXT,
  channel_id TEXT,
  message_id INTEGER,
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  sent_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS pm_permit_messages (
  userbot_id INTEGER PRIMARY KEY,
  text TEXT NOT NULL,
  entities TEXT NOT NULL DEFAULT '[]',
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS broadcast_pm_messages (
  userbot_id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL DEFAULT 'text',
  text TEXT,
  entities TEXT NOT NULL DEFAULT '[]',
  media_path TEXT,
  media_type TEXT,
  source_chat_id TEXT,
  source_message_id INTEGER,
  caption_entities TEXT NOT NULL DEFAULT '[]',
  file_name TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS panel_settings (
  userbot_id INTEGER PRIMARY KEY,
  wtb_timer TEXT,
  wtb_auto_reset_minutes INTEGER NOT NULL DEFAULT 3,
  channel_disabled INTEGER NOT NULL DEFAULT 0,
  wtb_target_channel TEXT,
  wtb_banned_words TEXT NOT NULL DEFAULT '',
  wtb_max_chars INTEGER NOT NULL DEFAULT 0,
  wtb_filter_links INTEGER NOT NULL DEFAULT 0,
  wtb_filter_usernames INTEGER NOT NULL DEFAULT 0,
  auto_react INTEGER NOT NULL DEFAULT 0,
  auto_react_emoji TEXT NOT NULL DEFAULT '❤️',
  -- Keep these two in sync with RECOMMENDED_GROUP_DELAY_SECONDS /
  -- RECOMMENDED_ROUND_DELAY_SECONDS in services/panelConfig.service.js —
  -- same safe/recommended cadence, just expressed as the DB-level default
  -- so a brand-new userbot can start Auto Promosi immediately without ever
  -- opening ⏱️ Atur Jeda.
  group_delay_seconds INTEGER NOT NULL DEFAULT 10,
  group_delay_max_seconds INTEGER,
  round_delay_seconds INTEGER NOT NULL DEFAULT 3600,
  FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payment_config (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  level TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Custom Submenu feature (Admin Panel -> Settings -> Custom Submenu).
-- Stores raw Telegram text + message entities per submenu so admin
-- formatting (bold/italic/spoiler/custom emoji/etc.) is preserved
-- exactly, without any Markdown/HTML re-parsing.
-- PM Permit interaction/idempotency state. One row per (userbot, Telegram
-- peer) pair, scoped by owner_kind ('owned' | 'pool') + owner_id so an
-- owned userbot #5 and a pool userbot #5 never share state. This is the
-- persistent replacement for any in-memory Map: it survives process
-- restarts, and the UNIQUE constraint below is what makes "only one PM
-- Permit per new user" possible to guarantee atomically even when two
-- incoming-message events for the same peer race each other — the first
-- INSERT wins, the second fails the unique check and simply does nothing.
-- status: 'pending' (claimed, send in flight) | 'sent' (delivered, never
-- send again) | 'skipped' (permanently undeliverable, e.g. blocked — do
-- not keep retrying).
CREATE TABLE IF NOT EXISTS pm_permit_state (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_kind TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  peer_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  first_seen_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_responded_at TEXT,
  UNIQUE(owner_kind, owner_id, peer_id)
);

-- Append-only audit trail of every subscription change on an owned userbot
-- (admin extension, paid renewal, automatic expiry). operation_id is UNIQUE
-- and is what makes each operation idempotent: a retried/duplicated
-- callback re-uses the same operation_id and can therefore never be applied
-- twice, while a deliberate second extension gets a fresh operation_id.
-- No FK to userbots on purpose: history must survive userbot deletion.
-- Never stores session strings, tokens or any other credential.
CREATE TABLE IF NOT EXISTS userbot_subscription_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  operation_id TEXT NOT NULL UNIQUE,
  action TEXT NOT NULL, -- admin_extend | order_renewal | auto_expire
  userbot_id INTEGER NOT NULL,
  owner_user_id INTEGER,
  admin_id INTEGER,
  order_id INTEGER,
  previous_status TEXT,
  previous_expiry TEXT,
  extension_days INTEGER,
  new_status TEXT,
  new_expiry TEXT,
  created_at TEXT NOT NULL -- ISO-8601 UTC
);
CREATE INDEX IF NOT EXISTS idx_userbot_sub_events_userbot ON userbot_subscription_events (userbot_id, id);

-- Ledger of RETIRED Backup Token hashes (never the plaintext). A token is
-- retired when it is used for a recovery, regenerated, rotated by an ownership
-- transfer, or when its userbot is removed/expired. token_hash is UNIQUE so a
-- hash can only ever be retired once. No FK to userbots on purpose: the record
-- must outlive the userbot so a stale token is still reported as "no longer
-- valid" instead of "unknown". reason: used | regenerated | transfer | expired | revoked
CREATE TABLE IF NOT EXISTS userbot_token_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash TEXT NOT NULL UNIQUE,
  userbot_id INTEGER NOT NULL,
  generation INTEGER NOT NULL DEFAULT 0,
  reason TEXT NOT NULL,
  retired_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_userbot_token_history_userbot ON userbot_token_history (userbot_id, id);

-- Durable runtime checkpoint for long-running userbot automation.
-- The row is deliberately independent from userbots FK ownership so a
-- crash/restart/update cannot cascade-delete recovery history before the
-- worker has a chance to reconcile it. cursor_key identifies the next
-- target when possible; workset_hash makes a changed target set a new cycle
-- instead of blindly applying an old positional cursor to new data.
CREATE TABLE IF NOT EXISTS userbot_runtime_jobs (
  job_key TEXT PRIMARY KEY,
  owner_kind TEXT NOT NULL CHECK (owner_kind IN ('owned', 'pool')),
  owner_id INTEGER NOT NULL,
  job_type TEXT NOT NULL CHECK (job_type IN ('auto_promosi')),
  status TEXT NOT NULL CHECK (status IN ('running', 'idle', 'cancelled', 'failed')),
  cursor INTEGER NOT NULL DEFAULT 0 CHECK (cursor >= 0),
  cursor_key TEXT,
  cycle_id TEXT,
  workset_hash TEXT,
  next_run_at TEXT,
  started_at TEXT,
  heartbeat_at TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_error TEXT,
  total_targets INTEGER NOT NULL DEFAULT 0 CHECK (total_targets >= 0),
  processed_targets INTEGER NOT NULL DEFAULT 0 CHECK (processed_targets >= 0),
  successful_targets INTEGER NOT NULL DEFAULT 0 CHECK (successful_targets >= 0),
  failed_targets INTEGER NOT NULL DEFAULT 0 CHECK (failed_targets >= 0),
  blocked_targets INTEGER NOT NULL DEFAULT 0 CHECK (blocked_targets >= 0),
  removed_targets INTEGER NOT NULL DEFAULT 0 CHECK (removed_targets >= 0),
  sent_count INTEGER NOT NULL DEFAULT 0 CHECK (sent_count >= 0),
  failed_count INTEGER NOT NULL DEFAULT 0 CHECK (failed_count >= 0),
  cycle_number INTEGER NOT NULL DEFAULT 0 CHECK (cycle_number >= 0),
  last_activity_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_userbot_runtime_jobs_status ON userbot_runtime_jobs (job_type, status, updated_at);
CREATE INDEX IF NOT EXISTS idx_userbot_runtime_jobs_owner ON userbot_runtime_jobs (owner_kind, owner_id, job_type);

CREATE TABLE IF NOT EXISTS userbot_promotion_target_health (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_kind TEXT NOT NULL CHECK (owner_kind IN ('owned', 'pool')),
  owner_id INTEGER NOT NULL,
  target_key TEXT NOT NULL,
  target TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('healthy', 'transient', 'unusable')),
  last_checked_at TEXT,
  last_error TEXT,
  failure_count INTEGER NOT NULL DEFAULT 0 CHECK (failure_count >= 0),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(owner_kind, owner_id, target_key)
);
CREATE INDEX IF NOT EXISTS idx_promotion_target_health_owner ON userbot_promotion_target_health (owner_kind, owner_id, status, updated_at);

CREATE TABLE IF NOT EXISTS base_reply_cooldowns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_kind TEXT NOT NULL CHECK (owner_kind IN ('owned', 'pool')),
  owner_id INTEGER NOT NULL,
  chat_id TEXT NOT NULL,
  rule_id TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'sent')),
  claimed_at_ms INTEGER NOT NULL,
  last_sent_at_ms INTEGER,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(owner_kind, owner_id, chat_id, rule_id)
);
CREATE INDEX IF NOT EXISTS idx_base_reply_cooldown_owner ON base_reply_cooldowns (owner_kind, owner_id, updated_at);

CREATE TABLE IF NOT EXISTS submenu_customizations (
  submenu_id TEXT PRIMARY KEY,
  content_text TEXT NOT NULL,
  content_entities TEXT NOT NULL DEFAULT '[]',
  updated_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`;

module.exports = { SCHEMA };
