const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { config } = require('../config');
const { SCHEMA } = require('./schema');
const logger = require('../utils/logger');
const sessionStore = require('../utils/userbotSessionStorage');

let db = null;

function initDatabase() {
  if (db) return db;

  const fullPath = path.resolve(process.cwd(), config.dbPath);
  const dir = path.dirname(fullPath);

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  db = new Database(fullPath);
  try {
    db.pragma('journal_mode = WAL');
    // Avoid immediate SQLITE_BUSY failures when another legitimate writer or
    // the OS is briefly holding the WAL/checkpoint lock. This is intentionally
    // bounded: database contention must still surface as an error eventually.
    db.pragma('busy_timeout = 5000');
    // Make FK enforcement explicit; migration code temporarily disables it only
    // during the atomic parent-table rebuild required by SQLite.
    db.pragma('foreign_keys = ON');
    db.exec(SCHEMA);
    runMigrations(db);
    migrateLegacyHomeSubmenu(db);
    migrateLegacyStorePolicy(db);
    backfillBackupTokenHashes(db);
    const sessionMigration = sessionStore.migrateLegacySessions(db);
    const migrated = Number(sessionMigration.userbots.migrated || 0) + Number(sessionMigration.userbotPool.migrated || 0);
    const blocked = Number(sessionMigration.userbots.blocked || 0) + Number(sessionMigration.userbotPool.blocked || 0);
    if (migrated) logger.info(`Migrated ${migrated} legacy plaintext userbot session(s) to .txt storage.`);
    if (blocked) logger.warn(`BLOCKED: ${blocked} legacy encrypted userbot session(s) remain untouched because no recovery key is available.`);
    const orphanSessionsRemoved = sessionStore.cleanupOrphanSessionFiles(db);
    if (orphanSessionsRemoved) logger.info(`Removed ${orphanSessionsRemoved} orphan userbot session file(s).`);
  } catch (err) {
    try { db.close(); } catch (_) {}
    db = null;
    throw err;
  }

  logger.info('Database initialized at', fullPath);

  // Restore Emoji Premium / Custom Icon Tombol / etc. from
  // config/settings.snapshot.json if this is a fresh DB (or missing
  // some keys) — see settingsPortability.service.js. Lazy-required and
  // wrapped so a bad snapshot can never stop the bot from starting.
  try {
    require('../services/settingsPortability.service').importFromFileIfNeeded();
  } catch (err) {
    logger.warn('Gagal memuat settings.snapshot.json:', err.message);
  }

  return db;
}

// Additive migrations for columns/tables introduced after the initial schema.
// The complete migration set executes in one transaction. Only the specific
// SQLite duplicate-column case is idempotently tolerated, and only after the
// existing column's type/NULL/default metadata matches the migration.
/**
 * The home screen originally had two Custom Submenu ids: `main` and `start`.
 * `/start` is now the single canonical home screen. Preserve an existing
 * legacy `main` customization by moving it to `start`; if both exist, keep
 * the explicit `/start` customization and remove only the obsolete duplicate.
 *
 * This runs after the database schema is initialized and before snapshot
 * restore, so the migration is effective even when the app is freshly
 * started from an existing database file.
 */
function migrateLegacyHomeSubmenu(database) {
  const migrate = database.transaction(() => {
    const legacy = database
      .prepare('SELECT * FROM submenu_customizations WHERE submenu_id = ?')
      .get('main');
    if (!legacy) return { migrated: false, removedDuplicate: false };

    const canonical = database
      .prepare('SELECT 1 FROM submenu_customizations WHERE submenu_id = ?')
      .get('start');

    if (canonical) {
      database.prepare('DELETE FROM submenu_customizations WHERE submenu_id = ?').run('main');
      return { migrated: false, removedDuplicate: true };
    }

    database
      .prepare(`
        INSERT INTO submenu_customizations
          (submenu_id, content_text, content_entities, updated_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(
        'start',
        legacy.content_text,
        legacy.content_entities,
        legacy.updated_by,
        legacy.created_at,
        legacy.updated_at
      );

    database.prepare('DELETE FROM submenu_customizations WHERE submenu_id = ?').run('main');
    return { migrated: true, removedDuplicate: false };
  });

  const result = migrate();
  if (result.migrated) {
    logger.info('Migrated legacy main home-screen customization to canonical start submenu.');
  } else if (result.removedDuplicate) {
    logger.info('Removed duplicate legacy main home-screen customization; canonical start customization retained.');
  }
}


/**
 * Purchase policy used to have two Custom Submenu ids for the same concept:
 * `store.category_policy` and `store.payment_policy`. The purchase flow now
 * displays the canonical payment-policy screen once. Preserve an existing
 * category-policy customization (including its raw Telegram entities) by
 * promoting it to the canonical id when that id is absent; when both exist,
 * the explicit canonical customization wins and only the obsolete duplicate
 * is removed. The whole conversion is transactional and idempotent.
 */
function migrateLegacyStorePolicy(database) {
  const migrate = database.transaction(() => {
    const legacy = database
      .prepare('SELECT * FROM submenu_customizations WHERE submenu_id = ?')
      .get('store.category_policy');
    if (!legacy) return { migrated: false, removedDuplicate: false };

    const canonical = database
      .prepare('SELECT 1 FROM submenu_customizations WHERE submenu_id = ?')
      .get('store.payment_policy');

    if (canonical) {
      database.prepare('DELETE FROM submenu_customizations WHERE submenu_id = ?').run('store.category_policy');
      return { migrated: false, removedDuplicate: true };
    }

    database.prepare(`
      INSERT INTO submenu_customizations
        (submenu_id, content_text, content_entities, updated_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      'store.payment_policy',
      legacy.content_text,
      legacy.content_entities,
      legacy.updated_by,
      legacy.created_at,
      legacy.updated_at
    );
    database.prepare('DELETE FROM submenu_customizations WHERE submenu_id = ?').run('store.category_policy');
    return { migrated: true, removedDuplicate: false };
  });

  const result = migrate();
  if (result.migrated) {
    logger.info('Migrated legacy store.category_policy customization to canonical store.payment_policy.');
  } else if (result.removedDuplicate) {
    logger.info('Removed duplicate legacy store.category_policy customization; canonical payment policy retained.');
  }
}

/**
 * Backup Token hardening for databases created before token_hash existed.
 *
 * Old versions stored the plaintext "Token Garansi" in userbots.token. For every
 * such row this hashes it into token_hash (so the token the buyer already holds
 * keeps working, unchanged) and then clears the plaintext, so no usable
 * credential remains at rest.
 *
 * Idempotent and safe to re-run: only rows that still carry plaintext are
 * touched, everything happens in ONE transaction (all rows or none), no
 * userbot/order/session/ownership column is modified, and a row whose hash would
 * collide with another row is left without a token (never with a shared one)
 * rather than aborting startup — its owner simply regenerates from Kontrol Panel.
 * Uses the same codec as the service so hashing can never drift.
 */
function backfillBackupTokenHashes(database) {
  const { hashStored } = require('../utils/tokenCodec');
  const pending = database
    .prepare("SELECT id, token, token_hash FROM userbots WHERE token IS NOT NULL AND token != ''")
    .all();
  if (pending.length === 0) return { hashed: 0, cleared: 0 };

  const nowIso = new Date().toISOString();
  const setHash = database.prepare(
    `UPDATE userbots SET token_hash = ?, token_generation = CASE WHEN token_generation < 1 THEN 1 ELSE token_generation END,
            token_rotated_at = COALESCE(token_rotated_at, ?), token = NULL WHERE id = ?`
  );
  const clearOnly = database.prepare('UPDATE userbots SET token = NULL WHERE id = ?');
  let hashed = 0;
  let cleared = 0;

  database.transaction(() => {
    for (const row of pending) {
      if (row.token_hash) {
        // Already migrated (e.g. partial earlier run): hash exists, drop the plaintext.
        clearOnly.run(row.id);
        cleared++;
        continue;
      }
      const hash = hashStored(row.token);
      if (!hash) {
        clearOnly.run(row.id);
        cleared++;
        continue;
      }
      try {
        setHash.run(hash, nowIso, row.id);
        hashed++;
      } catch (err) {
        if (!/UNIQUE constraint failed/i.test(String(err && err.message))) throw err;
        clearOnly.run(row.id);
        cleared++;
        logger.warn(`Backfill token: userbot #${row.id} memiliki token duplikat, token dikosongkan (owner dapat membuat token baru).`);
      }
    }
  })();

  logger.info(`Backfill Backup Token: ${hashed} token di-hash, ${cleared} plaintext dibersihkan tanpa hash baru.`);
  return { hashed, cleared };
}

function runMigrations(database) {
  const statements = [
    `CREATE TABLE IF NOT EXISTS panel_groups (id INTEGER PRIMARY KEY AUTOINCREMENT, userbot_id INTEGER NOT NULL, target TEXT NOT NULL, title TEXT, topic_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE(userbot_id, target))`,
    `CREATE TABLE IF NOT EXISTS panel_messages (userbot_id INTEGER PRIMARY KEY, kind TEXT NOT NULL DEFAULT 'text', text TEXT, media_path TEXT, media_type TEXT, source_chat_id TEXT, source_message_id INTEGER, updated_at TEXT NOT NULL DEFAULT (datetime('now')))`,
    `CREATE TABLE IF NOT EXISTS panel_wtb_replies (id INTEGER PRIMARY KEY AUTOINCREMENT, userbot_id INTEGER NOT NULL, keywords TEXT NOT NULL, response TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT (datetime('now')))`,
    `CREATE TABLE IF NOT EXISTS panel_settings (userbot_id INTEGER PRIMARY KEY, wtb_timer TEXT, wtb_auto_reset_minutes INTEGER NOT NULL DEFAULT 3, channel_disabled INTEGER NOT NULL DEFAULT 0, wtb_target_channel TEXT, wtb_banned_words TEXT NOT NULL DEFAULT '', wtb_max_chars INTEGER NOT NULL DEFAULT 0, wtb_filter_links INTEGER NOT NULL DEFAULT 0, wtb_filter_usernames INTEGER NOT NULL DEFAULT 0, auto_react INTEGER NOT NULL DEFAULT 0, auto_react_emoji TEXT NOT NULL DEFAULT '❤️', group_delay_seconds INTEGER NOT NULL DEFAULT 10, group_delay_max_seconds INTEGER, round_delay_seconds INTEGER NOT NULL DEFAULT 3600)`,
    "ALTER TABLE users ADD COLUMN is_banned INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE users ADD COLUMN banned_at TEXT",
    "ALTER TABLE users ADD COLUMN banned_reason TEXT",
    "ALTER TABLE userbots ADD COLUMN target TEXT",
    "ALTER TABLE userbots ADD COLUMN broadcast_text TEXT",
    "ALTER TABLE userbots ADD COLUMN mode TEXT NOT NULL DEFAULT 'sequential'",
    "ALTER TABLE userbots ADD COLUMN delay_seconds INTEGER NOT NULL DEFAULT 5",
    "ALTER TABLE userbots ADD COLUMN timer_config TEXT",
    "ALTER TABLE userbots ADD COLUMN timer_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE userbots ADD COLUMN watermark TEXT",
    "ALTER TABLE userbots ADD COLUMN watermark_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE userbots ADD COLUMN topic_grup TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN target TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN broadcast_text TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN broadcast_text_entities TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE userbot_pool ADD COLUMN broadcast_kind TEXT NOT NULL DEFAULT 'text'",
    "ALTER TABLE userbot_pool ADD COLUMN broadcast_source_chat_id TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN broadcast_source_message_id INTEGER",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_replies TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE userbot_pool ADD COLUMN mode TEXT NOT NULL DEFAULT 'sequential'",
    "ALTER TABLE userbot_pool ADD COLUMN delay_seconds INTEGER NOT NULL DEFAULT 5",
    "ALTER TABLE userbot_pool ADD COLUMN timer_config TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN timer_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE userbot_pool ADD COLUMN watermark TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN watermark_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE userbot_pool ADD COLUMN topic_grup TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN pm_permit_text TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_timer TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_auto_reset_minutes INTEGER NOT NULL DEFAULT 1440",
    "ALTER TABLE userbot_pool ADD COLUMN channel_disabled INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_target_channel TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_banned_words TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_max_chars INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_filter_links INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbot_pool ADD COLUMN wtb_filter_usernames INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbot_pool ADD COLUMN auto_react INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbot_pool ADD COLUMN auto_react_emoji TEXT NOT NULL DEFAULT '❤️'",
    "ALTER TABLE userbot_pool ADD COLUMN delay_max_seconds INTEGER",
    "ALTER TABLE userbot_pool ADD COLUMN round_delay_seconds INTEGER NOT NULL DEFAULT 3600",
    "ALTER TABLE users ADD COLUMN trial_claimed_at TEXT",
    "ALTER TABLE users ADD COLUMN join_gate_verified INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE userbots ADD COLUMN token TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN token TEXT",
    "ALTER TABLE userbot_pool ADD COLUMN telegram_userbot_id INTEGER",
    "ALTER TABLE userbot_pool ADD COLUMN reservation_order_id INTEGER",
    "ALTER TABLE userbot_pool ADD COLUMN reservation_expires_at TEXT",
    "ALTER TABLE panel_settings ADD COLUMN wtb_target_channel TEXT",
    "ALTER TABLE panel_settings ADD COLUMN wtb_banned_words TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE panel_settings ADD COLUMN wtb_max_chars INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE panel_settings ADD COLUMN wtb_filter_links INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE panel_settings ADD COLUMN wtb_filter_usernames INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE panel_settings ADD COLUMN auto_react INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE panel_settings ADD COLUMN auto_react_emoji TEXT NOT NULL DEFAULT '❤️'",
    "ALTER TABLE panel_settings ADD COLUMN group_delay_max_seconds INTEGER",
    "UPDATE panel_settings SET group_delay_max_seconds = group_delay_seconds WHERE group_delay_max_seconds IS NULL",
    "ALTER TABLE panel_messages ADD COLUMN entities TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE panel_messages ADD COLUMN caption_entities TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE panel_messages ADD COLUMN file_name TEXT",
    `CREATE TABLE IF NOT EXISTS pm_permit_messages (userbot_id INTEGER PRIMARY KEY, text TEXT NOT NULL, entities TEXT NOT NULL DEFAULT '[]', updated_at TEXT NOT NULL DEFAULT (datetime('now')))` ,
    `CREATE TABLE IF NOT EXISTS broadcast_pm_messages (userbot_id INTEGER PRIMARY KEY, kind TEXT NOT NULL DEFAULT 'text', text TEXT, entities TEXT NOT NULL DEFAULT '[]', media_path TEXT, media_type TEXT, source_chat_id TEXT, source_message_id INTEGER, caption_entities TEXT NOT NULL DEFAULT '[]', file_name TEXT, updated_at TEXT NOT NULL DEFAULT (datetime('now')))` ,
    "ALTER TABLE userbots ADD COLUMN runtime_stop_reason TEXT",
    "ALTER TABLE userbots ADD COLUMN expired_at TEXT",
    "ALTER TABLE userbots ADD COLUMN sub_version INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbots ADD COLUMN updated_at TEXT",
    "ALTER TABLE orders ADD COLUMN target_userbot_id INTEGER",
    "ALTER TABLE orders ADD COLUMN expires_at TEXT",
    "ALTER TABLE orders ADD COLUMN processing_started_at TEXT",
    "ALTER TABLE orders ADD COLUMN processing_heartbeat_at TEXT",
    "ALTER TABLE orders ADD COLUMN processing_claim_token TEXT",
    "ALTER TABLE users ADD COLUMN registration_notification_sent_at TEXT",
    "ALTER TABLE users ADD COLUMN registration_notification_message_id INTEGER",
    "ALTER TABLE users ADD COLUMN registration_notification_claim_token TEXT",
    "ALTER TABLE users ADD COLUMN registration_notification_claimed_at TEXT",
    "ALTER TABLE orders ADD COLUMN payment_proof_requested_at TEXT",
    "ALTER TABLE orders ADD COLUMN payment_proof_type TEXT",
    "ALTER TABLE orders ADD COLUMN payment_proof_file_id TEXT",
    "ALTER TABLE orders ADD COLUMN payment_proof_caption TEXT",
    "ALTER TABLE orders ADD COLUMN payment_proof_entities TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE orders ADD COLUMN payment_proof_received_at TEXT",
    "ALTER TABLE orders ADD COLUMN transaction_notification_duration_minutes INTEGER",
    "ALTER TABLE orders ADD COLUMN transaction_notification_expires_at TEXT",
    "ALTER TABLE orders ADD COLUMN transaction_notification_chat_id TEXT",
    "ALTER TABLE orders ADD COLUMN transaction_notification_message_id INTEGER",
    "ALTER TABLE orders ADD COLUMN transaction_notification_media_type TEXT",
    "ALTER TABLE orders ADD COLUMN transaction_notification_status TEXT NOT NULL DEFAULT 'none'",
    "ALTER TABLE orders ADD COLUMN transaction_notification_claim_token TEXT",
    "ALTER TABLE orders ADD COLUMN transaction_notification_claimed_at TEXT",
    "ALTER TABLE orders ADD COLUMN notification_actor_id INTEGER",
    `CREATE INDEX IF NOT EXISTS idx_orders_notification_lifecycle ON orders (status, transaction_notification_expires_at, transaction_notification_status)`,
    `CREATE INDEX IF NOT EXISTS idx_orders_user_status ON orders (user_id, status)`,
    `CREATE INDEX IF NOT EXISTS idx_orders_user_status_expires_at ON orders (user_id, status, expires_at)`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_pool_reservation ON userbot_pool (status, reservation_expires_at, reservation_order_id)`,
    `CREATE TABLE IF NOT EXISTS testimonial_deliveries (
  order_id INTEGER PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'none',
  claim_token TEXT,
  claimed_at TEXT,
  channel_id TEXT,
  message_id INTEGER,
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  sent_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
)`,
    `CREATE TABLE IF NOT EXISTS userbot_subscription_events (id INTEGER PRIMARY KEY AUTOINCREMENT, operation_id TEXT NOT NULL UNIQUE, action TEXT NOT NULL, userbot_id INTEGER NOT NULL, owner_user_id INTEGER, admin_id INTEGER, order_id INTEGER, previous_status TEXT, previous_expiry TEXT, extension_days INTEGER, new_status TEXT, new_expiry TEXT, created_at TEXT NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_sub_events_userbot ON userbot_subscription_events (userbot_id, id)`,
    `CREATE TABLE IF NOT EXISTS pm_permit_state (id INTEGER PRIMARY KEY AUTOINCREMENT, owner_kind TEXT NOT NULL, owner_id INTEGER NOT NULL, peer_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', first_seen_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')), last_responded_at TEXT, UNIQUE(owner_kind, owner_id, peer_id))`,
    "ALTER TABLE pm_permit_state ADD COLUMN last_responded_at TEXT", 
    "ALTER TABLE panel_wtb_replies ADD COLUMN entities TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE products ADD COLUMN feature_access TEXT",
    "ALTER TABLE userbots ADD COLUMN token_hash TEXT",
    "ALTER TABLE userbots ADD COLUMN token_generation INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE userbots ADD COLUMN token_rotated_at TEXT",
    `CREATE TABLE IF NOT EXISTS userbot_token_history (id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, userbot_id INTEGER NOT NULL, generation INTEGER NOT NULL DEFAULT 0, reason TEXT NOT NULL, retired_at TEXT NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_token_history_userbot ON userbot_token_history (userbot_id, id)`,
    // One userbot per active token hash, enforced by the database. Partial so
    // the many rows without a token (pending/legacy) do not collide on NULL.
    // Lives here (not in SCHEMA) because SCHEMA runs BEFORE the ALTERs above
    // and would fail on an existing database that lacks the column.
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_userbots_token_hash ON userbots (token_hash) WHERE token_hash IS NOT NULL`,
    `CREATE INDEX IF NOT EXISTS idx_userbots_status_expiry ON userbots (status, expires_at)`,
    `CREATE TABLE IF NOT EXISTS broadcast_jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_id INTEGER NOT NULL,
      kind TEXT NOT NULL DEFAULT 'broadcast',
      source_chat_id TEXT NOT NULL,
      source_message_id INTEGER NOT NULL,
      payload_json TEXT NOT NULL,
      buttons_json TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'queued',
      target_count INTEGER NOT NULL DEFAULT 0,
      target_max_user_id INTEGER,
      success_count INTEGER NOT NULL DEFAULT 0,
      fail_count INTEGER NOT NULL DEFAULT 0,
      skipped_count INTEGER NOT NULL DEFAULT 0,
      retry_count INTEGER NOT NULL DEFAULT 0,
      idempotency_key TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      started_at TEXT,
      completed_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      last_error TEXT
    )`,
    `CREATE INDEX IF NOT EXISTS idx_broadcast_jobs_status_created ON broadcast_jobs (status, created_at)`,
    "ALTER TABLE broadcast_jobs ADD COLUMN target_max_user_id INTEGER",
    `CREATE INDEX IF NOT EXISTS idx_broadcast_jobs_target_snapshot ON broadcast_jobs (target_max_user_id)`,
    `CREATE TABLE IF NOT EXISTS broadcast_deliveries (
      job_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      attempts INTEGER NOT NULL DEFAULT 0,
      claim_token TEXT,
      claimed_at TEXT,
      sent_at TEXT,
      last_error TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (job_id, user_id),
      FOREIGN KEY (job_id) REFERENCES broadcast_jobs(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(telegram_id) ON DELETE CASCADE
    )`,
    `CREATE INDEX IF NOT EXISTS idx_broadcast_deliveries_job_status ON broadcast_deliveries (job_id, status)`,
    `CREATE INDEX IF NOT EXISTS idx_userbots_user_status ON userbots (user_id, status)`,
    `CREATE INDEX IF NOT EXISTS idx_userbots_order_id ON userbots (order_id)`,
    `CREATE INDEX IF NOT EXISTS idx_subscriptions_user_status ON subscriptions (user_id, status, expires_at)`,
    `CREATE INDEX IF NOT EXISTS idx_orders_product_id ON orders (product_id)`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_pool_assigned_status_expiry ON userbot_pool (assigned_user_id, status, expires_at)`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_pool_telegram_userbot_id ON userbot_pool (telegram_userbot_id)`,
    `CREATE TABLE IF NOT EXISTS subscription_reminder_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      enabled INTEGER NOT NULL DEFAULT 1,
      thresholds_minutes TEXT NOT NULL DEFAULT '[10080,4320,1440]',
      template TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `INSERT OR IGNORE INTO subscription_reminder_settings (id) VALUES (1)`,
    `CREATE TABLE IF NOT EXISTS subscription_reminder_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_key TEXT NOT NULL UNIQUE,
      event_type TEXT NOT NULL DEFAULT 'automatic',
      userbot_id INTEGER NOT NULL,
      owner_user_id INTEGER NOT NULL,
      sub_version INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT NOT NULL,
      threshold_minutes INTEGER,
      status TEXT NOT NULL DEFAULT 'pending',
      claim_token TEXT,
      claimed_at TEXT,
      attempts INTEGER NOT NULL DEFAULT 0,
      sent_at TEXT,
      last_error TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (userbot_id) REFERENCES userbots(id) ON DELETE CASCADE
    )`,
    `CREATE INDEX IF NOT EXISTS idx_reminder_events_userbot ON subscription_reminder_events (userbot_id, sub_version, threshold_minutes)`,
    `CREATE INDEX IF NOT EXISTS idx_reminder_events_status ON subscription_reminder_events (status, claimed_at)`,
    `CREATE TABLE IF NOT EXISTS subscription_reminder_runs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      status TEXT NOT NULL,
      sent INTEGER NOT NULL DEFAULT 0,
      skipped INTEGER NOT NULL DEFAULT 0,
      failed INTEGER NOT NULL DEFAULT 0,
      attempted INTEGER NOT NULL DEFAULT 0,
      duration_ms INTEGER NOT NULL DEFAULT 0,
      error TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `CREATE TABLE IF NOT EXISTS auto_backup_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      enabled INTEGER NOT NULL DEFAULT 0,
      interval_hours INTEGER NOT NULL DEFAULT 24,
      retention_count INTEGER NOT NULL DEFAULT 7,
      send_to_admin INTEGER NOT NULL DEFAULT 0,
      last_run_at TEXT,
      last_status TEXT,
      last_error TEXT,
      last_file TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `INSERT OR IGNORE INTO auto_backup_settings (id) VALUES (1)`,
    `CREATE TABLE IF NOT EXISTS managed_cards (
      card_key TEXT PRIMARY KEY,
      chat_id TEXT NOT NULL,
      message_id INTEGER,
      last_hash TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `CREATE TABLE IF NOT EXISTS ubot_notify_settings (
      kind TEXT NOT NULL,
      asset_id INTEGER NOT NULL,
      channel_bot INTEGER NOT NULL DEFAULT 1,
      channel_saved INTEGER NOT NULL DEFAULT 0,
      channel_owner INTEGER NOT NULL DEFAULT 0,
      on_success INTEGER NOT NULL DEFAULT 0,
      on_fail INTEGER NOT NULL DEFAULT 1,
      on_flood INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (kind, asset_id)
    )`,
    `CREATE TABLE IF NOT EXISTS system_health_state (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      enabled INTEGER NOT NULL DEFAULT 1,
      heartbeat_hours INTEGER NOT NULL DEFAULT 6,
      signature TEXT,
      overall TEXT NOT NULL DEFAULT 'ok',
      incident_started_at TEXT,
      last_card_edit_at TEXT,
      last_checked_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `INSERT OR IGNORE INTO system_health_state (id) VALUES (1)`,
    `CREATE TABLE IF NOT EXISTS smart_delay_state (
      kind TEXT NOT NULL,
      asset_id INTEGER NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 0,
      current_seconds INTEGER NOT NULL DEFAULT 0,
      success_streak INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (kind, asset_id)
    )`,
    `CREATE TABLE IF NOT EXISTS userbot_runtime_jobs (
      job_key TEXT PRIMARY KEY,
      owner_kind TEXT NOT NULL CHECK (owner_kind IN ('owned', 'pool')),
      owner_id INTEGER NOT NULL,
      job_type TEXT NOT NULL CHECK (job_type IN ('auto_promosi')),
      status TEXT NOT NULL CHECK (status IN ('running', 'idle', 'cancelled', 'failed')),
      cursor INTEGER NOT NULL DEFAULT 0 CHECK (cursor >= 0),
      cursor_key TEXT,
      cycle_id TEXT,
      workset_hash TEXT,
      next_run_at TEXT,
      started_at TEXT,
      heartbeat_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      last_error TEXT
    )`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_runtime_jobs_status ON userbot_runtime_jobs (job_type, status, updated_at)`,
    `CREATE INDEX IF NOT EXISTS idx_userbot_runtime_jobs_owner ON userbot_runtime_jobs (owner_kind, owner_id, job_type)`,
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN total_targets INTEGER NOT NULL DEFAULT 0 CHECK (total_targets >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN processed_targets INTEGER NOT NULL DEFAULT 0 CHECK (processed_targets >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN successful_targets INTEGER NOT NULL DEFAULT 0 CHECK (successful_targets >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN failed_targets INTEGER NOT NULL DEFAULT 0 CHECK (failed_targets >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN blocked_targets INTEGER NOT NULL DEFAULT 0 CHECK (blocked_targets >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN removed_targets INTEGER NOT NULL DEFAULT 0 CHECK (removed_targets >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN sent_count INTEGER NOT NULL DEFAULT 0 CHECK (sent_count >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN failed_count INTEGER NOT NULL DEFAULT 0 CHECK (failed_count >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN cycle_number INTEGER NOT NULL DEFAULT 0 CHECK (cycle_number >= 0)",
    "ALTER TABLE userbot_runtime_jobs ADD COLUMN last_activity_at TEXT",
    `CREATE TABLE IF NOT EXISTS userbot_promotion_target_health (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_kind TEXT NOT NULL CHECK (owner_kind IN ('owned', 'pool')),
      owner_id INTEGER NOT NULL,
      target_key TEXT NOT NULL,
      target TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('healthy', 'transient', 'unusable')),
      last_checked_at TEXT,
      last_error TEXT,
      failure_count INTEGER NOT NULL DEFAULT 0 CHECK (failure_count >= 0),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(owner_kind, owner_id, target_key)
    )`,
    `CREATE INDEX IF NOT EXISTS idx_promotion_target_health_owner ON userbot_promotion_target_health (owner_kind, owner_id, status, updated_at)`,
    `CREATE TABLE IF NOT EXISTS base_reply_cooldowns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_kind TEXT NOT NULL CHECK (owner_kind IN ('owned', 'pool')),
      owner_id INTEGER NOT NULL,
      chat_id TEXT NOT NULL,
      rule_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('pending', 'sent')),
      claimed_at_ms INTEGER NOT NULL,
      last_sent_at_ms INTEGER,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(owner_kind, owner_id, chat_id, rule_id)
    )`,
    `CREATE INDEX IF NOT EXISTS idx_base_reply_cooldown_owner ON base_reply_cooldowns (owner_kind, owner_id, updated_at)`,
  ];

  const foreignKeysEnabled = Boolean(database.pragma('foreign_keys', { simple: true }));
  if (foreignKeysEnabled) database.pragma('foreign_keys = OFF');

  try {
    const migrate = database.transaction(() => {
      for (const sql of statements) executeMigrationStatement(database, sql);
      validateMigrationCreatedTables(database, statements);
      fixBrokenUserIdForeignKeys(database);
      backfillOrderExpirations(database);

      const violations = database.pragma('foreign_key_check');
      if (violations.length > 0) {
        const sample = violations.slice(0, 10)
          .map((v) => `${v.table}[rowid=${v.rowid}] -> ${v.parent}[fk=${v.fkid}]`)
          .join(', ');
        throw new Error(`Migrasi dibatalkan: PRAGMA foreign_key_check menemukan ${violations.length} violation. Contoh: ${sample}`);
      }
    });

    migrate();
  } finally {
    if (foreignKeysEnabled) database.pragma('foreign_keys = ON');
  }
}

function backfillOrderExpirations(database) {
  // Legacy rows predate the per-order expiry column. Their deterministic
  // expiry is derived from their persisted creation timestamp, never from
  // migration/startup time. Malformed creation timestamps fail the migration
  // before the database can enter a partially migrated state.
  database.prepare(
    "UPDATE orders SET expires_at = datetime(created_at, '+1 hour') WHERE expires_at IS NULL"
  ).run();
  const invalid = database.prepare(
    "SELECT COUNT(*) AS c FROM orders WHERE expires_at IS NULL OR datetime(expires_at) IS NULL"
  ).get();
  if (Number(invalid.c || 0) > 0) {
    throw new Error(`Migrasi order dibatalkan: ${invalid.c} row memiliki expires_at yang tidak dapat dihitung dari created_at.`);
  }
}

function validateMigrationCreatedTables(database, statements) {
  for (const sql of statements) {
    const match = /^CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+((?:"(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*))\s*\(/i.exec(sql.trim());
    if (!match) continue;
    const tableName = unquoteIdentifier(match[1]);
    if (!tableExists(database, tableName)) {
      throw migrationError(sql, new Error(`table ${tableName} tidak terbentuk`));
    }
    const expectedParts = parseCreateTableParts(sql);
    const actualSql = getTableCreateSql(database, tableName);
    if (!actualSql) throw migrationError(sql, new Error(`table ${tableName} ada tetapi sqlite_master tidak memiliki CREATE SQL.`));
    assertExistingTableMatchesMigration(database, tableName, expectedParts, actualSql, sql);
  }
}

function assertExistingTableMatchesMigration(database, tableName, expectedParts, actualSql, migrationSql) {
  const actualParts = parseCreateTableParts(actualSql);
  const actualColumnsByName = new Map(actualParts.columns.map((definition) => [getDefinitionName(definition), definition]));
  const expectedColumnsByName = new Map(expectedParts.columns.map((definition) => [getDefinitionName(definition), definition]));

  for (const [columnName, expectedDefinition] of expectedColumnsByName) {
    const actualDefinition = actualColumnsByName.get(columnName);
    if (!actualDefinition) {
      throw migrationError(migrationSql, new Error(`table ${tableName} ada tetapi kolom ${columnName} tidak ditemukan.`));
    }
    assertMigrationColumnContract(actualDefinition, expectedDefinition, tableName, columnName);
  }

  const expectedConstraints = expectedParts.constraints.map(normalizeConstraint).sort();
  const actualConstraints = actualParts.constraints.map(normalizeConstraint).sort();
  // schema.js is the canonical definition and may add constraints the
  // (older) migration copy doesn't carry, e.g. FOREIGN KEY ... ON DELETE
  // CASCADE. Only a MISSING expected constraint is a real mismatch.
  const missingConstraints = expectedConstraints.filter((c) => !actualConstraints.includes(c));
  if (missingConstraints.length > 0) {
    throw migrationError(migrationSql, new Error(`table ${tableName} memiliki table-level constraints yang berbeda dari migration. Expected=${JSON.stringify(expectedConstraints)} Actual=${JSON.stringify(actualConstraints)}`));
  }

  const expectedTail = normalizeTableTail(expectedParts.tail);
  const actualTail = normalizeTableTail(actualParts.tail);
  if (actualTail !== expectedTail) {
    throw migrationError(migrationSql, new Error(`table ${tableName} memiliki table option berbeda dari migration. Expected=${expectedTail || 'none'} Actual=${actualTail || 'none'}`));
  }

  const expectedFks = parseForeignKeyDefinitions(expectedParts.constraints).map(foreignKeyDefinitionToGroup);
  // Subset check (same rationale as table-level constraints above): schema.js
  // may declare FKs (e.g. ON DELETE CASCADE) that the migration copy omits.
  const actualFks = captureForeignKeyGroups(database, tableName).map(normalizeForeignKeyGroup).map((fk) => JSON.stringify(fk));
  const missingFks = expectedFks.map(transformForeignKeyGroup).map(normalizeForeignKeyGroup).map((fk) => JSON.stringify(fk)).filter((fk) => !actualFks.includes(fk));
  if (missingFks.length > 0) {
    throw new Error(`Migrasi FK "${tableName}" dibatalkan: FK semantics existing migration table tidak cocok. Missing=${missingFks.join(', ')}`);
  }
}

function assertMigrationColumnContract(actualDefinition, expectedDefinition, tableName, columnName) {
  const actual = columnDefinitionSignature(actualDefinition);
  const expected = columnDefinitionSignature(expectedDefinition);
  if (actual.type !== expected.type || actual.notNull !== expected.notNull || ![expected.defaultValue, ...(KNOWN_SCHEMA_DEFAULT_DIVERGENCE[`${tableName}.${columnName}`] || [])].map(normalizeSqlValue).includes(normalizeSqlValue(actual.defaultValue)) || actual.primaryKey !== expected.primaryKey || actual.unique !== expected.unique || actual.autoIncrement !== expected.autoIncrement || actual.generated !== expected.generated) {
    throw new Error(`Migration dibatalkan: ${tableName}.${columnName} sudah ada tetapi schema column contract berbeda dari migration.`);
  }
  if (actual.generated && normalizeConstraint(actualDefinition) !== normalizeConstraint(expectedDefinition)) {
    throw new Error(`Migration dibatalkan: ${tableName}.${columnName} memiliki generated expression berbeda dari migration.`);
  }
  if (actual.inlineReferences !== expected.inlineReferences && (actual.inlineReferences || expected.inlineReferences)) {
    throw new Error(`Migration dibatalkan: ${tableName}.${columnName} memiliki inline REFERENCES yang berbeda dari migration.`);
  }
}

function executeMigrationStatement(database, sql) {
  try {
    database.exec(sql);
  } catch (err) {
    const migration = parseAddColumnStatement(sql);
    if (!migration || !isDuplicateColumnError(err)) throw migrationError(sql, err);

    const info = database.pragma(`table_info(${quoteIdentifier(migration.table)})`)
      .find((column) => column.name === migration.column);
    if (!info) {
      throw migrationError(sql, new Error(`duplicate-column error dilaporkan tetapi kolom ${migration.table}.${migration.column} tidak ditemukan`));
    }

    assertExistingColumnMatchesMigration(info, migration.definition, migration.table, migration.column);
  }
}

function migrationError(sql, err) {
  const message = (err && err.message) || String(err);
  return new Error(`Migration gagal untuk SQL: ${sql}\nDatabase error: ${message}`, { cause: err });
}

function isDuplicateColumnError(err) {
  return /duplicate column(?: name)?/i.test((err && err.message) || '');
}

function parseAddColumnStatement(sql) {
  const match = /^ALTER\s+TABLE\s+((?:"(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*))\s+ADD\s+COLUMN\s+((?:"(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*))\s+([\s\S]+)$/i.exec(sql.trim());
  if (!match) return null;
  return {
    table: unquoteIdentifier(match[1]),
    column: unquoteIdentifier(match[2]),
    definition: match[3].trim(),
  };
}

function assertExistingColumnMatchesMigration(info, definition, tableName, columnName) {
  const expectedType = extractDeclaredType(definition);
  const actualType = String(info.type || '').replace(/\s+/g, ' ').trim().toUpperCase();
  const expectedNotNull = /\bNOT\s+NULL\b/i.test(definition);
  const expectedDefault = extractDefaultExpression(definition);
  const actualDefault = info.dflt_value == null ? null : String(info.dflt_value);

  if (expectedType && expectedType !== actualType) {
    throw new Error(`Migration dibatalkan: ${tableName}.${columnName} sudah ada tetapi type berbeda (expected ${expectedType}, actual ${actualType || 'EMPTY'}).`);
  }
  if (Boolean(info.notnull) !== expectedNotNull) {
    throw new Error(`Migration dibatalkan: ${tableName}.${columnName} sudah ada tetapi NOT NULL constraint berbeda.`);
  }
  const acceptedDefaults = [expectedDefault, ...(KNOWN_SCHEMA_DEFAULT_DIVERGENCE[`${tableName}.${columnName}`] || [])].map(normalizeSqlValue);
  if (!acceptedDefaults.includes(normalizeSqlValue(actualDefault))) {
    throw new Error(`Migration dibatalkan: ${tableName}.${columnName} sudah ada tetapi DEFAULT berbeda.`);
  }
}

// Declared type = the leading words BEFORE the first column constraint
// keyword. A fixed "up to two words" regex wrongly swallowed the constraint
// keyword ("INTEGER NOT NULL DEFAULT 0" -> "INTEGER NOT"), which made every
// already-migrated database fail with a false "type berbeda" error.
// Intentional, documented divergence between schema.js (fresh install) and
// the ALTER migration (upgrade of a pre-existing table):
//  - users.join_gate_verified: the ALTER uses DEFAULT 1 so users that existed
//    before the join gate are grandfathered as verified; schema.js uses
//    DEFAULT 0 and user.repository.js#create sets the value explicitly for
//    genuinely new users. Both defaults are valid for an existing column —
//    without this, EVERY fresh database crashed at startup on the second
//    pass (CREATE TABLE already created the column, then the ALTER hit
//    "duplicate column" and the DEFAULT comparison threw).
//  - panel_settings.group_delay_seconds: schema.js / RECOMMENDED_GROUP_DELAY_SECONDS
//    is 10 (the migration copy now matches). Databases created by earlier
//    builds carry DEFAULT 5 and stay valid — the default is only used for
//    brand-new rows and the app always writes explicit values.
const KNOWN_SCHEMA_DEFAULT_DIVERGENCE = {
  'users.join_gate_verified': ['0'],
  'panel_settings.group_delay_seconds': ['5'],
  'panel_settings.wtb_auto_reset_minutes': ['1440'],
  // userbot_pool.wtb_auto_reset_minutes: ALTER migration used DEFAULT 1440
  // (reasonable for pool); schema.js now matches but this entry guards against
  // databases created by any build that still had the old DEFAULT 3.
  'userbot_pool.wtb_auto_reset_minutes': ['3'],
};

function extractDeclaredType(definition) {
  const constraint = /^(?:CONSTRAINT|NOT|NULL|DEFAULT|PRIMARY|UNIQUE|REFERENCES|CHECK|COLLATE|GENERATED|AS)$/i;
  const words = [];
  for (const word of definition.trim().replace(/\(.*?\)/g, '').split(/\s+/)) {
    if (!word || constraint.test(word)) break;
    words.push(word);
  }
  return words.join(' ').toUpperCase();
}

function extractDefaultExpression(definition) {
  const match = /\bDEFAULT\s+(.+?)(?=\s+(?:NOT\s+NULL|UNIQUE|PRIMARY\s+KEY|REFERENCES|CHECK|COLLATE|GENERATED)\b|$)/is.exec(definition);
  return match ? match[1].trim() : null;
}

function normalizeSqlValue(value) {
  if (value == null) return null;
  let out = String(value).trim().replace(/\s+/g, ' ');
  while (out.startsWith('(') && out.endsWith(')') && findMatchingParen(out, 0) === out.length - 1) {
    out = out.slice(1, -1).trim();
  }
  return out.toUpperCase();
}

function fixBrokenUserIdForeignKeys(database) {
  const tableNames = ['orders', 'userbots'];
  const brokenTables = [];

  for (const name of tableNames) {
    if (!tableExists(database, name)) continue;
    const columns = getTableColumns(database, name);
    if (!columns.has('user_id')) {
      throw new Error(`Migrasi FK "${name}" dibatalkan: kolom user_id tidak ditemukan.`);
    }

    const fkList = database.pragma(`foreign_key_list(${name})`);
    const userFks = fkList.filter((fk) => fk.from === 'user_id' && fk.table === 'users');
    const correctUserFk = userFks.length === 1 && userFks[0].to === 'telegram_id';

    if (correctUserFk && fkList.filter((fk) => fk.from === 'user_id').length === 1) continue;

    let mapping = 'none';
    if (userFks.length > 0) {
      if (userFks.length !== 1) {
        throw new Error(`Migrasi FK "${name}" dibatalkan: user_id memiliki ${userFks.length} FK ke tabel users; schema legacy ambigu.`);
      }
      if (userFks[0].to === 'id') mapping = 'internal_id';
      else if (userFks[0].to === 'telegram_id') mapping = 'telegram_id';
      else throw new Error(`Migrasi FK "${name}" dibatalkan: user_id mereferensikan users.${userFks[0].to}, bukan users.id/users.telegram_id.`);
    } else {
      mapping = inferUnambiguousUserIdMapping(database, name);
      if (mapping === 'ambiguous') {
        throw new Error(`Migrasi FK "${name}" dibatalkan: nilai user_id tidak dapat dipetakan secara aman ke users.id atau users.telegram_id.`);
      }
    }

    brokenTables.push({ name, mapping });
  }

  for (const item of brokenTables) migrateLegacyTable(database, item.name, item.mapping);
}

function migrateLegacyTable(database, name, mapping) {
  const legacyCreateSql = getTableCreateSql(database, name);
  if (!legacyCreateSql) throw new Error(`Migrasi FK "${name}" dibatalkan: SQL CREATE TABLE legacy tidak ditemukan.`);

  const canonicalSql = extractCreateTableSql(SCHEMA, name);
  if (!canonicalSql) throw new Error(`Migrasi FK "${name}" dibatalkan: definisi tabel final tidak ditemukan di schema.js.`);

  validateUserIdMapping(database, name, mapping);

  const tempName = `__jaseb_migrate_${name}`;
  if (tableExists(database, tempName)) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: temporary table "${tempName}" sudah ada.`);
  }

  const originalCount = database.prepare(`SELECT COUNT(*) AS count FROM ${quoteIdentifier(name)}`).get().count;
  const originalIndexes = database.prepare(
    `SELECT name, sql FROM sqlite_master WHERE type = 'index' AND tbl_name = ? AND sql IS NOT NULL ORDER BY name`
  ).all(name);
  const originalTriggers = database.prepare(
    `SELECT name, sql FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ? ORDER BY name`
  ).all(name);
  const originalSequence = readSqliteSequence(database, name);
  const legacyParts = parseCreateTableParts(legacyCreateSql);
  const canonicalParts = parseCreateTableParts(canonicalSql);
  const legacyForeignKeys = captureForeignKeyGroups(database, name);
  const legacyForeignKeyDefinitions = parseForeignKeyDefinitions(legacyParts.constraints);
  for (const fk of legacyForeignKeys) {
    const match = legacyForeignKeyDefinitions.find((definition) => {
      const parsed = foreignKeyDefinitionToGroup(definition);
      return sameForeignKeyLogicalTarget(fk, parsed) && JSON.stringify(fk.toColumns) === JSON.stringify(parsed.toColumns);
    });
    if (match) fk.sql = match.sql;
  }
  const canonicalForeignKeys = parseForeignKeyDefinitions(canonicalParts.constraints).map((constraint) => foreignKeyDefinitionToGroup(constraint));
  const legacyColumns = getTableColumns(database, name);

  assertPrimaryKeyCompatible(database, name, canonicalSql, canonicalParts);
  assertCommonColumnDefinitionsCompatible(legacyParts, canonicalParts, name);

  const tempCreateSql = buildReplacementCreateSql({
    name,
    tempName,
    legacyParts,
    canonicalParts,
    legacyForeignKeys,
    canonicalForeignKeys,
    mapping,
  });

  database.exec(tempCreateSql);

  const finalColumns = getTableColumns(database, tempName);
  const legacyColumnNames = legacyParts.columns.map(getDefinitionName);
  const copyColumns = [...legacyColumns].filter((column) => finalColumns.has(column));
  if (legacyColumnNames.some((column) => !finalColumns.has(column))) {
    const missing = legacyColumnNames.filter((column) => !finalColumns.has(column));
    throw new Error(`Migrasi FK "${name}" dibatalkan: kolom legacy tidak dapat dipertahankan: ${missing.join(', ')}`);
  }

  const selectExpressions = copyColumns.map((column) => {
    if (column === 'user_id' && mapping === 'internal_id') {
      return `(SELECT u.telegram_id FROM users u WHERE u.id = legacy.${quoteIdentifier(column)}) AS ${quoteIdentifier(column)}`;
    }
    return `legacy.${quoteIdentifier(column)}`;
  });

  database.prepare(
    `INSERT INTO ${quoteIdentifier(tempName)} (${copyColumns.map(quoteIdentifier).join(', ')})\n` +
    `SELECT ${selectExpressions.join(', ')} FROM ${quoteIdentifier(name)} AS legacy`
  ).run();

  const copiedCount = database.prepare(`SELECT COUNT(*) AS count FROM ${quoteIdentifier(tempName)}`).get().count;
  if (copiedCount !== originalCount) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: row count berubah saat copy (${originalCount} -> ${copiedCount}).`);
  }

  const expectedFks = mergeExpectedForeignKeys(legacyForeignKeys, canonicalForeignKeys, mapping);
  assertForeignKeyMetadata(database, tempName, expectedFks, name, 'temporary');

  const tempPk = database.pragma(`table_info(${quoteIdentifier(tempName)})`).filter((column) => column.pk > 0)
    .sort((a, b) => a.pk - b.pk).map((column) => column.name);
  const legacyPk = database.pragma(`table_info(${quoteIdentifier(name)})`).filter((column) => column.pk > 0)
    .sort((a, b) => a.pk - b.pk).map((column) => column.name);
  if (JSON.stringify(tempPk) !== JSON.stringify(legacyPk) && legacyPk.length > 0) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: PRIMARY KEY legacy (${legacyPk.join(', ')}) berubah menjadi (${tempPk.join(', ')}).`);
  }

  database.exec(`DROP TABLE ${quoteIdentifier(name)}`);
  database.exec(`ALTER TABLE ${quoteIdentifier(tempName)} RENAME TO ${quoteIdentifier(name)}`);

  restoreSqliteSequence(database, name, originalSequence);

  for (const index of originalIndexes) {
    database.exec(index.sql);
  }
  for (const trigger of originalTriggers) {
    database.exec(trigger.sql);
  }

  const finalCount = database.prepare(`SELECT COUNT(*) AS count FROM ${quoteIdentifier(name)}`).get().count;
  if (finalCount !== originalCount) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: row count setelah swap berubah (${originalCount} -> ${finalCount}).`);
  }

  assertForeignKeyMetadata(database, name, expectedFks, name, 'final');
  assertRestoredObjects(database, name, originalIndexes, originalTriggers);
  assertLegacyConstraintsPresent(database, legacyParts, name);

  const expectedSequence = readSqliteSequence(database, name);
  const maxId = database.prepare(`SELECT MAX(id) AS max_id FROM ${quoteIdentifier(name)}`).get().max_id;
  if (hasAutoIncrement(database, name) && Number(maxId || 0) > 0 && Number(expectedSequence || 0) < Number(maxId)) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: sqlite_sequence (${expectedSequence ?? 'NULL'}) lebih kecil dari MAX(id) (${maxId}).`);
  }

  logger.info(`Migrasi: FK "${name}.user_id" diperbaiki ke users(telegram_id); ${originalCount} row dipertahankan dan schema final dipasang.`);
}

function buildReplacementCreateSql({ name, tempName, legacyParts, canonicalParts, legacyForeignKeys, canonicalForeignKeys, mapping }) {
  const legacyColumnsByName = new Map(legacyParts.columns.map((definition) => [getDefinitionName(definition), definition]));
  const canonicalColumnsByName = new Map(canonicalParts.columns.map((definition) => [getDefinitionName(definition), definition]));

  const finalColumns = canonicalParts.columns.map((canonicalDefinition) => {
    const columnName = getDefinitionName(canonicalDefinition);
    const legacyDefinition = legacyColumnsByName.get(columnName);
    if (!legacyDefinition) return canonicalDefinition;
    return mergeColumnDefinitions(legacyDefinition, canonicalDefinition, name, columnName);
  });

  for (const legacyDefinition of legacyParts.columns) {
    const columnName = getDefinitionName(legacyDefinition);
    if (!canonicalColumnsByName.has(columnName)) finalColumns.push(legacyDefinition);
  }

  const finalConstraints = [];
  const usedLegacyFkIds = new Set();
  const legacyFkConstraints = parseForeignKeyDefinitions(legacyParts.constraints);

  for (const canonicalConstraint of canonicalParts.constraints) {
    const canonicalFk = parseForeignKeyDefinition(canonicalConstraint);
    if (!canonicalFk) {
      if (/^\s*(?:CONSTRAINT\s+[^\s]+\s+)?PRIMARY\s+KEY\b/i.test(canonicalConstraint)) {
        finalConstraints.push(canonicalConstraint);
      } else {
        finalConstraints.push(canonicalConstraint);
      }
      continue;
    }

    const matches = legacyForeignKeys.filter((legacyFk) => sameForeignKeyLogicalTarget(legacyFk, canonicalFk));
    if (matches.length > 1) {
      throw new Error(`Migrasi FK "${name}" dibatalkan: lebih dari satu legacy FK memiliki local columns/table yang sama (${canonicalFk.fromColumns.join(', ')} -> ${canonicalFk.table}).`);
    }
    if (matches.length === 1) {
      const legacyFk = matches[0];
      const sourceConstraint = legacyFk.sql || renderForeignKeyConstraint(legacyFk);
      finalConstraints.push(transformLegacyForeignKeyConstraint(sourceConstraint, legacyFk, mapping));
      usedLegacyFkIds.add(legacyFk.id);
    } else {
      finalConstraints.push(canonicalConstraint);
    }
  }

  for (const legacyConstraint of legacyParts.constraints) {
    const legacyFk = parseForeignKeyDefinition(legacyConstraint);
    if (legacyFk) {
      const actual = legacyForeignKeys.find((fk) => sameForeignKeyDefinition(fk, legacyFk) || sameForeignKeyLogicalTarget(fk, legacyFk));
      if (actual && usedLegacyFkIds.has(actual.id)) continue;
      if (actual) finalConstraints.push(transformLegacyForeignKeyConstraint(legacyConstraint, actual, mapping));
      else finalConstraints.push(transformLegacyForeignKeyConstraint(legacyConstraint, foreignKeyDefinitionToGroup(legacyFk), mapping));
      continue;
    }

    if (/^\s*(?:CONSTRAINT\s+[^\s]+\s+)?PRIMARY\s+KEY\b/i.test(legacyConstraint)) {
      const canonicalPrimary = canonicalParts.constraints.some((candidate) => /^\s*(?:CONSTRAINT\s+[^\s]+\s+)?PRIMARY\s+KEY\b/i.test(candidate) && normalizeConstraint(candidate) === normalizeConstraint(legacyConstraint));
      if (!canonicalPrimary) throw new Error(`Migrasi FK "${name}" dibatalkan: PRIMARY KEY legacy berbeda dari schema final.`);
      continue;
    }

    if (!finalConstraints.some((candidate) => normalizeConstraint(candidate) === normalizeConstraint(legacyConstraint))) {
      finalConstraints.push(legacyConstraint);
    }
  }

  const allDefinitions = [...finalColumns, ...dedupeConstraints(finalConstraints)];
  const body = allDefinitions.map((definition) => `  ${definition.trim()}`).join(',\n');
  const canonicalTail = normalizeTableTail(canonicalParts.tail);
  const legacyTail = normalizeTableTail(legacyParts.tail);
  if (legacyTail && legacyTail !== canonicalTail) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: table option legacy (${legacyTail}) tidak kompatibel dengan schema final (${canonicalTail || 'none'}).`);
  }
  const tail = canonicalParts.tail ? ` ${canonicalParts.tail.trim()}` : '';
  return `CREATE TABLE ${quoteIdentifier(tempName)} (\n${body}\n)${tail}`;
}

function mergeColumnDefinitions(legacyDefinition, canonicalDefinition, tableName, columnName) {
  const legacySignature = columnDefinitionSignature(legacyDefinition);
  const canonicalSignature = columnDefinitionSignature(canonicalDefinition);
  if (legacySignature.type !== canonicalSignature.type || legacySignature.primaryKey !== canonicalSignature.primaryKey) {
    throw new Error(`Migrasi FK "${tableName}" dibatalkan: type/PRIMARY KEY kolom ${columnName} berbeda dengan schema final.`);
  }

  const legacyHasAuto = legacySignature.primaryKey && legacySignature.autoIncrement;
  const canonicalHasAuto = canonicalSignature.primaryKey && canonicalSignature.autoIncrement;
  if (legacyHasAuto !== canonicalHasAuto && !(canonicalHasAuto && !legacyHasAuto)) {
    throw new Error(`Migrasi FK "${tableName}" dibatalkan: AUTOINCREMENT kolom ${columnName} berbeda secara tidak kompatibel.`);
  }

  if (canonicalHasAuto && !legacyHasAuto) {
    if (legacySignature.defaultValue || legacySignature.unique || legacySignature.checks.length > 0 || legacySignature.inlineReferences || legacySignature.collate || legacySignature.constraintNames.length > 0) {
      throw new Error(`Migrasi FK "${tableName}" dibatalkan: PRIMARY KEY ${columnName} memiliki constraint legacy tambahan yang tidak aman untuk digabung dengan AUTOINCREMENT schema final.`);
    }
    return canonicalDefinition;
  }

  if (legacySignature.generated || canonicalSignature.generated) {
    if (!legacySignature.generated || !canonicalSignature.generated || normalizeConstraint(legacyDefinition) !== normalizeConstraint(canonicalDefinition)) {
      throw new Error(`Migrasi FK "${tableName}" dibatalkan: generated column ${columnName} berbeda antara legacy dan schema final.`);
    }
    return canonicalDefinition;
  }

  if (hasUnsupportedInlineConstraintDifference(legacyDefinition, canonicalDefinition)) {
    throw new Error(`Migrasi FK "${tableName}" dibatalkan: inline constraint kolom ${columnName} berbeda; migration berhenti agar constraint legacy tidak hilang.`);
  }

  // Start from the legacy definition so its existing DEFAULT/CHECK/UNIQUE/
  // COLLATE/REFERENCES semantics are not silently discarded. Add only
  // constraints that the current schema explicitly requires but the legacy
  // definition does not have. A legacy default remains authoritative when it
  // already exists, because changing an existing column's default can alter
  // future writes after migration.
  let merged = legacyDefinition.trim();
  if (canonicalSignature.notNull && !legacySignature.notNull) merged = appendColumnConstraint(merged, 'NOT NULL');
  if (canonicalSignature.unique && !legacySignature.unique) merged = appendColumnConstraint(merged, 'UNIQUE');
  if (canonicalSignature.collate && !legacySignature.collate) merged = appendColumnConstraint(merged, canonicalSignature.collate);
  if (canonicalSignature.checks.length > 0) {
    for (const check of canonicalSignature.checks) {
      if (!legacySignature.checks.some((legacyCheck) => normalizeConstraint(legacyCheck) === normalizeConstraint(check))) merged = appendColumnConstraint(merged, check);
    }
  }
  if (canonicalSignature.inlineReferences && !legacySignature.inlineReferences) {
    const referencesClause = extractReferencesClause(canonicalDefinition);
    if (!referencesClause) throw new Error(`Migrasi FK "${tableName}" dibatalkan: inline REFERENCES ${columnName} tidak dapat diparsing.`);
    merged = appendColumnConstraint(merged, referencesClause);
  }
  if (!legacySignature.defaultValue && canonicalSignature.defaultValue) merged = appendColumnConstraint(merged, `DEFAULT ${canonicalSignature.defaultValue}`);

  return merged;
}

function hasUnsupportedInlineConstraintDifference(legacyDefinition, canonicalDefinition) {
  const legacy = columnDefinitionSignature(legacyDefinition);
  const canonical = columnDefinitionSignature(canonicalDefinition);
  if (legacy.constraintNames.length !== canonical.constraintNames.length) return true;
  if (legacy.inlineReferences && canonical.inlineReferences) {
    const l = extractReferencesClause(legacyDefinition);
    const c = extractReferencesClause(canonicalDefinition);
    if (normalizeConstraint(l) !== normalizeConstraint(c)) return true;
  }
  if (legacy.collate && canonical.collate && normalizeConstraint(legacy.collate) !== normalizeConstraint(canonical.collate)) return true;
  return false;
}

function appendColumnConstraint(definition, constraint) {
  return `${definition.trim()} ${constraint.trim()}`;
}

function columnDefinitionSignature(definition) {
  const cleaned = String(definition).replace(/--[^\n]*/g, ' ').replace(/\/\*[\s\S]*?\*\//g, ' ').trim();
  const withoutName = cleaned.replace(/^("(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*)\s+/u, '');
  const typeMatch = /^(.+?)(?=\s+(?:CONSTRAINT|PRIMARY\s+KEY|NOT\s+NULL|UNIQUE|CHECK|DEFAULT|COLLATE|REFERENCES|GENERATED)\b|$)/is.exec(withoutName);
  const primaryKey = /\bPRIMARY\s+KEY\b/i.test(cleaned);
  const unique = /\bUNIQUE\b/i.test(cleaned);
  const checks = extractCheckClauses(cleaned);
  const collateMatch = /\bCOLLATE\s+([A-Za-z_][A-Za-z0-9_]*)/i.exec(cleaned);
  const constraintNames = [...cleaned.matchAll(/\bCONSTRAINT\s+([A-Za-z_][A-Za-z0-9_]*)/gi)].map((match) => match[1].toUpperCase());
  return {
    type: typeMatch ? typeMatch[1].replace(/\s+/g, ' ').trim().toUpperCase() : '',
    notNull: /\bNOT\s+NULL\b/i.test(cleaned),
    defaultValue: extractDefaultExpression(cleaned),
    primaryKey,
    unique,
    autoIncrement: /\bAUTOINCREMENT\b/i.test(cleaned),
    inlineReferences: /\bREFERENCES\b/i.test(cleaned),
    generated: /\bGENERATED\s+(?:ALWAYS\s+)?AS\b/i.test(cleaned),
    checks,
    collate: collateMatch ? `COLLATE ${collateMatch[1]}` : null,
    constraintNames,
  };
}

function assertCommonColumnDefinitionsCompatible(legacyParts, canonicalParts, tableName) {
  const canonicalByName = new Map(canonicalParts.columns.map((definition) => [getDefinitionName(definition), definition]));
  for (const legacyDefinition of legacyParts.columns) {
    const name = getDefinitionName(legacyDefinition);
    const canonicalDefinition = canonicalByName.get(name);
    if (!canonicalDefinition) continue;
    mergeColumnDefinitions(legacyDefinition, canonicalDefinition, tableName, name);
  }
}

function extractCheckClauses(definition) {
  const clauses = [];
  const source = String(definition);
  const keyword = /\bCHECK\s*\(/gi;
  let match;
  while ((match = keyword.exec(source))) {
    const open = source.indexOf('(', match.index);
    const close = findMatchingParen(source, open);
    if (close === -1) throw new Error(`Definisi column memiliki CHECK yang tidak valid: ${definition}`);
    clauses.push(source.slice(match.index, close + 1).trim());
    keyword.lastIndex = close + 1;
  }
  return clauses;
}

function extractReferencesClause(definition) {
  const match = /\bREFERENCES\b/i.exec(String(definition));
  return match ? String(definition).slice(match.index).trim() : null;
}

function assertPrimaryKeyCompatible(database, name, _canonicalSql, canonicalParts) {
  const legacyPk = database.pragma(`table_info(${quoteIdentifier(name)})`).filter((column) => column.pk > 0)
    .sort((a, b) => a.pk - b.pk).map((column) => column.name);
  const canonicalPk = canonicalParts.columns.filter((definition) => /\bPRIMARY\s+KEY\b/i.test(definition))
    .map(getDefinitionName);
  const canonicalTablePk = canonicalParts.constraints.filter((definition) => /^\s*(?:CONSTRAINT\s+[^\s]+\s+)?PRIMARY\s+KEY\b/i.test(definition))
    .map(parsePrimaryKeyColumns).flat();
  const expected = canonicalPk.length ? canonicalPk : canonicalTablePk;
  if (legacyPk.length && JSON.stringify(legacyPk) !== JSON.stringify(expected)) {
    throw new Error(`Migrasi FK "${name}" dibatalkan: PRIMARY KEY legacy (${legacyPk.join(', ')}) tidak cocok dengan schema final (${expected.join(', ')}).`);
  }
}

function parsePrimaryKeyColumns(definition) {
  const match = /PRIMARY\s+KEY\s*\(([^)]+)\)/i.exec(definition);
  return match ? match[1].split(',').map((value) => unquoteIdentifier(value.trim())) : [];
}

// SQLite stores the original CREATE TABLE text in sqlite_master INCLUDING
// comments (schema.js has `-- ...` comments inside column lists). Strip them
// (quote-aware) so definitions can be parsed structurally.
function stripSqlComments(sql) {
  let out = '';
  for (let i = 0; i < sql.length; i++) {
    const ch = sql[i];
    if (ch === "'" || ch === '"' || ch === '`') {
      let j = i + 1;
      while (j < sql.length) {
        if (sql[j] === ch) { if (sql[j + 1] === ch) { j += 2; continue; } break; }
        j++;
      }
      out += sql.slice(i, j + 1); i = j;
    } else if (ch === '-' && sql[i + 1] === '-') {
      while (i < sql.length && sql[i] !== '\n') i++;
      out += '\n';
    } else if (ch === '/' && sql[i + 1] === '*') {
      const end = sql.indexOf('*/', i + 2);
      i = end === -1 ? sql.length : end + 1;
      out += ' ';
    } else out += ch;
  }
  return out;
}

function parseCreateTableParts(rawCreateSql) {
  const createSql = stripSqlComments(rawCreateSql);
  const open = createSql.indexOf('(');
  if (open === -1) throw new Error('CREATE TABLE tidak valid: opening parenthesis tidak ditemukan.');
  const close = findMatchingParen(createSql, open);
  if (close === -1) throw new Error('CREATE TABLE tidak valid: closing parenthesis tidak ditemukan.');
  return {
    columns: splitTopLevelDefinitions(createSql.slice(open + 1, close)).map((d) => d.trim()).filter(Boolean).filter((d) => !isTableConstraintDefinition(d)),
    constraints: splitTopLevelDefinitions(createSql.slice(open + 1, close)).map((d) => d.trim()).filter(Boolean).filter(isTableConstraintDefinition),
    tail: createSql.slice(close + 1).trim(),
  };
}

function isTableConstraintDefinition(definition) {
  return /^(?:CONSTRAINT\s+[^\s]+\s+)?(?:PRIMARY\s+KEY|UNIQUE|CHECK|FOREIGN\s+KEY)\b/i.test(definition.trim());
}

function getDefinitionName(definition) {
  const match = /^("(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*)\s+/u.exec(definition.trim());
  if (!match) throw new Error(`Definisi column tidak dapat diparse: ${definition}`);
  return unquoteIdentifier(match[1]);
}

function parseForeignKeyDefinitions(constraints) {
  return constraints.map(parseForeignKeyDefinition).filter(Boolean);
}

function parseForeignKeyDefinition(definition) {
  const match = /^\s*(?:CONSTRAINT\s+([^\s]+)\s+)?FOREIGN\s+KEY\s*\(([^)]+)\)\s+REFERENCES\s+((?:"(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*))\s*\(([^)]+)\)([\s\S]*)$/i.exec(definition.trim());
  if (!match) return null;
  return {
    name: match[1] ? unquoteIdentifier(match[1]) : null,
    fromColumns: match[2].split(',').map((value) => unquoteIdentifier(value.trim())),
    table: unquoteIdentifier(match[3]),
    toColumns: match[4].split(',').map((value) => unquoteIdentifier(value.trim())),
    suffix: match[5] || '',
    sql: definition.trim(),
  };
}

function foreignKeyDefinitionToGroup(definition) {
  return {
    id: null,
    fromColumns: definition.fromColumns,
    table: definition.table,
    toColumns: definition.toColumns,
    onUpdate: extractForeignKeyOption(definition.suffix, 'UPDATE'),
    onDelete: extractForeignKeyOption(definition.suffix, 'DELETE'),
    match: extractForeignKeyMatch(definition.suffix),
    sql: definition.sql,
  };
}

function captureForeignKeyGroups(database, tableName) {
  const rows = database.pragma(`foreign_key_list(${quoteIdentifier(tableName)})`);
  const groups = new Map();
  for (const row of rows) {
    if (!groups.has(row.id)) groups.set(row.id, []);
    groups.get(row.id).push(row);
  }
  return [...groups.entries()].sort((a, b) => Number(a[0]) - Number(b[0])).map(([id, parts]) => {
    parts.sort((a, b) => Number(a.seq) - Number(b.seq));
    return {
      id: Number(id),
      fromColumns: parts.map((row) => row.from),
      table: parts[0].table,
      toColumns: parts.map((row) => row.to),
      onUpdate: parts[0].on_update,
      onDelete: parts[0].on_delete,
      match: parts[0].match,
    };
  });
}

function sameForeignKeyLogicalTarget(a, b) {
  return JSON.stringify(a.fromColumns) === JSON.stringify(b.fromColumns) && String(a.table).toLowerCase() === String(b.table).toLowerCase();
}

function sameForeignKeyDefinition(a, b) {
  return sameForeignKeyLogicalTarget(a, b) && JSON.stringify(a.toColumns) === JSON.stringify(b.toColumns);
}

function mergeExpectedForeignKeys(legacyFks, canonicalFks, mapping) {
  const expected = [];
  const usedLegacy = new Set();
  for (const canonical of canonicalFks) {
    const matches = legacyFks.filter((legacy) => sameForeignKeyLogicalTarget(legacy, canonical));
    if (matches.length > 1) throw new Error(`Migrasi FK dibatalkan: duplicate legacy FK relation ${canonical.fromColumns.join(',')} -> ${canonical.table}.`);
    if (matches.length === 1) {
      expected.push(transformForeignKeyGroup(matches[0], mapping));
      usedLegacy.add(matches[0].id);
    } else {
      expected.push(canonical);
    }
  }
  for (const legacy of legacyFks) {
    if (!usedLegacy.has(legacy.id)) expected.push(transformForeignKeyGroup(legacy, mapping));
  }
  return expected;
}

function transformForeignKeyGroup(fk, mapping) {
  const out = {
    ...fk,
    fromColumns: [...fk.fromColumns],
    toColumns: [...fk.toColumns],
  };
  if (mapping === 'internal_id' && out.table === 'users' && out.fromColumns.length === 1 && out.fromColumns[0] === 'user_id' && out.toColumns.length === 1 && out.toColumns[0] === 'id') {
    out.toColumns = ['telegram_id'];
  }
  return out;
}

function transformLegacyForeignKeyConstraint(sql, fk, mapping) {
  if (mapping === 'internal_id' && fk.table === 'users' && fk.fromColumns.length === 1 && fk.fromColumns[0] === 'user_id' && fk.toColumns.length === 1 && fk.toColumns[0] === 'id') {
    return sql.replace(/(REFERENCES\s+(?:"users"|`users`|\[users\]|users)\s*\(\s*)(?:"id"|`id`|\[id\]|id)(\s*\))/i, '$1telegram_id$2');
  }
  return sql;
}

function renderForeignKeyConstraint(fk) {
  const name = fk.name ? `CONSTRAINT ${quoteIdentifier(fk.name)} ` : '';
  const options = [
    fk.match && String(fk.match).toUpperCase() !== 'NONE' ? `MATCH ${fk.match}` : '',
    fk.onDelete && String(fk.onDelete).toUpperCase() !== 'NO ACTION' ? `ON DELETE ${fk.onDelete}` : '',
    fk.onUpdate && String(fk.onUpdate).toUpperCase() !== 'NO ACTION' ? `ON UPDATE ${fk.onUpdate}` : '',
  ].filter(Boolean).join(' ');
  return `${name}FOREIGN KEY (${fk.fromColumns.map(quoteIdentifier).join(', ')}) REFERENCES ${quoteIdentifier(fk.table)} (${fk.toColumns.map(quoteIdentifier).join(', ')})${options ? ` ${options}` : ''}`;
}

function extractForeignKeyOption(suffix, action) {
  const match = new RegExp(`ON\\s+${action}\\s+(NO\\s+ACTION|RESTRICT|CASCADE|SET\\s+NULL|SET\\s+DEFAULT)`, 'i').exec(suffix || '');
  return match ? match[1].toUpperCase().replace(/\\s+/g, ' ') : 'NO ACTION';
}

function extractForeignKeyMatch(suffix) {
  const match = /MATCH\s+([A-Za-z_][A-Za-z0-9_]*)/i.exec(suffix || '');
  return match ? match[1] : 'NONE';
}

function assertForeignKeyMetadata(database, tableName, expected, ownerName, phase) {
  const actual = captureForeignKeyGroups(database, tableName).map(normalizeForeignKeyGroup).sort(compareForeignKeys);
  const normalizedExpected = expected.map(transformForeignKeyGroup).map(normalizeForeignKeyGroup).sort(compareForeignKeys);
  if (JSON.stringify(actual) !== JSON.stringify(normalizedExpected)) {
    throw new Error(`Migrasi FK "${ownerName}" dibatalkan: FK semantics ${phase} tidak cocok. Expected=${JSON.stringify(normalizedExpected)} Actual=${JSON.stringify(actual)}`);
  }
}

function normalizeForeignKeyGroup(fk) {
  return {
    fromColumns: fk.fromColumns.map(String),
    table: String(fk.table),
    toColumns: fk.toColumns.map(String),
    onUpdate: String(fk.onUpdate || 'NO ACTION').toUpperCase(),
    onDelete: String(fk.onDelete || 'NO ACTION').toUpperCase(),
    match: String(fk.match || 'NONE').toUpperCase(),
  };
}

function compareForeignKeys(a, b) {
  return JSON.stringify(a).localeCompare(JSON.stringify(b));
}

function assertRestoredObjects(database, tableName, indexes, triggers) {
  for (const index of indexes) {
    const row = database.prepare("SELECT sql FROM sqlite_master WHERE type = 'index' AND name = ?").get(index.name);
    if (!row || normalizeSqlValue(row.sql) !== normalizeSqlValue(index.sql)) {
      throw new Error(`Migrasi FK "${tableName}" dibatalkan: index legacy ${index.name} tidak ter-rebuild identik.`);
    }
  }
  for (const trigger of triggers) {
    const row = database.prepare("SELECT sql FROM sqlite_master WHERE type = 'trigger' AND name = ?").get(trigger.name);
    if (!row || normalizeSqlValue(row.sql) !== normalizeSqlValue(trigger.sql)) {
      throw new Error(`Migrasi FK "${tableName}" dibatalkan: trigger legacy ${trigger.name} tidak ter-rebuild identik.`);
    }
  }
}

function assertLegacyConstraintsPresent(database, legacyParts, tableName) {
  const finalSql = getTableCreateSql(database, tableName) || '';
  const finalNorm = normalizeConstraint(finalSql);
  for (const constraint of legacyParts.constraints) {
    if (!/^\s*(?:CONSTRAINT\s+[^\s]+\s+)?(?:UNIQUE|CHECK|PRIMARY\s+KEY)\b/i.test(constraint)) continue;
    const bodyNorm = normalizeConstraint(constraint).replace(/^CREATE TABLE.*?\(/is, '').replace(/\)\s*;?$/s, '');
    if (!finalNorm.includes(bodyNorm)) {
      throw new Error(`Migrasi FK "${tableName}" dibatalkan: constraint legacy tidak ditemukan pada schema final.`);
    }
  }
}

function normalizeConstraint(value) {
  return String(value).replace(/--[^\n]*/g, ' ').replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/\s+/g, ' ').trim().toUpperCase();
}

function dedupeConstraints(constraints) {
  const seen = new Set();
  const out = [];
  for (const constraint of constraints) {
    const key = normalizeConstraint(constraint);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(constraint);
  }
  return out;
}

function normalizeTableTail(tail) {
  return String(tail || '').replace(/\s+/g, ' ').trim().toUpperCase();
}

function hasAutoIncrement(database, tableName) {
  const sql = getTableCreateSql(database, tableName) || '';
  return /\bAUTOINCREMENT\b/i.test(sql);
}

function validateUserIdMapping(database, tableName, mapping) {
  if (mapping === 'none' || mapping === 'telegram_id') return;

  const missing = database.prepare(
    `SELECT DISTINCT legacy.user_id AS user_id\n` +
    `FROM ${quoteIdentifier(tableName)} legacy\n` +
    `LEFT JOIN users u ON u.id = legacy.user_id\n` +
    `WHERE u.id IS NULL\n` +
    `ORDER BY legacy.user_id\n` +
    `LIMIT 20`
  ).all();

  if (missing.length > 0) {
    const ids = missing.map((row) => row.user_id).join(', ');
    throw new Error(`Migrasi FK "${tableName}" dibatalkan: ${missing.length >= 20 ? 'setidaknya ' : ''}legacy user_id orphan terhadap users.id: ${ids}`);
  }
}

function inferUnambiguousUserIdMapping(database, tableName) {
  const ids = database.prepare(`SELECT DISTINCT user_id FROM ${quoteIdentifier(tableName)} ORDER BY user_id`).all();
  if (ids.length === 0) return 'none';

  let matchesInternal = true;
  let matchesTelegram = true;
  for (const row of ids) {
    const value = row.user_id;
    const byId = database.prepare('SELECT 1 FROM users WHERE id = ?').get(value);
    const byTelegram = database.prepare('SELECT 1 FROM users WHERE telegram_id = ?').get(value);
    matchesInternal = matchesInternal && Boolean(byId);
    matchesTelegram = matchesTelegram && Boolean(byTelegram);
  }

  if (matchesInternal && !matchesTelegram) return 'internal_id';
  if (matchesTelegram && !matchesInternal) return 'telegram_id';
  if (matchesInternal && matchesTelegram) return 'ambiguous';
  return 'ambiguous';
}

function tableExists(database, tableName) {
  return Boolean(database.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?").get(tableName));
}

function getTableColumns(database, tableName) {
  return new Set(database.pragma(`table_info(${tableName})`).map((column) => column.name));
}

function getTableCreateSql(database, tableName) {
  const row = database.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?").get(tableName);
  return row && row.sql ? row.sql : null;
}

function readSqliteSequence(database, tableName) {
  const exists = database.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'sqlite_sequence'").get();
  if (!exists) return null;
  const row = database.prepare('SELECT seq FROM sqlite_sequence WHERE name = ?').get(tableName);
  return row ? Number(row.seq) : null;
}

function restoreSqliteSequence(database, tableName, previousSequence) {
  if (!hasAutoIncrement(database, tableName)) return;
  const maxIdRow = database.prepare(`SELECT MAX(id) AS max_id FROM ${quoteIdentifier(tableName)}`).get();
  const maxId = Number(maxIdRow.max_id) || 0;
  const previous = Number(previousSequence) || 0;
  const desired = Math.max(previous, maxId);
  if (desired <= 0) return;

  const exists = database.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'sqlite_sequence'").get();
  if (!exists) throw new Error(`Migrasi FK "${tableName}" dibatalkan: sqlite_sequence tidak tersedia untuk table AUTOINCREMENT.`);

  database.prepare("DELETE FROM sqlite_sequence WHERE name = ?").run(tableName);
  database.prepare('INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)').run(tableName, desired);
}

function extractLegacyColumnDefinitions(createSql) {
  const open = createSql.indexOf('(');
  if (open === -1) return [];
  const close = findMatchingParen(createSql, open);
  if (close === -1) return [];

  return splitTopLevelDefinitions(createSql.slice(open + 1, close))
    .map((definition) => definition.trim())
    .filter(Boolean)
    .filter((definition) => !/^(?:CONSTRAINT|PRIMARY\s+KEY|UNIQUE|CHECK|FOREIGN\s+KEY)\b/i.test(definition))
    .map((definition) => {
      const match = /^("(?:[^"]|"")*"|`(?:[^`]|``)*`|\[(?:[^\]])*\]|[A-Za-z_][A-Za-z0-9_]*)\s+/u.exec(definition);
      if (!match) return null;
      return { name: unquoteIdentifier(match[1]), definition };
    })
    .filter(Boolean);
}

function splitTopLevelDefinitions(body) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quote = null;
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    if (quote) {
      if (ch === quote) {
        if (body[i + 1] === quote && (quote === "'" || quote === '"' || quote === '`')) {
          i++;
        } else {
          quote = null;
        }
      } else if (quote === ']' && ch === ']') {
        quote = null;
      }
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === '[') { quote = ']'; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === ',' && depth === 0) {
      parts.push(body.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(body.slice(start));
  return parts;
}

function findMatchingParen(sql, openIndex) {
  let depth = 0;
  let quote = null;
  for (let i = openIndex; i < sql.length; i++) {
    const ch = sql[i];
    if (quote) {
      if (ch === quote) {
        if (sql[i + 1] === quote && (quote === "'" || quote === '"' || quote === '`')) i++;
        else quote = null;
      } else if (quote === ']' && ch === ']') quote = null;
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === '[') { quote = ']'; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function quoteIdentifier(value) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function unquoteIdentifier(value) {
  if (value.startsWith('[') && value.endsWith(']')) return value.slice(1, -1);
  if (value.startsWith('`') && value.endsWith('`')) return value.slice(1, -1).replace(/``/g, '`');
  if (value.startsWith('"') && value.endsWith('"')) return value.slice(1, -1).replace(/""/g, '"');
  return value;
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Extract one CREATE TABLE statement from the canonical SCHEMA string. It
 * balances parentheses and quoted literals so defaults such as
 * DEFAULT (datetime('now')) are handled correctly.
 */
function extractCreateTableSql(schemaSql, tableName) {
  const marker = `CREATE TABLE IF NOT EXISTS ${tableName} (`;
  const start = schemaSql.indexOf(marker);
  if (start === -1) return null;
  const open = start + marker.length - 1;
  const close = findMatchingParen(schemaSql, open);
  if (close === -1) return null;
  let end = close + 1;
  if (schemaSql[end] === ';') end++;
  return schemaSql.slice(start, end).trim();
}

function getDb() {
  if (!db) {
    throw new Error('Database has not been initialized. Call initDatabase() first.');
  }
  return db;
}

function checkHealth() {
  if (!db) throw new Error('Database has not been initialized. Call initDatabase() first.');
  const start = process.hrtime.bigint();
  db.prepare('SELECT 1').get();
  return Number(process.hrtime.bigint() - start) / 1e6;
}

module.exports = { initDatabase, getDb, checkHealth };
