/**
 * In-memory state for the Kontrol Panel reply-keyboard flow, keyed by
 * telegram_id. Tracks:
 *  - which userbot is currently "in control" (kind + id)
 *  - whether we're waiting for a text reply for one of the config
 *    wizards (Target/Teks/Mode/Jeda/Timer/Watermark/Topic Grup/Copy
 *    Settings/Transfer Ubot/Reset Ubot)
 *  - adminMode: true when the admin entered this asset's control
 *    panel via the Admin Panel (bypasses the normal ownership check)
 *  - returnTo: the verified screen/context that opened the current panel
 *    session (home, asset picker, or admin userbot picker).
 *
 * Same TTL pattern as state/adminState.js and state/buyerState.js.
 */

const TTL_MS = 30 * 60 * 1000; // 30 minutes — a control panel session can sit idle a while

const store = new Map();

function set(telegramId, data) {
  const previous = store.get(telegramId);
  store.set(telegramId, { ...previous, ...data, expiresAt: Date.now() + TTL_MS });
}

function get(telegramId) {
  const entry = store.get(telegramId);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(telegramId);
    return null;
  }
  return entry;
}

/**
 * Clears only the wizard step, keeps the selected asset (and the screen the
 * user is on). Also drops pendingReplyKeywords: it belongs to the 2-step
 * "Tambah Reply" wizard and must die with it, otherwise cancelling at step
 * 2/2 leaves the keyword behind for the next wizard.
 */
function clearStep(telegramId) {
  const entry = store.get(telegramId);
  if (!entry) return;
  set(telegramId, { ...entry, step: null, pendingReplyKeywords: null });
}

function clear(telegramId) {
  store.delete(telegramId);
}

module.exports = { set, get, clearStep, clear };
