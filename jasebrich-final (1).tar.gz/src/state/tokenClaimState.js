/**
 * In-memory state for the "🎫 Klaim Token" input flow (user is asked
 * to type their Token Login after opening the menu). Same TTL pattern
 * as state/buyerState.js and state/adminState.js — kept in its own
 * store so it never collides with the userbot phone/OTP flow.
 */

const TTL_MS = 10 * 60 * 1000; // 10 minutes

const store = new Map();

function set(telegramId, data) {
  store.set(telegramId, { ...data, expiresAt: Date.now() + TTL_MS });
}

function get(telegramId) {
  const entry = store.get(telegramId);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(telegramId);
    return null;
  }
  return entry;
}

function clear(telegramId) {
  store.delete(telegramId);
}

module.exports = { set, get, clear };
