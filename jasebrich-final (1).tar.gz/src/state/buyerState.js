/**
 * In-memory state for buyer-side text/contact input flows (phone
 * number + OTP code during "Beli Userbot" activation), keyed by
 * telegram_id. Same TTL pattern as state/adminState.js.
 */

const TTL_MS = 10 * 60 * 1000; // 10 minutes

const store = new Map();

function set(telegramId, data) {
  store.set(telegramId, { ...data, expiresAt: Date.now() + TTL_MS });
}

function get(telegramId) {
  const entry = store.get(telegramId);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(telegramId);
    return null;
  }
  return entry;
}

function clear(telegramId) {
  store.delete(telegramId);
}

module.exports = { set, get, clear };
