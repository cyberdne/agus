/**
 * In-memory state for the admin Custom Submenu wizard, keyed by
 * telegram_id so concurrent admins never collide (no shared globals).
 *
 * Shape stored per admin:
 *   {
 *     action: 'waiting_for_custom_text' | 'previewing',
 *     submenuId: string,
 *     pendingContent: { text: string, entities: object[] } | null,
 *     expiresAt: number (epoch ms)
 *   }
 */

const TTL_MS = 10 * 60 * 1000; // 10 minutes

const store = new Map();

function set(telegramId, data) {
  store.set(telegramId, { ...data, expiresAt: Date.now() + TTL_MS });
}

function get(telegramId) {
  const entry = store.get(telegramId);
  if (!entry) return null;

  if (Date.now() > entry.expiresAt) {
    store.delete(telegramId);
    return null;
  }

  return entry;
}

function clear(telegramId) {
  store.delete(telegramId);
}

module.exports = { set, get, clear };
