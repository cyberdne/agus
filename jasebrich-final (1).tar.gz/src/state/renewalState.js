/**
 * In-memory: which owned userbot a buyer chose to renew (keyed by
 * telegram_id). It only carries the choice between the "Perpanjang
 * Langganan" screens; the choice becomes PERSISTENT the moment the order is
 * created (orders.target_userbot_id), so a bot restart can never redirect a
 * payment to a different userbot. Same TTL pattern as the other state modules.
 */
const TTL_MS = 30 * 60 * 1000;
const store = new Map();

function set(telegramId, data) {
  store.set(telegramId, { ...data, expiresAt: Date.now() + TTL_MS });
}

function get(telegramId) {
  const entry = store.get(telegramId);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(telegramId);
    return null;
  }
  return entry;
}

function clear(telegramId) {
  store.delete(telegramId);
}

module.exports = { set, get, clear };
