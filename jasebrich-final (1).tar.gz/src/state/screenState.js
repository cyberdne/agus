/**
 * Tracks the message_id (and the "feature" it belongs to) of the last
 * "screen" (inline-keyboard) message the bot sent per chat, so
 * navigation can edit that message in place instead of sending a
 * brand new one every time (spam reduction) — but only while the
 * user stays inside the same feature. Moving to a different feature
 * always sends a fresh message instead of hijacking a screen that
 * belongs to whatever the user was doing before (see utils/render.js).
 *
 * Not used for messages that carry a custom reply keyboard — those
 * always need a fresh send (see utils/render.js).
 */

const store = new Map();

function get(chatId) {
  return store.get(chatId) || null;
}

/**
 * @param {number} chatId
 * @param {number} messageId
 * @param {string|null} [feature] identifies which feature/menu this screen
 *   belongs to (e.g. 'store', 'panel', 'adminproduct'). When omitted, the
 *   previously tracked feature (if any) is kept as-is.
 */
function set(chatId, messageId, feature) {
  if (chatId == null || messageId == null) return;
  const previous = store.get(chatId);
  store.set(chatId, {
    messageId,
    feature: feature !== undefined ? feature : previous ? previous.feature : null,
  });
}

function clear(chatId) {
  store.delete(chatId);
}

module.exports = { get, set, clear };
