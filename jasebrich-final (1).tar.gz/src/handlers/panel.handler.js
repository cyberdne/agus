const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Readable } = require('stream');
const { safeHandler } = require('../utils/errors');
const { Markup } = require('telegraf');
const { renderWithReplyKeyboard, renderScreen } = require('../utils/render');
const {
  panelMainKeyboard, baseReplyKeyboard, globalSettingsKeyboard, autoReactKeyboard, messageKeyboard, groupKeyboard, delayKeyboard, extraKeyboard,
  panelSelectAssetKeyboard, panelNoAssetKeyboard, assetButtonLabel, panelCancelKeyboard, panelInputKeyboard,
  groupDeleteListKeyboard, groupDeleteConfirmKeyboard, groupDeleteAllConfirmKeyboard, groupListPaginationKeyboard, groupLeavePaginationKeyboard, watermarkKeyboard, timerKeyboard, backupTokenKeyboard, backupTokenConfirmKeyboard,
} = require('../keyboards/panelControl.keyboard');
const { mainKeyboard } = require('../keyboards/main.keyboard');
const { MENU, PANEL_FEATURE, CALLBACK } = require('../constants/menu');
const featureAccessSvc = require('../services/featureAccess.service');
const { isAdminId } = require('../middlewares/admin.middleware');
const userbotService = require('../services/userbot.service');
const userbotRuntime = require('../services/userbotRuntime.service');
const userRepository = require('../database/repositories/user.repository');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const panelConfig = require('../services/panelConfig.service');
const poolRepo = require('../database/repositories/userbotPool.repository');
const poolPanelConfig = require('../services/poolPanelConfig.service');
const panelState = require('../state/panelState');
const { defineSubmenu, defineTemplate, buildReplyOptions, prependContent, getCustomContent } = require('../services/custom-submenu.service');
const smartDelay = require('../services/smartDelay.service');
const logger = require('../utils/logger');
const subscription = require('../services/subscription.service');
const userbotAccess = require('../services/userbotAccess.service');
const backupTokenSvc = require('../services/backupToken.service');
const { newTokenNoticeContent, describeCheckResult, backupStatusContent } = require('../utils/tokenNotice');
const subscriptionHandler = require('./subscription.handler');
const delayPolicy = require('../services/delayPolicy.service');
const { userResponseTpl } = require('../services/userResponseTemplate.service');
const screenState = require('../state/screenState');
const { answerCancelled } = require('../services/cancelNotice.service');
const { button, replyButton } = require('../utils/buttons');

const MAX_PANEL_MEDIA_BYTES = 20 * 1024 * 1024;

function normalizeUploadExtension(rawName, fallback = '.bin') {
  const ext = path.extname(String(rawName || '')).toLowerCase();
  return /^\.[a-z0-9]{1,8}$/.test(ext) ? ext : fallback;
}

function panelMediaDirectory() {
  const dir = path.resolve(process.cwd(), 'data', 'panel_media');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dir, 0o700); } catch (_) {}
  return dir;
}

async function downloadTelegramMedia(ctx, fileId, extension, prefix) {
  const link = await ctx.telegram.getFileLink(fileId);
  const href = String(link?.href || link || '');
  let parsed;
  try { parsed = new URL(href); } catch (_) { throw new Error('URL media Telegram tidak valid.'); }
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Protokol media Telegram tidak didukung.');

  const dir = panelMediaDirectory();
  const unique = `${prefix}-${process.pid}-${Date.now()}-${crypto.randomBytes(6).toString('hex')}`;
  const destination = path.join(dir, `${unique}${extension}`);
  const temp = path.join(dir, `.${unique}.part`);
  const controller = new AbortController();
  let bytes = 0;

  try {
    const res = await fetch(parsed.href, {
      signal: controller.signal,
      redirect: 'error',
    });
    if (!res.ok) throw new Error(`Gagal mengunduh media dari Telegram (HTTP ${res.status}).`);
    const declared = Number(res.headers.get('content-length'));
    if (Number.isFinite(declared) && declared > MAX_PANEL_MEDIA_BYTES) {
      throw new Error(`Ukuran media melebihi batas ${MAX_PANEL_MEDIA_BYTES / (1024 * 1024)} MB.`);
    }
    if (!res.body) throw new Error('Respons media Telegram tidak memiliki body.');

    const output = fs.createWriteStream(temp, { flags: 'wx', mode: 0o600 });
    try {
      for await (const chunk of Readable.fromWeb(res.body)) {
        bytes += chunk.length;
        if (bytes > MAX_PANEL_MEDIA_BYTES) {
          controller.abort();
          throw new Error(`Ukuran media melebihi batas ${MAX_PANEL_MEDIA_BYTES / (1024 * 1024)} MB.`);
        }
        if (!output.write(chunk)) await new Promise((resolve, reject) => {
          output.once('drain', resolve);
          output.once('error', reject);
        });
      }
      await new Promise((resolve, reject) => {
        output.once('close', resolve);
        output.once('error', reject);
        output.end();
      });
    } catch (err) {
      output.destroy();
      throw err;
    }
    fs.chmodSync(temp, 0o600);
    fs.renameSync(temp, destination);
    return destination;
  } catch (err) {
    try { if (fs.existsSync(temp)) fs.unlinkSync(temp); } catch (_) {}
    try { if (fs.existsSync(destination)) fs.unlinkSync(destination); } catch (_) {}
    throw err;
  }
}

const PANEL_NO_ASSET_TEXT =
  '🎛️ *Kontrol Panel*\n\n❌ Fitur ini hanya tersedia untuk user yang sudah memiliki *userbot aktif*.';

// Registers this screen under Admin Panel -> Settings -> Custom Submenu.
// The dashboard itself (showMainPanel/statusText below) is live status
// data and stays out of Custom Submenu on purpose — but this "you don't
// have an active userbot yet" message is static copy, same as every
// other top-level menu screen, and was previously hardcoded.
const noAssetSubmenu = defineSubmenu('control_panel_no_asset', '🎛️ Kontrol Panel (Belum Ada Userbot)', PANEL_NO_ASSET_TEXT, 'Markdown', { feature: 'Userbot', supportedPlaceholders: [] });
const panelMainSubmenu = defineSubmenu('control_panel_main', '🔥 Panel Kontrol Auto Promosi', '🔥 *Panel Kontrol Auto Promosi* 🔥\n\n⭐ Auto Promosi: {auto_promosi}\n💬 WTB Reply: {wtb_reply}\n🛡️ PM Permit: {pm_permit}\n🤖 Userbot: *{akun}* #{userbot_id}\n📦 Paket: *{userbot_status}*\n⏳ Kedaluwarsa: {expired_at}\n⏱️ Sisa masa aktif: *{expired}*\n\n📊 *Status Promosi*\n{status} · {progress}\n👥 Target: {processed_groups}/{total_groups} · Sisa: {remaining_groups}\n✅ Berhasil: {successful_groups} · ❌ Gagal: {failed_groups}\n🚫 Blokir: {blocked_groups} · 🗑️ Dihapus: {removed_groups}\n📨 Terkirim: {sent_count} · ⚠️ Gagal kirim: {failed_count}\n🔄 Putaran: {current_round}\n🕒 Mulai: {started_at}\n🕘 Aktivitas: {last_activity}\n⏳ Estimasi selesai: {estimated_completion}\n⏱️ Interval: {interval}\n🤖 Runtime: {runtime_status}', 'Markdown', { feature: 'Userbot', supportedPlaceholders: ['auto_promosi','wtb_reply','pm_permit','akun','userbot_id','userbot_status','expired_at','expired','jumlah_grup','jenis_pesan','jumlah_reply','jeda_grup','jeda_putaran','channel','telegram_userbot_id','userbot_produk','status','total_groups','processed_groups','successful_groups','failed_groups','blocked_groups','removed_groups','sent_count','failed_count','current_round','progress','remaining_groups','started_at','last_activity','estimated_completion','remaining_time','interval','runtime_status'] });
const panelPromotionStatusSubmenu = defineSubmenu('control_panel_promotion_status', '📊 Status Promosi', '📊 *Status Promosi*\n\n🚦 Status: {status}\n📍 Fase: {phase}\n🎯 Target aktif: {current_target}\n⏳ Menunggu: {wait_reason}\n⌛ Sisa tunggu: {wait_remaining}\n📈 Progress: {progress}\n👥 Target: {processed_groups}/{total_groups}\n🎯 Tersisa: {remaining_groups}\n\n✅ Berhasil: {successful_groups}\n❌ Gagal: {failed_groups}\n🚫 Terblokir: {blocked_groups}\n🗑️ Dihapus: {removed_groups}\n📨 Terkirim: {sent_count}\n⚠️ Gagal kirim: {failed_count}\n\n🔄 Putaran: {current_round}\n⏸️ Jeda putaran: {round_pause_remaining}\n🕒 Mulai: {started_at}\n🕘 Aktivitas terakhir: {last_activity}\n⏳ Estimasi selesai: {estimated_completion}\n⏱️ Interval: {interval}\n🤖 Runtime: {runtime_status}', 'Markdown', { feature: 'Auto Promosi', supportedPlaceholders: ['status','phase','current_target','wait_reason','wait_remaining','progress','total_groups','processed_groups','successful_groups','failed_groups','blocked_groups','removed_groups','sent_count','failed_count','current_round','remaining_groups','round_pause_remaining','started_at','last_activity','estimated_completion','remaining_time','interval','runtime_status','userbot_id','package_name','expires_at','remaining'] });
const panelBaseReplySubmenu = defineSubmenu('control_panel_base_reply', '💬 Base Reply', '💬 *Base Reply*\n\nStatus: {wtb_reply}\nAtur balasan WTB userbot kamu dari menu di bawah.', 'Markdown', { feature: 'Base Reply', supportedPlaceholders: ['wtb_reply','jumlah_reply','reply_list'] });
const panelMessageSubmenu = defineSubmenu('control_panel_message', '📝 Atur Pesan', '📝 *Pengaturan Pesan Promosi*\n\nPilih jenis pesan yang akan dikirim.', 'Markdown', { feature: 'Message Settings', supportedPlaceholders: ['jenis_pesan'] });
const panelGroupSubmenu = defineSubmenu('control_panel_group', '👥 Atur Grup', '👥 *Pengaturan Target Grup*\n\nKelola daftar grup/channel yang boleh menerima promosi.\n\nTarget saat ini: {jumlah_grup} grup.', 'Markdown', { feature: 'Group Settings', supportedPlaceholders: ['jumlah_grup','group_list'] });
const panelDelaySubmenu = defineSubmenu('control_panel_delay', '⏱️ Atur Jeda', '⏱️ *Pengaturan Jeda*\n\nJeda antar grup: {jeda_grup} detik *(acak setiap pindah grup)*\nJeda antar putaran: {jeda_putaran} detik *(tetap)*.', 'Markdown', { feature: 'Delay Settings', supportedPlaceholders: ['jeda_grup','jeda_putaran'] });
const panelExtraSubmenu = defineSubmenu('control_panel_extra', '🧰 Fitur Ekstra', '🧰 *Menu Fitur Tambahan*\n\nSemua aksi dijalankan pada sesi userbot yang sedang dipilih.\n\n⏱️ Sisa masa aktif: {expired}', 'Markdown', { feature: 'Feature Settings', supportedPlaceholders: ['expired'] });
const panelGuideSubmenu = defineSubmenu('control_panel_guide', '📖 Panduan Pakai', '📖 *Panduan Pakai*\n\n1. Tambah grup di 👥 Atur Grup.\n2. Atur pesan di 📝 Atur Pesan.\n3. Atur jeda.\n4. Tekan 🚀 Mulai Promosi.\n5. Untuk WTB Reply, tambah keyword dan balasan lalu aktifkan status reply.\n\nPastikan akun userbot memang sudah menjadi anggota grup target dan memiliki izin mengirim pesan.', 'Markdown', { feature: 'Feature Settings', supportedPlaceholders: [] });
const panelSelectAssetSubmenu = defineSubmenu('control_panel_select_asset', '🎛️ Pilih Userbot Kontrol Panel', '🎛️ *Kontrol Panel*\n\nPilih userbot yang ingin dikontrol.', 'Markdown', { feature: 'Userbot', supportedPlaceholders: [] });


// Context-specific user-facing response templates for the existing panel
// flow. These all use the SAME Custom Submenu registry/storage/renderer as
// the top-level screens above; there is no second template engine.
const panelTpl = {
  noSelection: defineTemplate('panel.no_selection', 'Userbot', 'Panel Belum Dipilih', 'Silakan buka 🎛️ Kontrol Panel terlebih dahulu.'),
  missingAsset: defineTemplate('panel.asset_missing', 'Userbot', 'Userbot Tidak Ditemukan', '❌ Userbot tidak ditemukan.'),
  featureLocked: defineTemplate('panel.feature_locked', 'Feature Access', 'Fitur Terkunci', '🔒 *Fitur Terkunci*\n\n{hasil}\n\nSilakan upgrade paket untuk mengakses fitur ini.', { supportedPlaceholders: ['hasil'] }),
  toggleBusy: defineTemplate('panel.promo_toggle_busy', 'Auto Promosi', 'Permintaan Masih Diproses', '⏳ Permintaan sebelumnya masih diproses, tunggu sebentar.'),
  noGroup: defineTemplate('panel.promo_no_group', 'Auto Promosi', 'Grup Belum Diatur', '❌ Tambahkan minimal satu grup di 👥 Atur Grup terlebih dahulu.'),
  noMessage: defineTemplate('panel.promo_no_message', 'Auto Promosi', 'Pesan Belum Diatur', '❌ Atur pesan promosi di 📝 Atur Pesan terlebih dahulu.'),
  startFailed: defineTemplate('panel.promo_start_failed', 'Auto Promosi', 'Gagal Memulai Promosi', '❌ Gagal memulai promosi: {reason}', { supportedPlaceholders: ['reason'] }),
  startRuntimeFailed: defineTemplate('panel.promo_start_runtime_failed', 'Auto Promosi', 'Runtime Tidak Aktif', '❌ Gagal memulai promosi: runtime tidak aktif setelah start. Periksa sesi userbot.', { supportedPlaceholders: [] }),
  stopRuntimeFailed: defineTemplate('panel.promo_stop_runtime_failed', 'Auto Promosi', 'Gagal Menghentikan Promosi', '❌ Gagal menghentikan promosi. Runtime masih berjalan, coba lagi.'),
  replyEmpty: defineTemplate('panel.base_reply_empty', 'Base Reply', 'Reply Kosong', 'Tidak ada reply yang tersimpan.'),
  replyDeletePrompt: defineTemplate('panel.base_reply_delete_prompt', 'Base Reply', 'Hapus Reply', '🗑️ Kirim ID reply yang ingin dihapus:\n\n{reply_list}', { supportedPlaceholders: ['reply_list'] }),
  messageEmpty: defineTemplate('panel.message_empty', 'Message Settings', 'Pesan Promosi Kosong', '📝 Belum ada pesan tersimpan.'),
  messageDeleted: defineTemplate('panel.message_deleted', 'Message Settings', 'Pesan Promosi Dihapus', '🗑️ Pesan promosi dihapus. Atur pesan baru sebelum menjalankan 🚀 Mulai Promosi.'),
  groupScanForumStart: defineTemplate('panel.group_forum_scan_start', 'Group Settings', 'Pemindaian Grup Topik', '🌐 Memindai grup topik (forum) dari chat userbot...'),
  groupScanFailed: defineTemplate('panel.group_scan_failed', 'Group Settings', 'Pemindaian Grup Gagal', '❌ Gagal memindai: {reason}', { supportedPlaceholders: ['reason'] }),
  groupForumEmpty: defineTemplate('panel.group_forum_empty', 'Group Settings', 'Grup Topik Tidak Ditemukan', '🌐 Tidak ditemukan grup bertipe topik (forum) di chat userbot ini.\n\nPastikan userbot sudah bergabung ke grup topik yang ingin dijadikan target.'),
  groupForumResult: defineTemplate('panel.group_forum_result', 'Group Settings', 'Hasil Pemindaian Grup Topik', '💡 *Hasil Pemindaian Grup Topik*\n\n{hasil}', { supportedPlaceholders: ['hasil'] }),
  groupScanStart: defineTemplate('panel.group_scan_start', 'Group Settings', 'Pemindaian Grup', '💡 Memindai grup dari chat userbot...'),
  groupValidateFailed: defineTemplate('panel.group_validate_failed', 'Group Settings', 'Validasi Grup Gagal', '❌ Gagal memvalidasi grup tersimpan: {reason}', { supportedPlaceholders: ['reason'] }),
  groupScanEmpty: defineTemplate('panel.group_scan_empty', 'Group Settings', 'Grup Tidak Ditemukan', '💡 Tidak ditemukan grup apapun di chat userbot ini.\n\nPastikan userbot sudah bergabung ke grup/supergrup yang ingin dijadikan target. Channel (bukan grup/discussion group) tidak dapat dijadikan target.'),
  groupScanResult: defineTemplate('panel.group_scan_result', 'Group Settings', 'Hasil Pemindaian Grup', '💡 *Tambah Grup selesai*\n\n{hasil}', { supportedPlaceholders: ['hasil'] }),
  groupEmpty: defineTemplate('panel.group_empty', 'Group Settings', 'Daftar Grup Kosong', 'Belum ada grup.'),
  groupDeletePrompt: defineTemplate('panel.group_delete_prompt', 'Group Settings', 'Hapus Grup', '❌ *Hapus Grup*\n\nPilih target yang ingin dihapus.'),
  groupLeaveScanStart: defineTemplate('panel.group_leave_scan_start', 'Group Settings', 'Scan Grup Tidak Usable', '👋 Memindai grup yang userbot tidak dapat gunakan untuk mengirim pesan...'),
  groupLeaveEmpty: defineTemplate('panel.group_leave_empty', 'Group Settings', 'Tidak Ada Grup Perlu Ditinggalkan', '👋 Tidak ditemukan grup yang terdeteksi tidak dapat menerima pesan userbot.'),
  groupLeaveList: defineTemplate('panel.group_leave_list', 'Group Settings', 'Keluar Grup', '👋 *Keluar Grup*\n\nDitemukan {jumlah} grup yang tidak dapat digunakan untuk operasi kirim.\nHalaman {halaman}\n\n{group_list}', { supportedPlaceholders: ['jumlah','halaman','group_list'] }),
  groupDeleteMissing: defineTemplate('panel.group_delete_missing', 'Group Settings', 'Target Grup Tidak Ditemukan', '❌ Grup tidak ditemukan (mungkin sudah dihapus).'),
  groupDeleteConfirm: defineTemplate('panel.group_delete_confirm', 'Group Settings', 'Konfirmasi Hapus Grup', '🗑️ Apakah yakin ingin menghapus target:\n*{hasil}*', { supportedPlaceholders: ['hasil'] }),
  groupDeleted: defineTemplate('panel.group_deleted', 'Group Settings', 'Grup Dihapus', '✅ Grup dihapus.'),
  groupDeleteAllConfirm: defineTemplate('panel.group_delete_all_confirm', 'Group Settings', 'Konfirmasi Hapus Semua Grup', '🗑️ Apakah yakin ingin menghapus SEMUA target grup ({jumlah} grup)?', { supportedPlaceholders: ['jumlah'] }),
  groupDeleteAllResult: defineTemplate('panel.group_delete_all_result', 'Group Settings', 'Semua Grup Dihapus', '🗑️ {jumlah} grup dihapus.', { supportedPlaceholders: ['jumlah'] }),
  groupList: defineTemplate('panel.group_list', 'Group Settings', 'Daftar Grup', '📋 *Daftar Grup* ({jumlah} target)\nHalaman {halaman}\n\n{group_list}', { supportedPlaceholders: ['jumlah','halaman','group_list','hasil'] }),
  groupListEmpty: defineTemplate('panel.group_list_empty', 'Group Settings', 'Daftar Grup Kosong', '📋 Daftar Grup kosong.\n\nGunakan 💡 Tambah Grup untuk memindai otomatis grup yang sudah diikuti userbot.'),
  pmPermitOff: defineTemplate('panel.pm_permit_off', 'PM Permit', 'PM Permit Nonaktif', '🛡️ PM Permit: ❌ OFF'),
  accountOwnership: defineTemplate('panel.ownership_error', 'Userbot', 'Akses Userbot Tidak Valid', '❌ Userbot tidak ditemukan atau bukan milik Anda.'),
  sessionInvalid: defineTemplate('panel.session_invalid', 'Userbot', 'Sesi Userbot Tidak Valid', '⚠️ *Sesi userbot tidak lagi valid.*\n\nSilakan lakukan *login ulang* dengan akun Telegram yang sama untuk melanjutkan sisa masa aktif userbot ini.'),
  sessionMissing: defineTemplate('panel.session_missing', 'Userbot', 'Sesi Userbot Tidak Ditemukan', '⚠️ Sesi Telegram userbot tidak ditemukan. Silakan lakukan login ulang untuk mengaktifkannya kembali.'),
  sessionCorrupt: defineTemplate('panel.session_corrupt', 'Userbot', 'Sesi Userbot Rusak', '⚠️ Data sesi Telegram userbot tidak dapat dibaca. Silakan lakukan login ulang dengan akun Telegram yang sama untuk memulihkan sesi tanpa mengubah sisa masa aktif.'),
  sessionTemporary: defineTemplate('panel.session_temporary_error', 'Userbot', 'Koneksi Telegram Bermasalah', '⚠️ Koneksi Telegram sedang bermasalah saat memeriksa userbot. Tidak ada status langganan atau sesi yang diubah. Silakan coba lagi beberapa saat lagi.'),
  sessionRuntimeUnavailable: defineTemplate('panel.session_runtime_unavailable', 'Userbot', 'Runtime Telegram Belum Siap', '⚠️ Sistem userbot belum dapat terhubung ke Telegram saat ini. Silakan coba lagi setelah konfigurasi/runtime tersedia.'),
  sessionIdentityMismatch: defineTemplate('panel.session_identity_mismatch', 'Userbot', 'Akun Telegram Tidak Sesuai', '❌ Sesi Telegram yang digunakan berbeda dari akun userbot yang terdaftar. Gunakan akun Telegram yang sama saat login ulang.'),
  replyFormatError: defineTemplate('panel.reply_format_error', 'Base Reply', 'Format Reply Salah', '❌ Format salah. Gunakan keyword1,keyword2 | teks balasan.'),
  replyAdded: defineTemplate('panel.reply_added', 'Base Reply', 'Reply Ditambahkan', '✅ Reply ditambahkan.'),
  replyKeywordEmpty: defineTemplate('panel.reply_keyword_empty', 'Base Reply', 'Keyword Kosong', '❌ Kata kunci tidak boleh kosong. Kirim ulang kata kunci pemicu.'),
  replyTextPrompt: defineTemplate('panel.reply_text_prompt', 'Base Reply', 'Instruksi Teks Reply', '➕ Tambah Reply (2/2)\n\nKata kunci: {pesan}\n\nSekarang kirim teks balasan untuk kata kunci di atas.', { supportedPlaceholders: ['pesan'] }),
  replySessionExpired: defineTemplate('panel.reply_session_expired', 'Base Reply', 'Sesi Reply Kedaluwarsa', '❌ Sesi Tambah Reply kedaluwarsa. Silakan mulai ulang dari ➕ Tambah Reply.'),
  replyTextEmpty: defineTemplate('panel.reply_text_empty', 'Base Reply', 'Teks Reply Kosong', '❌ Teks balasan tidak boleh kosong. Kirim ulang teks balasan.'),
  replyAddedDetail: defineTemplate('panel.reply_added_detail', 'Base Reply', 'Reply Ditambahkan Detail', '✅ Reply ditambahkan.\nKata kunci: {keyword}\nBalasan: {response}', { supportedPlaceholders: ['keyword','response'] }),
  replyDeleted: defineTemplate('panel.reply_deleted', 'Base Reply', 'Reply Dihapus', '✅ Reply dihapus jika ID cocok.'),
  wtbTimerSaved: defineTemplate('panel.wtb_timer_saved', 'Base Reply', 'Timer WTB Disimpan', '✅ Timer WTB disimpan.'),
  autoResetInvalid: defineTemplate('panel.auto_reset_invalid', 'Base Reply', 'Auto Reset Tidak Valid', 'Masukkan angka menit yang valid.'),
  autoResetSaved: defineTemplate('panel.auto_reset_saved', 'Base Reply', 'Auto Reset Disimpan', '✅ Auto Reset disimpan.'),
  reactInvalid: defineTemplate('panel.react_invalid', 'Base Reply', 'Emoji Reaksi Tidak Valid', 'Emoji reaksi tidak valid.'),
  reactSaved: defineTemplate('panel.react_saved', 'Base Reply', 'Emoji Reaksi Disimpan', '✅ Reaksi diubah menjadi {pesan}.', { supportedPlaceholders: ['pesan'] }),
  genericTextEmpty: defineTemplate('panel.text_empty', 'Message Settings', 'Teks Kosong', 'Teks tidak boleh kosong.'),
  textSaved: defineTemplate('panel.text_saved', 'Message Settings', 'Teks Disimpan', '✅ Teks default disimpan (format dan emoji premium dipertahankan).'),
  targetChannelSaved: defineTemplate('panel.target_channel_saved', 'Base Reply', 'Target Channel Disimpan', '✅ Target channel disimpan.'),
  bannedWordsSaved: defineTemplate('panel.banned_words_saved', 'Base Reply', 'Banned Words Disimpan', '✅ Banned words disimpan.'),
  maxCharsInvalid: defineTemplate('panel.max_chars_invalid', 'Base Reply', 'Batas Karakter Tidak Valid', 'Masukkan angka 0–4096.'),
  maxCharsSaved: defineTemplate('panel.max_chars_saved', 'Base Reply', 'Batas Karakter Disimpan', '✅ Batas karakter: {pesan}.', { supportedPlaceholders: ['pesan'] }),
  pmPermitTextEmpty: defineTemplate('panel.pm_permit_text_empty', 'PM Permit', 'Teks PM Permit Kosong', 'Teks PM Permit tidak boleh kosong.'),
  pmPermitRuntimeFailed: defineTemplate('panel.pm_permit_runtime_failed', 'PM Permit', 'PM Permit Gagal Aktif', '❌ Teks tersimpan, tapi PM Permit gagal diaktifkan di runtime: {reason}', { supportedPlaceholders: ['reason'] }),
  pmPermitActivated: defineTemplate('panel.pm_permit_activated', 'PM Permit', 'PM Permit Aktif', '✅ PM Permit aktif. Balasan otomatis disimpan dengan format dan emoji premium.'),
  messageSaved: defineTemplate('panel.message_saved', 'Message Settings', 'Pesan Disimpan', '✅ Pesan teks disimpan dengan format aslinya.'),
  joinSuccess: defineTemplate('panel.join_success', 'Group Settings', 'Berhasil Bergabung Grup', '✅ Userbot bergabung ke grup.'),
  leaveSuccess: defineTemplate('panel.leave_success', 'Group Settings', 'Berhasil Keluar Grup', '✅ Userbot keluar dari grup.'),
  delayInvalid: defineTemplate('panel.delay_invalid', 'Delay Settings', 'Durasi Tidak Valid', '❌ Durasi tidak valid. {pesan}', { supportedPlaceholders: ['pesan'] }),
  delaySaved: defineTemplate('panel.delay_saved', 'Delay Settings', 'Jeda Disimpan', '✅ {hasil}', { supportedPlaceholders: ['hasil'] }),
  broadcastEmpty: defineTemplate('panel.broadcast_empty', 'Broadcast PM', 'Pesan Broadcast Kosong', '❌ Pesan tidak boleh kosong.'),
  broadcastResult: defineTemplate('panel.broadcast_result', 'Broadcast PM', 'Broadcast Selesai', '📄 Broadcast PM selesai: {hasil}', { supportedPlaceholders: ['hasil'] }),
  timerInvalid: defineTemplate('panel.timer_invalid', 'Timer', 'Format Timer Salah', '❌ Format timer salah. Gunakan HH:MM-HH:MM, contoh 08:00-22:00, atau off.'),
  timerScreen: defineTemplate('panel.timer_screen', 'Timer', 'Timer', '⏰ *Timer*\n\nℹ️ Status: {status}\n🕒 Jam aktif (WIB): {jam}\n\n🌿 Promosi hanya berjalan di dalam jam aktif. Saat Timer nonaktif, promosi berjalan 24 jam tanpa mengubah jam yang sudah diatur.', { supportedPlaceholders: ['status','jam'] }),
  timerNoWindow: defineTemplate('panel.timer_no_window', 'Timer', 'Jam Belum Diatur', '❌ Atur jam aktif terlebih dahulu sebelum mengaktifkan Timer.'),
  timerSaved: defineTemplate('panel.timer_saved', 'Timer', 'Timer Disimpan', '✅ Timer WIB/Jakarta disimpan: {pesan}.', { supportedPlaceholders: ['pesan'] }),
  customWmInvalid: defineTemplate('panel.custom_wm_invalid', 'Custom WM', 'Custom WM Tidak Dapat Dipakai', '❌ Custom WM hanya dapat diaktifkan saat pesan promosi bertipe teks biasa. Ganti Pesan ke teks biasa terlebih dahulu.'),
  customWmSaved: defineTemplate('panel.custom_wm_saved', 'Custom WM', 'Custom WM Disimpan', '✅ Custom WM disimpan.'),
  watermarkNoText: defineTemplate('panel.watermark_no_text', 'Watermark', 'Watermark Belum Diatur', '❌ Atur teks watermark terlebih dahulu sebelum mengaktifkannya.'),
  watermarkScreen: defineTemplate('panel.watermark_screen', 'Watermark', 'Watermark', '💧 *Watermark*\n\nℹ️ Status: {status}\n🔖 Teks: {teks}\n\n🌿 Watermark ditambahkan di akhir pesan teks biasa. Pesan forward tidak diubah, dan format asli teks tetap utuh.', { supportedPlaceholders: ['status','teks'] }),
  tokenConfirmCancelled: defineTemplate('panel.backup_token_confirm_cancelled', 'Backup Token', 'Pembuatan Token Dibatalkan', '❌ Pembuatan token baru dibatalkan. Token yang berlaku tidak berubah.'),
  tokenExpired: defineTemplate('panel.backup_token_expired', 'Backup Token', 'Token Tidak Dapat Dibuat', '❌ Masa aktif userbot sudah berakhir, token baru tidak dapat dibuat.'),
  tokenCreateFailed: defineTemplate('panel.backup_token_create_failed', 'Backup Token', 'Token Tidak Dapat Dibuat', '❌ Token baru tidak dapat dibuat saat ini. Coba lagi.'),
  tokenCheckResult: defineTemplate('panel.backup_token_check_result', 'Backup Token', 'Hasil Cek Token', '{hasil}', { supportedPlaceholders: ['hasil'] }),
  transferTargetMissing: defineTemplate('panel.transfer_target_missing', 'Transfer Userbot', 'User Tujuan Tidak Ditemukan', '❌ User tujuan belum terdaftar. Gunakan @username yang tepat atau Telegram ID.'),
  transferSelf: defineTemplate('panel.transfer_self', 'Transfer Userbot', 'Transfer Tidak Diperlukan', '❌ Userbot sudah menjadi milik Anda.'),
  transferConflict: defineTemplate('panel.transfer_conflict', 'Transfer Userbot', 'Transfer Gagal', '❌ Kepemilikan userbot berubah saat diproses. Silakan coba lagi.'),
  transferFailed: defineTemplate('panel.transfer_failed', 'Transfer Userbot', 'Transfer Gagal', '❌ Userbot tidak dapat dipindahkan.'),
  transferSuccess: defineTemplate('panel.transfer_success', 'Transfer Userbot', 'Transfer Berhasil', '✅ Userbot #{jumlah} dipindahkan ke {hasil}. Pemilik lama tidak lagi memiliki akses kontrol, dan token backup lama Anda sudah tidak berlaku.', { supportedPlaceholders: ['jumlah','hasil'] }),
  transferReceived: defineTemplate('panel.transfer_received', 'Transfer Userbot', 'Userbot Diterima', '🎁 *Userbot Diterima*\n\nUserbot *{akun}* kini menjadi milik Anda dengan masa aktif yang sama. Buka 🎛️ Kontrol Panel untuk mengelolanya.', { supportedPlaceholders: ['akun'] }),
  resetCancelled: defineTemplate('panel.reset_cancelled', 'Reset Data', 'Reset Dibatalkan', '❌ Reset dibatalkan.'),
  resetCompleted: defineTemplate('panel.reset_completed', 'Reset Data', 'Reset Selesai', '🗑️ Semua pengaturan ekstra dan pengaturan panel userbot direset ke default.'),
  stepError: defineTemplate('panel.step_error', 'Panel', 'Operasi Panel Gagal', '❌ {reason}', { supportedPlaceholders: ['reason'] }),
  mediaSaved: defineTemplate('panel.media_saved', 'Message Settings', 'Media Disimpan', '✅ Media promosi disimpan dengan format/caption aslinya.'),
  promoStarted: defineTemplate('panel.promo_started', 'Auto Promosi', 'Promosi Diaktifkan', '🚀 Promosi otomatis diaktifkan.'),
  promoStopped: defineTemplate('panel.promo_stopped', 'Auto Promosi', 'Promosi Dihentikan', '⏹️ Promosi otomatis dihentikan.'),
  replyToggleFailed: defineTemplate('panel.base_reply_toggle_failed', 'Base Reply', 'Base Reply Gagal Diaktifkan', '❌ Gagal mengaktifkan Base Reply: {reason}', { supportedPlaceholders: ['reason'] }),
  replyStatus: defineTemplate('panel.base_reply_status', 'Base Reply', 'Status Base Reply', '💬 Status Reply: {status}', { supportedPlaceholders: ['status'] }),
  replyListScreen: defineTemplate('panel.base_reply_list', 'Base Reply', 'Daftar Reply & Settings', '📋 *Daftar Reply & Settings*\n\nStatus: {status}\nTimer WTB: {timer}\nAuto Reset: {auto_reset} menit\n\n{reply_list}', { supportedPlaceholders: ['status','timer','auto_reset','reply_list'] }),
  autoReactScreen: defineTemplate('panel.auto_react_screen', 'Base Reply', 'Auto React WTB', '❤️ *Auto React WTB*\n\nℹ️ Status: {status}\n💬 Reaksi: {reaction}\n\n🌿 Reaksi otomatis dikirim ke pesan WTB yang berhasil dikenali.', { supportedPlaceholders: ['status','reaction'] }),
  globalSettingsScreen: defineTemplate('panel.global_settings_screen', 'Base Reply', 'Global Settings', '⚙️ *Global Settings*\n\n📝 Pesan: {message_type}\n🎯 Target Channel: {target_channel}\n🚫 Banned Words: {banned_words}\n🔢 Maks Karakter: {max_chars}\n🔗 Filter Link: {filter_link}\n👤 Filter Username: {filter_username}', { supportedPlaceholders: ['message_type','target_channel','banned_words','max_chars','filter_link','filter_username'] }),
  globalMaxCharsStatus: defineTemplate('panel.global_max_chars_status', 'Base Reply', 'Status Maks Karakter', '🔢 Maks 70 Karakter: {status}', { supportedPlaceholders: ['status'] }),
  globalFilterLinkStatus: defineTemplate('panel.global_filter_link_status', 'Base Reply', 'Status Filter Link', '🔗 Filter Tanpa Link: {status}', { supportedPlaceholders: ['status'] }),
  globalFilterUsernameStatus: defineTemplate('panel.global_filter_username_status', 'Base Reply', 'Status Filter Username', '👤 Filter Tanpa Username: {status}', { supportedPlaceholders: ['status'] }),
  channelDisableStatus: defineTemplate('panel.channel_disable_status', 'Base Reply', 'Status Channel Disable', '🚫 Channel Disable: {status}', { supportedPlaceholders: ['status'] }),
};

function panelContent(template, ctx, extra = {}) {
  return template.getContent(ctx, extra);
}
async function replyPanelTemplate(ctx, template, extra = {}, options = {}) {
  const content = panelContent(template, ctx, extra);
  const keyboard = options.keyboard ? options.keyboard : undefined;
  await ctx.reply(content.text, { ...buildReplyOptions(content), ...(keyboard || {}) });
  return content;
}
async function replyPanelError(ctx, template, extra = {}) {
  const content = panelContent(template, ctx, extra);
  // Error replies during an input step keep the same keyboard the step
  // was opened with: multi-step wizards get Kembali+Batal, single-step
  // get Batal only. Outside a step (no state.step), fall back to Batal.
  const st = panelState.get(ctx.from.id);
  const kb = (st && st.step && MULTI_STEP_INPUTS && MULTI_STEP_INPUTS.has(st.step))
    ? panelInputKeyboard()
    : panelCancelKeyboard();
  await ctx.reply(content.text, { ...buildReplyOptions(content), ...kb });
  return content;
}

// Guards the "🚀 Mulai Promosi" / "⏹️ Stop Promosi" toggle against rapid
// double-taps racing each other for the SAME userbot (e.g. two clicks
// processed before the first syncAsset() resolves) — without this, both
// could concurrently pass the "not running yet" check and each call
// userbotRuntime.syncAsset(), risking a duplicate runtime/client build.
// This is a handler-level guard only; it doesn't add a second runtime/lock
// layer inside userbotRuntime itself, which already has none to reuse here.
const promoToggleInFlight = new Set();
const promotionStatusRefreshInFlight = new Map();
const promotionStatusRenderVersions = new Map();
// While Auto Promosi is running, the status screen itself is text-only. The
// persistent Reply Keyboard exposes only the Stop action.
// Inline (not reply) keyboard: Telegram refuses edits on messages sent with a reply keyboard (verified with /probeedit).
const promotionRunningKeyboard = (kind, id) => Markup.inlineKeyboard([
  [button.danger(PANEL_FEATURE.STOP, CALLBACK.PANEL_PROMOTION_STATUS_STOP(kind, id), { customizable: false })],
  [button.primary('📣 Notifikasi Pengiriman', CALLBACK.PANEL_NOTIFY(kind, id), { customizable: false })],
]);

function activeOwned(userId) { return subscription.listActiveNow(userId); }

/**
 * THE choke point for every Kontrol Panel control action (reply-keyboard
 * handlers, wizard text steps, media inputs, old inline callbacks). Nothing
 * here trusts UI state: every call re-checks ownership AND the subscription
 * (now >= expires_at) against the database through the centralized
 * userbotAccess service. An expired userbot never reaches the action code.
 */
function panelKind(ctx) {
  const st = panelState.get(ctx.from.id);
  return st && st.kind === 'pool' ? 'pool' : 'owned';
}
function assetRepoFor(ctx) { return panelKind(ctx) === 'pool' ? poolRepo : ownedRepo; }
function panelConfigFor(ctx) { return panelKind(ctx) === 'pool' ? poolPanelConfig : panelConfig; }

function selected(ctx) {
  const st=panelState.get(ctx.from.id);
  if(!st||!st.id||!['owned','pool'].includes(st.kind)){const c=panelContent(panelTpl.noSelection,ctx);ctx.reply(c.text,buildReplyOptions(c));return null;}
  const adminMode = Boolean(st.adminMode && isAdminId(ctx.from.id));
  const access = userbotAccess.checkUserbotControlAccess({ userbotId: st.id, actorId: ctx.from.id, adminMode, kind: st.kind });
  if(!access.ok){
    panelState.clear(ctx.from.id);
    subscriptionHandler.denyControl(ctx, access, { adminMode })
      .catch((err)=>logger.error(`denyControl gagal: ${err.message}`));
    return null;
  }
  return {state:st,asset:access.asset,kind:st.kind};
}

/**
 * Same guard for callers that hold a panel state but are not a `selected(ctx)`
 * consumer (e.g. the forward-message interceptor in panelText.middleware).
 * Resolves to the asset, or null after having shown the lock/renewal screen.
 */
async function guardPanelState(ctx, st) {
  if(!st||!st.id||!['owned','pool'].includes(st.kind)) return null;
  const adminMode = Boolean(st.adminMode && isAdminId(ctx.from.id));
  const access = userbotAccess.checkUserbotControlAccess({ userbotId: st.id, actorId: ctx.from.id, adminMode, kind: st.kind });
  if(!access.ok){
    panelState.clear(ctx.from.id);
    await subscriptionHandler.denyControl(ctx, access, { adminMode });
    return null;
  }
  return access.asset;
}
/**
 * Real backend authorization gate for product feature entitlement (as
 * opposed to userbotAccess.checkUserbotControlAccess above, which only
 * checks ownership + subscription validity). Wraps a handler at its
 * registration site in index.js (bot.hears/bot.action) — i.e. the actual
 * Telegraf dispatch entry point, so no direct command, old callback, or
 * reply-keyboard label match can ever reach the handler body without this
 * check running first. See services/featureAccess.service.js for how
 * entitlement is resolved (live, from the owning order's product).
 */
function requireFeature(featureId, handler) {
  return safeHandler(async (ctx) => {
    const sel = selected(ctx);
    if (!sel) return;
    const check = featureAccessSvc.checkAssetFeature(sel.asset, featureId, sel.kind);
    if (!check.allowed) {
      await sendFeatureUpgradeMessage(ctx, featureId);
      return;
    }
    return handler(ctx);
  });
}

/**
 * Maps every multi-step wizard `state.step` (panelState) to the Feature
 * Access id that gates the entry-point handler which started that wizard
 * (see the requirePanelFeature(...) wiring in index.js). The entry point
 * is already re-checked live on each screen open, but a wizard step is
 * reached via handleStepInput/handleMediaInput/handleBroadcastMediaInput
 * (routed from panelText.middleware / index.js's plain message listener),
 * NOT through requirePanelFeature — so without this map, entitlement
 * revoked *after* entry but *during* the wizard (e.g. admin unchecks the
 * product's checklist while the buyer is mid "Tambah Reply") would never
 * be re-checked before the step's mutation runs. Steps with no feature
 * gate at their entry point (e.g. reset/confirm-only steps that aren't
 * behind a requirePanelFeature-wrapped entry) are intentionally left out.
 */
const STEP_FEATURE = {
  await_add_reply: 'base_reply',
  await_add_reply_keyword: 'base_reply',
  await_add_reply_text: 'base_reply',
  await_delete_reply: 'base_reply',
  await_wtb_timer: 'base_reply',
  await_auto_reset: 'base_reply',
  await_react_emoji: 'base_reply',
  await_global_text: 'base_reply',
  await_target_channel: 'base_reply',
  await_banned_words: 'base_reply',
  await_max_chars: 'base_reply',
  await_pm_permit_text: 'pm_permit',
  await_message_media: 'message_settings',
  await_message_forward: 'message_settings',
  await_join_group: 'group_settings',
  await_leave_group: 'group_settings',
  await_group_delay: 'delay_settings',
  await_round_delay: 'delay_settings',
  await_broadcast_pm: 'broadcast_pm',
  await_timer: 'timer',
  await_custom_wm: 'custom_wm',
  await_transfer: 'transfer_ubot',
  await_reset_data: 'reset_data',
};

/**
 * Re-check Feature Access for the wizard step the user is currently in,
 * right before its mutation runs. Returns true (and clears the stale
 * wizard step) when the step is blocked, so callers can bail out exactly
 * like they do when `selected(ctx)` fails. Steps not present in
 * STEP_FEATURE are unrestricted, same as their (ungated) entry points.
 */
async function enforceStepFeature(ctx, asset, step) {
  const featureId = STEP_FEATURE[step];
  if (!featureId) return false;
  const check = featureAccessSvc.checkAssetFeature(asset, featureId, panelKind(ctx));
  if (check.allowed) return false;
  panelState.clearStep(ctx.from.id);
  await sendFeatureUpgradeMessage(ctx, featureId);
  return true;
}

async function sendFeatureUpgradeMessage(ctx, featureId) {
  const label = featureAccessSvc.FEATURE_LABEL[featureId] || featureId;
  if (ctx.callbackQuery) {
    const alert = panelContent(panelTpl.featureLockedAlert, ctx);
    await ctx.answerCbQuery(alert.text).catch(() => {});
  }
  const content = panelContent(panelTpl.featureLocked, ctx, { placeholderValues: { hasil: label } });
  await ctx.reply(
    content.text,
    { ...buildReplyOptions(content), ...Markup.inlineKeyboard([[button.success('🛒 Upgrade Paket', CALLBACK.STORE_HOME)]]) }
  );
}


function panelPlaceholderContext(asset) {
  const kind = asset && asset.__kind ? asset.__kind : (asset && Object.prototype.hasOwnProperty.call(asset, 'assigned_order_id') ? 'pool' : 'owned');
  const cfg = kind === 'pool' ? poolPanelConfig : panelConfig;
  const settings = cfg.getSettings(asset.id);
  const replies = cfg.listReplies(asset.id);
  const groups = cfg.listGroups(asset.id);
  const msg = cfg.getMessage(asset.id);
  const promotion = userbotRuntime.getPromotionStatus(kind, asset.id);
  const formatStatusTime = (value) => value ? new Date(value).toLocaleString('id-ID',{timeZone:'Asia/Jakarta',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})+' WIB' : '-';
  const formatEta = (seconds) => seconds == null ? 'Memperkirakan…' : seconds <= 0 ? 'Selesai' : `${Math.floor(seconds/3600)}j ${Math.floor((seconds%3600)/60)}m ${seconds%60}d`;
  const formatRoundPause = (seconds) => seconds == null ? '-' : seconds <= 0 ? '00:00' : `${String(Math.floor(seconds/3600)).padStart(2,'0')}:${String(Math.floor((seconds%3600)/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
  return { userbot: asset, panelStats: {
    autoPromosi: asset.auto_promosi ? '🟢 Aktif' : '❌ Nonaktif',
    wtbReply: asset.wtb_reply ? '🟢 Reply aktif' : '❌ Reply nonaktif',
    pmPermit: asset.pm_permit ? '🟢 Aktif' : '❌ Nonaktif',
    groupCount: groups.length, replyCount: replies.length,
    messageType: msg ? (msg.kind === 'media' ? 'Media' : msg.kind === 'forward' ? 'Forward' : 'Teks') : 'Belum diatur',
    groupDelay: delayPolicy.formatGroupDelayRange(delayPolicy.readGroupDelayRange(settings, cfg.RECOMMENDED_GROUP_DELAY_SECONDS)),
    roundDelay: Number(settings.round_delay_seconds || 0),
    channelStatus: settings.channel_disabled ? 'Nonaktif' : 'Diizinkan',
    promotionStatus: promotion.status, status: promotion.status, totalGroups: promotion.totalGroups, processedGroups: promotion.processedGroups,
    successfulGroups: promotion.successfulGroups, failedGroups: promotion.failedGroups, blockedGroups: promotion.blockedGroups, removedGroups: promotion.removedGroups,
    sentCount: promotion.sentCount, failedCount: promotion.failedCount, currentRound: promotion.cycle, progress: `${promotion.progress}%`, remainingGroups: promotion.remainingGroups,
    startedAt: formatStatusTime(promotion.startedAt), lastActivity: formatStatusTime(promotion.lastActivity), estimatedCompletion: formatEta(promotion.etaSeconds),
    interval: promotion.interval || '-', roundPauseRemaining: formatRoundPause(promotion.roundPauseRemainingSeconds), phase: promotion.phase || '-', currentTarget: promotion.currentTarget || '-', waitReason: promotion.waitReason || '-', waitRemaining: promotion.waitRemainingSeconds == null ? '-' : formatRoundPause(promotion.waitRemainingSeconds), runtimeStatus: promotion.runtimeStatus, userbotId: promotion.userbotId, packageName: promotion.packageName,
    expiresAt: promotion.expiresAt || '-', remaining: promotion.remaining == null ? '-' : String(promotion.remaining),
  } };
}
function statusText(asset) {
  const ctxLike = { from: { id: asset.user_id }, chat: { id: asset.user_id } };
  return panelMainSubmenu.getContent(ctxLike, panelPlaceholderContext(asset)).text;
}
async function showMainPanel(ctx, note='') {
  const sel=selected(ctx); if(!sel)return;
  ctx.__panelScreenRendered = true;
  // Re-entering the control of a userbot whose promotion is running -> show its live status.
  if(userbotRuntime.isAutoPromosiActive(panelKind(ctx), sel.asset.id)){ await openPromotionStatus(ctx, panelKind(ctx), sel.asset, true); return; }
  const content = panelMainSubmenu.getContent(ctx, panelPlaceholderContext(sel.asset));
  const sessionNote = sel.asset.runtime_stop_reason === 'SESSION_INVALID'
    ? panelContent(panelTpl.sessionInvalid, ctx).text
    : '';
  const combinedNote = [note, sessionNote].filter(Boolean).join('\n\n');
  const finalContent = combinedNote
    ? prependContent(`${combinedNote}\n\n`, content)
    : content;
  const active = userbotRuntime.isAutoPromosiActive(panelKind(ctx), sel.asset.id);
  await renderWithReplyKeyboard(ctx, finalContent.text, { ...buildReplyOptions(finalContent), ...panelMainKeyboard(active) }, null, 'control_panel_main_live');
}

async function showAssetPicker(ctx) {
  const assets = userbotService.getUserAssets(ctx.from.id);
  const now = Date.now();
  const activeOwned = assets.owned.filter((a) => subscription.isActiveNow(a, now));
  const activePool = assets.leased.filter((a) => a.status === 'assigned' && a.expires_at && new Date(a.expires_at).getTime() > now);
  if (!activeOwned.length && !activePool.length) {
    panelState.clear(ctx.from.id);
    const content = noAssetSubmenu.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...panelNoAssetKeyboard() });
    return;
  }
  panelState.set(ctx.from.id, { kind: 'owned', id: null, step: 'selecting', screen: 'select', adminMode: false, returnTo: 'home' });
  const content = panelSelectAssetSubmenu.getContent(ctx);
  await renderWithReplyKeyboard(ctx, content.text, { ...buildReplyOptions(content), ...panelSelectAssetKeyboard({ owned: activeOwned, leased: activePool }) });
}
// Puts the panel into "waiting for text input" mode: stores the wizard
// step and swaps the visible reply keyboard down to a single Cancel
// button (panelCancelKeyboard), so the user can bail out with one tap
// instead of having to type "Kembali"/"Batal" by hand. The cancel
// button's emoji is customizable from Admin Panel -> Settings ->
// Custom Icon Tombol, same as every other button in the bot.
const panelInputTemplates = {
  await_add_reply_keyword: defineTemplate('panel.input.add_reply_keyword', 'Base Reply', 'Input Keyword Reply', '➕ Tambah Reply (1/2)\n\nKirim kata kunci pemicu. Bisa lebih dari satu, pisahkan dengan koma.\nContoh: harga, minat, wtb'),
  await_delete_reply: defineTemplate('panel.input.delete_reply', 'Base Reply', 'Input ID Reply', '🗑️ Kirim ID reply yang ingin dihapus:\n\n{reply_list}', { supportedPlaceholders: ['reply_list'] }),
  await_wtb_timer: defineTemplate('panel.input.wtb_timer', 'Base Reply', 'Input Timer WTB', '⏰ Kirim timer WTB dengan format 08:00-22:00, atau "off".'),
  await_react_emoji: defineTemplate('panel.input.react_emoji', 'Base Reply', 'Input Emoji Reaksi', '❤️ Kirim emoji reaksi yang ingin digunakan. Contoh: ❤️, 👍, 🔥'),
  await_auto_reset: defineTemplate('panel.input.auto_reset', 'Base Reply', 'Input Auto Reset', '🔄 Kirim cooldown Base Reply dalam menit. Default: 3 menit. Contoh: 3.'),
  await_global_text: defineTemplate('panel.input.global_text', 'Message Settings', 'Input Pesan Default', '✏️ Kirim teks pesan default. Untuk media, gunakan 📝 Atur Pesan → Pesan Teks/Media.'),
  await_target_channel: defineTemplate('panel.input.target_channel', 'Base Reply', 'Input Target Channel', '🎯 Kirim username/ID channel target, atau "off" untuk semua grup.'),
  await_banned_words: defineTemplate('panel.input.banned_words', 'Base Reply', 'Input Banned Words', '🚫 Kirim banned words dipisahkan koma, atau "off" untuk menghapus.'),
  await_message_media: defineTemplate('panel.input.message_media', 'Message Settings', 'Input Pesan Promosi', '📄 Kirim teks pesan promosi (format Telegram apa pun — bold/italic/spoiler/blockquote/emoji premium — akan dipertahankan persis, dikirim dengan metode copy), atau kirim foto/video/dokumen dengan caption.\n\nMengirim pesan baru akan menggantikan pesan lama.'),
  await_message_forward: defineTemplate('panel.input.message_forward', 'Message Settings', 'Input Forward', '↪️ Forward satu pesan dari channel/grup ke chat ini.\n\nJika userbot belum bergabung ke chat asal, ia akan otomatis bergabung (khusus channel/grup publik) agar pesan ini bisa dikirim ke semua target.'),
  await_join_group: defineTemplate('panel.input.join_group', 'Group Settings', 'Input Join Group', '🔗 Kirim username/link/ID grup yang ingin dimasuki userbot.'),
  await_leave_group: defineTemplate('panel.input.leave_group', 'Group Settings', 'Input Leave Group', '👋 Kirim username/link/ID grup yang ingin ditinggalkan userbot.'),
  await_group_delay: defineTemplate('panel.input.group_delay', 'Delay Settings', 'Input Jeda Antar Grup', '{pesan}', { supportedPlaceholders: ['pesan'] }),
  await_round_delay: defineTemplate('panel.input.round_delay', 'Delay Settings', 'Input Jeda Antar Putaran', '{pesan}', { supportedPlaceholders: ['pesan'] }),
  await_broadcast_pm: defineTemplate('panel.input.broadcast_pm', 'Broadcast PM', 'Input Broadcast PM', '📄 Kirim SATU pesan yang akan dibroadcast ke semua chat private userbot.\n\nBisa: teks biasa (format + emoji premium dipertahankan), media, atau forward. Tidak perlu memasukkan target.'),
  await_pm_permit_text: defineTemplate('panel.input.pm_permit_text', 'PM Permit', 'Input Pesan PM Permit', '🛡️ Kirim teks balasan otomatis PM Permit. Format teks dan emoji premium akan dipertahankan.'),
  await_timer: defineTemplate('panel.input.timer', 'Timer', 'Input Timer', '⏰ Atur jam aktif Jaseb dalam WIB/Jakarta. Format HH:MM-HH:MM, contoh 08:00-22:00. Ketik "off" untuk selalu aktif.'),
  await_backup_token_regen: defineTemplate('panel.input.backup_token_regen', 'Backup Token', 'Backup Token', '{pesan}', { supportedPlaceholders: ['pesan'] }),
  await_custom_wm: defineTemplate('panel.input.custom_wm', 'Custom WM', 'Input Custom WM', '⭐ Kirim watermark. Ketik "off" untuk menghapus.'),
  await_check_token: defineTemplate('panel.input.check_token', 'Backup Token', 'Input Cek Token', '🔥 Cek Token\n\nKirim token backup yang ingin diperiksa. Pesan berisi token akan dihapus otomatis dari chat ini.'),
  await_transfer: defineTemplate('panel.input.transfer', 'Transfer Userbot', 'Input Transfer Userbot', '🔄 Kirim @username atau Telegram ID user tujuan. User tujuan wajib sudah terdaftar di bot.'),
  await_reset_data: defineTemplate('panel.input.reset_data', 'Reset Data', 'Konfirmasi Reset Data', '🗑️ Ini menghapus grup, pesan, reply, dan setting panel. Ketik RESET untuk konfirmasi.'),
  await_add_reply_text: defineTemplate('panel.input.add_reply_text', 'Base Reply', 'Input Teks Reply', '➕ Tambah Reply (2/2)\n\nKata kunci: {keyword}\n\nSekarang kirim teks balasan untuk kata kunci di atas.', { supportedPlaceholders: ['keyword'] }),
};

// Steps that are part of a multi-step wizard where the user can go back
// to the previous step — show Kembali + Batal (panelInputKeyboard).
// All other single-step input prompts show only Batal (panelCancelKeyboard),
// so the keyboard unambiguously matches the available action.
const MULTI_STEP_INPUTS = new Set(['await_add_reply_keyword', 'await_add_reply_text']);

function ask(ctx, step, prompt, extra = {}) {
  const st = panelState.get(ctx.from.id);
  panelState.set(ctx.from.id, { ...st, step });
  const template = panelInputTemplates[step];
  const content = template
    ? template.getContent(ctx, extra)
    : { text: prompt, entities: [], parse_mode: 'Markdown' };
  const text = content.text;
  const kb = MULTI_STEP_INPUTS.has(step) ? panelInputKeyboard() : panelCancelKeyboard();
  return ctx.reply(text, { ...buildReplyOptions(content), ...kb });
}

const ADD_REPLY_KEYWORD_PROMPT = '➕ Tambah Reply (1/2)\n\nKirim kata kunci pemicu. Bisa lebih dari satu, pisahkan dengan koma.\nContoh: harga, minat, wtb';

/**
 * "🔙 Kembali" while a panel input step is active.
 *  - Tambah Reply step 2 -> step 1, keeping the keywords already entered.
 *  - every other step   -> the panel screen the wizard was opened from
 *    (Batal does the same but announces the cancellation).
 * The step is cleared/changed BEFORE re-rendering, so the old step can never
 * capture the next message.
 */
async function inputBack(ctx, st) {
  if (st.step === 'await_add_reply_text' && st.pendingReplyKeywords) {
    return ask(ctx, 'await_add_reply_keyword', `${ADD_REPLY_KEYWORD_PROMPT}\n\nKata kunci saat ini: ${st.pendingReplyKeywords}`);
  }
  panelState.clearStep(ctx.from.id);
  return restoreScreen(ctx, st.screen);
}

// Re-renders whichever panel screen the user was on before a wizard step
// started (or before it was cancelled), restoring that screen's normal
// reply keyboard in place of the Cancel button shown during input mode.
async function restoreScreen(ctx, screen) {
  switch (screen) {
    case 'reply': return baseReplyHandler(ctx);
    case 'reply_global': return globalSettingsHandler(ctx);
    case 'reply_react': return autoReactHandler(ctx);
    case 'watermark': return watermarkHandler(ctx);
    case 'timer': return timerHandler(ctx);
    case 'backup_token': return backupTokenHandler(ctx);
    case 'message': return messageHandler(ctx);
    case 'group': return groupHandler(ctx);
    case 'delay': return delayHandler(ctx);
      case 'extra': return extraHandler(ctx);
    default: return homePanelHandler(ctx);
  }
}

// A wizard step can end in three ways: it re-renders a screen itself (Atur
// Jeda, Global Settings, ...), it keeps waiting for a better input (validation
// error / next step), or it just replies "✅ disimpan". The third case used to
// leave the single-button Cancel keyboard on screen, so the NEXT "Batal" was
// handled as a global cancel and threw the user out to the main menu. This
// puts the user back on the screen the wizard was started from - exactly what
// pressing Batal does - so both exits behave the same.
async function settleAfterStep(ctx) {
  if (ctx.__panelScreenRendered) return;              // step already re-rendered a screen
  const st = panelState.get(ctx.from.id);
  if (!st) {                                          // panel session ended (e.g. Transfer Ubot)
    await require('../services/mainMenu.service').renderMainMenu(ctx);
    return;
  }
  if (st.step) return;                                // still waiting for input
  await restoreScreen(ctx, st.screen);
}

const panelHandler=safeHandler(async ctx=>{
  const assets = userbotService.getUserAssets(ctx.from.id);
  const now = Date.now();
  const activeOwned = assets.owned.filter((a) => subscription.isActiveNow(a, now));
  const activePool = assets.leased.filter((a) => a.status === 'assigned' && a.expires_at && new Date(a.expires_at).getTime() > now);
  const allActive = [
    ...activeOwned.map((asset) => ({ kind:'owned', asset })),
    ...activePool.map((asset) => ({ kind:'pool', asset })),
  ];
  if(!allActive.length){
    const expired = assets.owned.filter((a) => !subscription.isActiveNow(a, now));
    panelState.clear(ctx.from.id);
    if(expired.length===1){ await subscriptionHandler.sendExpiredNotice(ctx, expired[0]); return; }
    if(expired.length>1){ await subscriptionHandler.sendExpiredPicker(ctx, expired); return; }
    const content = noAssetSubmenu.getContent(ctx);
    await renderScreen(ctx, content.text, {...buildReplyOptions(content), ...panelNoAssetKeyboard()});
    return;
  }
  if(allActive.length===1){
    const only=allActive[0];
    // Even the implicit single-userbot selection must pass the same real
    // session/authorization/capability gate as an explicit picker tap.
    panelState.set(ctx.from.id,{kind:only.kind,id:only.asset.id,step:null,screen:'select',adminMode:false,returnTo:'home'});
    await selectAsset(ctx, only.kind, only.asset.id);
    return;
  }
  panelState.set(ctx.from.id,{kind:'owned',id:null,step:'selecting',screen:'select',adminMode:false,returnTo:'home'});
  const content = panelSelectAssetSubmenu.getContent(ctx);
  await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...panelSelectAssetKeyboard({owned:activeOwned,leased:activePool})});
});

async function selectAsset(ctx,kind,id,note=''){
  if(!['owned','pool'].includes(kind)){const c=panelContent(panelTpl.accountOwnership,ctx);await ctx.reply(c.text,buildReplyOptions(c));return;}
  const current = panelState.get(ctx.from.id);
  const adminMode = Boolean(current && current.adminMode && isAdminId(ctx.from.id));
  const access=userbotAccess.checkUserbotControlAccess({userbotId:id,actorId:ctx.from.id,adminMode,kind});
  if(!access.ok){
    if(access.code==='EXPIRED'){panelState.clear(ctx.from.id);await subscriptionHandler.denyControl(ctx,access,{adminMode});return;}
    await replyPanelTemplate(ctx,panelTpl.asset_missing);return;
  }

  // Selection is a real capability gate, not merely a DB/ownership check.
  // Coalesce duplicate clicks through the runtime's per-asset lock while still
  // executing an actual GramJS authorization/identity check for every logical
  // selection. Temporary Telegram/API failures never mutate session state.
  try {
    const verification = await userbotRuntime.verifyAssetSession(kind,id);
    if (!verification || verification.verified !== true) {
      const status = verification && verification.status;
      if (status === 'RUNTIME_UNAVAILABLE') {
        panelState.clear(ctx.from.id);
        await replyPanelTemplate(ctx,panelTpl.sessionRuntimeUnavailable);
        return;
      }
      if (status === 'SESSION_MISSING') {
        const err = new Error('Sesi Telegram tidak tersedia.');
        err.code = 'SESSION_MISSING';
        throw err;
      }
      const err = new Error('Sesi Telegram belum dapat diverifikasi.');
      err.code = 'SESSION_VALIDATION_FAILED';
      throw err;
    }
  } catch (err) {
    panelState.clear(ctx.from.id);
    if (userbotRuntime.isSessionInvalidError(err)) {
      const lifecycle = require('../services/userbotLifecycle.service');
      const recovery = await lifecycle.handleSessionInvalid(kind,id,{notify: !(!adminMode && kind === 'owned')});

      // Owned userbots keep the same DB row, expiry, ownership and settings;
      // start the existing re-authentication flow instead of creating a new row.
      if (!adminMode && kind === 'owned') {
        const ubotFlow = require('./ubotFlow.handler');
        await ubotFlow.beginPhoneStep(ctx.telegram, ctx.from.id, id, 'reauth', { returnTo: 'main' });
        return;
      }

      // A Jaseb lease may have been atomically replaced. Continue directly on
      // the replacement only when the lifecycle service returned its exact new
      // asset; never guess by picking an arbitrary assigned stock row.
      if (!adminMode && kind === 'pool' && recovery && recovery.replacementId) {
        const replacementId = Number(recovery.replacementId);
        const replacementAccess = userbotAccess.checkUserbotControlAccess({ userbotId: replacementId, actorId: ctx.from.id, adminMode:false, kind:'pool' });
        if (replacementAccess.ok) {
          panelState.set(ctx.from.id,{kind:'pool',id:replacementId,step:null,screen:'main',adminMode:false,returnTo:current && current.screen === 'select' ? 'select' : 'home'});
          await showMainPanel(ctx, '✅ Userbot Jaseb pengganti sudah aktif. Sisa masa aktif dilanjutkan.');
          return;
        }
      }
      const content = kind === 'pool' ? panelTpl.sessionInvalid : panelTpl.sessionInvalid;
      await replyPanelTemplate(ctx,content);
      return;
    }
    if (err && err.code === 'SESSION_IDENTITY_MISMATCH') {
      await replyPanelTemplate(ctx,panelTpl.sessionIdentityMismatch);
      return;
    }
    if (err && err.code === 'SESSION_CORRUPT') {
      if (!adminMode && kind === 'owned') {
        const ubotFlow = require('./ubotFlow.handler');
        await ubotFlow.beginPhoneStep(ctx.telegram, ctx.from.id, id, 'reauth', { returnTo: 'main' });
        return;
      }
      await replyPanelTemplate(ctx,panelTpl.sessionCorrupt);
      return;
    }
    if (err && err.code === 'SESSION_MISSING') {
      if (!adminMode && kind === 'owned') {
        const ubotFlow = require('./ubotFlow.handler');
        await ubotFlow.beginPhoneStep(ctx.telegram, ctx.from.id, id, 'reauth', { returnTo: 'main' });
        return;
      }
      await replyPanelTemplate(ctx,panelTpl.sessionMissing);
      return;
    }
    if (err && err.code === 'RUNTIME_UNAVAILABLE') {
      await replyPanelTemplate(ctx,panelTpl.sessionRuntimeUnavailable);
      return;
    }
    logger.warn(`Validasi session ${kind} #${id} gagal sementara: ${(err && err.message) || err}`);
    await replyPanelTemplate(ctx,panelTpl.sessionTemporary);
    return;
  }

  panelState.set(ctx.from.id,{kind,id,step:null,screen:'main',adminMode,returnTo:current && current.screen === 'select' ? 'select' : 'home'});
  await showMainPanel(ctx,note);
}
const panelAssetInlineCallback=safeHandler(async ctx=>{await ctx.answerCbQuery();const [, ,kind,id]=ctx.callbackQuery.data.split(':');await selectAsset(ctx,kind,Number(id));});

// Only changes the panel screen. The live Status Promosi watcher is NOT tied to
// the screen: it keeps following the promotion for as long as the user stays in
// this userbot's control (it stops itself when the user leaves, see runStatusTick).
function makeScreen(ctx,screen){
  const st=panelState.get(ctx.from.id);
  panelState.set(ctx.from.id,{...st,screen,step:null});
  ctx.__panelScreenRendered = true;
}

const PROMOTION_STATUS_SCREEN = 'control_panel_promotion_status_live';
const PROMOTION_STATUS_SUBMENU_ID = 'control_panel_promotion_status';
const PROMOTION_STATUS_REFRESH_MS = 8000;        // tick; Telegram is only called when the text changed
const PROMOTION_STATUS_MAX_BACKOFF_MS = 120000;
const promotionStatusWatchers = new Map();        // userId -> live watcher (one per user)
const promotionStatusLive = new Map();            // userId -> { messageId, kind, id }: the ONE status message this user has

function stopPromotionStatusWatcher(userId){
  const key=Number(userId);
  const w=promotionStatusWatchers.get(key);
  if(w){ clearTimeout(w.timer); promotionStatusWatchers.delete(key); }
}
function promotionStatusKey(userId, kind, id){ return `${Number(userId)}:${String(kind)}:${Number(id)}`; }
function bumpPromotionStatusRenderVersion(userId, kind, id){
  const key=promotionStatusKey(userId,kind,id);
  const next=(promotionStatusRenderVersions.get(key)||0)+1;
  promotionStatusRenderVersions.set(key,next);
  return next;
}
function currentPromotionStatusRenderVersion(userId, kind, id){ return promotionStatusRenderVersions.get(promotionStatusKey(userId,kind,id))||0; }

// ROOT CAUSE of the frozen status: the default template is Markdown, and dynamic
// values (target "@promo_grup", wait reason, group titles) were inserted raw.
// An unmatched "_" or "*" makes Telegram reject the whole edit ("can't parse
// entities"); the watcher only logged it, so the message stayed on its last good
// text. Values are escaped here, but only on the default (Markdown) path: a
// template saved with Telegram entities is not parsed as Markdown, so escaping
// there would show literal backslashes.
function mdEscape(value){ return String(value).replace(/([_*`\[])/g, '\\$1'); }
function promotionStatusContent(ctxLike, asset, kind){
  const base=panelPlaceholderContext({...asset,__kind:kind});
  const custom=getCustomContent(PROMOTION_STATUS_SUBMENU_ID);
  const customHasEntities=Boolean(custom && Array.isArray(custom.entities) && custom.entities.length);
  if(!customHasEntities){
    for(const key of Object.keys(base.panelStats)){
      if(typeof base.panelStats[key]==='string') base.panelStats[key]=mdEscape(base.panelStats[key]);
    }
  }
  return panelPromotionStatusSubmenu.getContent(ctxLike, base);
}

// Single entry point that renders the live status screen and starts following it.
// Used by Mulai, Status Promosi, re-entering the userbot's control and Kembali.
// forceNew: entering the control again (Kontrol Panel, Kembali, Mulai) always posts a fresh status message
// and continues updating that one. Only the in-place "Status Promosi" button edits the existing message.
async function openPromotionStatus(ctx, kind, asset, forceNew=false){
  const uid=Number(ctx.from.id); const id=Number(asset.id);
  makeScreen(ctx,'promotion_status');
  const content=promotionStatusContent(ctx,asset,kind);
  const live=promotionStatusLive.get(uid);
  const following=promotionStatusWatchers.get(uid);
  // Already following this promotion (e.g. Status Promosi pressed again): edit the same message, post nothing.
  if(!forceNew && live && following && live.kind===kind && live.id===id){
    try{
      await editStatusMessage({uid,kind,id,telegram:ctx.telegram,messageId:live.messageId},content);
      return;
    }catch(err){
      const desc=String(err&&(err.description||err.message)||'');
      if(!/message to edit not found|message can't be edited|message is too old|MESSAGE_ID_INVALID|message not found/i.test(desc)) throw err;
    }
  }
  // Re-entering after leaving: the Stop keyboard can only be attached by a new message,
  // so post exactly one and remove the previous status message instead of stacking them.
  stopPromotionStatusWatcher(uid);
  // The status message carries only the inline Stop button. The persistent reply keyboard is set by a
  // short message that is deleted right away; Telegram keeps the keyboard after its carrier is deleted.
  await ctx.reply('⏹️ Promosi berjalan.',panelMainKeyboard(true)).then(m=>{ if(m&&m.message_id) ctx.telegram.deleteMessage(uid,m.message_id).catch(()=>{}); }).catch(()=>{});
  const sent=await ctx.reply(content.text,{...buildReplyOptions(content),...promotionRunningKeyboard(kind,id)});
  if(live && sent && live.messageId!==sent.message_id){
    ctx.telegram.deleteMessage(uid,live.messageId).catch(()=>{});
  }
  if(!sent||!sent.message_id) return;
  promotionStatusLive.set(uid,{messageId:Number(sent.message_id),kind,id});
  startPromotionStatusWatcher(ctx,kind,id,sent.message_id,content.text);
}

function startPromotionStatusWatcher(ctx, kind, id, messageId, initialText = null){
  const uid=Number(ctx.from.id);
  stopPromotionStatusWatcher(uid);
  if(!messageId) return;
  const w={uid,kind,id:Number(id),messageId:Number(messageId),lastText:initialText==null?null:String(initialText),
    from:ctx.from,chat:{id:uid,type:(ctx.chat&&ctx.chat.type)||'private'},telegram:ctx.telegram,timer:null,failures:0,startedAt:Date.now()};
  promotionStatusWatchers.set(uid,w);
  scheduleStatusTick(w,PROMOTION_STATUS_REFRESH_MS);
}
function scheduleStatusTick(w, delayMs){
  clearTimeout(w.timer);
  w.timer=setTimeout(()=>runStatusTick(w),delayMs);
  if(typeof w.timer.unref==='function') w.timer.unref();
}
function retryAfterMs(err){
  const fromParams=Number(err&&err.parameters&&err.parameters.retry_after||0);
  const m=String(err&&(err.description||err.message)||'').match(/retry after (\d+)/i);
  const secs=fromParams||(m?Number(m[1]):0);
  return secs>0?secs*1000:0;
}
// Edit only when the rendered text actually changed (smart update: no
// Telegram call for an unchanged status, so no repeated-edit rate limits).
async function editStatusMessage(w, content){
  try{
    await w.telegram.editMessageText(w.uid,w.messageId,undefined,content.text,{...buildReplyOptions(content),...promotionRunningKeyboard(w.kind,w.id)});
  }catch(err){
    const desc=String(err&&(err.description||err.message)||'');
    if(/message is not modified/i.test(desc)) return;
    // Last-resort: if Telegram still rejects the formatting, update the data as plain text.
    if(/can't parse entities|parse entities/i.test(desc)){ await w.telegram.editMessageText(w.uid,w.messageId,undefined,content.text,promotionRunningKeyboard(w.kind,w.id)); return; }
    throw err;
  }
}
async function runStatusTick(w){
  w.timer=null;
  if(promotionStatusWatchers.get(w.uid)!==w) return;            // replaced or stopped
  const st=panelState.get(w.uid);
  // The user left this userbot's control (Kembali to picker/home, another userbot, logout): stop.
  // Screen must still be the status screen: Kembali to the main panel keeps kind/id, so checking only those kept the watcher alive.
  if(!st||st.kind!==w.kind||Number(st.id)!==w.id||st.screen!=='promotion_status'){ stopPromotionStatusWatcher(w.uid); return; }
  const access=userbotAccess.checkUserbotControlAccess({userbotId:w.id,actorId:w.uid,adminMode:Boolean(st.adminMode&&isAdminId(w.uid)),kind:w.kind});
  if(!access.ok){ stopPromotionStatusWatcher(w.uid); return; }
  if(!userbotRuntime.isAutoPromosiActive(w.kind,w.id)){
    stopPromotionStatusWatcher(w.uid);
    try{
      const freshAsset=(w.kind==='pool'?poolRepo:ownedRepo).findById(w.id)||access.asset;
      const main=panelMainSubmenu.getContent({from:w.from,chat:w.chat},panelPlaceholderContext({...freshAsset,__kind:w.kind}));
      panelState.set(w.uid,{...st,screen:'main',step:null});
      await w.telegram.sendMessage(w.uid,main.text,{...buildReplyOptions(main),...panelMainKeyboard(false)});
    }catch(err){ logger.warn(`Kembali ke Panel Kontrol setelah promosi berhenti gagal untuk ${w.uid}: ${String(err&&err.message||err)}`); }
    return;
  }
  let delay=PROMOTION_STATUS_REFRESH_MS;
  let content=null;
  try{
    content=promotionStatusContent({from:w.from,chat:w.chat},access.asset,w.kind);
    if(content.text!==w.lastText){
      await editStatusMessage(w,content);
      w.lastText=content.text;
    }
    w.failures=0;
    w.reanchors=0;
  }catch(err){
    w.failures++;
    const desc=String(err&&(err.description||err.message)||err||'');
    const wait=retryAfterMs(err);
    if(wait){
      // 429 Too Many Requests: honour Telegram's retry_after instead of hammering.
      delay=wait+1000;
      logger.warn(`Status Promosi ${w.kind}#${w.id}: kena limit Telegram, tunggu ${Math.ceil(delay/1000)}s`);
    }else if(/message to edit not found|message can't be edited|message is too old|MESSAGE_ID_INVALID|there is no text in the message to edit|message not found/i.test(desc) && content){
      // Not editable any more: delete it and post a fresh one immediately. The 3s guard only stops a
      // tight loop if Telegram keeps failing; it is not a delay between normal updates.
      // Hard limit: re-posting is allowed only a few times in a row. If Telegram keeps refusing the
      // edit, stop instead of delete+send forever, and log the exact Telegram description.
      w.reanchors=(w.reanchors||0)+1;
      logger.warn(`Status Promosi ${w.kind}#${w.id}: edit ditolak Telegram (${w.reanchors}x berturut): ${desc}`);
      if(w.reanchors>3){
        logger.error(`Status Promosi ${w.kind}#${w.id} dihentikan: edit terus ditolak. Terakhir: ${desc}`);
        stopPromotionStatusWatcher(w.uid);
        return;
      }
      w.telegram.deleteMessage(w.uid,w.messageId).catch(()=>{});
      try{
        const sent=await w.telegram.sendMessage(w.uid,content.text,{...buildReplyOptions(content),...promotionRunningKeyboard(w.kind,w.id)});
        if(sent&&sent.message_id){ w.messageId=Number(sent.message_id); w.lastText=content.text; promotionStatusLive.set(w.uid,{messageId:w.messageId,kind:w.kind,id:w.id}); }
      }catch(e2){ logger.warn(`Status Promosi: pesan pengganti gagal untuk ${w.uid}: ${String(e2&&e2.message||e2)}`); }
    }else{
      delay=Math.min(PROMOTION_STATUS_MAX_BACKOFF_MS,PROMOTION_STATUS_REFRESH_MS*(2**Math.min(w.failures,4)));
      logger.warn(`Status Promosi ${w.kind}#${w.id} gagal diperbarui (percobaan ${w.failures}): ${desc}`);
    }
  }
  if(promotionStatusWatchers.get(w.uid)===w) scheduleStatusTick(w,delay);
}

const homePanelHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const kind=panelKind(ctx);const id=Number(s.asset.id);if(userbotRuntime.isAutoPromosiActive(kind,id)){await openPromotionStatus(ctx,kind,s.asset,true);return;}makeScreen(ctx,'main');await showMainPanel(ctx);});
const baseReplyHandler=safeHandler(async ctx=>{const sel=selected(ctx);if(!sel)return;makeScreen(ctx,'reply');const content=panelBaseReplySubmenu.getContent(ctx,panelPlaceholderContext(sel.asset));await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...baseReplyKeyboard()});});
const messageHandler=safeHandler(async ctx=>{const sel=selected(ctx);if(!sel)return;makeScreen(ctx,'message');const content=panelMessageSubmenu.getContent(ctx,panelPlaceholderContext(sel.asset));await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...messageKeyboard()});});
const groupHandler=safeHandler(async ctx=>{const sel=selected(ctx);if(!sel)return;makeScreen(ctx,'group');const content=panelGroupSubmenu.getContent(ctx,panelPlaceholderContext(sel.asset));await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...groupKeyboard()});});
const delayHandler=safeHandler(async ctx=>{const sel=selected(ctx);if(!sel)return;makeScreen(ctx,'delay');const content=panelDelaySubmenu.getContent(ctx,panelPlaceholderContext(sel.asset));const range=delayPolicy.readGroupDelayRange(panelConfigFor(ctx).getSettings(sel.asset.id),panelConfigFor(ctx).RECOMMENDED_GROUP_DELAY_SECONDS);const smartLine=`\n\n🧠 Smart Delay: ${smartDelay.describe(panelState.get(ctx.from.id).kind,sel.asset.id,range)}`;await renderWithReplyKeyboard(ctx,content.text+smartLine,{...buildReplyOptions(content),...delayKeyboard()});});
const extraHandler=safeHandler(async ctx=>{const sel=selected(ctx);if(!sel)return;makeScreen(ctx,'extra');const content=panelExtraSubmenu.getContent(ctx,panelPlaceholderContext(sel.asset));await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...extraKeyboard(isAdminId(ctx.from.id))});});
const guideHandler=safeHandler(async ctx=>{const sel=selected(ctx);if(!sel)return;const content=panelGuideSubmenu.getContent(ctx,panelPlaceholderContext(sel.asset));await ctx.reply(content.text,buildReplyOptions(content));});

// "🚀 Mulai Promosi" / "⏹️ Stop Promosi" — a single toggle handler, wired
// from BOTH labels (see index.js), that reads the userbot's REAL runtime
// status (userbotRuntime.isAutoPromosiActive) rather than trusting which
// label was tapped. Database flag is only persisted AFTER the runtime
// operation is confirmed to have actually succeeded — never optimistically
// — so start/stop failures never leave the UI lying about the real state.
const startHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  const assetId=s.asset.id;
  bumpPromotionStatusRenderVersion(ctx.from.id,panelKind(ctx),assetId);
  const toggleKey=`${panelKind(ctx)}:${assetId}`;
  if(promoToggleInFlight.has(toggleKey)){await replyPanelTemplate(ctx,panelTpl.toggleBusy);return;}
  promoToggleInFlight.add(toggleKey);
  try{
    const runningNow=userbotRuntime.isAutoPromosiActive(panelKind(ctx),assetId);
    if(!runningNow){
      // START
      if(!panelConfigFor(ctx).listGroups(assetId).length && !s.asset.target){await replyPanelTemplate(ctx,panelTpl.noGroup);return;}
      if(!panelConfigFor(ctx).getMessage(assetId)){await replyPanelTemplate(ctx,panelTpl.noMessage);return;}
      assetRepoFor(ctx).setFlags(assetId,{autoPromosi:true});
      try{
        await userbotRuntime.syncAsset(panelKind(ctx),assetId);
      }catch(err){
        assetRepoFor(ctx).setFlags(assetId,{autoPromosi:false}); // start genuinely failed — never claim active
        logger.error(`Mulai Promosi gagal ${assetId}: ${err.message}`);
        await replyPanelError(ctx,panelTpl.startFailed,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}});
        return;
      }
      if(!userbotRuntime.isAutoPromosiActive(panelKind(ctx),assetId)){
        assetRepoFor(ctx).setFlags(assetId,{autoPromosi:false});
        await replyPanelError(ctx,panelTpl.startRuntimeFailed);
        return;
      }
      await openPromotionStatus(ctx,panelKind(ctx),assetRepoFor(ctx).findById(assetId)||s.asset,true);
    } else {
      // STOP
      assetRepoFor(ctx).setFlags(assetId,{autoPromosi:false});
      try{
        await userbotRuntime.syncAsset(panelKind(ctx),assetId);
      }catch(err){
        logger.error(`Stop Promosi gagal sync ${assetId}: ${err.message}`);
      }
      if(userbotRuntime.isAutoPromosiActive(panelKind(ctx),assetId)){
        // Stop did not actually take effect — never fake "stopped" in DB/UI.
        assetRepoFor(ctx).setFlags(assetId,{autoPromosi:true});
        await replyPanelError(ctx,panelTpl.stopRuntimeFailed);
        return;
      }
      promotionStatusLive.delete(ctx.from.id);
      // Promosi berhasil dihentikan — kembali ke kontrol panel utama
      // agar tombol berubah menjadi "🚀 Mulai Promosi" (active=false).
      stopPromotionStatusWatcher(ctx.from.id);
      makeScreen(ctx,'main');
      await showMainPanel(ctx);
    }
  } finally {
    promoToggleInFlight.delete(toggleKey);
  }
});

const promotionStatusHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  const kind=panelKind(ctx);const id=Number(s.asset.id);
  if(!userbotRuntime.isAutoPromosiActive(kind,id)){makeScreen(ctx,'main');await showMainPanel(ctx);return;}
  await openPromotionStatus(ctx,kind,s.asset);
});

const promotionStatusRefreshHandler=safeHandler(async ctx=>{
  await promotionStatusHandler(ctx);
});

function promotionInlineContext(ctx) {
  const parts = String(ctx.callbackQuery?.data || '').split(':');
  const kind = parts[3];
  const id = Number(parts[4]);
  if (!['owned', 'pool'].includes(kind) || !Number.isInteger(id) || id <= 0) return null;
  const state = panelState.get(ctx.from.id);
  if (!state || state.kind !== kind || Number(state.id) !== id || state.screen !== 'promotion_status') return null;
  const access = userbotAccess.checkUserbotControlAccess({
    userbotId: id,
    actorId: ctx.from.id,
    adminMode: Boolean(state.adminMode && isAdminId(ctx.from.id)),
    kind,
  });
  if (!access.ok) return null;
  return { kind, id, state, asset: access.asset };
}

const promotionStatusRefreshInlineCallback=safeHandler(async ctx=>{
  const target=promotionInlineContext(ctx);
  if(!target){ await ctx.answerCbQuery('Status Promosi sudah tidak tersedia.',{show_alert:true}).catch(()=>{}); return; }
  await ctx.answerCbQuery().catch(()=>{});
  await promotionStatusRefreshHandler(ctx);
});

const promotionStatusStartInlineCallback=safeHandler(async ctx=>{
  const target=promotionInlineContext(ctx);
  if(!target){ await ctx.answerCbQuery('Sesi Status Promosi sudah tidak berlaku.',{show_alert:true}).catch(()=>{}); return; }
  await ctx.answerCbQuery().catch(()=>{});
  await startHandler(ctx);
});

const promotionStatusStopInlineCallback=safeHandler(async ctx=>{
  const target=promotionInlineContext(ctx);
  if(!target){ await ctx.answerCbQuery('Sesi Status Promosi sudah tidak berlaku.',{show_alert:true}).catch(()=>{}); return; }
  await ctx.answerCbQuery().catch(()=>{});
  await startHandler(ctx);
});

const promotionStatusBackInlineCallback=safeHandler(async ctx=>{
  const target=promotionInlineContext(ctx);
  if(!target){ await ctx.answerCbQuery('Sesi Status Promosi sudah tidak berlaku.',{show_alert:true}).catch(()=>{}); return; }
  await ctx.answerCbQuery().catch(()=>{});
  // Hentikan watcher auto-refresh sebelum kembali ke kontrol panel.
  stopPromotionStatusWatcher(ctx.from.id);
  await homePanelHandler(ctx);
});

// Turns a runtime automation flag ON and verifies it actually came alive
// (userbotRuntime.isRunning), mirroring the "🚀 Mulai Promosi" pattern —
// never tell the user a feature is active on the strength of the DB flag
// alone. If the underlying GramJS client failed to connect/attach (dead
// session, GramJS not installed, network/API error), the flag is rolled
// back and the real error is shown, instead of silently logging a warning
// while the panel still claims "🟢 Aktif".
async function enableRuntimeFlag(assetId, revertFlag, syncAssetKind, featureId) {
  try {
    await userbotRuntime.syncAsset(syncAssetKind, assetId);
  } catch (err) {
    revertFlag();
    return { ok: false, error: err.message };
  }
  if (!userbotRuntime.isRunning(syncAssetKind, assetId) || !userbotRuntime.isFeatureActive(syncAssetKind, assetId, featureId)) {
    revertFlag();
    return { ok: false, error: 'Runtime menolak aktivasi fitur. Periksa entitlement paket, sesi, dan konfigurasi userbot.' };
  }
  return { ok: true };
}

const replyToggleHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  const next=!Boolean(s.asset.wtb_reply);
  assetRepoFor(ctx).setFlags(s.asset.id,{wtbReply:next});
  if(next){
    const result=await enableRuntimeFlag(s.asset.id, ()=>assetRepoFor(ctx).setFlags(s.asset.id,{wtbReply:false}), panelKind(ctx), 'base_reply');
    if(!result.ok){
      await replyPanelError(ctx,panelTpl.replyToggleFailed,{placeholderValues:{reason:result.error}});
      return;
    }
  } else {
    await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
  }
  await replyPanelTemplate(ctx,panelTpl.replyStatus,{placeholderValues:{status:next?'🟢 ON':'❌ OFF'}});
});
// Base Reply "Tambah Reply" used to demand a single cramped line
// ("keyword1,keyword2 | teks balasan"), which is easy to get wrong on
// mobile. It's now a 2-step guided wizard: keyword(s) first, then the
// reply text, each with its own Cancel button.
const addReplyHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_add_reply_keyword',ADD_REPLY_KEYWORD_PROMPT);});
const deleteReplyHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const rows=panelConfigFor(ctx).listReplies(s.asset.id);if(!rows.length){await replyPanelTemplate(ctx,panelTpl.replyEmpty);return;}await ask(ctx,'await_delete_reply','',{ placeholderValues: { reply_list: rows.map(r=>`#${r.id} — ${r.keywords}`).join('\n') } });});
const wtbTimerHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_wtb_timer','⏰ Kirim timer WTB dengan format 08:00-22:00, atau "off".');});
const replyListHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const rows=panelConfigFor(ctx).listReplies(s.asset.id);const st=panelConfigFor(ctx).getSettings(s.asset.id);const list=rows.length?rows.map(r=>`#${r.id} ${r.enabled?'🟢':'⚪'} ${r.keywords}\n↳ ${r.response}`).join('\n\n'):'Belum ada reply khusus.';await replyPanelTemplate(ctx,panelTpl.replyListScreen,{placeholderValues:{status:s.asset.wtb_reply?'🟢 ON':'❌ OFF',timer:st.wtb_timer||'24 jam',auto_reset:String(st.wtb_auto_reset_minutes),reply_list:list}});});
const autoReactHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;makeScreen(ctx,'reply_react');const st=panelConfigFor(ctx).getSettings(s.asset.id);await renderWithReplyKeyboard(ctx,(panelContent(panelTpl.autoReactScreen,ctx,{placeholderValues:{status:st.auto_react?'🟢 AKTIF':'❌ NONAKTIF',reaction:st.auto_react_emoji||'❤️'}})).text,{...buildReplyOptions(panelContent(panelTpl.autoReactScreen,ctx,{placeholderValues:{status:st.auto_react?'🟢 AKTIF':'❌ NONAKTIF',reaction:st.auto_react_emoji||'❤️'}})),...autoReactKeyboard(Boolean(st.auto_react))});});
// Enable: persists auto_react=true, the actual source of truth read live
// by userbotRuntime.attach() on every incoming WTB-reply event (see
// sendAutoReaction gating in userbotRuntime.service.js) — there is no
// separate listener/worker to start for this feature, it is a plain
// per-event config read, so persisting the flag IS activating it.
// syncAsset() is still called (matching the disable handler and the
// project's enableRuntimeFlag pattern for other toggles) to keep the
// in-memory runtime record's flags snapshot fresh; it is a no-op with
// respect to auto_react specifically but harmless and idempotent.
// Re-rendering from the freshly-read DB state (autoReactHandler) — never
// from "which button was tapped" — is what keeps the menu, DB and
// runtime from ever disagreeing, and makes repeated taps idempotent
// (updateSettings is a plain UPDATE; tapping Aktifkan N times in a row
// leaves auto_react=1, no duplicate state, no extra listeners).
const autoReactEnableHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;panelConfigFor(ctx).updateSettings(s.asset.id,{auto_react:true});await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));await autoReactHandler(ctx);});
const autoReactDisableHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;panelConfigFor(ctx).updateSettings(s.asset.id,{auto_react:false});await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));await autoReactHandler(ctx);});
const autoReactChangeHandler=safeHandler(async ctx=>{if(!selected(ctx))return;makeScreen(ctx,'reply_react');await ask(ctx,'await_react_emoji','❤️ Kirim emoji reaksi yang ingin digunakan. Contoh: ❤️, 👍, 🔥');});
const autoResetHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_auto_reset','🔄 Kirim cooldown Base Reply dalam menit. Default: 3 menit. Contoh: 3.');});

const globalSettingsHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;makeScreen(ctx,'reply_global');const st=panelConfigFor(ctx).getSettings(s.asset.id);const m=panelConfigFor(ctx).getMessage(s.asset.id);const content=panelContent(panelTpl.globalSettingsScreen,ctx,{placeholderValues:{message_type:m?m.kind:'Belum diatur',target_channel:st.wtb_target_channel||'Semua grup',banned_words:st.wtb_banned_words||'-',max_chars:st.wtb_max_chars||'Tidak dibatasi',filter_link:st.wtb_filter_links?'🟢 ON':'❌ OFF',filter_username:st.wtb_filter_usernames?'🟢 ON':'❌ OFF'}});await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...globalSettingsKeyboard()});});
const globalTextHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_global_text','✏️ Kirim teks pesan default. Untuk media, gunakan 📝 Atur Pesan → Pesan Teks/Media.');});
const globalTargetChannelHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_target_channel','🎯 Kirim username/ID channel target, atau "off" untuk semua grup.');});
const globalBannedHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_banned_words','🚫 Kirim banned words dipisahkan koma, atau "off" untuk menghapus.');});
const globalMaxCharsHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const st=panelConfigFor(ctx).getSettings(s.asset.id);const next=Number(st.wtb_max_chars||0)===70?0:70;panelConfigFor(ctx).updateSettings(s.asset.id,{wtb_max_chars:next});await replyPanelTemplate(ctx,panelTpl.globalMaxCharsStatus,{placeholderValues:{status:next?'🟢 ON':'❌ OFF'}},{ keyboard: globalSettingsKeyboard() });});
const globalFilterLinkHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const st=panelConfigFor(ctx).getSettings(s.asset.id);const next=!Boolean(st.wtb_filter_links);panelConfigFor(ctx).updateSettings(s.asset.id,{wtb_filter_links:next});await replyPanelTemplate(ctx,panelTpl.globalFilterLinkStatus,{placeholderValues:{status:next?'🟢 ON':'❌ OFF'}},{ keyboard: globalSettingsKeyboard() });});
const globalFilterUsernameHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const st=panelConfigFor(ctx).getSettings(s.asset.id);const next=!Boolean(st.wtb_filter_usernames);panelConfigFor(ctx).updateSettings(s.asset.id,{wtb_filter_usernames:next});await replyPanelTemplate(ctx,panelTpl.globalFilterUsernameStatus,{placeholderValues:{status:next?'🟢 ON':'❌ OFF'}},{ keyboard: globalSettingsKeyboard() });});
const channelDisableHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const cur=panelConfigFor(ctx).getSettings(s.asset.id);const next=!cur.channel_disabled;panelConfigFor(ctx).updateSettings(s.asset.id,{channel_disabled:next});await replyPanelTemplate(ctx,panelTpl.channelDisableStatus,{placeholderValues:{status:next?'🟢 ON — channel akan dilewati':'❌ OFF — channel boleh diproses'} });});

const textMediaHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_message_media','📄 Kirim teks pesan promosi (format Telegram apa pun — bold/italic/spoiler/blockquote/emoji premium — akan dipertahankan persis, dikirim dengan metode copy), atau kirim foto/video/dokumen dengan caption.\n\nMengirim pesan baru akan menggantikan pesan lama.');});
const forwardHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_message_forward','↪️ Forward satu pesan dari channel/grup ke chat ini.\n\nJika userbot belum bergabung ke chat asal, ia akan otomatis bergabung (khusus channel/grup publik) agar pesan ini bisa dikirim ke semua target.');});
// "🗑️ Hapus Pesan": explicit, real delete for whatever is currently
// configured (text/media/forward) — also cleans up the media file on disk
// so switching kinds never leaves orphaned files behind. Auto Promosi
// already refuses to run with no message configured (see startHandler),
// so this correctly and safely disables sending until a new message is set.
const deleteMessageHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  const m=panelConfigFor(ctx).getMessage(s.asset.id);
  if(!m){await replyPanelTemplate(ctx,panelTpl.messageEmpty);return;}
  panelConfigFor(ctx).safeDeleteMedia(m.media_path);
  panelConfigFor(ctx).clearMessage(s.asset.id);
  assetRepoFor(ctx).updateConfig(s.asset.id,{watermark:null});
  await replyPanelTemplate(ctx,panelTpl.messageDeleted);
});
const viewMessageHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;const m=panelConfigFor(ctx).getMessage(s.asset.id);
  if(!m){await replyPanelTemplate(ctx,panelTpl.messageEmpty);return;}
  const entities=(()=>{try{return JSON.parse(m.entities||'[]')}catch(_){return []}})();
  const captionEntities=(()=>{try{return JSON.parse(m.caption_entities||'[]')}catch(_){return []}})();
  if(m.kind==='media'&&m.media_path&&fs.existsSync(m.media_path)){
    const opts={caption:m.text||undefined,caption_entities:captionEntities.length?captionEntities:undefined};
    if(m.media_type==='photo')await ctx.replyWithPhoto({source:m.media_path},opts);
    else if(m.media_type==='video')await ctx.replyWithVideo({source:m.media_path},opts);
    else if(m.media_type==='audio')await ctx.replyWithAudio({source:m.media_path},opts);
    else if(m.media_type==='animation')await ctx.replyWithAnimation({source:m.media_path},opts);
    else if(m.media_type==='voice')await ctx.replyWithVoice({source:m.media_path},opts);
    else await ctx.replyWithDocument({source:m.media_path,filename:m.file_name||undefined},opts);
    return;
  }
  if(m.kind==='forward'){
    try {
      const preview=await userbotRuntime.getForwardPreview(panelKind(ctx),s.asset.id);
      if(preview?.text){
        const extra=preview.hasMedia?'\n📎 Media: ya':'';
        const c = userResponseTpl.panelForwardPreviewText.getContent(ctx, {
          placeholderValues: {
            pesan: preview.text,
            media: extra,
            asal: preview.sourceChatId || '-',
            message_id: String(preview.sourceMessageId || '-'),
          },
        });
        await ctx.reply(c.text, buildReplyOptions(c));
      } else {
        const c = userResponseTpl.panelForwardPreviewMedia.getContent(ctx, {
          placeholderValues: {
            asal: preview?.sourceChatId || '-',
            message_id: String(preview?.sourceMessageId || m.source_message_id || '-'),
          },
        });
        await ctx.reply(c.text, buildReplyOptions(c));
      }
    } catch (err) {
      const c = userResponseTpl.panelForwardPreviewUnavailable.getContent(ctx, {
        placeholderValues: {
          asal: m.source_chat_id || '-',
          message_id: String(m.source_message_id || '-'),
        },
      });
      await ctx.reply(c.text, buildReplyOptions(c));
    }
    return;
  }
  await ctx.reply(m.text||'',entities.length?{entities}:undefined);
});

// "🌐 Topik Grup": scans the userbot's real dialogs for forum (topic-enabled)
// supergroups and registers each one as a promo target with a real,
// currently-open topic id — fully automatic, nothing to type. Re-running
// this later also refreshes the topic id for groups whose open topic has
// since changed (e.g. the previous one got closed).
const topicGroupHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  await replyPanelTemplate(ctx,panelTpl.groupScanForumStart);
  let found;
  try { found = await userbotRuntime.scanGroups(panelKind(ctx), s.asset.id); }
  catch (err) { await replyPanelError(ctx,panelTpl.groupScanFailed,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}}); return; }
  const forums = found.filter((g) => g.isForum);
  if (!forums.length) {
    await replyPanelTemplate(ctx,panelTpl.groupForumEmpty);
    return;
  }
  const existing = new Map(panelConfigFor(ctx).listGroups(s.asset.id).map((g) => [g.target, g]));
  let added=0, updated=0;
  for (const g of forums) {
    const cur = existing.get(g.target);
    if (cur && Number(cur.topic_id) === Number(g.topicId)) continue;
    panelConfigFor(ctx).addGroup(s.asset.id, g.target, g.title, g.topicId);
    if (cur) updated++; else added++;
  }
  await replyPanelTemplate(ctx,panelTpl.groupForumResult,{placeholderValues:{hasil:`🔎 ${forums.length} grup topik ditemukan.\n✅ ${added} baru dijadikan target.\n♻️ ${updated} target topik diperbarui.\n⚪ ${forums.length-added-updated} sudah sesuai (tidak berubah).\n\nSetiap target otomatis mengarah ke topic yang sedang terbuka di grup masing-masing.`}});
  await groupHandler(ctx);
});
// "💡 Tambah Grup": scans the userbot's real dialogs for every group/channel
// it is a member of and registers the ones not already configured as promo
// targets — fully automatic, nothing to type. Forum groups discovered here
// get their topic auto-detected too, so a freshly-added topic group can be
// sent to immediately without a separate 🌐 Topik Grup pass.
// "💡 Tambah Grup": two real passes over the userbot's live Telegram
// session in one connection.
// 1) Validate every already-saved target: if the userbot is no longer a
//    member (left/kicked/chat gone), that row is a dead target and is
//    removed so it stops being treated as active — this is the "grup lama
//    otomatis tergantikan" requirement. Ambiguous/transient errors never
//    remove a row.
// 2) Scan current dialogs for real GROUP/SUPERGROUP dialogs (never
//    broadcast channels — see isRealGroupEntity in userbotRuntime) and
//    register the ones not already configured.
// Forum groups discovered here get their topic auto-detected too, so a
// freshly-added topic group can be sent to immediately without a separate
// 🌐 Topik Grup pass.
const addGroupHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  await replyPanelTemplate(ctx,panelTpl.groupScanStart);

  let validation;
  try { validation = await userbotRuntime.validateGroupTargets(panelKind(ctx), s.asset.id); }
  catch (err) { await replyPanelError(ctx,panelTpl.groupValidateFailed,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}}); return; }
  const removed=validation.invalid.length;

  let found;
  try { found = await userbotRuntime.scanGroups(panelKind(ctx), s.asset.id); }
  catch (err) { await replyPanelError(ctx,panelTpl.groupScanFailed,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}}); return; }
  if (!found.length && !removed) {
    await replyPanelTemplate(ctx,panelTpl.groupScanEmpty);
    return;
  }
  const existing = new Set(panelConfigFor(ctx).listGroups(s.asset.id).map((g) => g.target));
  let added=0, skipped=0, topics=0;
  for (const g of found) {
    if (existing.has(g.target)) { skipped++; continue; }
    panelConfigFor(ctx).addGroup(s.asset.id, g.target, g.title, g.isForum ? g.topicId : null);
    added++;
    if (g.isForum) topics++;
  }
  await replyPanelTemplate(ctx,panelTpl.groupScanResult,{placeholderValues:{hasil:`🔎 ${found.length} grup ditemukan di chat userbot.\n✅ ${added} baru ditambahkan sebagai target${topics ? ` (${topics} di antaranya grup topik, topic otomatis terdeteksi)` : ''}.\n⚪ ${skipped} sudah ada sebelumnya (dilewati, tidak diubah).${removed ? `\n♻️ ${removed} target lama yang sudah tidak dapat diakses userbot telah dihapus otomatis.` : ''}`}});
  await groupHandler(ctx);
});
// "❌ Hapus Grup": button-driven, no manual ID typing. Shows every saved
// target as its own button; tapping one goes straight to a confirmation
// screen, then deletes by the real panel_groups.id (never by label text or
// list position — see groupDeleteConfirmCallback below).
const GROUP_DELETE_PAGE_SIZE = 10;
function groupDeleteView(ctx, page = 0) {
  const s = selected(ctx); if (!s) return null;
  const cfg = panelConfigFor(ctx);
  const total = Number(cfg.countGroups(s.asset.id));
  const totalPages = Math.max(1, Math.ceil(total / GROUP_DELETE_PAGE_SIZE));
  const safePage = Math.min(Math.max(0, Number(page) || 0), totalPages - 1);
  const rows = cfg.listGroupsPage(s.asset.id, safePage * GROUP_DELETE_PAGE_SIZE, GROUP_DELETE_PAGE_SIZE);
  return { s, rows, total, page: safePage, totalPages };
}
const deleteGroupHandler=safeHandler(async ctx=>{
  const view=groupDeleteView(ctx,0);
  if(!view || !view.total){await replyPanelTemplate(ctx,panelTpl.groupEmpty);return;}
  const c=panelContent(panelTpl.groupDeletePrompt,ctx,{placeholderValues:{halaman:`${view.page+1}/${view.totalPages}`}});
  await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupDeleteListKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
});
const groupDeletePageCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  const parts=String(ctx.callbackQuery?.data||'').split(':'); const userbotId=Number(parts[2]); const page=Number(parts[3]);
  const current=panelState.get(ctx.from.id);
  if(!current || Number(current.id)!==userbotId || !['owned','pool'].includes(current.kind)){await ctx.reply('❌ Akses daftar grup tidak valid.');return;}
  const view=groupDeleteView(ctx,page);
  if(!view || !view.total){const c=panelContent(panelTpl.groupEmpty,ctx);await renderScreen(ctx,c.text,buildReplyOptions(c),'panel');return;}
  const c=panelContent(panelTpl.groupDeletePrompt,ctx,{placeholderValues:{halaman:`${view.page+1}/${view.totalPages}`}});
  await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupDeleteListKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
});
const groupDeleteSelectCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  const s=selected(ctx); if(!s)return;
  const callbackParts=String(ctx.callbackQuery.data).split(':');
  const groupId=Number(callbackParts[2]);
  const page=Number(callbackParts[3]) || 0;
  const row=panelConfigFor(ctx).listGroups(s.asset.id).find(g=>g.id===groupId);
  if(!row){const c=panelContent(panelTpl.groupDeleteMissing,ctx);await renderScreen(ctx, c.text, buildReplyOptions(c), 'panel');return;}
  {const c=panelContent(panelTpl.groupDeleteConfirm,ctx,{placeholderValues:{hasil:row.title||row.target}});await renderScreen(ctx, c.text, {...buildReplyOptions(c),...groupDeleteConfirmKeyboard(row.id,page)}, 'panel');}
});
// panelgrp:delconfirm:<groupRowId> — confirmed, delete by primary key.
const groupDeleteConfirmCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  const s=selected(ctx); if(!s)return;
  const callbackParts=String(ctx.callbackQuery.data).split(':');
  const groupId=Number(callbackParts[2]);
  const page=Number(callbackParts[3]) || 0;
  const changes=panelConfigFor(ctx).deleteGroup(s.asset.id,groupId);
  const view=groupDeleteView(ctx,page);
  if(!view || !view.total){const c=panelContent(changes?panelTpl.groupDeleted:panelTpl.groupDeleteMissing,ctx);await renderScreen(ctx,c.text,buildReplyOptions(c),'panel');return;}
  const c=panelContent(panelTpl.groupDeletePrompt,ctx,{placeholderValues:{halaman:`${view.page+1}/${view.totalPages}`}});
  await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupDeleteListKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
});
// panelgrp:delall — asks for confirmation before wiping every saved target.
const groupDeleteAllCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  const s=selected(ctx); if(!s)return;
  const rows=panelConfigFor(ctx).listGroups(s.asset.id);
  if(!rows.length){const c=panelContent(panelTpl.groupEmpty,ctx);await renderScreen(ctx, c.text, buildReplyOptions(c), 'panel');return;}
  {const c=panelContent(panelTpl.groupDeleteAllConfirm,ctx,{placeholderValues:{jumlah:String(rows.length)}});await renderScreen(ctx, c.text, {...buildReplyOptions(c),...groupDeleteAllConfirmKeyboard()}, 'panel');}
});
// panelgrp:delallconfirm — deletes only this userbot's panel_groups rows;
// scope enforced in panelConfigFor(ctx).deleteAllGroups (userbot/order/product/user
// data are untouched).
const groupDeleteAllConfirmCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  const s=selected(ctx); if(!s)return;
  const changes=panelConfigFor(ctx).deleteAllGroups(s.asset.id);
  {const c=panelContent(panelTpl.groupDeleteAllResult,ctx,{placeholderValues:{jumlah:String(changes)}});await renderScreen(ctx, c.text, buildReplyOptions(c), 'panel');}
  await groupHandler(ctx);
});
const groupDeleteCancelCallback=safeHandler(async ctx=>{
  await answerCancelled(ctx);
  const s=selected(ctx); if(!s)return;
  await groupHandler(ctx);
});
// "📋 Daftar Grup": bounded, current read of configured targets. The list is
// deliberately paged at the data/query boundary so large configurations are
// never materialized into one Telegram message. The same implementation is
// used by owned and pool userbots through their existing panel-config adapter.
const GROUP_LIST_PAGE_SIZE = 10;
const GROUP_LIST_TITLE_MAX = 120;
function compactGroupTitle(value) {
  const text = String(value || '').replace(/[\r\n]+/g, ' ').trim();
  if (text.length <= GROUP_LIST_TITLE_MAX) return text;
  return `${text.slice(0, GROUP_LIST_TITLE_MAX - 1)}…`;
}
function groupListView(ctx, page = 0) {
  const s = selected(ctx);
  if (!s) return null;
  const cfg = panelConfigFor(ctx);
  const total = Number(cfg.countGroups(s.asset.id));
  const totalPages = Math.max(1, Math.ceil(total / GROUP_LIST_PAGE_SIZE));
  const safePage = Math.min(Math.max(0, Number(page) || 0), totalPages - 1);
  const rows = cfg.listGroupsPage(s.asset.id, safePage * GROUP_LIST_PAGE_SIZE, GROUP_LIST_PAGE_SIZE);
  return { s, rows, total, page: safePage, totalPages };
}
function groupListText(ctx, view) {
  const list = view.rows.map(g => `#${g.id} ${g.enabled ? '🟢' : '⚪'} ${compactGroupTitle(g.title || g.target)}${g.topic_id ? ` (topic ${g.topic_id})` : ''}`).join('\n');
  const c = panelContent(panelTpl.groupList, ctx, { placeholderValues: { jumlah: String(view.total), halaman: `${view.page + 1}/${view.totalPages}`, group_list: list } });
  return c;
}
const groupListHandler=safeHandler(async ctx=>{
  const view = groupListView(ctx, 0);
  if (!view) return;
  if (!view.total) { await replyPanelTemplate(ctx, panelTpl.groupListEmpty); return; }
  const c = groupListText(ctx, view);
  await ctx.reply(c.text, { ...buildReplyOptions(c), ...groupListPaginationKeyboard(view.s.asset.id, view.page, view.totalPages) });
});
const groupListPageCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  const parts = String(ctx.callbackQuery?.data || '').split(':');
  const userbotId = Number(parts[2]);
  const page = Number(parts[3]);
  if (!Number.isInteger(userbotId) || userbotId <= 0 || !Number.isInteger(page) || page < 0) return;
  const current = panelState.get(ctx.from.id);
  if (!current || Number(current.id) !== userbotId || !['owned','pool'].includes(current.kind)) {
    await ctx.reply('❌ Akses daftar grup tidak valid.');
    return;
  }
  const view = groupListView(ctx, page);
  if (!view) return;
  if (!view.total) { await renderScreen(ctx, panelContent(panelTpl.groupListEmpty, ctx).text, buildReplyOptions(panelContent(panelTpl.groupListEmpty, ctx)), 'panel'); return; }
  const c = groupListText(ctx, view);
  await renderScreen(ctx, c.text, { ...buildReplyOptions(c), ...groupListPaginationKeyboard(view.s.asset.id, view.page, view.totalPages) }, 'panel');
});
const groupListRefreshCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery('Memperbarui daftar grup…');
  const parts = String(ctx.callbackQuery?.data || '').split(':');
  const userbotId = Number(parts[2]);
  const page = Number(parts[3]);
  if (!Number.isInteger(userbotId) || userbotId <= 0 || !Number.isInteger(page) || page < 0) return;
  const current = panelState.get(ctx.from.id);
  if (!current || Number(current.id) !== userbotId || !['owned','pool'].includes(current.kind)) {
    await ctx.reply('❌ Akses daftar grup tidak valid.');
    return;
  }
  const view = groupListView(ctx, page);
  if (!view) return;
  if (!view.total) { const empty = panelContent(panelTpl.groupListEmpty, ctx); await renderScreen(ctx, empty.text, buildReplyOptions(empty), 'panel'); return; }
  const c = groupListText(ctx, view);
  await renderScreen(ctx, c.text, { ...buildReplyOptions(c), ...groupListPaginationKeyboard(view.s.asset.id, view.page, view.totalPages) }, 'panel');
});
const groupListBackCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery();
  await groupHandler(ctx);
});
const joinGroupHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_join_group','🔗 Kirim username/link/ID grup yang ingin dimasuki userbot.');});
const LEAVE_GROUP_PAGE_SIZE = 10;
function leaveGroupListText(ctx, view) {
  const list=view.rows.map(g=>`#${g.id} ${g.title || g.target}${g.reason ? `\n   ⚠️ ${g.reason}` : ''}`).join('\n\n');
  return panelContent(panelTpl.groupLeaveList,ctx,{placeholderValues:{jumlah:String(view.total),halaman:`${view.page+1}/${view.totalPages}`,group_list:list}});
}
async function loadLeaveGroupScan(ctx, force=false) {
  const s=selected(ctx); if(!s) return null;
  const existing=panelState.get(ctx.from.id)?.leaveGroupScan;
  if(!force && existing && Number(existing.userbotId)===Number(s.asset.id) && existing.kind===panelKind(ctx) && Array.isArray(existing.rows)) return existing.rows;
  const rows=await userbotRuntime.scanUnusableGroups(panelKind(ctx),s.asset.id);
  panelState.set(ctx.from.id,{leaveGroupScan:{kind:panelKind(ctx),userbotId:Number(s.asset.id),rows}});
  return rows;
}
function leaveGroupView(ctx,page=0,rows=null){
  const s=selected(ctx); if(!s) return null;
  const all=rows || panelState.get(ctx.from.id)?.leaveGroupScan?.rows || [];
  const total=all.length; const totalPages=Math.max(1,Math.ceil(total/LEAVE_GROUP_PAGE_SIZE));
  const safePage=Math.min(Math.max(0,Number(page)||0),totalPages-1);
  return {s,rows:all.slice(safePage*LEAVE_GROUP_PAGE_SIZE,(safePage+1)*LEAVE_GROUP_PAGE_SIZE),total,page:safePage,totalPages};
}
const leaveGroupHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  try{
    const rows=await loadLeaveGroupScan(ctx,true); const view=leaveGroupView(ctx,0,rows);
    if(!view || !view.total){await replyPanelTemplate(ctx,panelTpl.groupLeaveEmpty);return;}
    const c=leaveGroupListText(ctx,view);
    await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupLeavePaginationKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
  }catch(err){await replyPanelError(ctx,panelTpl.groupScanFailed,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}});}
});
const groupLeavePageCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery(); const parts=String(ctx.callbackQuery?.data||'').split(':'); const userbotId=Number(parts[2]); const page=Number(parts[3]);
  const current=panelState.get(ctx.from.id); if(!current || Number(current.id)!==userbotId || !['owned','pool'].includes(current.kind)){await ctx.reply('❌ Akses daftar grup tidak valid.');return;}
  const rows=await loadLeaveGroupScan(ctx,false); const view=leaveGroupView(ctx,page,rows);
  if(!view || !view.total){const c=panelContent(panelTpl.groupLeaveEmpty,ctx);await renderScreen(ctx,c.text,buildReplyOptions(c),'panel');return;}
  const c=leaveGroupListText(ctx,view); await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupLeavePaginationKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
});
const groupLeaveRefreshCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery('Memperbarui scan grup…'); const parts=String(ctx.callbackQuery?.data||'').split(':'); const userbotId=Number(parts[2]); const page=Number(parts[3]);
  const current=panelState.get(ctx.from.id); if(!current || Number(current.id)!==userbotId || !['owned','pool'].includes(current.kind)){await ctx.reply('❌ Akses daftar grup tidak valid.');return;}
  const rows=await loadLeaveGroupScan(ctx,true); const view=leaveGroupView(ctx,page,rows);
  if(!view || !view.total){const c=panelContent(panelTpl.groupLeaveEmpty,ctx);await renderScreen(ctx,c.text,buildReplyOptions(c),'panel');return;}
  const c=leaveGroupListText(ctx,view); await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupLeavePaginationKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
});
const groupLeaveSelectCallback=safeHandler(async ctx=>{
  await ctx.answerCbQuery(); const parts=String(ctx.callbackQuery?.data||'').split(':'); const userbotId=Number(parts[2]); const targetId=parts[3];
  const current=panelState.get(ctx.from.id); if(!current || Number(current.id)!==userbotId || !['owned','pool'].includes(current.kind)){await ctx.reply('❌ Akses keluar grup tidak valid.');return;}
  const rows=await loadLeaveGroupScan(ctx,false); const row=rows.find(g=>String(g.id)===String(targetId)); if(!row)return;
  try{
    await userbotRuntime.leaveGroup(panelKind(ctx),userbotId,row.id);
    const nextRows=rows.filter(g=>String(g.id)!==String(targetId)); panelState.set(ctx.from.id,{leaveGroupScan:{kind:panelKind(ctx),userbotId,rows:nextRows}});
    const view=leaveGroupView(ctx,0,nextRows); if(!view.total){const c=panelContent(panelTpl.groupLeaveEmpty,ctx);await renderScreen(ctx,c.text,buildReplyOptions(c),'panel');return;}
    const c=leaveGroupListText(ctx,view); await renderScreen(ctx,c.text,{...buildReplyOptions(c),...groupLeavePaginationKeyboard(view.rows,view.page,view.totalPages,view.s.asset.id)},'panel');
  }catch(err){logger.warn(`Leave group ${panelKind(ctx)}:${userbotId}:${targetId}: ${err.message}`);}
});
const groupLeaveBackCallback=safeHandler(async ctx=>{await ctx.answerCbQuery();panelState.set(ctx.from.id,{leaveGroupScan:null});await groupHandler(ctx);});
// Toggle only changes the flag; the status line on the delay screen shows the result.
const smartDelayToggleHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  const kind=panelState.get(ctx.from.id).kind;
  const range=delayPolicy.readGroupDelayRange(panelConfigFor(ctx).getSettings(s.asset.id),panelConfigFor(ctx).RECOMMENDED_GROUP_DELAY_SECONDS);
  const enabled=smartDelay.isEnabled(kind,s.asset.id);
  smartDelay.setEnabled(kind,s.asset.id,!enabled,range);
  await delayHandler(ctx);
});
const groupDelayHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  const current=panelConfigFor(ctx).getSettings(s.asset.id);
  const range = delayPolicy.readGroupDelayRange(current, panelConfigFor(ctx).RECOMMENDED_GROUP_DELAY_SECONDS);
  const rangeText = delayPolicy.formatGroupDelayRange(range);
  await ask(ctx,'await_group_delay','',{ placeholderValues: { pesan: `⏱️ Jeda antar grup saat ini: ${rangeText} detik${range.min===range.max?' (tetap)':' (acak setiap pindah grup)'}.\n\n💡 Rekomendasi awal: ${panelConfigFor(ctx).RECOMMENDED_GROUP_DELAY_SECONDS} detik (tetap kompatibel untuk user yang belum pernah mengubah pengaturan).\n\nKirim range baru, contoh: 1-20, 5-15s, 1m-2m. Setiap perpindahan grup akan melakukan sampling baru dari range tersebut.\n\nKirim satu angka untuk jeda tetap, "default" untuk rekomendasi, atau 0/off untuk tanpa jeda.` } });
});
const roundDelayHandler=safeHandler(async ctx=>{
  const s=selected(ctx); if(!s)return;
  const current=panelConfigFor(ctx).getSettings(s.asset.id);
  await ask(ctx,'await_round_delay',`✨ Jeda antar putaran saat ini: ${Number(current.round_delay_seconds||0)} detik (tetap).\n\n💡 Rekomendasi: ${panelConfigFor(ctx).RECOMMENDED_ROUND_DELAY_SECONDS} detik / ${Math.round(panelConfigFor(ctx).RECOMMENDED_ROUND_DELAY_SECONDS/60)} menit (tetap sesuai nilai konfigurasi).\n\nKirim durasi baru, contoh: 60, 5m, 1h. Nilai ini tidak diacak dan dipakai tetap setelah setiap putaran selesai.\n\nKirim "default" untuk kembali ke rekomendasi. Minimal 10 detik agar putaran tidak berjalan terus-menerus.`);
});

const broadcastPmHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_broadcast_pm','📄 Kirim SATU pesan yang akan dibroadcast ke semua chat private userbot.\n\nBisa: teks biasa (format + emoji premium dipertahankan), media, atau forward. Tidak perlu memasukkan target.');});
const pmPermitHandler=safeHandler(async ctx=>{const s=selected(ctx);if(!s)return;const next=!Boolean(s.asset.pm_permit);if(next){await ask(ctx,'await_pm_permit_text','🛡️ Kirim teks balasan otomatis PM Permit. Format teks dan emoji premium akan dipertahankan.');return;}assetRepoFor(ctx).setFlags(s.asset.id,{pmPermit:false});await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));await replyPanelTemplate(ctx,panelTpl.pmPermitOff);});
const adminPanelHandler=safeHandler(async ctx=>{if(!isAdminId(ctx.from.id)){await ctx.reply('❌ Hanya admin yang dapat membuka Panel Admin.');return;}return require('./admin/adminPanel.handler').adminPanelHandler(ctx);});
// Submenu "⏰ Timer": status + "Atur Jam" + Aktifkan/Nonaktifkan toggle.
// Jam aktif (WIB) is kept while Timer is disabled; only its enforcement stops.
const timerHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  makeScreen(ctx,'timer');
  const asset=assetRepoFor(ctx).findById(s.asset.id)||s.asset;
  const hasWindow=Boolean(asset.timer_config);
  const enabled=hasWindow && asset.timer_enabled!==0;
  const status=!hasWindow?'⚪ Belum diatur (selalu aktif)':(enabled?'🟢 AKTIF':'❌ NONAKTIF (selalu aktif)');
  const content=panelContent(panelTpl.timerScreen,ctx,{placeholderValues:{status,jam:hasWindow?asset.timer_config:'-'}});
  await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...timerKeyboard(enabled)});
});
const timerSetHandler=safeHandler(async ctx=>{if(!selected(ctx))return;makeScreen(ctx,'timer');await ask(ctx,'await_timer','⏰ Atur jam aktif Jaseb dalam WIB/Jakarta. Format HH:MM-HH:MM, contoh 08:00-22:00. Ketik "off" untuk selalu aktif.');});
const timerEnableHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  const asset=assetRepoFor(ctx).findById(s.asset.id)||s.asset;
  if(!asset.timer_config){await replyPanelError(ctx,panelTpl.timerNoWindow);return;}
  assetRepoFor(ctx).updateConfig(s.asset.id,{timer_enabled:true});
  await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
  await timerHandler(ctx);
});
const timerDisableHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  assetRepoFor(ctx).updateConfig(s.asset.id,{timer_enabled:false});
  await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
  await timerHandler(ctx);
});
// "🪽 Backup Token" submenu: token-free status (rendered WITH ctx so every
// {placeholder} is resolved) plus a button to issue a new token. The token is
// stored only as a hash and is never re-displayed.
const backupTokenHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  const status=backupTokenSvc.getStatus({actorId:ctx.from.id,userbotId:s.asset.id});
  if(!status.ok){await replyPanelTemplate(ctx,panelTpl.accountOwnership);return;}
  makeScreen(ctx,'backup_token');
  const content=backupStatusContent(ctx,s.asset.label,status);
  await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...backupTokenKeyboard()});
});
// Step 1 of "Buat Token Baru": explicit warning + confirm button (no typed code).
const backupTokenNewHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  makeScreen(ctx,'backup_token');
  await renderWithReplyKeyboard(ctx,'⚠️ Membuat token baru akan membuat token lama langsung tidak berlaku.\n\nTekan ✅ Ya, Buat Token Baru untuk melanjutkan, atau Kembali untuk membatalkan.',{...backupTokenConfirmKeyboard()});
});
// Step 2: rotate the token and deliver it once.
const backupTokenConfirmHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  const out=backupTokenSvc.regenerate({actorId:ctx.from.id,userbotId:s.asset.id});
  if(!out.ok){await replyPanelError(ctx,out.reason==='expired'?panelTpl.tokenExpired:panelTpl.tokenCreateFailed);await backupTokenHandler(ctx);return;}
  const tokenContent=newTokenNoticeContent(ctx,out.token);
  await ctx.reply(tokenContent.text,buildReplyOptions(tokenContent));
  await backupTokenHandler(ctx);
});
const customWmHandler=safeHandler(async ctx=>{if(!selected(ctx))return;makeScreen(ctx,'watermark');await ask(ctx,'await_custom_wm','💧 Kirim teks watermark. Ketik "off" untuk menghapus.');});
// Submenu "💧 Watermark": status (aktif/nonaktif + teks) with "Atur WM" and a
// single Aktifkan/Nonaktifkan toggle. Status is always read back from the DB,
// never from the tapped label.
const watermarkHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  makeScreen(ctx,'watermark');
  const asset=assetRepoFor(ctx).findById(s.asset.id)||s.asset;
  const hasText=Boolean(asset.watermark);
  const enabled=hasText && asset.watermark_enabled!==0;
  const status=!hasText?'⚪ Belum diatur':(enabled?'🟢 AKTIF':'❌ NONAKTIF');
  const content=panelContent(panelTpl.watermarkScreen,ctx,{placeholderValues:{status,teks:hasText?asset.watermark:'-'}});
  await renderWithReplyKeyboard(ctx,content.text,{...buildReplyOptions(content),...watermarkKeyboard(enabled)});
});
const watermarkEnableHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  const asset=assetRepoFor(ctx).findById(s.asset.id)||s.asset;
  if(!asset.watermark){await replyPanelError(ctx,panelTpl.watermarkNoText);return;}
  assetRepoFor(ctx).updateConfig(s.asset.id,{watermark_enabled:true});
  await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
  await watermarkHandler(ctx);
});
const watermarkDisableHandler=safeHandler(async ctx=>{
  const s=selected(ctx);if(!s)return;
  assetRepoFor(ctx).updateConfig(s.asset.id,{watermark_enabled:false});
  await userbotRuntime.syncAsset(panelKind(ctx),s.asset.id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
  await watermarkHandler(ctx);
});
// "🔥 Cek Token": validate a pasted token through the SAME canonical rules the
// claim/recovery flow uses (services/backupToken.service.js#inspect).
const checkTokenHandler=safeHandler(async ctx=>{
  if(!selected(ctx))return;
  await ask(ctx,'await_check_token','🔥 Cek Token\n\nKirim token backup yang ingin diperiksa. Pesan berisi token akan dihapus otomatis dari chat ini.');
});
const transferHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_transfer','🔄 Kirim @username atau Telegram ID user tujuan. User tujuan wajib sudah terdaftar di bot.');});
const resetDataHandler=safeHandler(async ctx=>{if(!selected(ctx))return;await ask(ctx,'await_reset_data','🗑️ Ini menghapus grup, pesan, reply, dan setting panel. Ketik RESET untuk konfirmasi.');});

function parseDurationSeconds(raw, opts = {}) {
  const value=String(raw||'').trim().toLowerCase();
  if(opts.allowZero && (value==='0'||value==='off'||value==='none')) return 0;
  const m=value.match(/^(\d+(?:\.\d+)?)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|h|hr|hrs|hour|hours)?$/);
  if(!m) return null;
  let n=Number(m[1]);
  const unit=m[2]||'s';
  if(unit.startsWith('m')) n*=60;
  else if(unit.startsWith('h')) n*=3600;
  if(!Number.isFinite(n) || !Number.isInteger(n)) return null;
  if(opts.min!==undefined && n<opts.min) return null;
  if(opts.max!==undefined && n>opts.max) return null;
  return n;
}

function parseTimerConfig(raw) {
  const v=String(raw||'').trim();
  if(v.toLowerCase()==='off') return null;
  const m=v.match(/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/);
  if(!m) return false;
  const nums=m.slice(1).map(Number);
  if(nums[0]>23||nums[2]>23||nums[1]>59||nums[3]>59) return false;
  return v;
}

function findRegisteredUser(query) {
  const q=String(query||'').trim().replace(/^@/,'');
  if(/^\d+$/.test(q)) return userRepository.findByTelegramId(Number(q));
  return userRepository.search(q,0,10).find(u=>String(u.username||'').toLowerCase()===q.toLowerCase()) || null;
}

async function handleStepInput(ctx,state,text){
  // Retry UX: a "❌ ..." validation/error reply sent while the SAME step is
  // still active carries that step's keyboard (Kembali / Batal).
  const originalReply = ctx.reply;
  ctx.reply = function stepReply(message, extra, ...rest) {
    const cur = panelState.get(ctx.from.id);
    const isError = typeof message === 'string' && message.trimStart().startsWith('❌');
    if (cur && cur.step === state.step && isError && !(extra && extra.reply_markup)) {
      // Preserve the correct keyboard for the step type on validation errors.
      const errKb = MULTI_STEP_INPUTS.has(cur.step) ? panelInputKeyboard() : panelCancelKeyboard();
      return originalReply.call(this, message, { ...(extra || {}), ...errKb }, ...rest);
    }
    return originalReply.call(this, message, extra, ...rest);
  };
  let handled;
  try { handled = await runStepInput(ctx,state,text); } finally { ctx.reply = originalReply; }
  if (handled) await settleAfterStep(ctx);
  return handled;
}

async function runStepInput(ctx,state,text){
  const s=selected(ctx); if(!s)return true; const id=s.asset.id;
  if(await enforceStepFeature(ctx,s.asset,state.step)) return true;
  try{
    switch(state.step){
      // Legacy one-line format, kept working in case anything still
      // routes here directly: "keyword1,keyword2 | teks balasan".
      case 'await_add_reply': {const m=text.split('|');if(m.length<2){await replyPanelError(ctx,panelTpl.replyFormatError);return true;}panelConfigFor(ctx).addReply(id,m[0],m.slice(1).join('|').trim());await replyPanelTemplate(ctx,panelTpl.replyAdded);panelState.clearStep(ctx.from.id);await baseReplyHandler(ctx);return true;}
      case 'await_add_reply_keyword': {
        const keywords=text.trim();
        if(!keywords){await replyPanelError(ctx,panelTpl.replyKeywordEmpty);return true;}
        panelState.set(ctx.from.id,{pendingReplyKeywords:keywords});
        await ask(ctx,'await_add_reply_text','',{ placeholderValues: { keyword: keywords } });
        return true;
      }
      case 'await_add_reply_text': {
        const st=panelState.get(ctx.from.id);
        const keywords=st && st.pendingReplyKeywords;
        if(!keywords){panelState.clearStep(ctx.from.id);await replyPanelError(ctx,panelTpl.replySessionExpired);await baseReplyHandler(ctx);return true;}
        // Keep the raw, untrimmed text alongside its ORIGINAL entities:
        // ctx.message.entities offsets are computed by Telegram against
        // ctx.message.text as sent, so trimming (or any other rebuild of
        // the string) before storing would shift every bold/italic/custom
        // emoji entity off its real character range. Only whitespace-only
        // input is rejected, exactly as before.
        const response=text;
        if(!response.trim()){await replyPanelError(ctx,panelTpl.replyTextEmpty);return true;}
        const entities=Array.isArray(ctx.message?.entities)?ctx.message.entities:[];
        panelConfigFor(ctx).addReply(id,keywords,response,entities);
        panelState.set(ctx.from.id,{pendingReplyKeywords:null});
        panelState.clearStep(ctx.from.id);
        await replyPanelTemplate(ctx,panelTpl.replyAddedDetail,{placeholderValues:{keyword:keywords,response:{text:response,entities}}});
        await baseReplyHandler(ctx);
        return true;
      }
      case 'await_delete_reply': panelConfigFor(ctx).deleteReply(id,text.trim());await replyPanelTemplate(ctx,panelTpl.replyDeleted);panelState.clearStep(ctx.from.id);await baseReplyHandler(ctx);return true;
      case 'await_wtb_timer': {panelConfigFor(ctx).updateSettings(id,{wtb_timer:text.trim().toLowerCase()==='off'?null:text.trim()});panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.wtbTimerSaved);return true;}
      case 'await_auto_reset': {const raw=text.trim();if(!/^\d+$/.test(raw)){await replyPanelError(ctx,panelTpl.autoResetInvalid);return true;}const n=Number(raw);if(!Number.isSafeInteger(n)||n<1||n>panelConfigFor(ctx).MAX_WTB_COOLDOWN_MINUTES){await replyPanelError(ctx,panelTpl.autoResetInvalid);return true;}panelConfigFor(ctx).updateSettings(id,{wtb_auto_reset_minutes:n});panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.autoResetSaved);return true;}
      case 'await_react_emoji': {const emoji=text.trim();if(!emoji||emoji.length>16){await replyPanelError(ctx,panelTpl.reactInvalid);return true;}panelConfigFor(ctx).updateSettings(id,{auto_react_emoji:emoji});panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.reactSaved,{placeholderValues:{pesan:emoji}});await autoReactHandler(ctx);return true;}
      case 'await_global_text': {
        // This writes to the SAME panel_messages row that the outgoing
        // Auto Promosi/PM broadcast pipeline (sendConfiguredMessage) reads
        // from, so it must capture ctx.message.entities exactly like
        // await_message_media does below — otherwise any bold/italic/...
        // /premium custom emoji typed here was silently discarded at save
        // time, before the message ever reached the send pipeline.
        if(!text.trim()){await replyPanelError(ctx,panelTpl.genericTextEmpty);return true;}
        const globalEntities=Array.isArray(ctx.message?.entities)?ctx.message.entities:[];
        panelConfigFor(ctx).setTextMessage(id,text,globalEntities);
        panelState.clearStep(ctx.from.id);
        await replyPanelTemplate(ctx,panelTpl.textSaved);
        await globalSettingsHandler(ctx);
        return true;
      }
      case 'await_target_channel': {const value=text.trim().toLowerCase()==='off'?null:text.trim();panelConfigFor(ctx).updateSettings(id,{wtb_target_channel:value});panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.targetChannelSaved);await globalSettingsHandler(ctx);return true;}
      case 'await_banned_words': {const value=text.trim().toLowerCase()==='off'?'':text.trim();panelConfigFor(ctx).updateSettings(id,{wtb_banned_words:value});panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.bannedWordsSaved);await globalSettingsHandler(ctx);return true;}
      case 'await_max_chars': {const n=Number(text.trim());if(!Number.isInteger(n)||n<0||n>4096){await replyPanelError(ctx,panelTpl.maxCharsInvalid);return true;}panelConfigFor(ctx).updateSettings(id,{wtb_max_chars:n});panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.maxCharsSaved,{placeholderValues:{pesan:String(n||'tanpa batas')}});await globalSettingsHandler(ctx);return true;}
      case 'await_pm_permit_text': {const value=text;if(!value.trim()){await replyPanelError(ctx,panelTpl.pmPermitTextEmpty);return true;}panelConfigFor(ctx).setPmPermitMessage(id,value,Array.isArray(ctx.message?.entities)?ctx.message.entities:[]);assetRepoFor(ctx).setFlags(id,{pmPermit:true});panelState.clearStep(ctx.from.id);const pmResult=await enableRuntimeFlag(id,()=>assetRepoFor(ctx).setFlags(id,{pmPermit:false}), panelKind(ctx), 'pm_permit');if(!pmResult.ok){await replyPanelError(ctx,panelTpl.pmPermitRuntimeFailed,{placeholderValues:{reason:pmResult.error||'Runtime menolak aktivasi.'}});return true;}await replyPanelTemplate(ctx,panelTpl.pmPermitActivated);return true;}
      case 'await_message_media': {
        const entities = Array.isArray(ctx.message?.entities) ? ctx.message.entities : [];
        panelConfigFor(ctx).setTextMessage(id, text, entities);
        panelState.clearStep(ctx.from.id);
        await replyPanelTemplate(ctx,panelTpl.messageSaved);
        return true;
      }
      case 'await_message_forward': return true;
      case 'await_join_group': {await userbotRuntime.joinGroup(panelKind(ctx),id,text.trim());panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.joinSuccess);return true;}
      case 'await_leave_group': {await userbotRuntime.leaveGroup(panelKind(ctx),id,text.trim());panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.leaveSuccess);return true;}
      case 'await_group_delay': {
        const isReset=['default','rekomendasi','reset'].includes(text.trim().toLowerCase());
        const range=isReset
          ? {min:panelConfigFor(ctx).RECOMMENDED_GROUP_DELAY_SECONDS,max:panelConfigFor(ctx).RECOMMENDED_GROUP_DELAY_SECONDS}
          : delayPolicy.parseGroupDelayRangeInput(text);
        if(!range){
          await replyPanelError(ctx,panelTpl.delayInvalid,{placeholderValues:{pesan:'Contoh: 1-20, 5-15s, 1m-2m. Satu angka juga valid untuk jeda tetap. Kirim "default" untuk rekomendasi, atau 0/off untuk tanpa jeda.'}});
          return true;
        }
        try {
          panelConfigFor(ctx).updateSettings(id,{group_delay_range:range});
        } catch(err) {
          await replyPanelError(ctx,panelTpl.delayInvalid,{placeholderValues:{pesan:'Range harus berupa angka bulat, tidak negatif, maksimum 86400 detik, dan nilai akhir harus >= nilai awal.'}});
          return true;
        }
        panelState.clearStep(ctx.from.id);
        await userbotRuntime.syncAsset(panelKind(ctx),id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
        const saved=delayPolicy.formatGroupDelayRange(range);
        const mode=range.min===range.max?'tetap':'acak setiap pindah grup';
        await replyPanelTemplate(ctx,panelTpl.delaySaved,{placeholderValues:{hasil:`Jeda antar grup disimpan: ${saved} detik (${mode})${isReset?' (rekomendasi).':'.'}`}});
        await delayHandler(ctx);
        return true;
      }
      case 'await_round_delay': {
        const isReset=['default','rekomendasi','reset'].includes(text.trim().toLowerCase());
        const n=isReset ? panelConfigFor(ctx).RECOMMENDED_ROUND_DELAY_SECONDS : parseDurationSeconds(text,{allowZero:false,min:10,max:604800});
        if(n===null){await replyPanelError(ctx,panelTpl.delayInvalid,{placeholderValues:{pesan:'Minimal 10 detik. Contoh: 60, 5m, 1h. Kirim "default" untuk rekomendasi.'}});return true;}
        panelConfigFor(ctx).updateSettings(id,{round_delay_seconds:n});
        panelState.clearStep(ctx.from.id);
        await userbotRuntime.syncAsset(panelKind(ctx),id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));
        await replyPanelTemplate(ctx,panelTpl.delaySaved,{placeholderValues:{hasil:`Jeda antar putaran disimpan: ${n} detik${isReset?' (rekomendasi).':'.'}`}});
        await delayHandler(ctx);
        return true;
      }
      case 'await_broadcast_pm': {const value=text; if(!value.trim()){await replyPanelError(ctx,panelTpl.broadcastEmpty);return true;} panelConfigFor(ctx).setBroadcastPmMessage(id,{kind:'text',text:value,entities:Array.isArray(ctx.message?.entities)?ctx.message.entities:[]}); panelState.clearStep(ctx.from.id); const r=await userbotRuntime.broadcastPm(panelKind(ctx),id); await replyPanelTemplate(ctx,panelTpl.broadcastResult,{placeholderValues:{hasil:`${r.sent}/${r.total} chat private diproses${r.failed?` (${r.failed} gagal)`:''}.`}}); return true;}
      case 'await_timer': {const timer=parseTimerConfig(text);if(timer===false){await replyPanelError(ctx,panelTpl.timerInvalid);return true;} assetRepoFor(ctx).updateConfig(id,{timer_config:timer,timer_enabled:Boolean(timer)});panelState.clearStep(ctx.from.id);await userbotRuntime.syncAsset(panelKind(ctx),id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));await replyPanelTemplate(ctx,panelTpl.timerSaved,{placeholderValues:{pesan:timer||'OFF (selalu aktif)'}});await timerHandler(ctx);return true;}
      case 'await_custom_wm': {const msg=panelConfigFor(ctx).getMessage(id);if(msg?.kind!=='text' && text.trim().toLowerCase()!=='off'){await replyPanelError(ctx,panelTpl.customWmInvalid);return true;} const wmOff=text.trim().toLowerCase()==='off';assetRepoFor(ctx).updateConfig(id,{watermark:wmOff?null:text.trim(),watermark_enabled:!wmOff});panelState.clearStep(ctx.from.id);await userbotRuntime.syncAsset(panelKind(ctx),id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));await replyPanelTemplate(ctx,panelTpl.customWmSaved);await watermarkHandler(ctx);return true;}
      case 'await_backup_token_regen': {
        panelState.clearStep(ctx.from.id);
        if(text.trim().toUpperCase()!=='BUAT'){await replyPanelError(ctx,panelTpl.tokenConfirmCancelled);return true;}
        const out=backupTokenSvc.regenerate({actorId:ctx.from.id,userbotId:id});
        if(!out.ok){await replyPanelError(ctx,out.reason==='expired'?panelTpl.tokenExpired:panelTpl.tokenCreateFailed);return true;}
        { const tokenContent = newTokenNoticeContent(ctx, out.token); await ctx.reply(tokenContent.text, buildReplyOptions(tokenContent)); }
        return true;
      }
      case 'await_check_token': {
        // The message holds a credential: drop it from the chat before replying.
        try{await ctx.deleteMessage();}catch(_){}
        panelState.clearStep(ctx.from.id);
        await replyPanelTemplate(ctx,panelTpl.tokenCheckResult,{placeholderValues:{hasil:describeCheckResult(backupTokenSvc.checkToken({actorId:ctx.from.id,rawCode:text}),ctx)}});
        return true;
      }
      case 'await_transfer': {
        const target=findRegisteredUser(text);
        if(!target){await replyPanelError(ctx,panelTpl.transferTargetMissing);return true;}
        if(Number(target.telegram_id)===Number(ctx.from.id)){await replyPanelError(ctx,panelTpl.transferSelf);return true;}
        // Ownership change + old-token invalidation + new owner's token are ONE
        // atomic operation; the current owner is re-verified inside it.
        const moved=backupTokenSvc.transferOwnership({userbotId:id,fromUserId:ctx.from.id,toUserId:Number(target.telegram_id)});
        if(!moved.ok){
          panelState.clearStep(ctx.from.id);
          await replyPanelError(ctx,moved.reason==='conflict'?panelTpl.transferConflict:panelTpl.transferFailed);
          return true;
        }
        await userbotRuntime.teardownAsset(panelKind(ctx),id);
        panelState.clear(ctx.from.id);
        await replyPanelTemplate(ctx,panelTpl.transferSuccess,{placeholderValues:{jumlah:String(id),hasil:`@${target.username||target.telegram_id}`}});
        // Only the NEW owner ever receives the new token; if delivery fails they can issue one from Kontrol Panel.
        try{
          const recipientCtx={from:{id:Number(target.telegram_id),first_name:target.first_name||target.username||'Kamu',last_name:'',username:target.username||undefined},chat:{id:Number(target.telegram_id)}};
          const received=panelContent(panelTpl.transferReceived,recipientCtx,{placeholderValues:{akun:moved.row.label||'Userbot'}});
          const tokenContent = newTokenNoticeContent(recipientCtx, moved.token, {intro:'Ini token backup Anda untuk userbot ini.'});
          await ctx.telegram.sendMessage(Number(target.telegram_id), received.text, buildReplyOptions(received));
          await ctx.telegram.sendMessage(Number(target.telegram_id), tokenContent.text, buildReplyOptions(tokenContent));
        }catch(err){logger.warn(`Gagal mengirim token baru ke pemilik baru userbot #${id}: ${(err&&err.message)||err}`);}
        return true;
      }
      case 'await_reset_data': {if(text.trim().toUpperCase()!=='RESET'){panelState.clearStep(ctx.from.id);await replyPanelError(ctx,panelTpl.resetCancelled);return true;}const oldMsg=panelConfigFor(ctx).getMessage(id);const oldBroadcast=panelConfigFor(ctx).getBroadcastPmMessage(id);panelConfigFor(ctx).resetAll(id);assetRepoFor(ctx).resetConfig(id);for(const file of [oldMsg?.media_path,oldBroadcast?.media_path]) panelConfigFor(ctx).safeDeleteMedia(file);await userbotRuntime.syncAsset(panelKind(ctx),id).catch(err=>logger.warn(`Runtime sync: ${err.message}`));panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.resetCompleted);return true;}
      default:return false;
    }
  }catch(err){logger.error(`Panel step error: ${err.message}`);await replyPanelError(ctx,panelTpl.stepError,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}});return true;}
}

async function handleMediaInput(ctx,state){
  const s=selected(ctx);if(!s)return true;if(state.step!=='await_message_media')return false;
  if(await enforceStepFeature(ctx,s.asset,state.step)) return true;
  const m=ctx.message||{};
  const media=m.photo?.at(-1)||m.video||m.document||m.audio||m.animation||m.voice||m.sticker;
  if(!media)return false;
  const fileId=media.file_id;
  const originalName=m.document?.file_name||m.audio?.file_name||m.animation?.file_name||null;
  const ext=m.photo?'.jpg':m.video?'.mp4':m.audio?'.mp3':m.animation?'.mp4':m.voice?'.ogg':m.sticker? (m.sticker.is_animated?'.tgs':m.sticker.is_video?'.webm':'.webp') : normalizeUploadExtension(originalName);
  const type=m.photo?'photo':m.video?'video':m.audio?'audio':m.animation?'animation':m.voice?'voice':m.sticker?'sticker':'document';
  const out=await downloadTelegramMedia(ctx,fileId,ext,`${s.asset.id}-media`);
  const caption=m.caption||'';
  const captionEntities=Array.isArray(m.caption_entities)?m.caption_entities:[];
  panelConfigFor(ctx).setMediaMessage(s.asset.id,out,type,caption,captionEntities,originalName);
  panelState.clearStep(ctx.from.id);await replyPanelTemplate(ctx,panelTpl.mediaSaved);
  await settleAfterStep(ctx);
  return true;
}

async function handleBroadcastMediaInput(ctx,state){
  const s=selected(ctx);if(!s||state.step!=='await_broadcast_pm')return false;
  if(await enforceStepFeature(ctx,s.asset,state.step)) return true;
  const m=ctx.message||{};
  const media=m.photo?.at(-1)||m.video||m.document||m.audio||m.animation||m.voice||m.sticker;
  if(!media)return false;
  const fileId=media.file_id;
  const originalName=m.document?.file_name||m.audio?.file_name||m.animation?.file_name||null;
  const ext=m.photo?'.jpg':m.video?'.mp4':m.audio?'.mp3':m.animation?'.mp4':m.voice?'.ogg':m.sticker?(m.sticker.is_animated?'.tgs':m.sticker.is_video?'.webm':'.webp'):normalizeUploadExtension(originalName);
  const type=m.photo?'photo':m.video?'video':m.audio?'audio':m.animation?'animation':m.voice?'voice':m.sticker?'sticker':'document';
  const out=await downloadTelegramMedia(ctx,fileId,ext,`${s.asset.id}-pm`);
  panelConfigFor(ctx).setBroadcastPmMessage(s.asset.id,{kind:'media',text:m.caption||'',media_path:out,media_type:type,caption_entities:Array.isArray(m.caption_entities)?m.caption_entities:[],file_name:originalName});
  panelState.clearStep(ctx.from.id);
  try {
    const r=await userbotRuntime.broadcastPm(panelKind(ctx),s.asset.id);
    await replyPanelTemplate(ctx,panelTpl.broadcastResult,{placeholderValues:{hasil:`${r.sent}/${r.total} chat private diproses${r.failed?` (${r.failed} gagal)`:''}.`}});
  } catch (err) {
    logger.error(`Broadcast PM error: ${err.message}`);
    await replyPanelError(ctx,panelTpl.stepError,{placeholderValues:{reason:err.message||'Terjadi kesalahan.'}});
  }
  await settleAfterStep(ctx);
  return true;
}

module.exports={stopPromotionStatusWatcher,panelHandler,guardPanelState,enforceStepFeature,selectAsset,panelAssetInlineCallback,showControlScreen:showMainPanel,showAssetPicker,assetButtonLabel,repoFor:(kind)=>kind==='owned'?ownedRepo:null,restoreScreen,settleAfterStep,inputBack,
homePanelHandler,baseReplyHandler,messageHandler,groupHandler,delayHandler,extraHandler,guideHandler,startHandler,promotionStatusHandler,promotionStatusRefreshHandler,
replyToggleHandler,addReplyHandler,smartDelayToggleHandler,deleteReplyHandler,globalSettingsHandler,globalTextHandler,globalTargetChannelHandler,globalBannedHandler,globalMaxCharsHandler,globalFilterLinkHandler,globalFilterUsernameHandler,wtbTimerHandler,replyListHandler,autoResetHandler,autoReactHandler,autoReactEnableHandler,autoReactDisableHandler,autoReactChangeHandler,channelDisableHandler,
textMediaHandler,forwardHandler,viewMessageHandler,deleteMessageHandler,topicGroupHandler,addGroupHandler,deleteGroupHandler,groupListHandler,joinGroupHandler,leaveGroupHandler,
groupDeleteSelectCallback,groupDeleteConfirmCallback,groupDeleteAllCallback,groupDeleteAllConfirmCallback,groupDeleteCancelCallback,groupDeletePageCallback,groupListPageCallback,groupListRefreshCallback,groupListBackCallback,groupLeavePageCallback,groupLeaveRefreshCallback,groupLeaveSelectCallback,groupLeaveBackCallback,
groupDelayHandler,roundDelayHandler,broadcastPmHandler,pmPermitHandler,adminPanelHandler,timerHandler,backupTokenHandler,customWmHandler,watermarkHandler,watermarkEnableHandler,watermarkDisableHandler,backupTokenNewHandler,backupTokenConfirmHandler,timerSetHandler,timerEnableHandler,timerDisableHandler,checkTokenHandler,transferHandler,resetDataHandler,
handleStepInput,handleMediaInput,handleBroadcastMediaInput,requireFeature,ask,promotionStatusRefreshInlineCallback,promotionStatusStartInlineCallback,promotionStatusStopInlineCallback,promotionStatusBackInlineCallback};
