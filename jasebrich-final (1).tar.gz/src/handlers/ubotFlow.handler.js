const { Markup } = require('telegraf');
const { replyButton } = require('../utils/buttons');
const buyerState = require('../state/buyerState');
const gramjsService = require('../services/gramjs.service');
const userbotService = require('../services/userbot.service');
const trialConfigService = require('../services/trialConfig.service');
const userbotRuntime = require('../services/userbotRuntime.service');
const logger = require('../utils/logger');
const backupToken = require('../services/backupToken.service');
const { newTokenNoticeContent } = require('../utils/tokenNotice');
const { defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');
const { MENU } = require('../constants/menu');
const { replyCancelled } = require('../services/cancelNotice.service');

const CANCEL_LABEL = MENU.BATAL;
const activationTpl = {
  phonePurchase: defineTemplate('userbot.activation_phone_purchase', 'Userbot', 'Verifikasi Kontak Userbot', '💬 *Verifikasi Kontak*\n\nSilakan bagikan nomor telepon akun Telegram yang akan dijadikan userbot dengan menekan tombol di bawah.\n\nTelegram akan mengirim kode OTP ke akun tersebut. Jangan bagikan OTP atau password 2FA kepada siapa pun selain bot ini.\n\nAtau ketik nomor secara manual dengan format: `+62812xxxxxxx`.'),
  phoneReauth: defineTemplate('userbot.activation_phone_reauth', 'Userbot', 'Login Ulang Userbot', '🔐 *Login Ulang Userbot*\n\nSesi Telegram userbot kamu tidak valid. Langganan dan semua pengaturan tetap aman — cukup login ulang dengan akun Telegram yang sama.\n\n💬 *Verifikasi Kontak*\n\nSilakan bagikan nomor telepon akun Telegram yang akan dijadikan userbot dengan menekan tombol di bawah.\n\nTelegram akan mengirim kode OTP ke akun tersebut. Jangan bagikan OTP atau password 2FA kepada siapa pun selain bot ini.\n\nAtau ketik nomor secara manual dengan format: `+62812xxxxxxx`.'),
  phoneInvalid: defineTemplate('userbot.activation_phone_invalid', 'Userbot', 'Nomor Telepon Tidak Valid', '❌ Format nomor HP tidak valid. Contoh: +62812xxxxxxx. Coba lagi.'),
  otpSendingPurchase: defineTemplate('userbot.activation_otp_sending_purchase', 'Userbot', 'Mengirim OTP', '⏳ Mengirim kode OTP ke nomor tersebut.'),
  otpSendingTrial: defineTemplate('userbot.activation_otp_sending_trial', 'Trial', 'Menghubungkan Trial ke Telegram', '🔄 Sedang menghubungkan ke server Telegram untuk meminta kode OTP...'),
  otpPrompt: defineTemplate('userbot.activation_otp_prompt', 'Userbot', 'Input Kode OTP', '🛠️ *Silakan Periksa Kode OTP Dari Akun Resmi Telegram.*\n\n🔔 Kirim Code Dengan Format: `1 2 3 4 5` (Spasi)'),
  otpSendFailed: defineTemplate('userbot.activation_otp_send_failed', 'Userbot', 'OTP Gagal Dikirim', '❌ Gagal mengirim OTP: {reason}', { supportedPlaceholders: ['reason'] }),
  otpFormatInvalid: defineTemplate('userbot.activation_otp_format_invalid', 'Userbot', 'Format Kode OTP Tidak Valid', '❌ Format kode tidak valid. Kirim dengan format: `1 2 3 4 5`.'),
  otpExpired: defineTemplate('userbot.activation_otp_expired', 'Userbot', 'Kode OTP Kadaluarsa', '⏰ Kode OTP sudah kadaluarsa. Silakan kirim ulang nomor HP untuk mendapat kode baru.'),
  otpAttemptLimit: defineTemplate('userbot.activation_otp_attempt_limit', 'Userbot', 'Batas Percobaan OTP Tercapai', '🔒 Batas percobaan kode OTP tercapai. Sesi login dibatalkan demi keamanan. Silakan mulai lagi dari nomor HP.'),
  passwordAttemptLimit: defineTemplate('userbot.activation_password_attempt_limit', 'Userbot', 'Batas Percobaan Password Tercapai', '🔒 Batas percobaan password 2FA tercapai. Sesi login dibatalkan demi keamanan. Silakan mulai lagi dari nomor HP.'),
  twoFactorPrompt: defineTemplate('userbot.activation_2fa_prompt', 'Userbot', 'Password 2FA Diperlukan', '🔒 Akun ini memiliki verifikasi 2 langkah. Silakan kirim password cloud Telegram Anda.'),
  otpFailed: defineTemplate('userbot.activation_otp_failed', 'Userbot', 'OTP Salah atau Kedaluwarsa', '❌ Kode OTP salah/kadaluarsa: {reason}.', { supportedPlaceholders: ['reason'] }),
  passwordFailed: defineTemplate('userbot.activation_password_failed', 'Userbot', 'Password 2FA Salah', '❌ Password salah: {reason}.', { supportedPlaceholders: ['reason'] }),
  reauthIdentity: defineTemplate('userbot.reauth_identity_mismatch', 'Userbot Recovery', 'Akun Telegram Berbeda', '❌ Akun Telegram yang kamu login berbeda dari akun userbot ini. Login ulang harus memakai akun yang sama. Ketik 🤖 Buat Userbot untuk mencoba lagi.'),
  reauthExpired: defineTemplate('userbot.reauth_expired', 'Userbot Recovery', 'Masa Aktif Berakhir', '⏰ Masa aktif userbot ini sudah berakhir, jadi pemulihan dibatalkan dan tidak ada yang berubah. Perpanjang langganan lewat 🛒 Toko.'),
  reauthRotated: defineTemplate('userbot.reauth_rotated', 'Userbot Recovery', 'Token Recovery Tidak Berlaku', '❌ Token yang kamu gunakan sudah tidak berlaku (sudah digunakan atau diganti). Pemulihan dibatalkan dan tidak ada yang berubah.'),
  reauthDefaultFailure: defineTemplate('userbot.reauth_failed', 'Userbot Recovery', 'Recovery Gagal', '❌ Userbot tidak ditemukan atau tidak dapat login ulang.'),
  reauthSuccess: defineTemplate('userbot.reauth_success', 'Userbot Recovery', 'Recovery Berhasil', '✅ Sesi userbot berhasil dipulihkan. Subscription dan pengaturan kamu tidak berubah.'),
};

/**
 * Keyboards of the userbot login wizard (phone -> OTP -> 2FA). Each step
 * shows exactly its own actions; none is one-time, so the exit path
 * (Kembali / Batal) survives every retry.
 */
function phoneKeyboard() {
  return Markup.keyboard([
    [replyButton.contactRequest('💬 Kontak Saya')],
    [replyButton.primary(MENU.KEMBALI), replyButton.danger(CANCEL_LABEL, { customizable: false })],
  ]).resize();
}

function codeKeyboard() {
  return Markup.keyboard([
    [replyButton.primary(MENU.KEMBALI), replyButton.danger(CANCEL_LABEL, { customizable: false })],
  ]).resize();
}

function keyboardForStep(step) {
  return step === 'await_phone' ? phoneKeyboard() : codeKeyboard();
}

/**
 * Kicks off the phone/OTP login flow with the buyer right after their
 * "Beli Userbot" order is confirmed by an admin (mirrors screenshot 4:
 * "Venom's Userbot" asking for phone, then a spaced-digit OTP code).
 */
async function beginPhoneStep(telegram, telegramId, ownedId, flow = 'purchase', options = {}) {
  const isTrial = flow === 'trial';
  const returnTo = options && options.returnTo === 'trial' ? 'trial' : 'main';
  buyerState.set(telegramId, {
    step: 'await_phone',
    ownedId,
    flow: flow === 'reauth' ? 'reauth' : isTrial ? 'trial' : 'purchase',
    returnTo,
  });
  const content = phonePromptContent(flow, { from: { id: telegramId }, chat: { id: telegramId } });
  await telegram.sendMessage(telegramId, content.text, { ...buildReplyOptions(content), ...phoneKeyboard() });
}

function phonePromptContent(flow, ctx) {
  return (flow === 'reauth' ? activationTpl.phoneReauth : activationTpl.phonePurchase).getContent(ctx);
}

function phonePromptText(flow) {
  return phonePromptContent(flow, { from: { id: 0 }, chat: { id: 0 } }).text;
}

async function beginTrialContactStep(telegram, telegramId, ownedId) {
  return beginPhoneStep(telegram, telegramId, ownedId, 'trial', { returnTo: 'trial' });
}

function normalizePhoneNumber(phoneNumber) {
  let value = String(phoneNumber || '').trim().replace(/[^\d+]/g, '');
  if (value.startsWith('00')) value = `+${value.slice(2)}`;
  if (!value.startsWith('+')) value = `+${value}`;
  return value;
}

async function safeDeleteMessage(ctx) {
  if (!ctx.message || !ctx.message.message_id || !ctx.chat) return;
  try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch (_) {}
}

async function handlePhoneInput(ctx, state, phoneNumber) {
  const normalized = normalizePhoneNumber(phoneNumber);
  if (!/^\+?\d{8,15}$/.test(normalized)) {
    {const c=activationTpl.phoneInvalid.getContent(ctx);await ctx.reply(c.text,{...buildReplyOptions(c),...phoneKeyboard()});}
    return;
  }

  {const c=(state.flow === 'trial' ? activationTpl.otpSendingTrial : activationTpl.otpSendingPurchase).getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}

  try {
    await gramjsService.startPhoneLogin(ctx.from.id, normalized);
    if (state.ownedId) {
      // phone column update
      userbotService.updateOwnedUserbotPhone(state.ownedId, normalized);
    }
    buyerState.set(ctx.from.id, { step: 'await_otp', ownedId: state.ownedId, phone: normalized, flow: state.flow || 'purchase', returnTo: state.returnTo || 'main' });
    const otpContent = activationTpl.otpPrompt.getContent(ctx);
    await ctx.reply(otpContent.text, { ...buildReplyOptions(otpContent), ...codeKeyboard() });
  } catch (err) {
    logger.error('startPhoneLogin failed:', err && err.stack ? err.stack : err);
    const reason = gramjsService.getUserFacingErrorMessage(err);
    {const c=activationTpl.otpSendFailed.getContent(ctx,{placeholderValues:{reason}});await ctx.reply(c.text,{...buildReplyOptions(c),...phoneKeyboard()});}
  }
}

const REAUTH_FAILURE_TEXT = {
  identity_mismatch: '❌ Akun Telegram yang kamu login berbeda dari akun userbot ini. Login ulang harus memakai akun yang sama. Ketik 🤖 Buat Userbot untuk mencoba lagi.',
  expired: '⏰ Masa aktif userbot ini sudah berakhir, jadi pemulihan dibatalkan dan tidak ada yang berubah. Perpanjang langganan lewat 🛒 Toko.',
  rotated: '❌ Token yang kamu gunakan sudah tidak berlaku (sudah digunakan atau diganti). Pemulihan dibatalkan dan tidak ada yang berubah.',
};
const REAUTH_DEFAULT_FAILURE_TEXT = '❌ Userbot tidak ditemukan atau tidak dapat login ulang.';

/**
 * Completes a re-login of an EXISTING userbot (plain re-auth after
 * SESSION_INVALID, or recovery started with a Backup Token). The whole decision
 * — ownership, same Telegram account, active period, token consumption and the
 * session swap on the same row — is ONE atomic step in
 * services/backupToken.service.js#completeRecovery; nothing is created here.
 */
async function finalizeReauth(ctx, state, sessionString, telegramUserbotId) {
  const out = backupToken.completeRecovery({ actorId: ctx.from.id, userbotId: state.ownedId, sessionString, telegramUserbotId });
  buyerState.clear(ctx.from.id);
  if (!out.ok) {
    const failureTemplate = out.reason === 'identity_mismatch' ? activationTpl.reauthIdentity : out.reason === 'expired' ? activationTpl.reauthExpired : out.reason === 'rotated' ? activationTpl.reauthRotated : activationTpl.reauthDefaultFailure;
    const failure = failureTemplate.getContent(ctx);
    await ctx.reply(failure.text, buildReplyOptions(failure));
    return;
  }
  {const c=activationTpl.reauthSuccess.getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}
  if (out.newToken) {
    // Recovery used the Backup Token up: the owner receives its replacement, once.
    { const tokenContent = newTokenNoticeContent(ctx, out.newToken, { intro: 'Token yang baru saja kamu pakai sudah tidak berlaku.' }); await ctx.reply(tokenContent.text, buildReplyOptions(tokenContent)); }
  }
  require('../services/userbotLifecycle.service')
    .restoreRuntime(out.row.id)
    .catch((err) => logger.error(`Restore runtime setelah re-auth #${out.row.id}: ${err.message}`));
  await require('../services/mainMenu.service').renderMainMenu(ctx);
}

async function finalizeActivation(ctx, state, sessionString, telegramUserbotId, account = null) {
  if (state.flow === 'reauth') return finalizeReauth(ctx, state, sessionString, telegramUserbotId);
  const expiresAt = state.flow === 'trial'
    ? userbotService.getTrialExpiresAt(trialConfigService.getTrialDurationHours())
    : null;
  const userbot = userbotService.activateOwned(state.ownedId, {
    sessionString,
    telegramUserbotId,
    expiresAt,
    tokenPrefix: state.flow === 'trial' ? 'LIFE-UBOT' : 'JASEB',
  });
  if (!userbot) throw new Error('Data userbot tidak ditemukan saat aktivasi.');

  buyerState.clear(ctx.from.id);

  const accountName = [account && account.firstName, account && account.lastName]
    .filter(Boolean)
    .join(' ') || account?.username || 'Akun Telegram';

  // The activation result is intentionally sent only once: the pinned
  // receipt below is the canonical activation message and supports the
  // full Custom Submenu/placeholder system.
  await userbotService.sendPinnedActivationMessage(ctx.telegram, ctx.from.id, {
    name: accountName,
    id: telegramUserbotId,
    token: userbot.token,
    phone: account?.phone || userbot.phone || null,
    username: account?.username || null,
    expiresAt: userbot.expires_at || null,
    orderId: userbot.order_id || null,
    productName: userbot.label || null,
    activatedAt: userbot.activated_at || new Date().toISOString(),
    status: userbot.status || 'active',
  });


  logger.info(`Owned userbot #${userbot.id} activated for user ${ctx.from.id} as Telegram account ${telegramUserbotId}`);

  userbotRuntime.syncAsset('owned', userbot.id).catch((err) =>
    logger.error(`Gagal sinkronisasi runtime setelah aktivasi owned #${userbot.id}: ${err.message}`)
  );
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatIndonesiaDate(value) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    dateStyle: 'long',
    timeStyle: 'short',
  }).format(d) + ' WIB';
}

async function handleOtpInput(ctx, state, rawCode) {
  const code = rawCode.replace(/\s+/g, '');
  if (!/^\d{4,7}$/.test(code)) {
    {const c=activationTpl.otpFormatInvalid.getContent(ctx);await ctx.reply(c.text,{...buildReplyOptions(c),...codeKeyboard()});}
    return;
  }

  try {
    const { sessionString, telegramUserbotId, account } = await gramjsService.submitOtp(ctx.from.id, code);
    await safeDeleteMessage(ctx);
    await finalizeActivation(ctx, state, sessionString, telegramUserbotId, account);
  } catch (err) {
    if (err && err.code === '2FA_REQUIRED') {
      buyerState.set(ctx.from.id, { step: 'await_password', ownedId: state.ownedId, phone: state.phone, flow: state.flow || 'purchase', returnTo: state.returnTo || 'main' });
      {const c=activationTpl.twoFactorPrompt.getContent(ctx);await ctx.reply(c.text,{...buildReplyOptions(c),...codeKeyboard()});}
      return;
    }

    logger.error('submitOtp failed:', err && err.stack ? err.stack : err);

    if (err && err.code === 'PHONE_CODE_EXPIRED') {
      // Telegram's auth attempt is no longer usable. Clean the real GramJS
      // session and re-enter the phone step so the visible keyboard matches
      // the instruction without requiring a manual Kembali action.
      try { gramjsService.cancelLogin(ctx.from.id); } catch (_) {}
      buyerState.set(ctx.from.id, { step: 'await_phone', ownedId: state.ownedId, flow: state.flow || 'purchase', returnTo: state.returnTo || 'main' });
      const c = activationTpl.otpExpired.getContent(ctx);
      await ctx.reply(c.text, { ...buildReplyOptions(c), ...phoneKeyboard() });
      return;
    }

    if (err && err.code === 'OTP_ATTEMPT_LIMIT') {
      buyerState.set(ctx.from.id, { step: 'await_phone', ownedId: state.ownedId, flow: state.flow || 'purchase', returnTo: state.returnTo || 'main' });
      const c = activationTpl.otpAttemptLimit.getContent(ctx);
      await ctx.reply(c.text, { ...buildReplyOptions(c), ...phoneKeyboard() });
      return;
    }

    const reason = gramjsService.getUserFacingErrorMessage(err);
    {const c=activationTpl.otpFailed.getContent(ctx,{placeholderValues:{reason}});await ctx.reply(c.text,{...buildReplyOptions(c),...codeKeyboard()});}
  }
}

async function handlePasswordInput(ctx, state, password) {
  try {
    const { sessionString, telegramUserbotId, account } = await gramjsService.submitPassword(ctx.from.id, password);
    await safeDeleteMessage(ctx);
    await finalizeActivation(ctx, state, sessionString, telegramUserbotId, account);
  } catch (err) {
    logger.error('submitPassword failed:', err && err.stack ? err.stack : err);

    if (err && err.code === 'PASSWORD_ATTEMPT_LIMIT') {
      buyerState.set(ctx.from.id, { step: 'await_phone', ownedId: state.ownedId, flow: state.flow || 'purchase', returnTo: state.returnTo || 'main' });
      const c = activationTpl.passwordAttemptLimit.getContent(ctx);
      await ctx.reply(c.text, { ...buildReplyOptions(c), ...phoneKeyboard() });
      return;
    }

    const reason = gramjsService.getUserFacingErrorMessage(err);
    {const c=activationTpl.passwordFailed.getContent(ctx,{placeholderValues:{reason}});await ctx.reply(c.text,{...buildReplyOptions(c),...codeKeyboard()});}
  }
}

/**
 * "🔙 Kembali" inside the login wizard.
 *   OTP / 2FA -> phone step: the pending GramJS login is aborted first (a late
 *                 OTP/2FA result can never complete it), then the phone step
 *                 is re-entered with its own keyboard.
 *   phone     -> trial: the Terms screen (safe: the pending trial record is
 *                 kept and only the step changes); purchase/re-auth: the main
 *                 menu — the pending userbot record is preserved so "Buat
 *                 Userbot" resumes it, exactly as Batalkan does.
 * Returns false when the state is not a wizard step Kembali applies to.
 */
async function backFlow(ctx) {
  const state = buyerState.get(ctx.from.id);
  if (!state) return false;

  if (state.step === 'await_otp' || state.step === 'await_password') {
    try { gramjsService.cancelLogin(ctx.from.id); } catch (_) {}
    buyerState.set(ctx.from.id, { step: 'await_phone', ownedId: state.ownedId, flow: state.flow || 'purchase', returnTo: state.returnTo || 'main' });
    {const c=phonePromptContent(state.flow,ctx);await ctx.reply(c.text,{...buildReplyOptions(c),...phoneKeyboard()});}
    return true;
  }

  if (state.step === 'await_phone') {
    try { gramjsService.cancelLogin(ctx.from.id); } catch (_) {}
    if (state.returnTo === 'trial') {
      buyerState.set(ctx.from.id, { step: 'trial_terms', ownedId: state.ownedId, flow: 'trial', returnTo: 'trial' });
      await require('./trial.handler').renderTrialTerms(ctx);
      return true;
    }
    buyerState.clear(ctx.from.id);
    await require('../services/mainMenu.service').renderMainMenu(ctx);
    return true;
  }
  return false;
}

async function cancelFlow(ctx) {
  const state = buyerState.get(ctx.from.id);
  if (!state) return false;
  gramjsService.cancelLogin(ctx.from.id);
  buyerState.clear(ctx.from.id);
  await replyCancelled(ctx);
  // Every entry point of this flow (Buat Userbot, Coba Gratis, order
  // confirmation) starts from the main menu, so that is where cancelling
  // returns - otherwise the one-time contact/phone keyboard is left behind
  // with nothing to tap. The pending userbot record is kept on purpose so
  // "Buat Userbot" can resume it.
  await require('../services/mainMenu.service').renderMainMenu(ctx);
  return true;
}

module.exports = { backFlow, keyboardForStep, phoneKeyboard, codeKeyboard, beginPhoneStep, beginTrialContactStep, handlePhoneInput, handleOtpInput, handlePasswordInput, cancelFlow };
