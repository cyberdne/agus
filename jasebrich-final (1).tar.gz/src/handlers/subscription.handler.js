/**
 * User-facing subscription handlers: the "Userbot kadaluarsa" lock screen and
 * the "Perpanjang Langganan" entry point (`subscription:renew:<userbots.id>`).
 * The renewal button feeds the EXISTING Store renewal/payment flow — no
 * second payment system.
 */
const { safeHandler } = require('../utils/errors');
const { mainKeyboard } = require('../keyboards/main.keyboard');
const userbotService = require('../services/userbot.service');
const { isAdminId } = require('../middlewares/admin.middleware');
const userRepository = require('../database/repositories/user.repository');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const subscription = require('../services/subscription.service');
const renewalTarget = require('../services/renewalTarget.service');
const notice = require('../services/subscriptionNotice.service');
const { CATEGORIES } = require('../services/product.service');
const { defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');
const store = require('./store.handler');
const logger = require('../utils/logger');
const subscriptionTpl = {
  mainReloaded: defineTemplate('userbot.main_reloaded', 'Userbot', 'Menu Utama Dimuat Ulang', '🏠 Menu utama dimuat ulang.'),
  noActive: defineTemplate('userbot.no_active', 'Userbot', 'Userbot Aktif Tidak Ditemukan', '❌ Userbot aktif tidak ditemukan.'),
  expiredPicker: defineTemplate('userbot.expired_picker', 'Userbot', 'Pilih Userbot Kadaluarsa', '⛔ *Userbot Kadaluarsa*\n\nSemua userbot kamu telah kadaluarsa.\nPilih Userbot yang ingin diperpanjang:'),
  renewalOwnershipError: defineTemplate('userbot.renewal_ownership_error', 'Userbot', 'Userbot Tidak Ditemukan', '❌ Userbot tidak ditemukan atau bukan milik kamu.'),
};

/**
 * Replaces whatever reply keyboard the user still has on screen (e.g. the old
 * Kontrol Panel buttons) with the main menu, so stale buttons stop being tappable.
 */
async function restoreMainKeyboard(ctx) {
  const id = ctx.from.id;
  const content = subscriptionTpl.mainReloaded.getContent(ctx);
  await ctx.reply(content.text, { ...buildReplyOptions(content), ...mainKeyboard(isAdminId(id), userRepository.hasClaimedTrial(id), userbotService.hasControllablePanelAsset(id)) });
}

/** Shows the expired lock screen for ONE userbot (owner variant or admin variant). */
async function sendExpiredNotice(ctx, asset, { adminMode = false } = {}) {
  const built = adminMode ? notice.buildAdminExpiredNotice(asset) : notice.buildExpiredNotice(ctx, asset);
  await ctx.reply(built.text, built.options);
  if (!adminMode) await restoreMainKeyboard(ctx);
}

/**
 * Called by the panel guard when a control action is rejected.
 * EXPIRED -> renewal screen; anything else keeps the pre-existing message.
 */
async function denyControl(ctx, access, { adminMode = false } = {}) {
  if (access && access.code === 'EXPIRED' && access.asset) {
    await sendExpiredNotice(ctx, access.asset, { adminMode });
    return;
  }
  {const c=subscriptionTpl.noActive.getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}
}

/** Several userbots, none controllable: let the user pick which one to renew. */
async function sendExpiredPicker(ctx, expiredRows) {
  const { Markup } = require('telegraf');
  const { button } = require('../utils/buttons');
  const { CALLBACK } = require('../constants/menu');
  const { formatIndonesiaDate } = require('../utils/placeholders');
  const keyboard = Markup.inlineKeyboard(
    expiredRows.map((r) => [
      button.primary(`⛔ ${r.label || 'Userbot'} #${r.id} — ${formatIndonesiaDate(r.expires_at)}`, CALLBACK.SUBSCRIPTION_RENEW(r.id)),
    ])
  );
  const content = subscriptionTpl.expiredPicker.getContent(ctx);
  await ctx.reply(content.text, { ...buildReplyOptions(content), ...keyboard });
  await restoreMainKeyboard(ctx);
}

// subscription:renew:<userbots.id>
const subscriptionRenewCallback = safeHandler(async (ctx) => {
  try { await ctx.answerCbQuery(); } catch (_) { /* best effort */ }
  const userbotId = Number(String(ctx.callbackQuery.data).split(':')[2]);
  const asset = Number.isInteger(userbotId) ? ownedRepo.findById(userbotId) : null;
  // Ownership is enforced server-side: another user's userbot id in a
  // forwarded/old button can never start a renewal.
  if (!asset || Number(asset.user_id) !== Number(ctx.from.id) || !subscription.isRenewable(asset)) {
    {const c=subscriptionTpl.renewalOwnershipError.getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}
    return;
  }
  renewalTarget.choose(ctx.from.id, asset.id);
  await store.renderCategoryProducts(ctx, CATEGORIES.RENEWAL);
  logger.debug(`User ${ctx.from.id} started renewal for userbot #${asset.id}`);
});

module.exports = { sendExpiredNotice, denyControl, sendExpiredPicker, restoreMainKeyboard, subscriptionRenewCallback };
