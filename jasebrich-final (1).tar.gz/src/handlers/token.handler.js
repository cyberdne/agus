const { Markup } = require('telegraf');
const { safeHandler } = require('../utils/errors');
const { renderWithReplyKeyboard } = require('../utils/render');
const { replyButton } = require('../utils/buttons');
const { MENU } = require('../constants/menu');
const { replyCancelled } = require('../services/cancelNotice.service');
const { renderMainMenu } = require('../services/mainMenu.service');
const userRepository = require('../database/repositories/user.repository');
const userbotService = require('../services/userbot.service');
const tokenClaimState = require('../state/tokenClaimState');
const ubotFlow = require('./ubotFlow.handler');
const { formatRemainingDuration } = require('../utils/placeholders');
const { newTokenNoticeContent } = require('../utils/tokenNotice');
const { defineSubmenu, defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');
const logger = require('../utils/logger');

const CLAIM_TEXT =
  `🛠️ *Klaim Akses via Token*\n\n` +
  `Hai! Selamat datang di menu klaim token.\n\n` +
  `ℹ️ *Apa itu Token Login?*\n` +
  `Token ini adalah kode spesial yang berfungsi untuk:\n\n` +
  `🛡️ Garansi Akses: Mengaktifkan kembali garansi Userbot Anda.\n` +
  `🎁 Reward Spesial: Mendapatkan akses dari hadiah atau reward spesial dari Owner.\n\n` +
  `🔔 Silakan masukkan Token Login Anda di bawah ini.`;

// Registers this screen under Admin Panel -> Settings -> Custom Submenu,
// same as Store/Fitur Unggulan/Panduan Buat/pesan /start — this was
// previously missing, so "🎫 Klaim Token" could never be customized
// even though every other top-level menu screen could.
const submenu = defineSubmenu('token', '🎫 Klaim Token', CLAIM_TEXT, 'Markdown', { feature: 'Token', supportedPlaceholders: [] });
const tokenTpl = {
  invalid: defineTemplate('token.invalid', 'Token', 'Token Tidak Valid', '❌ Token tidak ditemukan atau tidak valid. Periksa kembali dan coba lagi.'),
  rotated: defineTemplate('token.rotated', 'Token', 'Token Sudah Tidak Berlaku', '❌ Token ini sudah tidak berlaku (sudah digunakan atau diganti dengan token baru). Gunakan token terbaru Anda.'),
  revoked: defineTemplate('token.revoked', 'Token', 'Token Dicabut', '❌ Token ini sudah dicabut karena userbot terkait telah dihapus. Periksa kembali.'),
  alreadyActive: defineTemplate('token.already_active', 'Token', 'Userbot Sudah Aktif', 'ℹ️ Userbot ini sudah aktif — tidak perlu diklaim ulang.'),
  notRecoverable: defineTemplate('token.not_recoverable', 'Token', 'Userbot Belum Dapat Dipulihkan', 'ℹ️ Userbot untuk token ini belum dapat dipulihkan karena aktivasinya belum selesai.'),
  rateLimited: defineTemplate('token.rate_limited', 'Token', 'Percobaan Terlalu Banyak', '⏳ Terlalu banyak percobaan token yang gagal. Coba lagi dalam beberapa menit.'),
  expiredTrial: defineTemplate('token.expired_trial', 'Token', 'Trial Kedaluwarsa', '⏰ Masa aktif trial sudah berakhir, jadi token ini tidak dapat digunakan. Trial tidak dapat diaktifkan kembali.'),
  expiredUserbot: defineTemplate('token.expired_userbot', 'Token', 'Userbot Kedaluwarsa', '⏰ Masa aktif userbot untuk token ini sudah berakhir, jadi token tidak dapat digunakan untuk pemulihan.\n\nPerpanjang langganan lewat 🛒 Toko.'),
  recoveryStarted: defineTemplate('token.recovery_started', 'Userbot', 'Recovery Userbot Dimulai', '✅ Token valid untuk 🤖 *{produk}*.\n\nUserbot ini akan dipulihkan (bukan userbot baru).\n{sisa_info}\n\nLogin ulang dengan akun Telegram yang *sama*.', { supportedPlaceholders: ['produk','sisa_info'] }),
  reactivated: defineTemplate('token.reactivated', 'Token', 'Garansi Userbot Diaktifkan', '✅ Garansi berhasil diaktifkan kembali untuk {produk}.', { supportedPlaceholders: ['produk'] }),
};

// Token input has exactly one previous screen (the main menu it was opened
// from): Kembali returns there silently, Batal aborts and says so.
function claimKeyboardMarkup() {
  return Markup.keyboard([[replyButton.primary(MENU.KEMBALI), replyButton.danger(MENU.BATAL, { customizable: false })]]).resize();
}
const claimKeyboard = claimKeyboardMarkup();

/** "🎫 Klaim Token" reply-keyboard entry point — always opens the token-input prompt. */
const klaimTokenHandler = safeHandler(async (ctx) => {
  tokenClaimState.set(ctx.from.id, { step: 'await_token' });
  const content = submenu.getContent(ctx);
  await renderWithReplyKeyboard(ctx, content.text, { ...buildReplyOptions(content), ...claimKeyboard });
  logger.debug(`User ${ctx.from.id} opened Klaim Token`);
});

async function backToMain(ctx) {
  await renderMainMenu(ctx);
}

/** "🔙 Kembali" from the token prompt: leave the flow, return to the main menu. */
async function backFromClaim(ctx) {
  tokenClaimState.clear(ctx.from.id);
  await backToMain(ctx);
}

/** "❌ Batal" while mid-flow, and /cancel — see middlewares/tokenClaimText.middleware.js. */
async function cancelClaim(ctx) {
  tokenClaimState.clear(ctx.from.id);
  // Same wording as the generic Batal path (navigationCancellation), so
  // "❌ Batal" and "/cancel" behave identically.
  await replyCancelled(ctx);
  await backToMain(ctx);
}

// Reasons that mean "this text is not a token you can use" keep the prompt open
// so the user can retry, and are worded IDENTICALLY for a token that does not
// exist and a token that belongs to someone else — the reply must never tell an
// outsider that a given token exists.
const RETRY_REASON_TEXT = {
  not_found: '❌ Token tidak ditemukan atau tidak valid. Periksa kembali dan coba lagi.',
  rotated: '❌ Token ini sudah tidak berlaku (sudah digunakan atau diganti dengan token baru). Gunakan token terbaru Anda.',
  revoked: '❌ Token ini sudah dicabut karena userbot terkait telah dihapus. Periksa kembali.',
};
RETRY_REASON_TEXT.not_owner = RETRY_REASON_TEXT.not_found;

// Reasons that end the flow (the userbot itself decides the outcome).
const FINAL_REASON_TEXT = {
  already_active: 'ℹ️ Userbot ini sudah aktif — tidak perlu diklaim ulang.',
  not_recoverable: 'ℹ️ Userbot untuk token ini belum dapat dipulihkan karena aktivasinya belum selesai.',
  rate_limited: '⏳ Terlalu banyak percobaan token yang gagal. Coba lagi dalam beberapa menit.',
};

function expiredTemplate(trial) {
  return trial ? tokenTpl.expiredTrial : tokenTpl.expiredUserbot;
}

async function safeDeleteInput(ctx) {
  if (!ctx.message || !ctx.message.message_id || !ctx.chat) return;
  try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch (_) {}
}

/** Handles the token code once the user sends it while `await_token` is active. */
async function handleTokenInput(ctx, rawCode) {
  // The message holds a credential: remove it from the chat as soon as it is read.
  await safeDeleteInput(ctx);

  const result = userbotService.claimToken(ctx.from.id, rawCode);
  tokenClaimState.clear(ctx.from.id);

  if (!result.ok) {
    if (RETRY_REASON_TEXT[result.reason]) {
      const failureTemplate = result.reason === 'rotated' ? tokenTpl.rotated : result.reason === 'revoked' ? tokenTpl.revoked : tokenTpl.invalid;
      const failure = failureTemplate.getContent(ctx);
      await ctx.reply(failure.text, { ...buildReplyOptions(failure), ...claimKeyboardMarkup() });
      // Keep the flow open so the user can retry without reopening the menu.
      tokenClaimState.set(ctx.from.id, { step: 'await_token' });
      return;
    }
    const failureTemplate = result.reason === 'expired' ? expiredTemplate(result.trial) : result.reason === 'already_active' ? tokenTpl.alreadyActive : result.reason === 'not_recoverable' ? tokenTpl.notRecoverable : result.reason === 'rate_limited' ? tokenTpl.rateLimited : tokenTpl.invalid;
    const failure = failureTemplate.getContent(ctx);
    await ctx.reply(failure.text, buildReplyOptions(failure));
    await backToMain(ctx);
    return;
  }

  if (result.kind === 'owned' && result.action === 'reauth') {
    // Recovery of the SAME userbot through the existing phone -> OTP -> 2FA
    // re-auth wizard. Nothing is created: the wizard swaps the session on this
    // very row, and the remaining active period is left exactly as it is.
    const remaining = result.expiresAt ? formatRemainingDuration(result.expiresAt) : null;
    const recoveryContent = tokenTpl.recoveryStarted.getContent(ctx, {
      placeholderValues: {
        produk: result.label || 'Userbot',
        sisa_info: `Userbot ini akan dipulihkan (bukan userbot baru).${remaining && remaining !== '-' ? ` Sisa masa aktif tetap *${remaining}* — tidak diperpanjang atau di-reset.` : ' Masa aktif tidak berubah.'}`,
      },
    });
    await ctx.reply(recoveryContent.text, buildReplyOptions(recoveryContent));
    await ubotFlow.beginPhoneStep(ctx.telegram, ctx.from.id, result.userbotId, 'reauth', { returnTo: 'main' });
    logger.info(`User ${ctx.from.id} claimed token -> recovery started for owned userbot #${result.userbotId}`);
    return;
  }

  const kindLabel = result.kind === 'owned' ? '🤖' : '🔥';
  const content = tokenTpl.reactivated.getContent(ctx, { placeholderValues: { produk: `${kindLabel} ${result.label}` } });
  await ctx.reply(content.text, buildReplyOptions(content));
  if (result.newToken) { const tokenContent = newTokenNoticeContent(ctx, result.newToken); await ctx.reply(tokenContent.text, buildReplyOptions(tokenContent)); }
  await backToMain(ctx);
  logger.info(`User ${ctx.from.id} claimed token -> reactivated ${result.kind} "${result.label}"`);
}

module.exports = { klaimTokenHandler, cancelClaim, backFromClaim, handleTokenInput, claimKeyboardMarkup };
