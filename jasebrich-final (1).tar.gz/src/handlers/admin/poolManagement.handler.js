const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { poolHomeKeyboard, poolDetailKeyboard, poolDeleteConfirmKeyboard, poolHomeActionKeyboard, poolAddMethodKeyboard, poolPhoneInputKeyboard, poolSessionInputKeyboard, adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const poolRepo = require('../../database/repositories/userbotPool.repository');
const adminState = require('../../state/adminState');
const gramjsService = require('../../services/gramjs.service');
const logger = require('../../utils/logger');

async function renderPoolHome(ctx, showActions = false) {
  const list = poolRepo.listAll();
  const text =
    `📇 *Stok Userbot Jaseb*\n\n` +
    `Ini adalah akun-akun yang ADMIN sediakan, disewakan otomatis ke buyer "Beli Jaseb" selama masa aktif lalu kembali ke stok.\n\n` +
    (list.length === 0
      ? 'Belum ada stok. Tambahkan minimal 1 agar "Beli Jaseb" bisa diproses.'
      : list
          .map(
            (p) =>
              `${p.status === 'available' ? '🟢' : p.status === 'assigned' ? '🟡' : '⚪'} ${p.label} (#${p.id}) — ${p.status}` +
              (p.status === 'assigned' ? ` -> user ${p.assigned_user_id}, exp ${p.expires_at}` : '')
          )
          .join('\n'));

  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...poolHomeKeyboard(list) });
  if (showActions) {
    await ctx.reply('🔧 *Aksi Stok Userbot*', { parse_mode: 'Markdown', ...poolHomeActionKeyboard() });
  }
}

const poolHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderPoolHome(ctx, Boolean(ctx.__adminReply || (ctx.callbackQuery && ctx.callbackQuery.data === ADMIN_CALLBACK.POOL_HOME)));
});

// Admin adds a pool userbot through one of the two real onboarding methods:
// phone/OTP or an already-authorized GramJS StringSession. The existing
// phone flow is preserved; method choice is only an additional first step.
const poolAddCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = { action: 'admin_pool_method' };
  adminState.set(ctx.from.id, state);
  await renderPoolAddMethod(ctx, state);
});

async function renderPoolAddMethod(ctx, state = {}) {
  const labelNote = state.label ? `\n\n🏷️ Label saat ini: ${JSON.stringify(state.label)}` : '';
  await renderScreen(
    ctx,
    '➕ *Tambah Stok Userbot*\n\nPilih metode penambahan stok:' + labelNote,
    { parse_mode: 'Markdown', ...poolAddMethodKeyboard() }
  );
}

const poolAddPhoneCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const current = adminState.get(ctx.from.id) || {};
  const next = current.label
    ? { action: 'admin_pool_phone', label: current.label, method: 'phone' }
    : { action: 'admin_pool_label', method: 'phone' };
  adminState.set(ctx.from.id, next);
  await promptPoolStep(ctx, next);
});

const poolAddSessionCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const current = adminState.get(ctx.from.id) || {};
  const next = current.label
    ? { action: 'admin_pool_session', label: current.label, method: 'session' }
    : { action: 'admin_pool_label', method: 'session' };
  adminState.set(ctx.from.id, next);
  await promptPoolStep(ctx, next);
});

const poolViewCallback = safeHandler(async (ctx) => {
  const id = Number(String(ctx.callbackQuery.data).split(':')[2]);
  if (!Number.isInteger(id) || id <= 0) { await ctx.answerCbQuery('❌ ID stok tidak valid.', { show_alert: true }); return; }
  const row = poolRepo.findById(id);
  if (!row) { await ctx.answerCbQuery('❌ Stok tidak ditemukan.', { show_alert: true }); return; }
  const reserved = row.status === 'reserved';
  const assigned = row.status === 'assigned';
  const text = [
    '📦 *Detail Stok Userbot Jaseb*', '',
    `🆔 ID: #${row.id}`,
    `🏷️ Label: ${row.label || '-'}`,
    `📱 Nomor: ${row.phone || '-'}`,
    `🤖 Telegram ID: ${row.telegram_userbot_id || '-'}`,
    `📌 Status: ${row.status.toUpperCase()}`,
    reserved ? `🔒 Reservation Order: #${row.reservation_order_id || '-'}` : '',
    reserved ? `⏳ Reservation Expire: ${row.reservation_expires_at || '-'}` : '',
    assigned ? `👤 Assigned User: ${row.assigned_user_id || '-'}` : '',
    assigned ? `🧾 Assigned Order: #${row.assigned_order_id || '-'}` : '',
    assigned ? `⏳ Lease Expire: ${row.expires_at || '-'}` : '',
    `⚙️ Runtime Flags: Promosi=${row.auto_promosi ? 'ON' : 'OFF'}, WTB=${row.wtb_reply ? 'ON' : 'OFF'}, PM=${row.pm_permit ? 'ON' : 'OFF'}`,
  ].filter(Boolean).join('\n');
  await ctx.answerCbQuery();
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...poolDetailKeyboard(id, (row.status === 'available' || row.status === 'disabled') && !reserved && !assigned) });
});

const poolDeleteConfirmCallback = safeHandler(async (ctx) => {
  const id = Number(String(ctx.callbackQuery.data).split(':')[2]);
  const row = poolRepo.findById(id);
  if (!row) { await ctx.answerCbQuery('❌ Stok tidak ditemukan.', { show_alert: true }); return; }
  if (row.status === 'assigned' || row.status === 'reserved' || row.assigned_order_id || row.assigned_user_id || row.reservation_order_id) {
    await ctx.answerCbQuery('❌ Stok sedang digunakan/reserved dan tidak dapat dihapus.', { show_alert: true });
    return;
  }
  await ctx.answerCbQuery();
  const text = `⚠️ *Konfirmasi Hapus Stok*\n\nID: #${row.id}\nLabel: ${row.label}\n\nTindakan ini hanya boleh dilakukan untuk stok yang belum dipakai.`;
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...poolDeleteConfirmKeyboard(id) });
});

const poolDeleteCallback = safeHandler(async (ctx) => {
  const id = Number(String(ctx.callbackQuery.data).split(':')[2]);
  if (!Number.isInteger(id) || id <= 0) { await ctx.answerCbQuery('❌ ID stok tidak valid.', { show_alert: true }); return; }
  const row = poolRepo.findById(id);
  if (!row) { await ctx.answerCbQuery('❌ Stok tidak ditemukan.', { show_alert: true }); return; }
  if (row.status === 'assigned' || row.status === 'reserved' || row.assigned_order_id || row.assigned_user_id || row.reservation_order_id) {
    await ctx.answerCbQuery('❌ Stok sudah digunakan/reserved; penghapusan dibatalkan.', { show_alert: true });
    return;
  }
  const removed = poolRepo.remove(id);
  if (!removed) { await ctx.answerCbQuery('❌ Stok berubah atau tidak lagi dapat dihapus.', { show_alert: true }); return; }
  await ctx.answerCbQuery('🗑️ Stok berhasil dihapus.');
  logger.info(`Admin ${ctx.from.id} removed pool userbot #${id}`);
  await renderPoolHome(ctx);
});

const poolCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  gramjsService.cancelLogin(ctx.from.id);
  adminState.clear(ctx.from.id);
  await renderPoolHome(ctx, true);
});

// ---- text-driven wizard steps (called from adminFlow middleware) ----

async function handlePoolLabelText(ctx, state) {
  const label = ctx.message.text.trim();
  if (!label) {
    await ctx.reply('❌ Label tidak boleh kosong.');
    return;
  }
  const method = state && state.method === 'session' ? 'session' : 'phone';
  const next = { action: method === 'session' ? 'admin_pool_session' : 'admin_pool_phone', label, method };
  adminState.set(ctx.from.id, next);
  await promptPoolStep(ctx, next);
}

/**
 * Prompt + keyboard for the steps a "Kembali" can land on (label, phone).
 * The label already entered is kept in state, so going back from phone to
 * label and forward again never loses valid data.
 */
async function promptPoolMethodStep(ctx, state = {}) {
  await renderPoolAddMethod(ctx, state);
}

async function promptPoolStep(ctx, state) {
  if (state.action === 'admin_pool_label') {
    const methodText = state.method === 'session' ? 'Session String' : 'Nomor Telepon';
    await ctx.reply(
      '➕ *Tambah Stok Userbot*\n\n' +
        `Metode: *${methodText}*\n\n` +
        (state.label ? `Label saat ini: ${JSON.stringify(state.label)}\n\n` : '') +
        'Kirim *label* untuk akun ini (contoh: "Jaseb Slot 1").',
      { parse_mode: 'Markdown', ...adminInputKeyboard(state) }
    );
    return;
  }
  if (state.action === 'admin_pool_session') {
    await ctx.reply(
      '🔑 *Tambah via Session String*\n\nKirim Session String GramJS yang sudah terotorisasi. Session akan divalidasi langsung ke Telegram dan tidak perlu dikirim ulang setelah validasi.',
      { parse_mode: 'Markdown', ...poolSessionInputKeyboard() }
    );
    return;
  }
  await ctx.reply(
    '📱 Bagikan kontak akun Telegram yang akan dijadikan stok, atau ketik nomor manual dengan format +62812xxxxxxx.',
    poolPhoneInputKeyboard()
  );
}

function normalizePhone(raw) {
  let value = String(raw || '').trim().replace(/[^\d+]/g, '');
  if (value.startsWith('00')) value = `+${value.slice(2)}`;
  if (!value.startsWith('+')) value = `+${value}`;
  return value;
}

async function handlePoolPhoneContact(ctx, state) {
  const contact = ctx.message && ctx.message.contact;
  if (!contact || Number(contact.user_id) !== Number(ctx.from.id)) {
    await ctx.reply('❌ Silakan bagikan kontak akun Telegram admin sendiri melalui tombol *Kontak Saya*.', { parse_mode: 'Markdown' });
    return;
  }
  const phone = normalizePhone(contact.phone_number);
  await handlePoolPhoneValue(ctx, state, phone);
}

async function handlePoolPhoneValue(ctx, state, phone) {
  if (!/^\+?\d{8,15}$/.test(phone)) {
    await ctx.reply('❌ Format nomor HP tidak valid. Contoh: +62812xxxxxxx.');
    return;
  }
  await ctx.reply('⏳ Mengirim kode OTP...');
  try {
    await gramjsService.startPhoneLogin(ctx.from.id, phone);
    const next = { action: 'admin_pool_otp', label: state.label, phone };
    adminState.set(ctx.from.id, next);
    await ctx.reply('🔐 Kirim kode OTP dengan format: `1 2 3 4 5` (dipisah spasi).', { parse_mode: 'Markdown', ...adminInputKeyboard(next) });
  } catch (err) {
    logger.error('pool startPhoneLogin failed:', err && err.stack ? err.stack : err);
    await ctx.reply(`❌ Gagal mengirim OTP: ${gramjsService.getUserFacingErrorMessage(err)}`, adminInputKeyboard(state));
  }
}

async function handlePoolPhoneText(ctx, state) {
  return handlePoolPhoneValue(ctx, state, normalizePhone(ctx.message.text));
}

async function finalizePoolActivation(ctx, state, sessionString, telegramUserbotId) {
  const row = poolRepo.create({ label: state.label, phone: state.phone, sessionString, telegramUserbotId });
  adminState.clear(ctx.from.id);
  await ctx.reply(`✅ Userbot *${row.label}* (#${row.id}) ditambahkan ke stok Jaseb.`, { parse_mode: 'Markdown' });
  logger.info(`Admin ${ctx.from.id} added pool userbot #${row.id}`);
  await renderPoolHome(ctx, true);
}

async function deleteSensitiveInputMessage(ctx) {
  try {
    if (ctx.chat && ctx.message && ctx.message.message_id) {
      await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id);
    }
  } catch (_) {
    // Best-effort cleanup only. Never block the business flow if the bot
    // cannot delete the admin's message.
  }
}

function safeAccountDisplay(account) {
  if (!account) return 'Telegram User';
  if (account.username) return `@${String(account.username).replace(/^@+/, '')}`;
  const name = [account.firstName, account.lastName].filter(Boolean).join(' ').trim();
  return name || 'Telegram User';
}

async function handlePoolSessionText(ctx, state) {
  const sessionString = String(ctx.message.text || '').trim();
  await deleteSensitiveInputMessage(ctx);
  if (!sessionString) {
    await ctx.reply('❌ Session tidak boleh kosong.', poolSessionInputKeyboard());
    return;
  }
  if (!state || !state.label) {
    adminState.set(ctx.from.id, { action: 'admin_pool_method' });
    await ctx.reply('❌ Data label stok tidak ditemukan. Pilih kembali metode penambahan stok.', poolAddMethodKeyboard());
    return;
  }

  try {
    await ctx.reply('⏳ Memvalidasi Session String langsung ke Telegram...');
    const verified = await gramjsService.verifySessionString(sessionString);
    const duplicate = poolRepo.findExistingAcrossUserbotTables(
      verified.telegramUserbotId,
      verified.account && verified.account.phone
    );
    if (duplicate) {
      const err = new Error('Akun Telegram tersebut sudah terdaftar sebagai userbot/stok.');
      err.code = 'DUPLICATE_USERBOT';
      throw err;
    }

    const row = poolRepo.create({
      label: state.label,
      phone: verified.account && verified.account.phone ? verified.account.phone : null,
      sessionString: verified.sessionString,
      telegramUserbotId: verified.telegramUserbotId,
    });
    adminState.clear(ctx.from.id);
    await ctx.reply(
      `✅ Userbot ${row.label} (#${row.id}) berhasil ditambahkan ke stok Jaseb.\n\n` +
      `👤 Akun: ${safeAccountDisplay(verified.account)}\n` +
      `🆔 Telegram ID: ${verified.telegramUserbotId}\n` +
      `📌 Status: ${row.status}`
    );
    logger.info(`Admin ${ctx.from.id} added pool userbot #${row.id} from a verified StringSession.`);
    await renderPoolHome(ctx, true);
  } catch (err) {
    if (err && err.code === 'DUPLICATE_USERBOT') {
      logger.warn(`Pool session rejected for duplicate Telegram account by admin ${ctx.from.id}.`);
      await ctx.reply('❌ Akun Telegram tersebut sudah terdaftar sebagai userbot/stok dan tidak dapat ditambahkan dua kali.', poolSessionInputKeyboard());
      return;
    }
    logger.error('pool session validation/create failed:', err && err.stack ? err.stack : err);
    const message = gramjsService.getUserFacingErrorMessage(err);
    await ctx.reply(`❌ ${message}`, poolSessionInputKeyboard());
  }
}

async function handlePoolOtpText(ctx, state) {
  const code = ctx.message.text.replace(/\s+/g, '');
  if (!/^\d{4,7}$/.test(code)) {
    await ctx.reply('❌ Format kode tidak valid. Kirim dengan format: `1 2 3 4 5`.', { parse_mode: 'Markdown' });
    return;
  }
  try {
    const { sessionString, telegramUserbotId } = await gramjsService.submitOtp(ctx.from.id, code);
    try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch (_) {}
    await finalizePoolActivation(ctx, state, sessionString, telegramUserbotId);
  } catch (err) {
    if (err && err.code === '2FA_REQUIRED') {
      const next = { action: 'admin_pool_password', label: state.label, phone: state.phone };
      adminState.set(ctx.from.id, next);
      await ctx.reply('🔒 Akun ini punya 2FA. Kirim password cloud Telegram-nya.', adminInputKeyboard(next));
      return;
    }

    logger.error('pool submitOtp failed:', err && err.stack ? err.stack : err);
    if (err && (err.code === 'PHONE_CODE_EXPIRED' || err.code === 'OTP_ATTEMPT_LIMIT')) {
      const next = { action: 'admin_pool_phone', label: state.label };
      adminState.set(ctx.from.id, next);
      await ctx.reply(
        err.code === 'PHONE_CODE_EXPIRED'
          ? '⏰ Kode OTP sudah kadaluarsa. Silakan kirim ulang nomor HP untuk mendapatkan kode baru.'
          : '🔒 Batas percobaan OTP tercapai. Sesi login dibatalkan. Silakan mulai lagi dari nomor HP.',
        adminInputKeyboard(next)
      );
      return;
    }
    await ctx.reply(`❌ Kode salah/kadaluarsa: ${gramjsService.getUserFacingErrorMessage(err)}.`, adminInputKeyboard(state));
  }
}

async function handlePoolPasswordText(ctx, state) {
  try {
    const { sessionString, telegramUserbotId } = await gramjsService.submitPassword(ctx.from.id, ctx.message.text);
    try { await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id); } catch (_) {}
    await finalizePoolActivation(ctx, state, sessionString, telegramUserbotId);
  } catch (err) {
    logger.error('pool submitPassword failed:', err && err.stack ? err.stack : err);
    if (err && err.code === 'PASSWORD_ATTEMPT_LIMIT') {
      const next = { action: 'admin_pool_phone', label: state.label };
      adminState.set(ctx.from.id, next);
      await ctx.reply('🔒 Batas percobaan password 2FA tercapai. Sesi login dibatalkan. Silakan mulai lagi dari nomor HP.', adminInputKeyboard(next));
      return;
    }
    await ctx.reply(`❌ Password salah: ${gramjsService.getUserFacingErrorMessage(err)}.`, adminInputKeyboard(state));
  }
}

module.exports = {
  poolHomeCallback,
  poolAddCallback,
  poolAddPhoneCallback,
  poolAddSessionCallback,
  poolViewCallback,
  poolDeleteConfirmCallback,
  poolDeleteCallback,
  poolCancelCallback,
  handlePoolLabelText,
  handlePoolPhoneText,
  handlePoolSessionText,
  handlePoolPhoneContact,
  handlePoolOtpText,
  handlePoolPasswordText,
  promptPoolMethodStep,
  promptPoolStep,
};
