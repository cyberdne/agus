const { adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { Markup } = require('telegraf');
// Every button, including the Custom Icon Tombol admin UI's own
// nav/meta buttons, now goes through the same helper and gets
// registered/customizable like any other button in the bot — no
// exceptions. (Previously this screen's own buttons opted out via
// `customizable: false`; that carve-out was removed per product
// decision to register literally every button that exists.)
const { button, replyButton } = require('../../utils/buttons');
const iconConfig = require('../../services/buttonIconConfig.service');
const { escapeMdV2, emojiMdV2 } = require('../../utils/emojiMarkdown');
const adminState = require('../../state/adminState');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const { settingsCallback } = require('./settings.handler');

const PAGE_SIZE = 8;

/**
 * Custom Icon Tombol — practical flow:
 *   1) Admin taps "Pilih Tombol" and gets a paginated list of every
 *      button label the bot has ever rendered (auto-discovered, see
 *      src/utils/buttons.js -> buttonIcons.registerLabel).
 *   2) Admin taps the button they want to customize.
 *   3) Bot asks for ONE emoji (regular or Premium/custom emoji) — no
 *      typing the button name, no special format to remember.
 *   4) Saved instantly, no restart needed.
 *
 * Because step 1 is sourced from an auto-discovered list, any button
 * added by a future feature shows up here automatically as soon as it
 * is rendered once through the button/replyButton helpers — nothing
 * to wire up manually.
 */

function homeKeyboard() {
  return Markup.inlineKeyboard([
    [button.success('🎯 Pilih Tombol untuk Custom Icon', ADMIN_CALLBACK.BUTTON_ICONS_PICK_PAGE(0))],
    [button.danger('♻️ Reset Semua Icon', ADMIN_CALLBACK.BUTTON_ICONS_RESET)],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.SETTINGS_OPEN)],
  ]);
}

function homeText() {
  const rows = iconConfig.list();
  const known = iconConfig.getKnownLabels();
  return (
    `🎨 *Custom Icon Tombol*\n\n` +
    `Ganti icon/emoji tombol mana pun di bot — tinggal pilih tombolnya dari daftar, lalu kirim emoji\\-nya\\. ` +
    `Berlaku untuk *semua* tombol yang ada, termasuk yang akan ditambahkan di fitur\\-fitur berikutnya \\(otomatis terdeteksi\\)\\.\n\n` +
    `Total tombol terdeteksi: ${known.length}\n` +
    `Total custom icon aktif: ${rows.length}\n\n` +
    (rows.length
      ? rows
          .slice(0, 50)
          .map((x) => `• ${emojiMdV2(x)} ${escapeMdV2(x.label)}`)
          .join('\n')
      : 'Belum ada custom icon\\.')
  );
}

async function renderHome(ctx, notice = '') {
  await renderScreen(ctx, `${notice ? escapeMdV2(notice) + '\n\n' : ''}${homeText()}`, { parse_mode: 'MarkdownV2', ...homeKeyboard() });
}

const buttonIconsHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

const buttonIconsResetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  iconConfig.reset();
  await renderHome(ctx, '♻️ Semua custom icon telah direset ke default.');
});

const buttonIconsCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

// ---------------------------------------------------------------------
// Step 1: pick a button from a paginated list
// ---------------------------------------------------------------------

function pickKeyboard(labels, page) {
  const start = page * PAGE_SIZE;
  const pageLabels = labels.slice(start, start + PAGE_SIZE);

  const rows = pageLabels.map((label) => {
    // Token derived from the label's own text, NOT its position in
    // `labels` — see labelToken()/findLabelByToken() in
    // buttonIconConfig.service.js. The known-labels registry can grow
    // (any button rendered anywhere in the bot adds to it) between this
    // render and the admin's tap, which would silently shift a
    // positional index onto a different label.
    const token = iconConfig.labelToken(label);
    const entry = iconConfig.getIcon(label);
    const preview = entry ? `${entry.customEmojiId ? '💎' : entry.icon} ` : '';
    return [button.primary(`${preview}${label}`, ADMIN_CALLBACK.BUTTON_ICONS_PICK_SELECT(token))];
  });

  const nav = [];
  if (page > 0) nav.push(button.primary('⬅️ Sebelumnya', ADMIN_CALLBACK.BUTTON_ICONS_PICK_PAGE(page - 1)));
  if (start + PAGE_SIZE < labels.length) nav.push(button.primary('➡️ Berikutnya', ADMIN_CALLBACK.BUTTON_ICONS_PICK_PAGE(page + 1)));
  if (nav.length) rows.push(nav);

  rows.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.BUTTON_ICONS_HOME)]);
  return Markup.inlineKeyboard(rows);
}

async function renderPickList(ctx, page) {
  const labels = iconConfig.getKnownLabels();
  if (!labels.length) {
    await renderScreen(
      ctx,
      '🎨 *Pilih Tombol*\n\nBelum ada tombol yang terdeteksi. Buka-buka menu bot sebentar (Store, Kontrol Panel, dll) lalu coba lagi — setiap tombol otomatis terdaftar begitu pernah ditampilkan.',
      { parse_mode: 'Markdown', ...Markup.inlineKeyboard([[button.danger('🔙 Kembali', ADMIN_CALLBACK.BUTTON_ICONS_HOME)]]) }
    );
    return;
  }
  const totalPages = Math.max(1, Math.ceil(labels.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(0, page), totalPages - 1);
  await renderScreen(
    ctx,
    `🎨 *Pilih Tombol untuk Custom Icon*\n\nHalaman ${safePage + 1}/${totalPages} — tap salah satu tombol di bawah:`,
    { parse_mode: 'Markdown', ...pickKeyboard(labels, safePage) }
  );
}

const buttonIconsPickPageCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  const page = parseInt(ctx.match[1], 10) || 0;
  await renderPickList(ctx, page);
});

// ---------------------------------------------------------------------
// Step 2: status screen for the picked button
// ---------------------------------------------------------------------

function statusKeyboard(token, hasCustom) {
  const rows = [[button.success('✏️ Set / Ganti Icon', ADMIN_CALLBACK.BUTTON_ICONS_PICK_SET(token))]];
  if (hasCustom) rows.push([button.danger('🗑️ Hapus Icon Ini', ADMIN_CALLBACK.BUTTON_ICONS_PICK_REMOVE(token))]);
  rows.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.BUTTON_ICONS_PICK_PAGE(0))]);
  return Markup.inlineKeyboard(rows);
}

function labelForToken(token) {
  return iconConfig.findLabelByToken(token);
}

async function renderStatus(ctx, token, notice = '') {
  const label = labelForToken(token);
  if (!label) {
    await ctx.reply('❌ Tombol tidak ditemukan (daftar mungkin berubah). Silakan pilih ulang dari daftar.');
    await renderPickList(ctx, 0);
    return;
  }
  const entry = iconConfig.getIcon(label);
  const text =
    `${notice ? escapeMdV2(notice) + '\n\n' : ''}🎨 *${escapeMdV2(label)}*\n\n` +
    `Status:\n${entry ? `✅ Custom aktif: ${emojiMdV2(entry)}${entry.customEmojiId ? ' \\(custom emoji Premium\\)' : ''}` : '⬜ Belum ada custom icon \\(pakai default\\)\\.'}`;
  await renderScreen(ctx, text, { parse_mode: 'MarkdownV2', ...statusKeyboard(token, !!entry) });
}

const buttonIconsPickSelectCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  const token = ctx.match[1];
  await renderStatus(ctx, token);
});

const buttonIconsPickRemoveCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const token = ctx.match[1];
  const label = labelForToken(token);
  if (label) iconConfig.removeIcon(label);
  await renderStatus(ctx, token, '✅ Icon custom untuk tombol ini sudah dihapus.');
});

// ---------------------------------------------------------------------
// Step 3: ask for a single emoji, then save
// ---------------------------------------------------------------------

const buttonIconsPickSetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const token = ctx.match[1];
  const label = labelForToken(token);
  if (!label) {
    await ctx.reply('❌ Tombol tidak ditemukan (daftar mungkin berubah). Silakan pilih ulang dari daftar.');
    await renderPickList(ctx, 0);
    return;
  }
  adminState.set(ctx.from.id, { action: 'admin_button_icon_set', label, token });
  await renderScreen(
    ctx,
    `🎨 *${label}*\n\nKirim *satu emoji* untuk tombol ini (emoji biasa atau custom/Premium emoji — cukup paste, tidak perlu ketik apa-apa lagi).`,
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

async function handleButtonIconText(ctx, state) {
  if (state.action !== 'admin_button_icon_set') return;
  const raw = String(ctx.message.text || '').trim();
  if (!raw) {
    await ctx.reply('❌ Kirim satu emoji untuk tombol ini.');
    return;
  }
  const entities = ctx.message.entities || [];
  const custom = entities.find((e) => e.type === 'custom_emoji');
  const saved = iconConfig.setIcon(state.label, raw, { customEmojiId: custom && custom.custom_emoji_id });
  adminState.clear(ctx.from.id);
  await ctx.reply(
    `✅ Icon untuk “${escapeMdV2(state.label)}” disimpan: ${emojiMdV2(saved)}${saved.customEmojiId ? ' \\(custom emoji Premium\\)' : ''}\\. Langsung aktif tanpa restart\\.`,
    { parse_mode: 'MarkdownV2' }
  );
  await renderStatus(ctx, state.token);
}

module.exports = {
  buttonIconsHomeCallback,
  buttonIconsResetCallback,
  buttonIconsCancelCallback,
  buttonIconsPickPageCallback,
  buttonIconsPickSelectCallback,
  buttonIconsPickSetCallback,
  buttonIconsPickRemoveCallback,
  handleButtonIconText,
};
