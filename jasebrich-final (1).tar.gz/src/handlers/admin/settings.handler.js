const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const { settingsKeyboard } = require('../../keyboards/admin.keyboard');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

const SETTINGS_TEXT = '⚙️ *Settings*\n\nPilih pengaturan yang ingin diubah.';

const settingsCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, SETTINGS_TEXT, { parse_mode: 'Markdown', ...settingsKeyboard() }, ADMIN_CALLBACK.SETTINGS_OPEN);
  logger.debug(`Admin ${ctx.from.id} opened Settings`);
});

module.exports = { settingsCallback };
