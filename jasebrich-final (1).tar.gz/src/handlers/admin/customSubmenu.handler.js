const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const submenuRegistry = require('../../constants/submenu.registry');
const customSubmenuService = require('../../services/custom-submenu.service');
const { applyPlaceholders } = require('../../utils/placeholders');
const adminState = require('../../state/adminState');
const screenState = require('../../state/screenState');
const {
  customSubmenuListKeyboard,
  customSubmenuStatusKeyboard,
  customSubmenuInputCancelKeyboard,
  customSubmenuPreviewKeyboard,
  customSubmenuPreviewBackKeyboard,
  customSubmenuResetConfirmKeyboard,
} = require('../../keyboards/admin.keyboard');
const logger = require('../../utils/logger');
const ownedUserbotRepo = require('../../database/repositories/ownedUserbot.repository');
const panelConfig = require('../../services/panelConfig.service');
const panelState = require('../../state/panelState');
const delayPolicy = require('../../services/delayPolicy.service');
const { isEntityTextInvalidError, buildHtmlFallbackPayload } = require('../../utils/telegramFormatting');

function resolveCallbackSubmenuId(rawValue) {
  return submenuRegistry.resolveCallbackId(rawValue);
}

function formatDate(isoLike) {
  // SQLite datetime('now') gives 'YYYY-MM-DD HH:MM:SS' (UTC). Keep it
  // simple and readable without pulling in a date library.
  if (!isoLike) return '-';
  return isoLike;
}

// Shown to the admin every time they're about to type a custom
// message, so they know placeholders exist without hunting for docs.
function buildPreviewExtra(ctx, submenuId) {
  const normalizedId = String(submenuId || '');

  // Statistics templates are real dynamic templates: their default content
  // reads extra.statistics.* and their custom placeholders are resolved from
  // the same snapshot used by the runtime renderer. Reuse the statistics
  // handler's canonical context builder rather than manufacturing an editor
  // copy or a partial object. The require is intentionally lazy to avoid a
  // top-level dependency cycle during module initialization.
  if (normalizedId === 'admin.statistics' || normalizedId.startsWith('admin.statistics.')) {
    const { buildStatisticsRenderContext } = require('./statistics.handler');
    return buildStatisticsRenderContext();
  }

  if (normalizedId === 'system.ping') {
    const { getPingRenderContext } = require('../ping.handler');
    const ping = getPingRenderContext();
    return {
      ping,
      placeholderValues: {
        bot_ping: ping.botPingMs == null ? '-' : ping.botPingMs,
        db_ping: ping.dbPingMs == null ? 'unavailable' : `${ping.dbPingMs} ms`,
        uptime: ping.uptime,
        memory: ping.memoryRssMb,
        cpu: ping.cpuLoadPercent,
      },
    };
  }

  const panelish = normalizedId.startsWith('control_panel_');
  const activation = normalizedId === 'userbot_activation_success';
  if (!panelish && !activation) return {};

  const panelStateValue = panelState.get(ctx.from.id);
  let asset = null;
  if (panelStateValue && panelStateValue.kind === 'owned' && panelStateValue.id) {
    asset = ownedUserbotRepo.findById(panelStateValue.id);
    if (asset && (asset.user_id !== ctx.from.id || asset.status !== 'active')) asset = null;
  }
  if (!asset) asset = ownedUserbotRepo.listActiveByUser(ctx.from.id)[0] || null;
  if (!asset) return {};

  const settings = panelConfig.getSettings(asset.id);
  const replies = panelConfig.listReplies(asset.id);
  const groups = panelConfig.listGroups(asset.id);
  const msg = panelConfig.getMessage(asset.id);
  return {
    userbot: asset,
    panelStats: {
      autoPromosi: asset.auto_promosi ? 'AKTIF' : 'NONAKTIF',
      wtbReply: asset.wtb_reply ? 'AKTIF' : 'NONAKTIF',
      pmPermit: asset.pm_permit ? 'AKTIF' : 'NONAKTIF',
      groupCount: groups.length,
      replyCount: replies.length,
      messageType: msg ? (msg.kind === 'media' ? 'Media' : msg.kind === 'forward' ? 'Forward' : 'Teks') : 'Belum diatur',
      groupDelay: delayPolicy.formatGroupDelayRange(delayPolicy.readGroupDelayRange(settings, panelConfig.RECOMMENDED_GROUP_DELAY_SECONDS)),
      roundDelay: Number(settings.round_delay_seconds || 0),
      channelStatus: settings.channel_disabled ? 'Nonaktif' : 'Diizinkan',
    },
  };
}

function placeholderInstructions(submenuId) {
  const docs = customSubmenuService.getPlaceholderDocs(submenuId);
  const lines = docs.map((p) => `• \`${p.token}\` — ${p.desc}`);
  return (
    (lines.length
      ? `📌 *Placeholder yang bisa dipakai* (opsional):\n${lines.join('\n')}\n\n`
      : `📌 Template ini tidak menggunakan placeholder dinamis.\n\n`) +
    `Template akan dipakai sesuai context fitur ini. Placeholder di atas hanya menerima data yang memang tersedia pada flow tersebut.`
  );
}

// ---------------------------------------------------------------------
// List
// ---------------------------------------------------------------------

const CUSTOM_SUBMENU_PAGE_SIZE = 8;

function buildCustomSubmenuPage(page = 0) {
  const all = submenuRegistry.getAll({ scope: 'USER' });
  const totalPages = Math.max(1, Math.ceil(all.length / CUSTOM_SUBMENU_PAGE_SIZE));
  const safePage = Math.min(Math.max(0, Number(page) || 0), totalPages - 1);
  const offset = safePage * CUSTOM_SUBMENU_PAGE_SIZE;
  const submenus = all.slice(offset, offset + CUSTOM_SUBMENU_PAGE_SIZE).map((s) => ({
    ...s,
    hasCustom: customSubmenuService.hasCustomContent(s.id),
  }));
  return { submenus, page: safePage, totalPages, total: all.length };
}

async function renderCustomSubmenuList(ctx, page = 0, notice = '') {
  const view = buildCustomSubmenuPage(page);
  const text = `${notice ? `${notice}\n\n` : ''}🎨 *Custom Submenu & Response*\n\n` +
    `Semua pesan user-facing yang terdaftar di source ditampilkan per context fitur. ` +
    `Pilih template yang ingin diubah.\n\n` +
    `Halaman ${view.page + 1}/${view.totalPages} • ${view.total} template`;
  await renderScreen(ctx, text, {
    parse_mode: 'Markdown',
    ...customSubmenuListKeyboard(view.submenus, view),
  });
}

const customSubmenuListCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderCustomSubmenuList(ctx, 0);
});

const customSubmenuPageCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const raw = Number(String(ctx.callbackQuery.data || '').split(':')[2]);
  await renderCustomSubmenuList(ctx, Number.isInteger(raw) && raw >= 0 ? raw : 0);
});

// ---------------------------------------------------------------------
// Select — shows status screen if a custom exists, otherwise goes
// straight to the input prompt (fewer taps for first-time setup).
// ---------------------------------------------------------------------

async function sendActiveTemplateContent(ctx, submenuId) {
  const reference = customSubmenuService.getTemplateReference(submenuId, ctx, buildPreviewExtra(ctx, submenuId));
  const active = reference.activeContent;
  const source = reference.currentCustom ? 'custom' : 'default';
  if (!active || typeof active.text !== 'string' || !active.text.length) {
    throw new Error(`Editor reference content kosong untuk context ${submenuId}`);
  }

  try {
    const replyOptions = customSubmenuService.buildReplyOptions(active);
    const sent = await ctx.reply(active.text, replyOptions);
    logger.debug(
      `Custom Submenu reference sent context=${submenuId} source=${source} ` +
      `messageType=${reference.meta.messageType || 'text'} ` +
      `parseMode=${active.parse_mode || (Array.isArray(active.entities) ? 'entities' : 'none')} ` +
      `messageId=${sent && sent.message_id ? sent.message_id : '-'}`
    );
    return sent;
  } catch (err) {
    // Telegram may reject a technically valid entity payload because of a
    // client/API-specific formatting edge case. Retry exactly once using the
    // loss-minimizing HTML serializer already shared by the runtime. Do not
    // retry unrelated API failures, which could otherwise create duplicates.
    if (Array.isArray(active.entities) && active.entities.length && isEntityTextInvalidError(err) && ctx.chat && typeof ctx.telegram?.sendMessage === 'function') {
      const payload = buildHtmlFallbackPayload({ chat_id: ctx.chat.id, text: active.text, entities: active.entities });
      const sent = await ctx.telegram.sendMessage(ctx.chat.id, payload.text, { parse_mode: payload.parse_mode });
      logger.debug(`Custom Submenu reference formatting fallback used context=${submenuId}`);
      return sent;
    }
    logger.error(
      `Custom Submenu reference send failed context=${submenuId} source=${source} ` +
      `messageType=${reference.meta.messageType || 'text'} ` +
      `chatId=${ctx.chat && ctx.chat.id ? ctx.chat.id : '-'} ` +
      `error=${(err && (err.description || err.message)) || err}`
    );
    throw err;
  }
}

async function showStatusScreen(ctx, submenuId, notice = '') {
  const submenu = submenuRegistry.getById(submenuId);
  if (!submenu) throw new Error('Template context tidak ditemukan.');
  const reference = customSubmenuService.getTemplateReference(submenuId, ctx, buildPreviewExtra(ctx, submenuId));
  const storedCustom = customSubmenuService.getCustomContent(submenuId);
  const status = storedCustom && reference.currentCustom
    ? '✅ Custom aktif'
    : storedCustom
      ? '⚠️ Custom tersimpan tetapi tidak valid — runtime menggunakan default'
      : '⬜ Belum ada custom — runtime menggunakan default';

  const placeholderHint = reference.placeholders.length
    ? `\n\nPlaceholder tersedia: ${reference.placeholders.map((p) => p.token).join(', ')}`
    : '';
  const text =
    `${notice ? notice + '\n\n' : ''}${submenu.label}\n\n` +
    `Status: ${status}\n` +
    (storedCustom ? `Terakhir diperbarui: ${formatDate(storedCustom.updatedAt)}\n` : '') +
    `\nPesan di bawah adalah pesan yang benar-benar digunakan runtime saat ini.${placeholderHint}`;

  if (submenu.scope !== 'USER' || submenu.editable === false) throw new Error('Template ini tidak dapat diedit dari Custom Submenu.');
  await renderScreen(ctx, text, { ...customSubmenuStatusKeyboard(submenuId) });
  await sendActiveTemplateContent(ctx, submenuId);
}

async function showInputPrompt(ctx, submenuId) {
  const submenu = submenuRegistry.getById(submenuId);
  if (!submenu) throw new Error('Template context tidak ditemukan.');

  adminState.set(ctx.from.id, {
    action: 'waiting_for_custom_text',
    submenuId,
    pendingContent: null,
    returnTo: customSubmenuService.hasCustomContent(submenuId) ? 'status' : 'list',
  });

  const reference = customSubmenuService.getTemplateReference(submenuId, ctx, buildPreviewExtra(ctx, submenuId));
  const status = reference.currentCustom ? 'Custom aktif' : 'Menggunakan default';
  const text =
    `🎨 *Custom ${submenu.label}*\n\n` +
    `Status: *${status}*\n` +
    `Batas maksimum: *${reference.maxLength} karakter*\n\n` +
    `Kirim versi custom baru untuk mengganti pesan yang sedang digunakan.\n\n` +
    placeholderInstructions(submenuId) + '\n\n' +
    `Pesan di bawah adalah referensi pesan aktual yang sedang digunakan bot. Jangan ubah placeholder yang ingin tetap dinamis.`;

  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...customSubmenuInputCancelKeyboard() });
  await sendActiveTemplateContent(ctx, submenuId);
}

const customSubmenuSelectCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);

  if (!submenuId) {
    await ctx.reply('❌ Submenu tidak ditemukan.');
    return;
  }

  if (customSubmenuService.hasCustomContent(submenuId)) {
    await showStatusScreen(ctx, submenuId);
  } else {
    await showInputPrompt(ctx, submenuId);
  }
});

const customSubmenuEditCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);

  if (!submenuId) {
    await ctx.reply('❌ Submenu tidak ditemukan.');
    return;
  }

  await showInputPrompt(ctx, submenuId);
});

const customSubmenuResendCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);

  if (!submenuId) {
    await ctx.reply('❌ Submenu tidak ditemukan.');
    return;
  }

  const submenu = submenuRegistry.getById(submenuId);

  adminState.set(ctx.from.id, {
    action: 'waiting_for_custom_text',
    submenuId,
    pendingContent: null,
    returnTo: customSubmenuService.hasCustomContent(submenuId) ? 'status' : 'list',
  });

  const reference = customSubmenuService.getTemplateReference(submenuId, ctx, buildPreviewExtra(ctx, submenuId));
  await renderScreen(
    ctx,
    `🎨 *Custom ${submenu.label}*\n\nSilakan kirim ulang pesan yang ingin digunakan.\n\n` +
      `Batas maksimum: *${reference.maxLength} karakter*.\n\n` +
      placeholderInstructions(submenuId) +
      `\n\nPesan di bawah adalah pesan aktual yang sedang digunakan bot.`,
    { parse_mode: 'Markdown', ...customSubmenuInputCancelKeyboard() }
  );
  await sendActiveTemplateContent(ctx, submenuId);
});

// ---------------------------------------------------------------------
// Preview (of already-saved content, from the status screen)
// ---------------------------------------------------------------------

const customSubmenuPreviewCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);
  if (!submenuId) {
    await ctx.reply('❌ Submenu tidak ditemukan.');
    return;
  }
  const custom = customSubmenuService.getCustomContent(submenuId);

  if (!custom) {
    await renderScreen(ctx, '⬜ Submenu ini belum memiliki custom text.', {}, 'admin');
    return;
  }

  const resolved = applyPlaceholders(custom.text, custom.entities, ctx, buildPreviewExtra(ctx, submenuId));

  // Inline -> edit the same message. Preserve the original Telegram entities
  // instead of adding parse_mode, because the custom text may contain links,
  // spoilers, code, blockquotes or premium/custom emoji.
  await renderScreen(ctx, resolved.text, {
    entities: resolved.entities,
    ...customSubmenuPreviewBackKeyboard(submenuId),
  }, 'admin');
});

// ---------------------------------------------------------------------
// Text capture — invoked from the global admin-state middleware in
// index.js when an admin is in the 'waiting_for_custom_text' state.
// ---------------------------------------------------------------------

async function handleIncomingCustomText(ctx, state) {
  const submenu = submenuRegistry.getById(state.submenuId);

  const message = ctx.message || {};
  const text = typeof message.text === 'string' ? message.text : typeof message.caption === 'string' ? message.caption : '';
  if (!text.trim()) {
    await ctx.reply('❌ Custom Submenu hanya menerima pesan teks atau caption teks. Kirim ulang konten yang ingin disimpan.');
    return;
  }
  const entities = Array.isArray(message.entities) ? message.entities : Array.isArray(message.caption_entities) ? message.caption_entities : [];
  const pendingContent = customSubmenuService.validateContent({
    text,
    entities,
  }, state.submenuId);

  adminState.set(ctx.from.id, {
    action: 'previewing',
    submenuId: state.submenuId,
    pendingContent,
    returnTo: state.returnTo || 'list',
  });

  const previewExtra = buildPreviewExtra(ctx, state.submenuId);
  const resolved = applyPlaceholders(pendingContent.text, pendingContent.entities, ctx, previewExtra);
  const hasPlaceholder = resolved.text !== pendingContent.text;

  await ctx.reply(
    `👀 *Preview Custom ${submenu.label}*\n\n` +
      `Pesan di bawah adalah preview dari pesan yang kamu kirim. Apakah sudah sesuai?` +
      (hasPlaceholder
        ? `\n\n_Placeholder di bawah sudah diganti pakai data akun kamu sebagai contoh — pengguna lain akan melihat data mereka masing-masing._`
        : ''),
    { parse_mode: 'Markdown' }
  );

  // Rendered with placeholders resolved (using the admin's own data
  // as an example) so what they see here matches what a real user
  // would see, with the save/resend/cancel controls attached to it.
  // This becomes the new "screen" message — its buttons will be
  // edited in place from here on.
  const sent = await ctx.reply(resolved.text, {
    entities: resolved.entities,
    ...customSubmenuPreviewKeyboard(state.submenuId),
  });
  if (ctx.chat && sent && sent.message_id) {
    screenState.set(ctx.chat.id, sent.message_id, 'custom_submenu');
  }
}

// ---------------------------------------------------------------------
// Save
// ---------------------------------------------------------------------

const customSubmenuSaveCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);
  const state = adminState.get(ctx.from.id);

  if (!submenuId || !state || state.action !== 'previewing' || state.submenuId !== submenuId || !state.pendingContent) {
    await ctx.reply('⚠️ Sesi custom text sudah tidak berlaku. Silakan mulai ulang dari Custom Submenu.');
    adminState.clear(ctx.from.id);
    return;
  }

  customSubmenuService.setCustomContent(submenuId, state.pendingContent, ctx.from.id);
  adminState.clear(ctx.from.id);

  const submenu = submenuRegistry.getById(submenuId);
  await showStatusScreen(ctx, submenuId, `✅ Custom text untuk ${submenu.label} berhasil disimpan.`);
  logger.info(`Admin ${ctx.from.id} saved custom content for "${submenuId}"`);
});

// ---------------------------------------------------------------------
// Reset
// ---------------------------------------------------------------------

const customSubmenuResetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);

  if (!submenuId) {
    await ctx.reply('❌ Submenu tidak ditemukan.');
    return;
  }

  const submenu = submenuRegistry.getById(submenuId);
  const text =
    `⚠️ *Reset Custom Text?*\n\n` +
    `Custom text ${submenu.label} akan dihapus dan bot kembali menggunakan text default.`;

  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...customSubmenuResetConfirmKeyboard(submenuId) });
});

const customSubmenuResetConfirmCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const submenuId = resolveCallbackSubmenuId(ctx.match[1]);

  if (!submenuId) {
    await ctx.reply('❌ Submenu tidak ditemukan.');
    return;
  }

  customSubmenuService.deleteCustomContent(submenuId);
  adminState.clear(ctx.from.id);

  const submenu = submenuRegistry.getById(submenuId);
  await renderScreen(ctx, `♻️ Custom text ${submenu.label} telah direset ke default.`, {});
  logger.info(`Admin ${ctx.from.id} reset custom content for "${submenuId}"`);
});

// ---------------------------------------------------------------------
// Cancel — returns the admin to wherever they were before starting
// the input flow (status screen if a custom already existed, the
// submenu list otherwise) instead of leaving them at a dead end.
// ---------------------------------------------------------------------

const customSubmenuCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  const state = adminState.get(ctx.from.id);
  adminState.clear(ctx.from.id);

  const submenuId = state && state.submenuId;
  const returnTo = state && state.returnTo;

  if (submenuId && returnTo === 'status' && submenuRegistry.exists(submenuId)) {
    await showStatusScreen(ctx, submenuId);
    return;
  }

  await renderCustomSubmenuList(ctx, 0, '❌ Dibatalkan.');
});

module.exports = {
  customSubmenuListCallback,
  customSubmenuPageCallback,
  customSubmenuSelectCallback,
  customSubmenuEditCallback,
  customSubmenuResendCallback,
  customSubmenuPreviewCallback,
  customSubmenuSaveCallback,
  customSubmenuResetCallback,
  customSubmenuResetConfirmCallback,
  customSubmenuCancelCallback,
  handleIncomingCustomText,
};
