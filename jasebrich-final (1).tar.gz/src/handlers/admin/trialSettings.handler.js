const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const {
  trialSettingsHomeKeyboard,
  trialFeatureChecklistKeyboard,
  adminInputKeyboard,
} = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const trialConfigService = require('../../services/trialConfig.service');
const featureAccess = require('../../services/featureAccess.service');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

/** TASK 15/30 — live, never-hardcoded status line for the Trial Settings home screen. */
function trialFeatureAccessSummaryLine() {
  const configured = featureAccess.getTrialFeatureAccess();
  const total = featureAccess.listFeatures().length;
  if (configured === null) return '🔓 Semua fitur (belum dibatasi)';
  if (configured.length === 0) return '🔒 Tidak ada fitur yang diizinkan';
  return `🔐 ${configured.length} dari ${total} fitur aktif`;
}

async function renderTrialSettingsHome(ctx) {
  const hours = trialConfigService.getTrialDurationHours();
  const text =
    `🎁 *Durasi Trial*\n\n` +
    `Setiap user baru bisa klaim free trial 1× seumur hidup. Userbot trial akan aktif selama durasi ini sejak diklaim.\n\n` +
    `⏱️ Durasi saat ini: *${hours} jam*\n\n` +
    `🔐 *Akses Fitur Trial*\n` +
    `${trialFeatureAccessSummaryLine()}`;
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...trialSettingsHomeKeyboard() });
}

const trialSettingsHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderTrialSettingsHome(ctx);
});

const trialSettingsSetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_trial_duration' });
  await renderScreen(ctx, '🔢 Kirim durasi trial dalam *jam* (angka bulat, minimal 1). Contoh: `1`', {
    parse_mode: 'Markdown',
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const trialSettingsCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderTrialSettingsHome(ctx);
});

async function handleTrialDurationText(ctx, state) {
  if (state.action !== 'admin_trial_duration') return;

  try {
    trialConfigService.setTrialDurationHours(ctx.message.text.trim());
  } catch (err) {
    await ctx.reply(`❌ ${(err && err.message) || 'Durasi tidak valid.'} Coba lagi.`);
    return;
  }

  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Durasi trial tersimpan.');
  await renderTrialSettingsHome(ctx);
  logger.info(`Admin ${ctx.from.id} updated trial duration to ${trialConfigService.getTrialDurationHours()} hour(s)`);
}

// ======================================================================
// TRIAL -> AKSES FITUR TRIAL
//
// Same shape as Product Management's Feature Access editor
// (productManagement.handler.js#productEditFeatureToggleCallback /
// ...SaveCallback / ...CancelCallback): staged selection lives in
// adminState under a DEDICATED action ('admin_trial_features', never the
// generic 'admin_trial_duration') so it can never collide with the Set
// Durasi text step; nothing is persisted until Simpan is pressed.
// ======================================================================

function trialFeatureChecklistText() {
  return (
    `🔐 *Akses Fitur Trial*\n\n` +
    `Pilih fitur yang boleh digunakan userbot selama free trial. Perubahan berlaku *langsung* untuk trial yang sedang aktif setelah disimpan.\n\n` +
    `${trialFeatureAccessSummaryLine()}`
  );
}

async function renderTrialFeatureChecklist(ctx, selectedFeatures) {
  await renderScreen(ctx, trialFeatureChecklistText(), {
    parse_mode: 'Markdown',
    ...trialFeatureChecklistKeyboard(selectedFeatures),
  });
}

// trial_settings:features
const trialFeaturesHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  // NULL (unrestricted) opens the editor with every box checked, since
  // that's the capability set unrestricted actually grants today — same
  // convention as Product Management's Edit Feature Access entry point.
  const configured = featureAccess.getTrialFeatureAccess();
  const selectedFeatures = configured === null ? featureAccess.listFeatures().map((f) => f.id) : configured;
  adminState.set(ctx.from.id, { action: 'admin_trial_features', selectedFeatures });
  await renderTrialFeatureChecklist(ctx, selectedFeatures);
});

// trial_settings:feattoggle:<featureId>
const trialFeaturesToggleCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const featureId = ctx.callbackQuery.data.split(':')[2];
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_trial_features') {
    await ctx.reply('❌ Sesi edit sudah kadaluarsa. Silakan buka ulang dari Durasi Trial.');
    return;
  }
  if (!featureAccess.isValidFeatureId(featureId)) {
    await ctx.reply('❌ Fitur tidak dikenali.');
    return;
  }
  const current = new Set(state.selectedFeatures || []);
  if (current.has(featureId)) current.delete(featureId);
  else current.add(featureId);
  const selectedFeatures = Array.from(current);
  adminState.set(ctx.from.id, { ...state, selectedFeatures });
  await renderTrialFeatureChecklist(ctx, selectedFeatures);
});

// trial_settings:featsave
const trialFeaturesSaveCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_trial_features') {
    await ctx.reply('❌ Sesi edit sudah kadaluarsa. Silakan buka ulang dari Durasi Trial.');
    return;
  }
  // setTrialFeatureAccess validates every id against FEATURE_REGISTRY and
  // never trusts staged state; on any unexpected failure the state (and
  // the admin's selection) is kept so Simpan can simply be pressed again.
  try {
    featureAccess.setTrialFeatureAccess(state.selectedFeatures || []);
  } catch (err) {
    logger.error(`Admin ${ctx.from.id} failed saving trial feature access: ${err && err.message}`);
    await ctx.reply('❌ Gagal menyimpan Akses Fitur Trial. Coba tekan Simpan lagi.');
    return;
  }
  adminState.clear(ctx.from.id);
  logger.info(`Admin ${ctx.from.id} saved trial feature access: [${(state.selectedFeatures || []).join(', ')}]`);
  await ctx.reply('✅ Akses Fitur Trial tersimpan.');
  await renderTrialSettingsHome(ctx);
});

// trial_settings:featreset — TASK 32: explicitly restore NULL/unrestricted.
const trialFeaturesResetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_trial_features') {
    await ctx.reply('❌ Sesi edit sudah kadaluarsa. Silakan buka ulang dari Durasi Trial.');
    return;
  }
  featureAccess.resetTrialFeatureAccess();
  adminState.clear(ctx.from.id);
  logger.info(`Admin ${ctx.from.id} reset trial feature access to unrestricted`);
  await ctx.reply('✅ Akses Fitur Trial dikembalikan ke 🔓 Semua fitur.');
  await renderTrialSettingsHome(ctx);
});

// trial_settings:featcancel — discard staged checklist, keep persisted config unchanged.
const trialFeaturesCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderTrialSettingsHome(ctx);
});

// Admin typed text instead of using the checklist buttons.
async function handleTrialFeaturesText(ctx) {
  await ctx.reply('❌ Gunakan tombol di atas untuk memilih fitur.');
}

module.exports = {
  trialSettingsHomeCallback,
  trialSettingsSetCallback,
  trialSettingsCancelCallback,
  handleTrialDurationText,
  trialFeaturesHomeCallback,
  trialFeaturesToggleCallback,
  trialFeaturesSaveCallback,
  trialFeaturesResetCallback,
  trialFeaturesCancelCallback,
  handleTrialFeaturesText,
};
