const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { notificationHomeKeyboard, notificationRegistrationKeyboard, notificationTransactionKeyboard } = require('../../keyboards/admin.keyboard');
const notificationService = require('../../services/notification.service');
const adminState = require('../../state/adminState');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const logger = require('../../utils/logger');

const HOME_TEXT = '🔔 *Notifikasi*\n\nPusat konfigurasi notification log registrasi dan transaksi.';

function registrationText() {
  const current = notificationService.getChannel('registration');
  return `🆕 *Log Registrasi*\n\nChannel aktif: *${current ? escapeMarkdown(current.title) : 'Belum diset'}*`;
}

function transactionText() {
  const current = notificationService.getChannel('transaction');
  const duration = notificationService.getTransactionDurationMinutes();
  return (
    `💳 *Log Transaksi*\n\n` +
    `Channel aktif: *${current ? escapeMarkdown(current.title) : 'Belum diset'}*\n` +
    `Durasi aktif notification baru: *${duration} menit*`
  );
}

function escapeMarkdown(text) {
  return String(text || '').replace(/([_*[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

async function renderHome(ctx) {
  await renderScreen(ctx, HOME_TEXT, { parse_mode: 'Markdown', ...notificationHomeKeyboard() });
}

async function renderRegistration(ctx) {
  await renderScreen(ctx, registrationText(), { parse_mode: 'Markdown', ...notificationRegistrationKeyboard(notificationService.getChannel('registration')) });
}

async function renderTransaction(ctx) {
  await renderScreen(ctx, transactionText(), { parse_mode: 'Markdown', ...notificationTransactionKeyboard(notificationService.getChannel('transaction'), notificationService.getTransactionDurationMinutes()) });
}

const notificationHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

const notificationRegistrationHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderRegistration(ctx);
});

const notificationTransactionHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderTransaction(ctx);
});

const notificationSetRegistrationChannelCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_notification_registration_channel' });
  await ctx.reply('📢 Kirim @username channel atau chat ID channel (-100...). Bot akan memvalidasi type dan permission sebelum disimpan.', {
    reply_markup: require('../../keyboards/admin.keyboard').adminInputKeyboard(adminState.get(ctx.from.id)).reply_markup,
  });
});

const notificationSetTransactionChannelCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_notification_transaction_channel' });
  await ctx.reply('📢 Kirim @username channel atau chat ID channel (-100...). Bot akan memvalidasi type dan permission sebelum disimpan.', {
    reply_markup: require('../../keyboards/admin.keyboard').adminInputKeyboard(adminState.get(ctx.from.id)).reply_markup,
  });
});

const notificationSetDurationCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_notification_transaction_duration' });
  await ctx.reply(`⏱️ Kirim durasi notification transaksi dalam menit (${notificationService.MIN_DURATION_MINUTES}-${notificationService.MAX_DURATION_MINUTES}). Durasi baru hanya berlaku untuk transaksi berikutnya.` , {
    reply_markup: require('../../keyboards/admin.keyboard').adminInputKeyboard(adminState.get(ctx.from.id)).reply_markup,
  });
});

const notificationResetRegistrationCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Channel registrasi di-reset.');
  notificationService.resetChannel('registration');
  await renderRegistration(ctx);
});

const notificationResetTransactionCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Channel transaksi di-reset.');
  notificationService.resetChannel('transaction');
  await renderTransaction(ctx);
});

async function handleNotificationText(ctx, state) {
  if (!state || !['admin_notification_registration_channel', 'admin_notification_transaction_channel', 'admin_notification_transaction_duration'].includes(state.action)) return false;
  const text = typeof ctx.message?.text === 'string' ? ctx.message.text.trim() : '';
  if (!text) return true;
  try {
    if (state.action === 'admin_notification_transaction_duration') {
      const value = notificationService.setTransactionDuration(text);
      adminState.clear(ctx.from.id);
      await ctx.reply(`✅ Durasi notification transaksi disimpan: ${value} menit.`);
      await renderTransaction(ctx);
      return true;
    }
    const kind = state.action === 'admin_notification_registration_channel' ? 'registration' : 'transaction';
    const validated = await notificationService.validateChannel(ctx.telegram, text);
    notificationService.setChannel(kind, validated);
    adminState.clear(ctx.from.id);
    await ctx.reply(`✅ Channel ${kind === 'registration' ? 'registrasi' : 'transaksi'} berhasil disimpan: *${escapeMarkdown(validated.title)}*`, { parse_mode: 'Markdown' });
    if (kind === 'transaction') await notificationService.sweepTransactionNotifications(ctx.telegram);
    await (kind === 'registration' ? renderRegistration(ctx) : renderTransaction(ctx));
    return true;
  } catch (err) {
    logger.warn(`Notification admin input gagal: ${(err && err.message) || err}`);
    await ctx.reply(`❌ ${String(err && err.message || 'Konfigurasi tidak valid.')}\n\nCoba lagi dengan data yang benar.`);
    return true;
  }
}

const notificationCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

module.exports = {
  notificationHomeCallback,
  notificationRegistrationHomeCallback,
  notificationTransactionHomeCallback,
  notificationSetRegistrationChannelCallback,
  notificationSetTransactionChannelCallback,
  notificationSetDurationCallback,
  notificationResetRegistrationCallback,
  notificationResetTransactionCallback,
  notificationCancelCallback,
  handleNotificationText,
};
