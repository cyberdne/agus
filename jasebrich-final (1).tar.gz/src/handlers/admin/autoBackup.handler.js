'use strict';
const path = require('path');
const { Markup } = require('telegraf');
const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { button: rawButton } = require('../../utils/buttons');
const { escapeHtml } = require('../../utils/telegramFormatting');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const autoBackup = require('../../services/autoBackup.service');
const policy = require('../../services/autoBackup.policy');

const button = {
  primary: (l, cb, o) => rawButton.primary(l, cb, { ...o, customizable: false }),
  success: (l, cb, o) => rawButton.success(l, cb, { ...o, customizable: false }),
  danger: (l, cb, o) => rawButton.danger(l, cb, { ...o, customizable: false }),
};

function onOff(on, label) {
  return `${label}: ${on ? '🟢 ON' : '⚪ OFF'}`;
}

function homeText(cfg, notice = '') {
  const last = cfg.lastRunAt
    ? `${escapeHtml(cfg.lastRunAt)} UTC — ${escapeHtml(cfg.lastStatus || '-')}` +
      (cfg.lastFile ? `\n📄 ${escapeHtml(cfg.lastFile)}` : '') +
      (cfg.lastError ? `\n⚠️ ${escapeHtml(cfg.lastError)}` : '')
    : 'Belum pernah berjalan';
  return `${notice ? `${notice}\n\n` : ''}🗄️ <b>Backup Otomatis Database</b>\n\n` +
    `Salinan database dibuat dengan API backup SQLite (aman saat bot sedang menulis), diverifikasi integritasnya, ` +
    `lalu file lama dihapus sesuai retensi.\n\n` +
    `⚙️ Status: <b>${cfg.enabled ? 'AKTIF' : 'NONAKTIF'}</b>\n` +
    `⏱️ Interval: <b>${cfg.intervalHours} jam</b>\n` +
    `🗂️ Retensi: <b>${cfg.retention} file</b>\n` +
    `📤 Kirim ke admin: <b>${cfg.sendToAdmin ? 'Ya' : 'Tidak'}</b>\n\n` +
    `🕒 Terakhir: ${last}`;
}

function homeKeyboard(cfg) {
  return Markup.inlineKeyboard([
    [button.primary(onOff(cfg.enabled, 'Backup Otomatis'), ADMIN_CALLBACK.AUTO_BACKUP_TOGGLE)],
    [
      button.primary(`⏱️ ${cfg.intervalHours} jam`, ADMIN_CALLBACK.AUTO_BACKUP_INTERVAL),
      button.primary(`🗂️ ${cfg.retention} file`, ADMIN_CALLBACK.AUTO_BACKUP_RETENTION),
    ],
    [button.primary(onOff(cfg.sendToAdmin, 'Kirim ke admin'), ADMIN_CALLBACK.AUTO_BACKUP_SEND)],
    [button.success('▶️ Jalankan Sekarang', ADMIN_CALLBACK.AUTO_BACKUP_RUN)],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.SETTINGS_BACKUP_HOME)],
  ]);
}

async function show(ctx, notice = '') {
  const cfg = autoBackup.getConfig();
  await renderScreen(ctx, homeText(cfg, notice), { parse_mode: 'HTML', ...homeKeyboard(cfg) });
}

const autoBackupHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await show(ctx);
});

const autoBackupToggleCallback = safeHandler(async (ctx) => {
  const cfg = autoBackup.getConfig();
  autoBackup.updateSettings({ enabled: !cfg.enabled });
  await show(ctx);
});

const autoBackupIntervalCallback = safeHandler(async (ctx) => {
  const cfg = autoBackup.getConfig();
  autoBackup.updateSettings({ intervalHours: policy.nextIntervalOption(cfg.intervalHours) });
  await show(ctx);
});

const autoBackupRetentionCallback = safeHandler(async (ctx) => {
  const cfg = autoBackup.getConfig();
  autoBackup.updateSettings({ retention: policy.nextRetentionOption(cfg.retention) });
  await show(ctx);
});

const autoBackupSendCallback = safeHandler(async (ctx) => {
  const cfg = autoBackup.getConfig();
  autoBackup.updateSettings({ sendToAdmin: !cfg.sendToAdmin });
  await show(ctx);
});

const autoBackupRunCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Membuat backup...').catch(() => {});
  try {
    const { file, bytes, pruned, delivery } = await autoBackup.runNow({ telegram: ctx.telegram });
    const sent = delivery.delivered > 0
      ? `\n📤 Dikirim ke ${delivery.delivered} admin.`
      : delivery.skippedSize ? '\n📦 File melebihi batas upload Telegram, tidak dikirim.' : '';
    await show(ctx, `✅ Backup dibuat: ${escapeHtml(path.basename(file))} (${(bytes / 1024).toFixed(1)} KB). ` +
      `File lama dihapus: ${pruned}.${sent}`);
  } catch (err) {
    await show(ctx, `❌ Backup gagal: ${escapeHtml(err.message)}`);
  }
});

module.exports = {
  autoBackupHomeCallback, autoBackupToggleCallback, autoBackupIntervalCallback,
  autoBackupRetentionCallback, autoBackupSendCallback, autoBackupRunCallback,
};
