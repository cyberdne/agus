const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { transactionListKeyboard, transactionDetailKeyboard, adminPanelKeyboard } = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const orderRepo = require('../../database/repositories/order.repository');
const orderService = require('../../services/order.service');
const notificationService = require('../../services/notification.service');
const { formatRupiah } = require('../../services/product.service');
const { notifyApprovedOrder, notifyRejectedOrder } = require('./orderConfirm.handler');
const logger = require('../../utils/logger');

const PAGE_SIZE = 10;

function parseId(data, prefix) {
  const raw = String(data || '');
  if (!raw.startsWith(prefix)) return null;
  const value = Number(raw.slice(prefix.length));
  return Number.isSafeInteger(value) && value > 0 ? value : null;
}

function parsePage(data) {
  const value = Number(String(data || '').split(':')[2]);
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmtDate(value) {
  if (!value) return '-';
  const d = new Date(value);
  return Number.isFinite(d.getTime()) ? d.toISOString().replace('T', ' ').replace('.000Z', ' UTC') : String(value);
}

function paymentStatus(order) {
  if (!order) return '-';
  if (order.status === 'expired') return 'KEDALUWARSA';
  if (order.status === 'cancelled') return order.payment_proof_file_id ? 'DITOLAK/DIBATALKAN' : 'DIBATALKAN';
  if (order.status === 'rejected') return 'DITOLAK';
  if (order.status === 'awaiting_confirmation') return 'MENUNGGU REVIEW';
  if (order.status === 'paid') return 'DISETUJUI / MENUNGGU FULFILLMENT';
  if (order.status === 'fulfilled') return 'DISETUJUI / FULFILLED';
  if (order.payment_proof_file_id) return 'BUKTI TERKIRIM';
  return 'BELUM ADA BUKTI';
}

function productLabel(order) {
  return order?.product_name || order?.current_product_name || 'Produk dihapus';
}

function transactionListText(rows, page, totalCount) {
  const totalPages = Math.max(1, Math.ceil(Number(totalCount || 0) / PAGE_SIZE));
  const body = rows.length
    ? rows.map((o) => {
        const buyer = o.user_first_name || o.user_username || `User ${o.user_id}`;
        return `• <b>#${o.id}</b> — ${escapeHtml(productLabel(o))}\n  👤 ${escapeHtml(buyer)} (<code>${escapeHtml(o.user_id)}</code>)\n  📦 Qty: ${escapeHtml(o.qty)} • 💰 ${escapeHtml(formatRupiah(Number(o.total_price || 0)))}\n  📌 Order: ${escapeHtml(o.status)} • 💳 ${escapeHtml(paymentStatus(o))}\n  ⏳ Exp: ${escapeHtml(fmtDate(o.expires_at))}\n  ✅ Fulfillment: ${escapeHtml(o.fulfillment_ref || '-')}`;
      }).join('\n\n')
    : 'Belum ada transaksi.';
  return `🧾 <b>Transaksi</b>\n\n${body}\n\nHalaman ${page + 1}/${totalPages} • Total ${Number(totalCount || 0)}`;
}

function transactionDetailText(order, note = '') {
  const buyerName = order.user_first_name || order.user_username || `User ${order.user_id}`;
  const lines = [
    '🧾 <b>Detail Transaksi</b>',
    note ? `⚠️ ${escapeHtml(note)}` : '',
    '',
    `<b>Order:</b> #${escapeHtml(order.id)}`,
    `<b>User:</b> ${escapeHtml(buyerName)} (<code>${escapeHtml(order.user_id)}</code>)`,
    `<b>Username:</b> @${escapeHtml(order.user_username || '-')}`,
    `<b>Produk:</b> ${escapeHtml(productLabel(order))}`,
    `<b>Tipe:</b> ${escapeHtml(order.category || order.current_product_category || '-')}`,
    `<b>Quantity:</b> ${escapeHtml(order.qty)}`,
    `<b>Harga/unit:</b> ${escapeHtml(formatRupiah(Number(order.unit_price || 0)))}`,
    `<b>Total:</b> ${escapeHtml(formatRupiah(Number(order.total_price || 0)))}`, 
    `<b>Durasi:</b> ${escapeHtml(order.duration_days)} hari`,
    `<b>Status Order:</b> ${escapeHtml(order.status)}`,
    `<b>Status Payment:</b> ${escapeHtml(paymentStatus(order))}`,
    `<b>Fulfillment:</b> ${escapeHtml(order.fulfillment_ref || '-')}`,
    `<b>Bukti:</b> ${order.payment_proof_file_id ? `${escapeHtml(order.payment_proof_type || 'media')} tersimpan` : 'belum ada'}`,
    `<b>Dibuat:</b> ${escapeHtml(fmtDate(order.created_at))}`,
    `<b>Diubah:</b> ${escapeHtml(fmtDate(order.updated_at))}`,
    `<b>Expired:</b> ${escapeHtml(fmtDate(order.expires_at))}`,
  ];
  return lines.filter((x) => x !== '').join('\n');
}

async function renderTransactionDetail(ctx, order, note = '') {
  const id = Number(order?.id || 0);
  return renderScreen(
    ctx,
    transactionDetailText(order, note),
    { parse_mode: 'HTML', ...transactionDetailKeyboard(order) },
    `admin_transactions_detail:${id}`
  );
}

async function showTransactionList(ctx, page = 0) {
  const total = orderRepo.countForAdmin();
  const safePage = Math.min(Math.max(0, Number(page) || 0), Math.max(0, Math.ceil(total / PAGE_SIZE) - 1));
  const rows = orderRepo.listForAdmin({ offset: safePage * PAGE_SIZE, limit: PAGE_SIZE });
  await renderScreen(ctx, transactionListText(rows, safePage, total), {
    parse_mode: 'HTML',
    ...transactionListKeyboard(rows, safePage, total),
  }, 'admin_transactions');
}

const transactionHomeCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  await showTransactionList(ctx, 0);
});

const transactionListCallback = safeHandler(async (ctx) => {
  const page = parsePage(ctx.callbackQuery.data);
  if (page === null) {
    await ctx.answerCbQuery('❌ Halaman transaksi tidak valid.', { show_alert: true });
    return;
  }
  await ctx.answerCbQuery();
  await showTransactionList(ctx, page);
});

const transactionViewCallback = safeHandler(async (ctx) => {
  const id = parseId(ctx.callbackQuery.data, 'admintrx:view:');
  if (!id) {
    await ctx.answerCbQuery('❌ Order ID tidak valid.', { show_alert: true });
    return;
  }
  const refreshed = orderService.refreshOrder(id);
  const order = refreshed || orderRepo.findById(id);
  if (!order) {
    await ctx.answerCbQuery('❌ Transaksi tidak ditemukan.', { show_alert: true });
    return;
  }
  await ctx.answerCbQuery();
  await renderTransactionDetail(ctx, order);
});

const transactionProofCallback = safeHandler(async (ctx) => {
  const id = parseId(ctx.callbackQuery.data, 'admintrx:proof:');
  if (!id) {
    await ctx.answerCbQuery('❌ Order ID tidak valid.', { show_alert: true });
    return;
  }
  const order = orderRepo.findById(id);
  if (!order || !order.payment_proof_file_id) {
    await ctx.answerCbQuery('❌ Bukti pembayaran tidak tersedia.', { show_alert: true });
    return;
  }
  const caption = `🧾 Bukti pembayaran Order #${order.id}\nUser: ${order.user_id}\nDiterima: ${fmtDate(order.payment_proof_received_at)}`;
  try {
    if (order.payment_proof_type === 'photo') {
      await ctx.telegram.sendPhoto(ctx.chat.id, order.payment_proof_file_id, { caption });
    } else if (order.payment_proof_type === 'document') {
      await ctx.telegram.sendDocument(ctx.chat.id, order.payment_proof_file_id, { caption });
    } else if (order.payment_proof_type === 'video') {
      await ctx.telegram.sendVideo(ctx.chat.id, order.payment_proof_file_id, { caption });
    } else {
      await ctx.answerCbQuery('❌ Tipe bukti pembayaran tidak didukung.', { show_alert: true });
      return;
    }
  } catch (err) {
    logger.error(`Payment proof #${id} retrieval failed:`, err && err.message ? err.message : err);
    await ctx.answerCbQuery('❌ Bukti tersimpan tetapi Telegram menolak file_id tersebut. Periksa data proof transaksi ini.', { show_alert: true });
    await renderTransactionDetail(ctx, order, 'Payment proof tersimpan di database tetapi file Telegram tidak dapat diambil ulang.');
    return;
  }
  await ctx.answerCbQuery('✅ Bukti pembayaran dikirim ke chat admin.');
  await renderTransactionDetail(ctx, order);
});

const transactionApproveCallback = safeHandler(async (ctx) => {
  const id = parseId(ctx.callbackQuery.data, 'admintrx:approve:');
  if (!id) {
    await ctx.answerCbQuery('❌ Order ID tidak valid.', { show_alert: true });
    return;
  }
  const current = orderService.refreshOrder(id);
  if (!current) { await ctx.answerCbQuery('❌ Transaksi tidak ditemukan.', { show_alert: true }); return; }
  if (!['awaiting_confirmation', 'paid'].includes(current.status)) {
    await ctx.answerCbQuery(`❌ Transaksi tidak dapat di-approve pada status ${current.status}.`, { show_alert: true });
    await renderTransactionDetail(ctx, current);
    return;
  }
  let result;
  try {
    result = await orderService.fulfillOrder(ctx.telegram, id);
  } catch (err) {
    const fresh = orderRepo.findById(id);
    logger.error(`Admin transaction approval #${id} failed:`, err && err.message ? err.message : err);
    if (fresh && fresh.status === 'fulfilled') {
      await ctx.answerCbQuery('✅ Approval sudah tercatat di database.', { show_alert: true });
      await renderTransactionDetail(ctx, fresh, 'Approval sudah committed; pengiriman notifikasi/runtime perlu diperiksa.');
      return;
    }
    await ctx.answerCbQuery('❌ Approval gagal diproses; state transaksi tidak diubah menjadi sukses palsu.', { show_alert: true });
    return;
  }
  if (!result.ok) {
    const fresh = result.order || orderRepo.findById(id);
    const message = result.reason === 'already_fulfilled' ? 'Transaksi sudah fulfilled.'
      : result.reason === 'already_processing' ? 'Transaksi sedang diproses admin lain.'
      : result.reason === 'out_of_stock' ? 'Stok belum tersedia untuk legacy order ini; transaksi tetap paid.'
      : result.reason === 'expired' ? 'Transaksi sudah expired.'
      : 'State transaksi sudah berubah.';
    await ctx.answerCbQuery(`❌ ${message}`, { show_alert: true });
    if (fresh) await renderTransactionDetail(ctx, fresh);
    return;
  }
  const fresh = orderRepo.findById(id) || result.order;
  await ctx.answerCbQuery('✅ Approval berhasil.');
  if (notificationService.getChannel('transaction') && fresh) {
    await notificationService.updateTransactionNotification(ctx.telegram, fresh, {
      status: fresh.status === 'fulfilled' ? 'APPROVED' : fresh.status.toUpperCase(),
      actorId: ctx.from.id,
    });
  }
  await notifyApprovedOrder(ctx.telegram, fresh, result);
  await renderTransactionDetail(ctx, fresh);
});

const transactionRejectCallback = safeHandler(async (ctx) => {
  const id = parseId(ctx.callbackQuery.data, 'admintrx:reject:');
  if (!id) { await ctx.answerCbQuery('❌ Order ID tidak valid.', { show_alert: true }); return; }
  const current = orderService.refreshOrder(id);
  if (!current) { await ctx.answerCbQuery('❌ Transaksi tidak ditemukan.', { show_alert: true }); return; }
  if (current.status !== 'awaiting_confirmation') {
    await ctx.answerCbQuery(`❌ Reject tidak tersedia pada status ${current.status}.`, { show_alert: true });
    await renderTransactionDetail(ctx, current);
    return;
  }
  const result = orderService.rejectPendingOrder({ orderId: id });
  if (!result.ok) {
    const fresh = result.order || orderRepo.findById(id);
    await ctx.answerCbQuery('❌ Transaksi sudah berubah atau diproses admin lain.', { show_alert: true });
    if (fresh) await renderTransactionDetail(ctx, fresh);
    return;
  }
  const fresh = result.order || orderRepo.findById(id);
  await notifyRejectedOrder(ctx.telegram, fresh);
  if (notificationService.getChannel('transaction') && fresh) {
    await notificationService.updateTransactionNotification(ctx.telegram, fresh, { status: 'REJECTED', actorId: ctx.from.id });
  }
  await ctx.answerCbQuery('❌ Transaksi ditolak.');
  await renderTransactionDetail(ctx, fresh);
});

module.exports = { transactionHomeCallback, transactionListCallback, transactionViewCallback, transactionProofCallback, transactionApproveCallback, transactionRejectCallback };
