const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { startStickerHomeKeyboard, adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const startStickerService = require('../../services/startSticker.service');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

async function renderStartStickerHome(ctx) {
  const fileId = startStickerService.getStartStickerFileId();
  const text =
    `🎬 *Sticker /start*\n\n` +
    `Sticker ini dikirim ke user selama 3 detik sebelum menu utama muncul, setiap kali mereka /start.\n\n` +
    `Status: ${fileId ? '✅ Sudah diset' : '⬜ Belum diset'}`;
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...startStickerHomeKeyboard(Boolean(fileId)) });
}

const startStickerHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderStartStickerHome(ctx);
});

const startStickerSetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_start_sticker' });
  await renderScreen(ctx, '🎬 Kirim *sticker* yang ingin dipakai saat user /start.', {
    parse_mode: 'Markdown',
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const startStickerRemoveCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  startStickerService.removeStartSticker();
  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Sticker /start dihapus.');
  await renderStartStickerHome(ctx);
  logger.info(`Admin ${ctx.from.id} removed the /start sticker`);
});

const startStickerCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderStartStickerHome(ctx);
});

async function handleStartStickerSticker(ctx, state) {
  if (state.action !== 'admin_start_sticker') return;
  const sticker = ctx.message.sticker;
  if (!sticker || !sticker.file_id) return;

  startStickerService.setStartStickerFileId(sticker.file_id);
  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Sticker /start tersimpan.');
  await renderStartStickerHome(ctx);
  logger.info(`Admin ${ctx.from.id} updated the /start sticker`);
}

module.exports = {
  startStickerHomeCallback,
  startStickerSetCallback,
  startStickerRemoveCallback,
  startStickerCancelCallback,
  handleStartStickerSticker,
};
