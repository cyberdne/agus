const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { joinGateSettingsHomeKeyboard, adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const adminState = require('../../state/adminState');
const joinGateService = require('../../services/joinGate.service');
const logger = require('../../utils/logger');

async function renderJoinGateHome(ctx) {
  const c = joinGateService.getConfig();
  const text =
    `📢 *Wajib Join / Join Gate*\n\n` +
    `Status: ${c.enabled ? '🟢 Aktif' : '🔴 Nonaktif'}\n` +
    `Channel: ${c.channelId ? `✅ ${c.channelTitle}` : '⬜ Belum diset'}\n` +
    `Grup opsional: ${c.groupId ? `✅ ${c.groupTitle}` : '⬜ Belum diset'}\n\n` +
    `User baru akan ditahan di halaman verifikasi sampai bergabung ke channel wajib.`;
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...joinGateSettingsHomeKeyboard(c) });
}

const joinGateHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderJoinGateHome(ctx);
});

const joinGateToggleCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const c = joinGateService.getConfig();
  if (!c.channelId || !c.channelLink) {
    await ctx.reply('❌ Set channel wajib terlebih dahulu.');
    return renderJoinGateHome(ctx);
  }
  joinGateService.setEnabled(!c.enabled);
  await renderJoinGateHome(ctx);
  logger.info(`Admin ${ctx.from.id} ${!c.enabled ? 'enabled' : 'disabled'} join gate`);
});

const joinGateSetChannelCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_join_gate_channel' });
  await renderScreen(ctx,
    `📢 *Set Channel Wajib*\n\n` +
    `Kirim username/channel ID dengan format:\n` +
    `• Public: @username\n` +
    `• Private: -1001234567890 | https://t.me/+invite\n\n` +
    `Bot harus menjadi admin di channel agar dapat mengecek membership.`,
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

const joinGateSetGroupCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_join_gate_group' });
  await renderScreen(ctx,
    `💬 *Set Grup Opsional*\n\n` +
    `Format:\n` +
    `• Public: @username\n` +
    `• Private: -1001234567890 | https://t.me/+invite`,
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

const joinGateRemoveGroupCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  joinGateService.clearGroup();
  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Grup opsional dihapus.');
  await renderJoinGateHome(ctx);
});

const joinGateRemoveChannelCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  joinGateService.clearChannel();
  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Channel wajib dihapus dan Wajib Join dinonaktifkan.');
  await renderJoinGateHome(ctx);
});

const joinGateCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderJoinGateHome(ctx);
});

async function handleJoinGateText(ctx, state) {
  if (!state || !['admin_join_gate_channel', 'admin_join_gate_group'].includes(state.action)) return;
  try {
    if (state.action === 'admin_join_gate_channel') {
      await joinGateService.setChannel(ctx.telegram, ctx.message.text);
      joinGateService.setEnabled(true);
      adminState.clear(ctx.from.id);
      await ctx.reply('✅ Channel wajib tersimpan dan Wajib Join diaktifkan.');
    } else {
      await joinGateService.setGroup(ctx.telegram, ctx.message.text);
      adminState.clear(ctx.from.id);
      await ctx.reply('✅ Grup opsional tersimpan.');
    }
    await renderJoinGateHome(ctx);
  } catch (err) {
    await ctx.reply(`❌ ${err.message}`);
  }
}

module.exports = {
  joinGateHomeCallback,
  joinGateToggleCallback,
  joinGateSetChannelCallback,
  joinGateSetGroupCallback,
  joinGateRemoveGroupCallback,
  joinGateRemoveChannelCallback,
  joinGateCancelCallback,
  handleJoinGateText,
};
