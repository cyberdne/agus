/**
 * Admin Panel -> Settings -> Perpanjang Langganan Userbot
 *
 *   list userbots -> detail -> pick duration (or custom) -> confirm -> apply
 *
 * All callback identifiers carry the stable internal userbots.id (never a
 * label/emoji). The heavy lifting (atomic transaction, audit, idempotency,
 * runtime reconciliation) lives in services/userbotLifecycle.service.js +
 * services/subscription.service.js; this file is presentation only.
 */
const crypto = require('crypto');
const { Markup } = require('telegraf');
const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { button } = require('../../utils/buttons');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const { adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const adminState = require('../../state/adminState');
const ownedRepo = require('../../database/repositories/ownedUserbot.repository');
const userRepository = require('../../database/repositories/user.repository');
const subscription = require('../../services/subscription.service');
const lifecycle = require('../../services/userbotLifecycle.service');
const runtime = require('../../services/userbotRuntime.service');
const { formatIndonesiaDate, formatRemainingDuration } = require('../../utils/placeholders');
const logger = require('../../utils/logger');

const inflight = new Set();

const dateOf = (v) => (v ? formatIndonesiaDate(v) : 'Tanpa batas');
const ownerLabel = (row) => {
  const u = userRepository.findByTelegramId(row.user_id) || {};
  return u.username ? `@${u.username}` : u.first_name || String(row.user_id);
};
const stateIcon = (st) => (st === subscription.STATE.ACTIVE ? '✅' : st === subscription.STATE.EXPIRED ? '⛔' : '⚪');
const esc = (t) => String(t ?? '').replace(/([_*`\[])/g, '\\$1');

function runtimeLine(row) {
  if (runtime.isRunning('owned', row.id)) return '🟢 Berjalan';
  if (row.runtime_stop_reason === 'SESSION_INVALID') return '🔴 Berhenti — sesi Telegram tidak valid';
  if (row.runtime_stop_reason === 'SUBSCRIPTION_EXPIRED') return '🔴 Berhenti — langganan kadaluarsa';
  return '⚪ Berhenti / tidak ada otomasi aktif';
}

function detailText(row) {
  const st = subscription.getSubscriptionState(row);
  return (
    `⏳ *Perpanjang Langganan Userbot*\n\n` +
    `👤 User: ${esc(ownerLabel(row))} (\`${row.user_id}\`)\n` +
    `🤖 Userbot: *#${row.id}* ${esc(row.label || '')}\n` +
    `📌 Status: *${st}*\n` +
    `⏳ Expired: *${dateOf(row.expires_at)}*\n` +
    `🕐 Sisa: *${formatRemainingDuration(row.expires_at)}*\n` +
    `⚙️ Runtime: ${runtimeLine(row)}\n\n` +
    `Pilih durasi perpanjangan:`
  );
}

// ---- list -----------------------------------------------------------------
async function renderList(ctx, filter, page) {
  const data = subscription.listForAdmin({ filter, page });
  const rows = data.rows.map((r) => [
    button.primary(
      `${stateIcon(r.state)} #${r.id} ${r.owner_username ? '@' + r.owner_username : r.user_id} • ${r.state}${r.expires_at ? ' • ' + formatIndonesiaDate(r.expires_at).replace(/ \d{2}\.\d{2} WIB$/, '') : ''}`,
      ADMIN_CALLBACK.SUBEXT_SELECT(r.id)
    ),
  ]);
  const nav = [];
  if (data.page > 0) nav.push(button.primary('⬅️ Prev', ADMIN_CALLBACK.SUBEXT_LIST(filter, data.page - 1)));
  nav.push(button.primary(`${data.page + 1}/${data.totalPages}`, ADMIN_CALLBACK.SUBEXT_LIST(filter, data.page)));
  if (data.page < data.totalPages - 1) nav.push(button.primary('Next ➡️', ADMIN_CALLBACK.SUBEXT_LIST(filter, data.page + 1)));
  rows.push(nav);
  rows.push([
    button.primary(`Semua (${data.counts.all})`, ADMIN_CALLBACK.SUBEXT_LIST('a', 0)),
    button.danger(`Expired (${data.counts.expired})`, ADMIN_CALLBACK.SUBEXT_LIST('e', 0)),
    button.success(`Aktif (${data.counts.active})`, ADMIN_CALLBACK.SUBEXT_LIST('s', 0)),
  ]);
  const text =
    `⏳ *Perpanjang Langganan Userbot*\n\nPilih Userbot milik user (${data.total} ditemukan` +
    `${filter === 'e' ? ', filter: expired' : filter === 's' ? ', filter: aktif' : ''}).`;
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) });
}

const subextHomeCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderList(ctx, 'a', 0);
});

const subextListCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , filter, page] = ctx.callbackQuery.data.split(':');
  await renderList(ctx, ['a', 'e', 's'].includes(filter) ? filter : 'a', Number(page) || 0);
});

// ---- detail ---------------------------------------------------------------
async function renderDetail(ctx, row) {
  const rows = [];
  const opts = subscription.getExtensionOptions().map((d) => button.primary(`+${d} Hari`, ADMIN_CALLBACK.SUBEXT_PICK(row.id, d)));
  for (let i = 0; i < opts.length; i += 3) rows.push(opts.slice(i, i + 3));
  rows.push([button.success('✏️ Custom', ADMIN_CALLBACK.SUBEXT_CUSTOM(row.id))]);
  rows.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.SUBEXT_LIST('a', 0))]);
  await renderScreen(ctx, detailText(row), { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) });
}

function loadExtendable(idStr) {
  const row = ownedRepo.findById(Number(idStr));
  return row && subscription.isRenewable(row) ? row : null;
}

const subextSelectCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  const row = loadExtendable(ctx.callbackQuery.data.split(':')[2]);
  if (!row) return renderScreen(ctx, '❌ Userbot tidak ditemukan atau tidak dapat diperpanjang.', Markup.inlineKeyboard([[button.danger('🔙 Kembali', ADMIN_CALLBACK.SUBEXT_LIST('a', 0))]]));
  await renderDetail(ctx, row);
});

// ---- confirmation ---------------------------------------------------------
async function renderConfirm(ctx, row, days) {
  const calc = subscription.computeExtension(row, days);
  const nonce = crypto.randomBytes(4).toString('hex');
  const text =
    `🧾 *Konfirmasi Perpanjangan*\n\n` +
    `Userbot: *#${row.id}* (${esc(ownerLabel(row))})\n` +
    `Sebelumnya: *${subscription.getSubscriptionState(row)}* — ${dateOf(row.expires_at)}\n` +
    `Durasi: *+${calc.days} Hari*\n` +
    `Dihitung dari: ${calc.base === 'current_expiry' ? 'expiry saat ini (masih aktif)' : 'sekarang (sudah expired)'}\n` +
    `Expiry baru: *${dateOf(calc.newExpiry)}*\n\n` +
    `_Expiry final dihitung ulang dari data terbaru saat kamu menekan Konfirmasi._`;
  await renderScreen(ctx, text, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [button.success('✅ Konfirmasi', ADMIN_CALLBACK.SUBEXT_GO(row.id, calc.days, nonce))],
      [button.danger('❌ Batal', ADMIN_CALLBACK.SUBEXT_CANCEL)],
    ]),
  });
}

const subextPickCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , idStr, daysStr] = ctx.callbackQuery.data.split(':');
  const row = loadExtendable(idStr);
  if (!row) return renderScreen(ctx, '❌ Userbot tidak ditemukan atau tidak dapat diperpanjang.');
  try {
    await renderConfirm(ctx, row, Number(daysStr));
  } catch (err) {
    await ctx.reply(`❌ ${err.message}`);
  }
});

const subextCustomCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const row = loadExtendable(ctx.callbackQuery.data.split(':')[2]);
  if (!row) return renderScreen(ctx, '❌ Userbot tidak ditemukan atau tidak dapat diperpanjang.');
  adminState.set(ctx.from.id, { action: 'admin_subext_custom', userbotId: row.id });
  await ctx.reply(`✏️ Kirim jumlah hari perpanjangan untuk Userbot #${row.id} (angka bulat 1–${subscription.MAX_EXTENSION_DAYS}).`, {
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

async function handleSubextCustomText(ctx, state) {
  const days = Number(String(ctx.message.text).trim());
  if (!Number.isInteger(days) || days < 1 || days > subscription.MAX_EXTENSION_DAYS) {
    await ctx.reply(`❌ Masukkan angka bulat 1–${subscription.MAX_EXTENSION_DAYS}. Coba lagi.`);
    return;
  }
  const row = loadExtendable(state.userbotId);
  adminState.clear(ctx.from.id);
  if (!row) { await ctx.reply('❌ Userbot tidak ditemukan atau tidak dapat diperpanjang.'); return; }
  await renderConfirm(ctx, row, days);
}

const subextCancelCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderList(ctx, 'a', 0);
});

// ---- apply ----------------------------------------------------------------
// subext:go:<userbotId>:<days>:<nonce>
const subextGoCallback = safeHandler(async (ctx) => {
  const [, , idStr, daysStr, nonce] = ctx.callbackQuery.data.split(':');
  const userbotId = Number(idStr);
  const days = Number(daysStr);
  if (!nonce || !/^[0-9a-f]{8}$/.test(nonce)) { await ctx.answerCbQuery('Permintaan tidak valid.'); return; }
  // The operation identity = who + which userbot + how long + THIS confirmation screen.
  const operationId = `admin:${ctx.from.id}:${userbotId}:${days}:${nonce}`;
  if (inflight.has(operationId)) { await ctx.answerCbQuery('Sedang diproses…'); return; }
  inflight.add(operationId);
  try {
    await ctx.answerCbQuery('Memproses…');
    let result;
    try {
      result = await lifecycle.extendAndReconcile({ userbotId, days, operationId, action: 'admin_extend', adminId: ctx.from.id });
    } catch (err) {
      const msg = err instanceof subscription.SubscriptionError ? err.message : 'Terjadi kesalahan. Tidak ada perubahan yang disimpan.';
      if (!(err instanceof subscription.SubscriptionError)) logger.error(`Admin extend gagal userbot #${userbotId}: ${err.message}`);
      await renderScreen(ctx, `❌ Gagal memperpanjang: ${esc(msg)}`, Markup.inlineKeyboard([[button.danger('🔙 Kembali', ADMIN_CALLBACK.SUBEXT_LIST('a', 0))]]));
      return;
    }
    const ev = result.event;
    const backKb = Markup.inlineKeyboard([[button.danger('🔙 Kembali', ADMIN_CALLBACK.SUBEXT_LIST('a', 0))]]);
    if (result.duplicate) {
      await renderScreen(
        ctx,
        `ℹ️ *Operasi ini sudah diproses sebelumnya* — tidak ada perpanjangan ganda.\n\nUserbot: *#${ev.userbot_id}*\nDurasi: +${ev.extension_days} Hari\nExpiry: *${dateOf(ev.new_expiry)}*`,
        { parse_mode: 'Markdown', ...backKb }
      );
      return;
    }
    await renderScreen(
      ctx,
      `✅ *Langganan berhasil diperpanjang*\n\nUserbot: *#${ev.userbot_id}*\nSebelumnya: ${ev.previous_status} — ${dateOf(ev.previous_expiry)}\nDurasi: +${ev.extension_days} Hari\nExpiry baru: *${dateOf(ev.new_expiry)}*\nStatus: *ACTIVE*\n\n${lifecycle.describeRuntime(result.runtime)}`,
      { parse_mode: 'Markdown', ...backKb }
    );
    // Best-effort notice to the owner.
    try {
      await ctx.telegram.sendMessage(
        result.row.user_id,
        `✅ Langganan userbot *#${result.row.id}* telah diperpanjang.\n\n⏳ Masa aktif sekarang sampai: *${dateOf(ev.new_expiry)}*\nAkses Kontrol Panel sudah aktif kembali.`,
        { parse_mode: 'Markdown' }
      );
    } catch (err) {
      logger.warn(`Gagal memberi tahu user ${result.row.user_id} soal perpanjangan: ${err.message}`);
    }
    logger.info(`Admin ${ctx.from.id} extended userbot #${userbotId} +${days}d -> ${ev.new_expiry}`);
  } finally {
    inflight.delete(operationId);
  }
});

module.exports = {
  subextHomeCallback, subextListCallback, subextSelectCallback, subextPickCallback,
  subextCustomCallback, subextGoCallback, subextCancelCallback, handleSubextCustomText,
};
