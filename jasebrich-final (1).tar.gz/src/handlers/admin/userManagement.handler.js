const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const {
  userListKeyboard,
  userDetailKeyboard,
  userDeleteConfirmKeyboard,
  userBanReasonSkipKeyboard,
  userSearchResultKeyboard,
  adminInputKeyboard,
  userListActionKeyboard,
  userSearchActionKeyboard,
  PAGE_SIZE,
} = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const userRepo = require('../../database/repositories/user.repository');
const userService = require('../../services/user.service');
const { formatRupiah } = require('../../services/product.service');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

// ---------- List / Search ----------

// adminuser:list:<page>
const userListCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const page = Number(ctx.callbackQuery.data.split(':')[2]) || 0;
  await renderUserList(ctx, page);
});

async function renderUserList(ctx, page) {
  adminState.clear(ctx.from.id);
  const users = userRepo.listPage(page * PAGE_SIZE, PAGE_SIZE);
  const total = userRepo.count();

  const text =
    `👥 *User Management*\n\n` +
    `Total user: ${total}\n\n` +
    (users.length === 0 ? 'Belum ada user.' : 'Pilih user untuk lihat detail:');

  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...userListKeyboard(users, page, total) });

  // Reply-keyboard actions are installed only when entering the list from a
  // reply/text flow. Inline pagination/user selection must edit in place and
  // must not spam another action-menu message.
  if (ctx.__adminReply) {
    await ctx.reply('🔧 *Aksi User Management*', { parse_mode: 'Markdown', ...userListActionKeyboard() });
  }
}

const userSearchCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_user_search' });
  await renderScreen(
    ctx,
    '🔍 *Cari User*\n\nKirim Telegram ID (angka) atau sebagian username/nama.',
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

async function renderSearchResults(ctx, query, page) {
  const users = userRepo.search(query, page * PAGE_SIZE, PAGE_SIZE);
  const total = userRepo.searchCount(query);

  const text =
    `🔍 *Hasil Pencarian: "${query}"*\n\n` +
    `Ditemukan: ${total} user\n\n` +
    (users.length === 0 ? 'Tidak ada user yang cocok.' : 'Pilih user untuk lihat detail:');

  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...userSearchResultKeyboard(users, page, total, query) });

  if (!ctx.callbackQuery) {
    await ctx.reply('🔧 *Aksi Pencarian User*', { parse_mode: 'Markdown', ...userSearchActionKeyboard() });
  }
}

// adminuser:searchres:<encodedQuery>:<page>
const userSearchResultsCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const parts = ctx.callbackQuery.data.split(':');
  const page = Number(parts[parts.length - 1]) || 0;
  const state = adminState.get(ctx.from.id);
  let query = state && typeof state.searchQuery === 'string' ? state.searchQuery : '';
  // Preserve compatibility with already-sent legacy callbacks that still
  // carry an encoded query, but NEVER create new callbacks in that format.
  if (!query && String(ctx.callbackQuery.data).startsWith('adminuser:searchres:')) {
    const legacy = String(ctx.callbackQuery.data).split(':');
    try { query = decodeURIComponent(legacy.slice(2, -1).join(':')); } catch (_) { query = ''; }
  }
  if (!query) {
    await renderUserList(ctx, 0);
    return;
  }
  await renderSearchResults(ctx, query, page);
});

const userSearchClearCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  await renderUserList(ctx, 0);
});

// ---------- Add (pre-register) ----------

const userAddCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_user_add' });
  await renderScreen(
    ctx,
    `➕ *Tambah User*\n\n` +
      `Kirim data dalam satu baris, dipisah \`|\`:\n\n` +
      `\`TelegramID|Username(opsional)|NamaDepan(opsional)\`\n\n` +
      `Contoh:\n\`123456789|johndoe|John\``,
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

const userCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderUserList(ctx, 0);
});

// ---------- Detail ----------

function detailText(profile) {
  const { user, stats } = profile;
  return (
    `👤 *Detail User*\n\n` +
    `ID: \`${user.telegram_id}\`\n` +
    `Nama: ${user.first_name || '-'} ${user.last_name || ''}\n` +
    `Username: ${user.username ? '@' + user.username : '-'}\n` +
    `Status: ${user.is_banned ? `🚫 Banned${user.banned_reason ? ` (${user.banned_reason})` : ''}` : '✅ Aktif'}\n` +
    `Terdaftar: ${user.created_at}\n\n` +
    `📦 Total Order: ${stats.totalOrders} (${stats.pendingOrders} pending)\n` +
    `💰 Total Belanja: ${formatRupiah(stats.totalSpent)}\n` +
    `🤖 Userbot Aktif (milik sendiri): ${stats.activeOwnedUserbots}\n` +
    `🔥 Userbot Jaseb (disewa): ${stats.activeLeasedUserbots}`
  );
}

// adminuser:view:<telegramId>
const userViewCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  const profile = userService.getUserProfile(telegramId);
  if (!profile) {
    await renderScreen(ctx, '❌ User tidak ditemukan.', userListKeyboard([], 0, 0));
    return;
  }
  await renderScreen(ctx, detailText(profile), { parse_mode: 'Markdown', ...userDetailKeyboard(profile.user, 0) });
});

// adminuser:resettrial:<telegramId> — give the user their one-time trial back
const userResetTrialCallback = safeHandler(async (ctx) => {
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  if (!Number.isInteger(telegramId) || !userRepo.findByTelegramId(telegramId)) {
    await ctx.answerCbQuery('User tidak ditemukan.', { show_alert: true });
    return;
  }
  userRepo.resetTrialClaim(telegramId);
  logger.info(`Admin ${ctx.from.id} reset trial claim for user ${telegramId}`);
  await ctx.answerCbQuery('✅ Hak trial dikembalikan.');
  const profile = userService.getUserProfile(telegramId);
  if (profile) await renderScreen(ctx, detailText(profile), { parse_mode: 'Markdown', ...userDetailKeyboard(profile.user, 0) });
});

// ---------- Ban (with reason prompt) / Unban ----------

// adminuser:ban:<telegramId> — asks for a reason before applying
const userBanCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  const user = userRepo.findByTelegramId(telegramId);
  if (!user) return;
  adminState.set(ctx.from.id, { action: 'admin_user_ban_reason', telegramId });
  await renderScreen(
    ctx,
    `🚫 *Ban User \`${telegramId}\`*\n\nKirim alasan ban (akan tersimpan & ditampilkan di detail user), atau lewati.`,
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

async function applyBan(ctx, telegramId, reason) {
  await userService.banUser(telegramId, reason || null, ctx.from.id);
  adminState.clear(ctx.from.id);
  const profile = userService.getUserProfile(telegramId);
  await renderScreen(ctx, detailText(profile), { parse_mode: 'Markdown', ...userDetailKeyboard(profile.user, 0) });
}

// adminuser:banskip:<telegramId> — ban with no reason
const userBanReasonSkipCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('🚫 User dibanned');
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  await applyBan(ctx, telegramId, null);
});

// adminuser:unban:<telegramId>
const userUnbanCallback = safeHandler(async (ctx) => {
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  userService.unbanUser(telegramId, ctx.from.id);
  await ctx.answerCbQuery('✅ User di-unban');
  const profile = userService.getUserProfile(telegramId);
  await renderScreen(ctx, detailText(profile), { parse_mode: 'Markdown', ...userDetailKeyboard(profile.user, 0) });
});

// ---------- Delete (cascade) ----------

// adminuser:delconfirm:<telegramId>
const userDeleteConfirmCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  const profile = userService.getUserProfile(telegramId);
  if (!profile) return;

  const warnings = [];
  if (profile.stats.activeLeasedUserbots > 0) {
    warnings.push(`⚠️ ${profile.stats.activeLeasedUserbots} userbot Jaseb yang sedang disewa akan otomatis dikembalikan ke stok.`);
  }
  if (profile.stats.activeOwnedUserbots > 0) {
    warnings.push(`⚠️ ${profile.stats.activeOwnedUserbots} userbot miliknya akan dihapus permanen.`);
  }
  if (profile.stats.totalOrders > 0) {
    warnings.push(`⚠️ ${profile.stats.totalOrders} riwayat order akan dihapus permanen.`);
  }

  await renderScreen(
    ctx,
    `⚠️ *Yakin ingin menghapus user \`${telegramId}\`?*\n\n` +
      (warnings.length > 0 ? warnings.join('\n') + '\n\n' : '') +
      `Tindakan ini tidak bisa dibatalkan.`,
    { parse_mode: 'Markdown', ...userDeleteConfirmKeyboard(profile.user, 0) }
  );
});

// adminuser:del:<telegramId>
const userDeleteCallback = safeHandler(async (ctx) => {
  const telegramId = Number(ctx.callbackQuery.data.split(':')[2]);
  const result = userService.deleteUserCascade(telegramId, ctx.from.id);
  await ctx.answerCbQuery('🗑️ User dihapus');

  await renderScreen(
    ctx,
    `🗑️ *User \`${telegramId}\` dihapus.*\n\n` +
      `${result.returnedPoolLeases} userbot Jaseb dikembalikan ke stok\n` +
      `${result.removedOwnedUserbots} userbot milik user dihapus\n` +
      `${result.removedOrders} order dihapus`,
    { parse_mode: 'Markdown' }
  );

  await renderUserList(ctx, 0);
});

// ---------- Text-driven wizard steps (called from adminFlow middleware) ----------

async function handleUserSearchText(ctx, state) {
  const query = ctx.message.text.trim();
  if (!query) {
    await ctx.reply('❌ Kata kunci tidak boleh kosong.');
    return;
  }
  adminState.set(ctx.from.id, { action: 'admin_user_search_results', searchQuery: query });
  await renderSearchResults(ctx, query, 0);
}

async function handleUserAddText(ctx, state) {
  const parts = ctx.message.text.split('|').map((s) => s.trim());
  const [idStr, username, firstName] = parts;
  const telegramId = Number(idStr);

  if (!/^\d+$/.test(idStr || '') || Number.isNaN(telegramId)) {
    await ctx.reply('❌ Telegram ID harus berupa angka. Contoh: `123456789|johndoe|John`', { parse_mode: 'Markdown' });
    return;
  }

  try {
    const user = userService.adminRegisterUser(telegramId, { username, firstName });
    adminState.clear(ctx.from.id);
    await ctx.reply(`✅ User \`${user.telegram_id}\` berhasil ditambahkan.`, { parse_mode: 'Markdown' });
    logger.info(`Admin ${ctx.from.id} manually added user ${telegramId}`);
  } catch (err) {
    await ctx.reply(`❌ ${err.message}`);
  }
}

async function handleUserBanReasonText(ctx, state) {
  const reason = ctx.message.text.trim();
  await applyBan(ctx, state.telegramId, reason);
  await ctx.reply(`🚫 User \`${state.telegramId}\` dibanned. Alasan: ${reason}`, { parse_mode: 'Markdown' });
}

module.exports = {
  userListCallback,
  userSearchCallback,
  userSearchResultsCallback,
  userSearchClearCallback,
  userAddCallback,
  userCancelCallback,
  userViewCallback,
  userResetTrialCallback,
  userBanCallback,
  userBanReasonSkipCallback,
  userUnbanCallback,
  userDeleteConfirmCallback,
  userDeleteCallback,
  handleUserSearchText,
  handleUserAddText,
  handleUserBanReasonText,
};
