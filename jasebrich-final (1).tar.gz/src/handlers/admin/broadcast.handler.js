const crypto = require('crypto');
const { Markup } = require('telegraf');
const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { replyButton, button } = require('../../utils/buttons');
const { renderScreen } = require('../../utils/render');
const adminState = require('../../state/adminState');
const broadcastService = require('../../services/broadcast.service');
const userRepo = require('../../database/repositories/user.repository');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const logger = require('../../utils/logger');

function homeKeyboard() {
  return Markup.keyboard([
    [replyButton.success('📣 Buat Broadcast')],
    [replyButton.primary('📜 Riwayat Broadcast'), replyButton.primary('📊 Broadcast Berjalan')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

function inputKeyboard() {
  return Markup.keyboard([[replyButton.primary('🔙 Kembali'), replyButton.danger('❌ Batal')]]).resize();
}

function draftKeyboard(adminId, hasButtons) {
  const rows = [];
  rows.push([button.primary(hasButtons ? '✏️ Ubah Tombol' : '➕ Tambah Tombol', ADMIN_CALLBACK.BROADCAST_ADD_BUTTONS)]);
  rows.push([button.primary('🔄 Preview Ulang', ADMIN_CALLBACK.BROADCAST_PREVIEW)]);
  rows.push([button.success('✅ Kirim Broadcast', ADMIN_CALLBACK.BROADCAST_CONFIRM), button.danger('❌ Batal', ADMIN_CALLBACK.BROADCAST_CANCEL)]);
  return Markup.inlineKeyboard(rows);
}

function normalizeStateForDraft(state) {
  return { ...state, buttons: broadcastService.normalizeButtons(state.buttons || []) };
}

async function renderHome(ctx) {
  const current = broadcastService.history(1)[0];
  const eligible = userRepo.countBroadcastRecipients();
  const latest = current
    ? `

🧾 Broadcast terakhir: #${current.id} — ${current.status}\n🎯 ${current.target_count} target | ✅ ${current.success_count} | ❌ ${current.fail_count} | ⏭️ ${current.skipped_count}`
    : '';
  await renderScreen(
    ctx,
    `📣 *Broadcast Admin*\n\n🎯 Target eligible saat ini: *${eligible}* user${latest}\n\nPilih aksi di bawah.`,
    { parse_mode: 'Markdown', ...homeKeyboard() }
  );
}

const broadcastHomeCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

const broadcastCreateCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.set(ctx.from.id, {
    action: 'admin_broadcast_content',
    draftId: crypto.randomUUID(),
    payload: null,
    buttons: [],
  });
  await ctx.reply(
    `📣 *Buat Broadcast*\n\nKirim satu pesan sebagai konten broadcast. Sistem mempertahankan tipe media dan formatting Telegram yang diterima.\n\nSetelah itu Anda akan melihat preview dan konfirmasi sebelum mass-send.`,
    { parse_mode: 'Markdown', ...inputKeyboard() }
  );
});

async function renderDraft(ctx, state) {
  const normalized = normalizeStateForDraft(state);
  adminState.set(ctx.from.id, normalized);
  await broadcastService.preview(ctx.telegram, ctx.chat.id, normalized.payload, normalized.buttons, ctx.from.id);
  await ctx.reply(
    `👁️ *Preview Broadcast*\n\n🎯 Target saat ini: ${userRepo.countBroadcastRecipients()} user\n🔘 Tombol: ${normalized.buttons.length}\n\nPastikan preview sudah benar sebelum menekan *Kirim Broadcast*.`,
    { parse_mode: 'Markdown', ...draftKeyboard(ctx.from.id, normalized.buttons.length) }
  );
}

async function handleContentInput(ctx, state) {
  try {
    const payload = broadcastService.normalizePayload(ctx.message);
    const next = { ...state, action: 'admin_broadcast_buttons', payload, buttons: Array.isArray(state.buttons) ? state.buttons : [] };
    adminState.set(ctx.from.id, next);
    await ctx.reply('✅ Konten diterima. Opsional: kirim definisi tombol satu per baris atau tekan 🔙 Kembali untuk kembali ke Broadcast.', inputKeyboard());
    await ctx.reply(
      '🔘 *Tombol (opsional)*\n\nFormat satu baris per tombol:\n`Lihat Promo | URL | https://example.com`\natau\n`Perpanjang | CALLBACK | renewal`\n\nLayout manual opsional: `Nama | CALLBACK | action | ROW:1`. Jika satu tombol memakai ROW:n, semua tombol wajib memakai ROW:n.\n\nAction callback yang tersedia: `store`, `renewal`, `home`.\n\nKetik `-` untuk tanpa tombol.',
      { parse_mode: 'Markdown', ...inputKeyboard() }
    );
  } catch (err) {
    await ctx.reply(`❌ ${String(err?.message || 'Konten tidak valid.')}`);
  }
  return true;
}

async function handleButtonsInput(ctx, state) {
  try {
    const buttons = broadcastService.parseButtonLines(ctx.message?.text || '');
    await renderDraft(ctx, { ...state, action: 'admin_broadcast_buttons', buttons });
  } catch (err) {
    await ctx.reply(`❌ ${String(err?.message || 'Format tombol tidak valid.')}`, inputKeyboard());
  }
  return true;
}

const broadcastPreviewCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state?.payload) { await renderHome(ctx); return; }
  await renderDraft(ctx, state);
});

const broadcastAddButtonsCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state?.payload) { await renderHome(ctx); return; }
  adminState.set(ctx.from.id, { ...state, action: 'admin_broadcast_buttons' });
  await ctx.reply('🔘 Kirim daftar tombol satu per baris. Format lama tetap valid: `Nama | URL | https://...` atau `Nama | CALLBACK | store/renewal/home`. Layout opsional: `Nama | CALLBACK | action | ROW:1`.', { parse_mode: 'Markdown', ...inputKeyboard() });
});

const broadcastConfirmCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Memasukkan ke antrean...');
  const state = adminState.get(ctx.from.id);
  if (!state?.payload || !state.draftId) { await renderHome(ctx); return; }
  const snapshot = userRepo.getBroadcastRecipientSnapshot();
  const job = broadcastService.createJob({
    adminId: ctx.from.id,
    sourceChatId: ctx.chat.id,
    sourceMessageId: ctx.message?.message_id || 0,
    payload: state.payload,
    buttons: state.buttons || [],
    targetCount: snapshot.count,
    targetMaxUserId: snapshot.maxUserId,
    idempotencyKey: `broadcast:${ctx.from.id}:${state.draftId}`,
  });
  adminState.clear(ctx.from.id);
  await ctx.reply(`⏳ *Broadcast #${job.id}* masuk antrean.\n\n🎯 Target snapshot: ${snapshot.count}\nStatus akan diperbarui dari hasil pengiriman nyata.`, { parse_mode: 'Markdown', ...homeKeyboard() });
  void broadcastService.startJob(ctx.telegram, job.id);
});

const broadcastCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

function formatJob(j) {
  return `#${j.id} — ${j.status}\n🎯 ${j.target_count} | ✅ ${j.success_count} | ❌ ${j.fail_count} | ⏭️ ${j.skipped_count}${j.completed_at ? `\n🕒 ${j.completed_at}` : ''}`;
}

const broadcastHistoryCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  const jobs = broadcastService.history(15);
  const text = jobs.length
    ? `📜 *Riwayat Broadcast*\n\n${jobs.map(formatJob).join('\n\n')}`
    : '📜 *Riwayat Broadcast*\n\nBelum ada broadcast.';
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...homeKeyboard() });
});

const broadcastStatusCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const active = broadcastService.history(20).filter((j) => ['queued', 'running'].includes(j.status));
  const text = active.length
    ? `📊 *Broadcast Berjalan*\n\n${active.map(formatJob).join('\n\n')}`
    : '📊 *Broadcast Berjalan*\n\nTidak ada broadcast aktif.';
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...homeKeyboard() });
});

const broadcastDraftActionCallback = safeHandler(async (ctx) => {
  const parts = String(ctx.callbackQuery.data).split(':');
  const adminId = Number(parts[2]);
  const index = Number(parts[3]);
  if (Number(ctx.from.id) !== adminId) { await ctx.answerCbQuery('Preview bukan milik Anda.', { show_alert: true }); return; }
  const state = adminState.get(ctx.from.id);
  const b = state?.buttons?.[index];
  await ctx.answerCbQuery(b ? `Preview action: ${b.type === 'url' ? b.url : b.action}` : 'Tombol preview tidak tersedia.');
});

const broadcastActionCallback = safeHandler(async (ctx) => {
  const parts = String(ctx.callbackQuery.data).split(':');
  const jobId = Number(parts[2]);
  const index = Number(parts[3]);
  const job = broadcastService.status(jobId);
  if (!job || !job.buttons?.[index]) { await ctx.answerCbQuery('Action tidak tersedia.', { show_alert: true }); return; }
  const b = job.buttons[index];
  if (b.type === 'url') { await ctx.answerCbQuery('Gunakan tombol URL pada pesan.'); return; }
  await ctx.answerCbQuery();
  if (b.action === 'renewal') {
    const store = require('../store.handler');
    const { CATEGORIES } = require('../../services/product.service');
    await store.renderCategoryProducts(ctx, CATEGORIES.RENEWAL);
  } else if (b.action === 'store') {
    const store = require('../store.handler');
    await store.storeHandler(ctx);
  } else {
    const menu = require('../menu.handler');
    await menu.navHomeCallback(ctx);
  }
});

module.exports = {
  broadcastHomeCallback,
  broadcastCreateCallback,
  broadcastPreviewCallback,
  broadcastAddButtonsCallback,
  broadcastConfirmCallback,
  broadcastCancelCallback,
  broadcastHistoryCallback,
  broadcastStatusCallback,
  broadcastDraftActionCallback,
  broadcastActionCallback,
  handleContentInput,
  handleButtonsInput,
};
