const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { buildReplyOptions, defineTemplate } = require('../../services/custom-submenu.service');
const { adminStatisticsKeyboard, adminStatisticsSectionKeyboard } = require('../../keyboards/adminStatistics.keyboard');
const {
  STATISTICS_SECTIONS,
  isValidStatisticsSection,
  parseStatisticsSectionCallback,
  parseStatisticsSectionRefreshCallback,
} = require('../../constants/statistics');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const statisticsService = require('../../services/statistics.service');

function escapeHtml(value) {
  return String(value == null ? '-' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function mb(value) {
  return value == null ? '-' : `${value} MB`;
}

function bytes(value) {
  if (value == null) return '-';
  const n = Number(value);
  if (!Number.isFinite(n)) return '-';
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / 1048576).toFixed(1)} MB`;
}

const statisticsTemplate = defineTemplate(
  'admin.statistics',
  'Admin Panel',
  '📊 Statistik',
  '<b>📊 Statistik JASEB</b>\n\nPilih kategori statistik yang ingin dilihat.',
  { parseMode: 'HTML', maxLength: 4096 }
);

const statisticsSectionTemplates = {
  users: defineTemplate('admin.statistics.users', 'Admin Panel', '👥 Statistik Users', ({}, extra) => {
    const u = extra.statistics.users;
    return [
      '<b>👥 USERS</b>',
      `Total: <b>${u.total}</b>`,
      `Aktif (30 hari): <b>${u.active30d}</b>`,
      `Tidak aktif (30 hari): <b>${u.inactive30d}</b>`,
      `Aktif 24 jam: <b>${u.recentlyActive24h}</b>`,
      `Admin terdaftar: <b>${u.admins}</b>`,
      `Banned: <b>${u.banned}</b>`,
      `Trial pernah diklaim: <b>${u.trialClaimed}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['total_users','active_users','inactive_users','recent_users','admin_users','banned_users','trial_claimed'] }),
  userbot: defineTemplate('admin.statistics.userbot', 'Admin Panel', '🤖 Statistik Userbot', ({}, extra) => {
    const ub = extra.statistics.userbots;
    return [
      '<b>🤖 USERBOT</b>',
      `Total: <b>${ub.total}</b>`,
      `Aktif: <b>${ub.active}</b>`,
      `Tidak aktif: <b>${ub.inactive}</b>`,
      `Pending OTP: <b>${ub.pendingOtp}</b>`,
      `Expired: <b>${ub.expired}</b>`,
      `Revoked: <b>${ub.revoked}</b>`,
      `Runtime records: <b>${ub.runtimeRecords}</b>`,
      `Sedang berjalan: <b>${ub.running}</b>`,
      `Runtime tidak berjalan: <b>${ub.stopped}</b>`,
      `Promotion berjalan: <b>${ub.promotionRunning}</b>`,
      `Promotion tidak aktif: <b>${ub.promotionStopped}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['total_userbots','active_userbots','inactive_userbots','pending_userbots','expired_userbots','revoked_userbots','runtime_userbots','running_userbots','promotion_running','promotion_stopped'] }),
  stock: defineTemplate('admin.statistics.stock', 'Admin Panel', '📦 Statistik Stok Userbot', ({}, extra) => {
    const pool = extra.statistics.pool;
    return [
      '<b>📦 STOK USERBOT JASEB</b>',
      `Total: <b>${pool.total}</b>`,
      `Tersedia: <b>${pool.available}</b>`,
      `Terpakai: <b>${pool.assigned}</b>`,
      `Disabled: <b>${pool.disabled}</b>`,
      `Assigned expired: <b>${pool.assignedExpired}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['stock_total','stock_available','stock_used','stock_disabled'] }),
  orders: defineTemplate('admin.statistics.orders', 'Admin Panel', '🛒 Statistik Order', ({}, extra) => {
    const o = extra.statistics.orders;
    return [
      '<b>🛒 ORDER</b>',
      `Total: <b>${o.total}</b>`,
      `Pending: <b>${o.pending}</b>`,
      `Menunggu verifikasi: <b>${o.awaitingConfirmation}</b>`,
      `Processing: <b>${o.processing}</b>`,
      `Paid: <b>${o.paid}</b>`,
      `Fulfilled: <b>${o.fulfilled}</b>`,
      `Berhasil (paid+fulfilled): <b>${o.successful}</b>`,
      `Rejected: <b>${o.rejected}</b>`,
      `Cancelled: <b>${o.cancelled}</b>`,
      `Expired: <b>${o.expired}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['orders_total','orders_pending','orders_processing','orders_successful','orders_rejected','orders_cancelled','orders_expired'] }),
  payments: defineTemplate('admin.statistics.payments', 'Admin Panel', '💳 Statistik Payment', ({}, extra) => {
    const p = extra.statistics.payments;
    return [
      '<b>💳 PAYMENT</b>',
      `Open/pending: <b>${p.pending}</b>`,
      `Menunggu bukti: <b>${p.waitingProof}</b>`,
      `Bukti tersimpan: <b>${p.proofSubmitted}</b>`,
      `Terverifikasi: <b>${p.verified}</b>`,
      `Ditolak: <b>${p.rejected}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['payment_pending','payment_waiting_proof','payment_proof_submitted','payment_verified','payment_rejected'] }),
  subscription: defineTemplate('admin.statistics.subscription', 'Admin Panel', '📅 Statistik Subscription', ({}, extra) => {
    const s = extra.statistics.subscriptions;
    return [
      '<b>📅 SUBSCRIPTION / TRIAL</b>',
      `Aktif: <b>${s.active}</b>`,
      `Expired: <b>${s.expired}</b>`,
      `Akan expired ≤ 7 hari: <b>${s.expiringSoon}</b>`,
      `Trial aktif: <b>${s.trialActive}</b>`,
      `Trial pernah diklaim: <b>${s.trialClaimed}</b>`,
      `Trial tidak aktif: <b>${s.trialInactive}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['subscription_active','subscription_expired','subscription_expiring','trial_active','trial_inactive'] }),
  promotion: defineTemplate('admin.statistics.promotion', 'Admin Panel', '📣 Statistik Promotion', ({}, extra) => {
    const p = extra.statistics.promotion;
    return [
      '<b>📣 PROMOTION</b>',
      `Loop aktif: <b>${p.running}</b>`,
      `Promotion tidak aktif: <b>${p.stopped}</b>`,
      `Runtime records: <b>${p.runtimeRecords}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['promotion_running','promotion_stopped','active_promotion_loops'] }),
  system: defineTemplate('admin.statistics.system', 'Admin Panel', '🖥 Statistik System', ({}, extra) => {
    const s = extra.statistics;
    const sys = s.system || {};
    const db = s.database || {};
    const sched = s.scheduler || {};
    const runtime = s.userbots || {};
    const esc = escapeHtml;
    const integrity = db.integrity === 'ok' ? '✅ OK' : esc(db.integrity || 'unknown');
    return [
      '<b>🖥 SYSTEM</b>',
      `🟢 Aplikasi: <b>v${esc(sys.appVersion || '-')}</b>`,
      `⏱ Runtime: <b>${esc(sys.uptime || '-')}</b>`,
      `🕒 Server: <code>${esc(sys.serverTime || '-')}</code>`,
      `🆔 PID: <code>${esc(sys.pid || '-')}</code>`,
      `⚙️ Node.js: <b>${esc(sys.nodeVersion || '-')}</b>`,
      `💻 Platform: <b>${esc(sys.platform || '-')} / ${esc(sys.arch || '-')}</b>`,
      '',
      '<b>🧠 RESOURCE</b>',
      `RSS: <b>${mb(sys.processMemoryMb)}</b>`,
      `Heap: <b>${mb(sys.heapUsedMb)} / ${mb(sys.heapTotalMb)}</b>`,
      `External: <b>${mb(sys.externalMb)}</b>`,
      `System RAM: <b>${mb(sys.systemMemoryMb)}</b>`,
      `Free RAM: <b>${mb(sys.systemFreeMb)}</b>`,
      `CPU: <b>${sys.cpuLoadPercent == null ? '-' : `${sys.cpuLoadPercent}%`}</b> · Load 1m: <b>${sys.cpuLoad1 == null ? '-' : sys.cpuLoad1}</b> · Core: <b>${sys.cpuCount || '-'}</b>`,
      '',
      '<b>🗄 DATABASE</b>',
      `Status: <b>${db.status === 'ok' ? '✅ OK' : '❌ UNAVAILABLE'}</b>`,
      `Query: <b>${db.latencyMs == null ? '-' : `${db.latencyMs} ms`}</b>`,
      `Size: <b>${bytes(db.sizeBytes)}</b>`,
      `Journal: <b>${esc(db.journalMode || '-')}</b> · FK: <b>${db.foreignKeys === true ? 'ON' : db.foreignKeys === false ? 'OFF' : '-'}</b>`,
      `Integrity: <b>${integrity}</b>`,
      '',
      '<b>📊 DATA</b>',
      `Users: <b>${esc(s.users?.total ?? '-')}</b> · Aktif 30d: <b>${esc(s.users?.active30d ?? '-')}</b>`,
      `Userbot: <b>${esc(s.userbots?.total ?? '-')}</b> · Aktif: <b>${esc(s.userbots?.active ?? '-')}</b> · Expired: <b>${esc(s.userbots?.expired ?? '-')}</b>`,
      `Stok: <b>${esc(s.pool?.total ?? '-')}</b> · Tersedia: <b>${esc(s.pool?.available ?? '-')}</b>`,
      `Order: <b>${esc(s.orders?.total ?? '-')}</b> · Pending: <b>${esc(s.orders?.pending ?? '-')}</b>`,
      '',
      '<b>⏱ SCHEDULER / RUNTIME</b>',
      `Scheduler: <b>${sched.running ? '🟢 RUNNING' : '🔴 STOPPED'}</b> · Tick: <b>${sched.tickRunning ? 'RUNNING' : 'IDLE'}</b>`,
      `Last tick: <b>${esc(sched.lastTickCompletedAt || '-')}</b>`,
      `Last error: <b>${sched.lastTickError ? '⚠️ ADA — cek log server' : '✅ Tidak ada'}</b>`,
      `Userbot runtime: <b>${runtime.running ?? '-'}/${runtime.runtimeRecords ?? '-'}</b> · Promotion: <b>${runtime.promotionRunning ?? '-'}</b>`,
    ].join('\n');
  }, { parseMode: 'HTML', maxLength: 4096, supportedPlaceholders: ['uptime','app_version','server_time','pid','node_version','platform','arch','process_memory','heap_used','heap_total','external_memory','system_memory','system_free_memory','cpu_load','cpu_load_1m','cpu_cores','db_status','db_latency','db_size','db_integrity','wal_status','foreign_keys','scheduler_status','scheduler_last_tick'] }),
};

function placeholderValues(s) {
  const value = (path, fallback = '-') => {
    const parts = path.split('.');
    let cur = s;
    for (const part of parts) cur = cur == null ? undefined : cur[part];
    return cur == null ? fallback : String(cur);
  };
  return {
    total_users: value('users.total'), active_users: value('users.active30d'), inactive_users: value('users.inactive30d'),
    recent_users: value('users.recentlyActive24h'), admin_users: value('users.admins'), banned_users: value('users.banned'),
    trial_claimed: value('users.trialClaimed'), total_userbots: value('userbots.total'), active_userbots: value('userbots.active'),
    inactive_userbots: value('userbots.inactive'), pending_userbots: value('userbots.pendingOtp'), expired_userbots: value('userbots.expired'),
    revoked_userbots: value('userbots.revoked'), runtime_userbots: value('userbots.runtimeRecords'), running_userbots: value('userbots.running'),
    promotion_running: value('userbots.promotionRunning'), promotion_stopped: value('userbots.promotionStopped'), stock_total: value('pool.total'), stock_available: value('pool.available'),
    stock_used: value('pool.assigned'), stock_disabled: value('pool.disabled'), orders_total: value('orders.total'), orders_pending: value('orders.pending'),
    orders_processing: value('orders.processing'), orders_successful: value('orders.successful'), orders_rejected: value('orders.rejected'),
    orders_cancelled: value('orders.cancelled'), orders_expired: value('orders.expired'), payment_pending: value('payments.pending'),
    payment_waiting_proof: value('payments.waitingProof'), payment_proof_submitted: value('payments.proofSubmitted'), payment_verified: value('payments.verified'),
    payment_rejected: value('payments.rejected'), subscription_active: value('subscriptions.active'), subscription_expired: value('subscriptions.expired'),
    subscription_expiring: value('subscriptions.expiringSoon'), trial_active: value('subscriptions.trialActive'), trial_inactive: value('subscriptions.trialInactive'),
    uptime: value('system.uptime'), app_version: value('system.appVersion'), server_time: value('system.serverTime'), pid: value('system.pid'),
    node_version: value('system.nodeVersion'), platform: value('system.platform'), arch: value('system.arch'),
    process_memory: value('system.processMemoryMb'), heap_used: value('system.heapUsedMb'), heap_total: value('system.heapTotalMb'),
    external_memory: value('system.externalMb'), system_memory: value('system.systemMemoryMb'), system_free_memory: value('system.systemFreeMb'),
    cpu_load: value('system.cpuLoadPercent'), cpu_load_1m: value('system.cpuLoad1'), cpu_cores: value('system.cpuCount'), db_status: value('database.status'),
    db_latency: value('database.latencyMs'), db_size: s.database.sizeBytes == null ? '-' : bytes(s.database.sizeBytes), db_integrity: value('database.integrity'),
    wal_status: value('database.journalMode'), foreign_keys: s.database.foreignKeys == null ? '-' : (s.database.foreignKeys ? 'ON' : 'OFF'),
    scheduler_status: value('scheduler.running', 'stopped'), scheduler_last_tick: value('scheduler.lastTickCompletedAt'), active_promotion_loops: value('promotion.running'),
  };
}

function statisticsHomeContent(ctx, statistics) {
  return statisticsTemplate.getContent(ctx, {
    statistics,
    placeholderValues: placeholderValues(statistics),
  });
}

/**
 * Build the exact data/context contract used by every statistics template.
 * Custom Submenu reuses this function for editor/reference rendering so a
 * dynamic statistics template never executes without its real statistics
 * snapshot.
 */
function buildStatisticsRenderContext() {
  const statistics = statisticsService.getStatisticsSnapshot();
  return {
    statistics,
    placeholderValues: placeholderValues(statistics),
  };
}

async function renderStatistics(ctx) {
  const renderContext = buildStatisticsRenderContext();
  const content = statisticsHomeContent(ctx, renderContext.statistics);
  await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...adminStatisticsKeyboard() }, ADMIN_CALLBACK.STATISTICS_HOME);
}

function normalizeStatisticsSection(value) {
  return isValidStatisticsSection(value) ? value : null;
}

const STATISTICS_SECTION_TEMPLATE_KEYS = new Set(Object.keys(statisticsSectionTemplates));
for (const [, section] of STATISTICS_SECTIONS) {
  if (!STATISTICS_SECTION_TEMPLATE_KEYS.has(section)) {
    throw new Error(`Statistik category registry/template mismatch: missing template for "${section}"`);
  }
}
for (const section of STATISTICS_SECTION_TEMPLATE_KEYS) {
  if (!isValidStatisticsSection(section)) {
    throw new Error(`Statistik category registry/template mismatch: unregistered template "${section}"`);
  }
}

async function renderStatisticsSection(ctx, section, { answer = true, refreshMessage = false } = {}) {
  const normalized = normalizeStatisticsSection(section);
  if (!normalized) {
    if (answer) await ctx.answerCbQuery('Kategori statistik tidak valid.', { show_alert: true });
    return;
  }
  const renderContext = buildStatisticsRenderContext();
  const template = statisticsSectionTemplates[normalized];
  const content = template.getContent(ctx, renderContext);
  if (answer) await ctx.answerCbQuery(refreshMessage ? 'Statistik diperbarui.' : '');
  await renderScreen(ctx, content.text, {
    ...buildReplyOptions(content),
    ...adminStatisticsSectionKeyboard(normalized),
  }, ADMIN_CALLBACK.STATISTICS_SECTION(normalized));
}

const statisticsHandler = safeHandler(async (ctx) => {
  await renderStatistics(ctx);
});

const statisticsCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  await renderStatistics(ctx);
});

const statisticsRefreshCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Statistik diperbarui.');
  await renderStatistics(ctx);
});

const statisticsSectionCallback = safeHandler(async (ctx) => {
  const section = parseStatisticsSectionCallback(ctx.callbackQuery && ctx.callbackQuery.data);
  await renderStatisticsSection(ctx, section);
});

const statisticsSectionRefreshCallback = safeHandler(async (ctx) => {
  const section = parseStatisticsSectionRefreshCallback(ctx.callbackQuery && ctx.callbackQuery.data);
  await renderStatisticsSection(ctx, section, { refreshMessage: true });
});

module.exports = {
  statisticsHandler,
  statisticsCallback,
  statisticsRefreshCallback,
  statisticsSectionCallback,
  statisticsSectionRefreshCallback,
  renderStatistics,
  renderStatisticsSection,
  placeholderValues,
  buildStatisticsRenderContext,
};
