const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { paymentHomeKeyboard, adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const paymentService = require('../../services/payment.service');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

async function renderPaymentHome(ctx) {
  const qris = paymentService.getQrisFileId();
  const note = paymentService.getQrisNote();
  const bank = paymentService.getBankInfo();
  const text =
    `💳 *Payment Settings*\n\n` +
    `Gambar QRIS: ${qris ? '✅ Sudah diset' : '❌ Belum diset'}\n` +
    `Catatan QRIS: ${note ? note : '-'}\n` +
    `Info Rekening/E-Wallet: ${bank ? bank : '-'}`;
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...paymentHomeKeyboard() });
}

const paymentHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderPaymentHome(ctx);
});

const paymentSetQrisCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_payment_qris_photo' });
  await renderScreen(ctx, '🖼️ Kirim *foto* QRIS sekarang.', {
    parse_mode: 'Markdown',
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const paymentSetNoteCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_payment_note' });
  await renderScreen(ctx, '📝 Kirim teks catatan yang tampil di bawah QRIS (misal nominal unik/instruksi).', {
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const paymentSetBankCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_payment_bank' });
  await renderScreen(ctx, '🏦 Kirim teks info rekening/e-wallet alternatif.', {
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const paymentCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderPaymentHome(ctx);
});

async function handlePaymentText(ctx, state) {
  if (state.action === 'admin_payment_note') {
    paymentService.setQrisNote(ctx.message.text);
  } else if (state.action === 'admin_payment_bank') {
    paymentService.setBankInfo(ctx.message.text);
  } else {
    return;
  }
  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Tersimpan.');
  logger.info(`Admin ${ctx.from.id} updated payment config (${state.action})`);
}

async function handlePaymentPhoto(ctx, state) {
  if (state.action !== 'admin_payment_qris_photo') return;
  const photos = ctx.message.photo;
  const fileId = photos[photos.length - 1].file_id;
  paymentService.setQrisFileId(fileId);
  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Gambar QRIS tersimpan.');
  logger.info(`Admin ${ctx.from.id} updated QRIS image`);
}

module.exports = {
  paymentHomeCallback,
  paymentSetQrisCallback,
  paymentSetNoteCallback,
  paymentSetBankCallback,
  paymentCancelCallback,
  handlePaymentText,
  handlePaymentPhoto,
};
