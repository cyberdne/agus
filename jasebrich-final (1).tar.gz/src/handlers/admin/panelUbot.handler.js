const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { Markup } = require('telegraf');
const { button: rawButton } = require('../../utils/buttons');
// Every button in this file is either a dynamic per-userbot row (label,
// id, owner) or admin back-navigation — never a "fitur" — so none of it
// may show up in Custom Icon Tombol.
const button = {
  primary: (l, cb, o) => rawButton.primary(l, cb, { ...o, customizable: false }),
  danger: (l, cb, o) => rawButton.danger(l, cb, { ...o, customizable: false }),
};
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const ownedRepo = require('../../database/repositories/ownedUserbot.repository');
const poolRepo = require('../../database/repositories/userbotPool.repository');
const panelState = require('../../state/panelState');
const panelHandler = require('../panel.handler');
const logger = require('../../utils/logger');

function listAllUserbots() {
  const owned = ownedRepo.listAll();
  const pool = poolRepo.listAll();
  return { owned, pool };
}

function keyboardFor({ owned, pool }) {
  const rows = [];
  for (const a of owned) {
    rows.push([button.primary(`🤖 ${a.label || 'Userbot'} #${a.id} (${a.user_id})`, ADMIN_CALLBACK.PANEL_UBOT_SELECT('owned', a.id))]);
  }
  for (const a of pool) {
    rows.push([
      button.primary(
        `🔥 ${a.label || 'Jaseb'} #${a.id} ${a.assigned_user_id ? `(${a.assigned_user_id})` : '(kosong)'}`,
        ADMIN_CALLBACK.PANEL_UBOT_SELECT('pool', a.id)
      ),
    ]);
  }
  if (rows.length === 0) {
    rows.push([button.primary('— Belum ada userbot —', ADMIN_CALLBACK.PANEL_UBOT_HOME)]);
  }
  rows.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.PANEL_HOME)]);
  return Markup.inlineKeyboard(rows);
}

const panelUbotHomeCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  const all = listAllUserbots();
  await renderScreen(
    ctx,
    '🎛️ *Kontrol Panel Ubot* (Admin)\n\nPilih userbot Userbot/Jaseb yang ingin dikontrol.',
    { parse_mode: 'Markdown', ...keyboardFor(all) }
  );
  logger.debug(`Admin ${ctx.from.id} opened Kontrol Panel Ubot list`);
});

const panelUbotSelectCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , kind, idStr] = ctx.callbackQuery.data.split(':');
  const id = Number(idStr);
  if (!['owned', 'pool'].includes(kind)) {
    await renderScreen(ctx, '❌ Jenis userbot tidak valid.', {}, 'admin');
    return;
  }
  const repo = kind === 'pool' ? poolRepo : ownedRepo;
  const asset = repo.findById(id);
  if (!asset) {
    await renderScreen(ctx, '❌ Userbot tidak ditemukan.', {}, 'admin');
    return;
  }
  panelState.set(ctx.from.id, { kind, id, step: null, screen: 'main', adminMode: true, returnTo: 'admin_ubot_list' });
  try {
    await ctx.editMessageReplyMarkup();
  } catch (err) {
    // ignore
  }
  // Reuse the exact same ownership/entitlement/session/capability validation
  // gate used by normal users. Admin mode changes authorization scope only; it
  // must never make an invalid Telegram session look controllable.
  await panelHandler.selectAsset(ctx, kind, id, '🔧 Anda mengontrol userbot ini sebagai Admin.');
  logger.debug(`Admin ${ctx.from.id} mengontrol ${kind}:${id} lewat Admin Panel`);
});

module.exports = { panelUbotHomeCallback, panelUbotSelectCallback };
