const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { premiumEmojiHomeKeyboard, adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const premiumEmojiConfig = require('../../services/premiumEmojiConfig.service');
const { emojiMdV2 } = require('../../utils/emojiMarkdown');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

async function renderPremiumEmojiHome(ctx) {
  const garansiCfg = premiumEmojiConfig.getGaransiConfig();
  const nonGaransiCfg = premiumEmojiConfig.getNonGaransiConfig();
  const text =
    `💎 *Emoji Premium*\n\n` +
    `Emoji ini dipakai di tombol Store, daftar produk, dan konfirmasi pesanan untuk membedakan paket bergaransi & non\\-garansi\\.\n\n` +
    `⭐ Emoji Bergaransi saat ini: ${emojiMdV2(garansiCfg)}\n` +
    `💎 Emoji Non\\-Garansi saat ini: ${emojiMdV2(nonGaransiCfg)}`;
  await renderScreen(ctx, text, { parse_mode: 'MarkdownV2', ...premiumEmojiHomeKeyboard() });
}

const premiumEmojiHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderPremiumEmojiHome(ctx);
  logger.debug(`Admin ${ctx.from.id} opened Emoji Premium settings`);
});

const premiumEmojiSetGaransiCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_premium_emoji_garansi' });
  await renderScreen(ctx, '⭐ Kirim emoji baru untuk paket *Bergaransi*. Contoh: `⭐`', {
    parse_mode: 'Markdown',
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const premiumEmojiSetNonGaransiCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_premium_emoji_nongaransi' });
  await renderScreen(ctx, '💎 Kirim emoji baru untuk paket *Non-Garansi*. Contoh: `💎`', {
    parse_mode: 'Markdown',
    ...adminInputKeyboard(adminState.get(ctx.from.id)),
  });
});

const premiumEmojiCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderPremiumEmojiHome(ctx);
});

async function handlePremiumEmojiText(ctx, state) {
  if (state.action !== 'admin_premium_emoji_garansi' && state.action !== 'admin_premium_emoji_nongaransi') return;

  // Capture the custom_emoji entity (if the admin pasted a Telegram
  // Premium/custom emoji) the same way buttonIcons.handler.js does —
  // without this, only the plain fallback glyph gets saved and the
  // real animated emoji is lost.
  const entities = ctx.message.entities || [];
  const custom = entities.find((e) => e.type === 'custom_emoji');
  const customEmojiId = custom && custom.custom_emoji_id;

  try {
    if (state.action === 'admin_premium_emoji_garansi') {
      premiumEmojiConfig.setGaransiEmoji(ctx.message.text.trim(), customEmojiId);
    } else {
      premiumEmojiConfig.setNonGaransiEmoji(ctx.message.text.trim(), customEmojiId);
    }
  } catch (err) {
    await ctx.reply(`❌ ${(err && err.message) || 'Emoji tidak valid.'} Coba lagi.`);
    return;
  }

  adminState.clear(ctx.from.id);
  await ctx.reply('✅ Emoji tersimpan.');
  await renderPremiumEmojiHome(ctx);
  logger.info(`Admin ${ctx.from.id} updated premium emoji (${state.action})`);
}

module.exports = {
  premiumEmojiHomeCallback,
  premiumEmojiSetGaransiCallback,
  premiumEmojiSetNonGaransiCallback,
  premiumEmojiCancelCallback,
  handlePremiumEmojiText,
};
