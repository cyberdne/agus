const { adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const fs = require('fs');
const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { Markup } = require('telegraf');
const { replyButton } = require('../../utils/buttons');
const { button: rawButton } = require('../../utils/buttons');
const button = {
  primary: (l, cb, o) => rawButton.primary(l, cb, { ...o, customizable: false }),
  success: (l, cb, o) => rawButton.success(l, cb, { ...o, customizable: false }),
  danger: (l, cb, o) => rawButton.danger(l, cb, { ...o, customizable: false }),
};
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const adminState = require('../../state/adminState');
const settingsPortability = require('../../services/settingsPortability.service');
const logger = require('../../utils/logger');

const MAX_IMPORT_BYTES = 5 * 1024 * 1024;

function homeKeyboard() {
  return Markup.inlineKeyboard([
    [button.success('📤 Export & Kirim File', ADMIN_CALLBACK.SETTINGS_BACKUP_EXPORT)],
    [button.primary('📥 Import File Backup', ADMIN_CALLBACK.SETTINGS_BACKUP_IMPORT)],
    [button.success('🗄️ Backup Otomatis Database', ADMIN_CALLBACK.AUTO_BACKUP_HOME)],
    [button.primary('🩺 Kesehatan Sistem', ADMIN_CALLBACK.SYSTEM_HEALTH_HOME)],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.SETTINGS_OPEN)],
  ]);
}

function homeText(notice = '') {
  let info = 'Belum ada file backup.';
  if (fs.existsSync(settingsPortability.SNAPSHOT_PATH)) {
    try {
      const data = settingsPortability.readPayloadFromFile();
      info =
        `Versi: ${data.version}\n` +
        `Terakhir disimpan: ${data.exportedAt || '-'}\n` +
        `Settings: ${Object.keys(data.settings || {}).length}\n` +
        `Payment config: ${(data.paymentConfig || []).length}\n` +
        `Custom submenu: ${(data.submenuCustomizations || []).length}`;
    } catch (_) {
      info = 'File backup ada tapi tidak valid / tidak terbaca.';
    }
  }

  return (
    `${notice ? `${notice}\n\n` : ''}💾 *Backup Pengaturan*\n\n` +
    `Backup mencakup konfigurasi Admin Panel yang tersimpan di database: settings, payment config, dan Custom Submenu. ` +
    `Data user, order, session userbot, stok, dan log sengaja tidak ikut agar restore tidak merusak data operasional.\n\n` +
    `${info}\n\n` +
    `*Export* membuat file JSON baru dan mengirimkannya ke chat admin. ` +
    `*Import* meminta file JSON backup untuk dipulihkan secara atomik.`
  );
}

const settingsBackupHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...homeKeyboard() });
  logger.debug(`Admin ${ctx.from.id} opened Backup Pengaturan`);
});

const settingsBackupExportCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  try {
    const payload = settingsPortability.exportToFile();
    await ctx.replyWithDocument(
      { source: settingsPortability.SNAPSHOT_PATH, filename: 'jaseb-settings-backup.json' },
      {
        caption:
          `✅ *Backup berhasil dibuat.*\n\n` +
          `Versi: ${payload.version}\n` +
          `Settings: ${Object.keys(payload.settings).length}\n` +
          `Payment: ${payload.paymentConfig.length}\n` +
          `Custom Submenu: ${payload.submenuCustomizations.length}`,
        parse_mode: 'Markdown',
      }
    );
    await renderScreen(ctx, homeText('✅ Backup terbaru sudah diekspor dan dikirim sebagai file JSON.'), {
      parse_mode: 'Markdown',
      ...homeKeyboard(),
    });
  } catch (err) {
    await renderScreen(ctx, homeText(`❌ Gagal export: ${err.message}`), {
      parse_mode: 'Markdown',
      ...homeKeyboard(),
    });
  }
});

const settingsBackupImportCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_settings_backup_import' });
  await renderScreen(
    ctx,
    `📥 Import Backup Pengaturan\n\n` +
      `Kirim file JSON backup hasil Export JASEB ke chat ini.\n\n` +
      `Restore akan mengganti seluruh konfigurasi yang tercakup dalam file secara atomik. ` +
      `Data user/order/session tetap aman dan tidak disentuh.`,
    {
      ...adminInputKeyboard(adminState.get(ctx.from.id)),
    }
  );
});

async function handleSettingsBackupDocument(ctx, state) {
  if (!state || state.action !== 'admin_settings_backup_import') return false;
  const document = ctx.message && ctx.message.document;
  if (!document) return false;

  if (document.file_size && document.file_size > MAX_IMPORT_BYTES) {
    await ctx.reply('❌ File backup terlalu besar. Backup JSON JASEB yang valid seharusnya kecil; batas import adalah 5 MB.');
    return true;
  }

  const fileName = String(document.file_name || '').toLowerCase();
  if (fileName && !fileName.endsWith('.json')) {
    await ctx.reply('❌ File harus berformat .json. Kirim file backup hasil Export JASEB.');
    return true;
  }

  try {
    const link = await ctx.telegram.getFileLink(document.file_id);
    const response = await fetch(link.href || String(link));
    if (!response.ok) throw new Error(`Gagal mengunduh file dari Telegram (HTTP ${response.status}).`);
    const text = await response.text();
    if (Buffer.byteLength(text, 'utf8') > MAX_IMPORT_BYTES) {
      throw new Error('Ukuran file backup melebihi batas 5 MB.');
    }

    const result = settingsPortability.importPayload(text, { force: true });
    adminState.clear(ctx.from.id);

    await ctx.reply(
      `✅ Import berhasil.\n\n` +
        `Versi: ${result.version}\n` +
        `Settings: ${result.settings}\n` +
        `Payment config: ${result.paymentConfig}\n` +
        `Custom submenu: ${result.submenuCustomizations}`
    );
    await renderScreen(ctx, homeText('✅ Backup berhasil dipulihkan penuh.'), {
      parse_mode: 'Markdown',
      ...homeKeyboard(),
    });
    logger.info(`Admin ${ctx.from.id} imported settings backup version ${result.version}`);
  } catch (err) {
    // Error text must remain plain text here. Backup JSON can contain arbitrary
    // user-configured characters, and rendering an error through Markdown/
    // MarkdownV2 can mask the real import problem with a Telegram parse error.
    await ctx.reply(`❌ Import gagal: ${String(err && err.message ? err.message : err)}`);
  }

  return true;
}

const settingsBackupImportLocalCallback = safeHandler(async (ctx) => {
  // Compatibility helper for any caller still invoking the old callback.
  await ctx.answerCbQuery();
  try {
    const result = settingsPortability.importFromFileIfNeeded({ force: true });
    await renderScreen(ctx, homeText(`✅ Backup lokal dipulihkan — ${result.imported || 0} item konfigurasi.`), {
      parse_mode: 'Markdown',
      ...homeKeyboard(),
    });
  } catch (err) {
    await renderScreen(ctx, homeText(`❌ Gagal import: ${err.message}`), {
      parse_mode: 'Markdown',
      ...homeKeyboard(),
    });
  }
});

module.exports = {
  settingsBackupHomeCallback,
  settingsBackupExportCallback,
  settingsBackupImportCallback,
  settingsBackupImportLocalCallback,
  handleSettingsBackupDocument,
};
