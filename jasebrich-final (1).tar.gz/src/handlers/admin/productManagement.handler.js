const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const {
  productHomeKeyboard,
  productListKeyboard,
  productDetailKeyboard,
  productDeleteConfirmKeyboard,
  productAddGaransiKeyboard,
  productAddDescSkipKeyboard,
  productEditFieldKeyboard,
  productEditGaransiKeyboard,
  productEditDescClearKeyboard,
  productAddFeatureChecklistKeyboard,
  productEditFeatureChecklistKeyboard,
  adminInputKeyboard,
  productListActionKeyboard,
  PAGE_SIZE,
} = require('../../keyboards/admin.keyboard');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const productService = require('../../services/product.service');
const { formatRupiah } = require('../../services/product.service');
const featureAccess = require('../../services/featureAccess.service');
const premiumEmojiConfig = require('../../services/premiumEmojiConfig.service');
const { escapeMdV2, emojiMdV2 } = require('../../utils/emojiMarkdown');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');

const { navSignature } = require('../../constants/adminInputFlows');
const CATEGORY_LABEL = { userbot: '🤖 Userbot', jaseb: '🔥 Jaseb' };

const MAX_NAME_LEN = 100;
const MAX_DESC_LEN = 500;
const MAX_PRICE = 1_000_000_000;
const MAX_DURATION_DAYS = 3650;

const productHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, '📦 *Produk Management*\n\nPilih kategori:', {
    parse_mode: 'Markdown',
    ...productHomeKeyboard(),
  });
});

// adminproduct:cat:<category>
const productCatCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const category = ctx.callbackQuery.data.split(':')[2];
  await renderProductList(ctx, category, 0, true);
});

// adminproduct:list:<category>:<page>
const productListCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , category, pageStr] = ctx.callbackQuery.data.split(':');
  await renderProductList(ctx, category, Number(pageStr) || 0);
});

async function renderProductList(ctx, category, page, showActions = false) {
  const products = productService.listPage(category, page * PAGE_SIZE, PAGE_SIZE);
  const total = productService.count(category);
  const text =
    `📦 *Produk — ${CATEGORY_LABEL[category] || category}*\n\n` +
    `Total: ${total}\n\n` +
    (products.length === 0 ? 'Belum ada produk.' : 'Pilih produk untuk edit/hapus, atau tambah baru:');
  await renderScreen(ctx, text, {
    parse_mode: 'Markdown',
    ...productListKeyboard(category, products, page, total),
  });

  if (showActions) {
    await ctx.reply('🔧 *Aksi Produk*', { parse_mode: 'Markdown', ...productListActionKeyboard(category) });
  }
}

// adminproduct:view:<id>
const productViewCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  await renderProductView(ctx, id);
});

async function renderProductView(ctx, id) {
  const p = productService.getById(id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  const cfg = premiumEmojiConfig.configForGaransi(p.garansi);
  const configured = featureAccess.parseFeatureAccess(p);
  const featureLine =
    configured === null
      ? 'Semua fitur \\(belum dikonfigurasi\\)'
      : configured.length === 0
      ? 'Tidak ada fitur diaktifkan'
      : configured.map((id) => escapeMdV2(featureAccess.FEATURE_LABEL[id] || id)).join(', ');
  const text =
    `${emojiMdV2(cfg)} *${escapeMdV2(p.name)}*\n\n` +
    `Kategori: ${escapeMdV2(CATEGORY_LABEL[p.category] || p.category)}\n` +
    `Harga: ${escapeMdV2(formatRupiah(p.price))}/bln\n` +
    `Durasi: ${p.duration_days} hari/bln\n` +
    `Garansi: ${p.garansi ? 'Ya' : 'Tidak'}\n` +
    `Status: ${p.is_active ? '✅ Aktif' : '⛔ Nonaktif'}\n` +
    `Feature Access: ${featureLine}\n` +
    `Deskripsi: ${escapeMdV2(p.description || '-')}`;
  await renderScreen(ctx, text, { parse_mode: 'MarkdownV2', ...productDetailKeyboard(p) });
}

// ======================================================================
// ADD PRODUCT — interactive step-by-step wizard.
// Steps: category (already chosen via the button that triggers this
// callback) -> name -> price -> duration -> garansi -> description ->
// create. Each text step validates input and re-prompts on failure
// without advancing state, so nothing partial ever reaches the database
// until the very last step. Cancel (adminState.clear) is always available
// via the persistent "❌ Batal Produk" reply button.
// ======================================================================

const ADD_STEP_TEXT = {
  admin_product_add_name: (s) =>
    `➕ *Tambah Produk — ${CATEGORY_LABEL[s.category]}*\n\n` +
    (s.name ? `Nama saat ini: \`${String(s.name).replace(/`/g, "'")}\`\n\n` : '') +
    `Langkah 1/6 — Kirim *nama* produk.`,
  admin_product_add_price: (s) =>
    (s.price ? `Harga saat ini: \`${s.price}\`\n\n` : '') +
    `Langkah 2/6 — Kirim *harga* per bulan dalam Rupiah (angka saja, contoh: 15000).`,
  admin_product_add_duration: (s) =>
    (s.durationDays ? `Durasi saat ini: \`${s.durationDays}\` hari\n\n` : '') +
    `Langkah 3/6 — Kirim *durasi* aktif produk dalam hari (angka saja, contoh: 30).`,
  admin_product_add_garansi: () => 'Langkah 4/6 — Apakah produk ini *bergaransi*?',
  admin_product_add_desc: () =>
    'Langkah 5/6 — Kirim *deskripsi* produk, atau kirim `-` / tekan tombol Lewati Deskripsi di bawah untuk melewati.',
  admin_product_add_features: () =>
    `Langkah 6/6 — *Feature Access*\n\nCentang fitur yang tersedia untuk produk ini, lalu Simpan. Atau lewati untuk memberi akses penuh (tidak dibatasi).`,
};

/**
 * Render ONE step of the Add Product wizard together with the keyboard that
 * belongs to that step. Used for forward moves and for "Kembali", so both
 * directions always show identical UI. Steps whose main UI is inline
 * (garansi, features) additionally refresh the reply keyboard when it
 * differs from the previous step's, so the visible keyboard never belongs to
 * another step.
 */
async function promptProductAddStep(ctx, state, fromAction) {
  const text = ADD_STEP_TEXT[state.action](state);
  const opts = { parse_mode: 'Markdown' };
  if (state.action === 'admin_product_add_garansi') {
    await ctx.reply(text, { ...opts, ...productAddGaransiKeyboard() });
  } else if (state.action === 'admin_product_add_features') {
    await ctx.reply(text, { ...opts, ...productAddFeatureChecklistKeyboard(state.selectedFeatures || []) });
  } else {
    await renderScreen(ctx, text, { ...opts, ...adminInputKeyboard(state) });
    return;
  }
}

// adminproduct:add:<category>
const productAddCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const category = ctx.callbackQuery.data.split(':')[2];
  if (!CATEGORY_LABEL[category]) {
    await ctx.reply('❌ Kategori tidak valid.');
    return;
  }
  const fresh = { action: 'admin_product_add_name', category };
  adminState.set(ctx.from.id, fresh);
  await promptProductAddStep(ctx, fresh, null);
});

async function handleProductAddNameText(ctx, state) {
  const name = (ctx.message.text || '').trim();
  if (!name) {
    await ctx.reply('❌ Nama produk tidak boleh kosong. Kirim nama produk.');
    return;
  }
  if (name.length > MAX_NAME_LEN) {
    await ctx.reply(`❌ Nama terlalu panjang (maks ${MAX_NAME_LEN} karakter). Kirim ulang nama produk.`);
    return;
  }
  const next = { ...state, action: 'admin_product_add_price', name };
  adminState.set(ctx.from.id, next);
  await promptProductAddStep(ctx, next, state.action);
}

function parsePriceInput(text) {
  const digits = String(text || '').replace(/[.\s]/g, '');
  if (!/^\d+$/.test(digits)) return null;
  return Number(digits);
}

async function handleProductAddPriceText(ctx, state) {
  const price = parsePriceInput(ctx.message.text);
  if (price === null || !Number.isFinite(price)) {
    await ctx.reply('❌ Harga harus berupa angka positif. Contoh: 15000. Kirim ulang harga.');
    return;
  }
  if (price <= 0) {
    await ctx.reply('❌ Harga harus lebih dari 0. Kirim ulang harga.');
    return;
  }
  if (price > MAX_PRICE) {
    await ctx.reply('❌ Harga terlalu besar. Kirim ulang harga yang wajar.');
    return;
  }
  const next = { ...state, action: 'admin_product_add_duration', price };
  adminState.set(ctx.from.id, next);
  await promptProductAddStep(ctx, next, state.action);
}

async function handleProductAddDurationText(ctx, state) {
  const raw = String(ctx.message.text || '').trim();
  if (!/^\d+$/.test(raw)) {
    await ctx.reply('❌ Durasi harus berupa angka hari (contoh: 30). Kirim ulang durasi.');
    return;
  }
  const durationDays = Number(raw);
  if (durationDays <= 0) {
    await ctx.reply('❌ Durasi harus lebih dari 0 hari. Kirim ulang durasi.');
    return;
  }
  if (durationDays > MAX_DURATION_DAYS) {
    await ctx.reply('❌ Durasi terlalu panjang. Kirim ulang durasi yang wajar (maks 3650 hari).');
    return;
  }
  const next = { ...state, action: 'admin_product_add_garansi', durationDays };
  adminState.set(ctx.from.id, next);
  await promptProductAddStep(ctx, next, state.action);
}

// Admin typed text instead of tapping Ya/Tidak — this step only accepts a
// button tap, so re-show the same prompt instead of falling through to the
// generic "perintah tidak dikenali" handler and leaving the wizard stuck.
async function handleProductAddGaransiText(ctx) {
  await ctx.reply('❌ Pilih salah satu tombol Ya/Tidak di atas untuk menentukan garansi.', {
    ...productAddGaransiKeyboard(),
  });
}

// adminproduct:addgaransi:<ya|tidak>
const productAddGaransiCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_add_garansi') {
    await ctx.reply('❌ Sesi tambah produk sudah kadaluarsa. Silakan mulai ulang dari Produk Management.');
    return;
  }
  const value = ctx.callbackQuery.data.split(':')[2];
  const garansi = value === 'ya';
  const next = { ...state, action: 'admin_product_add_desc', garansi };
  adminState.set(ctx.from.id, next);
  await promptProductAddStep(ctx, next, state.action);
});

async function finalizeProductAdd(ctx, state, featureAccessJson) {
  const p = productService.create({
    category: state.category,
    name: state.name,
    description: state.description || null,
    price: state.price,
    durationDays: state.durationDays,
    garansi: state.garansi,
    featureAccess: featureAccessJson,
  });
  adminState.clear(ctx.from.id);
  logger.info(`Admin ${ctx.from.id} added product #${p.id} (${p.name})`);
  await ctx.reply(`✅ Produk *${escapeMdV2(p.name)}* berhasil ditambahkan\\.`, { parse_mode: 'MarkdownV2' });
  await renderProductView(ctx, p.id);
}

async function goToFeatureStep(ctx, state) {
  const next = { ...state, action: 'admin_product_add_features', selectedFeatures: state.selectedFeatures || [] };
  adminState.set(ctx.from.id, next);
  await promptProductAddStep(ctx, next, state.action);
}

async function handleProductAddDescText(ctx, state) {
  const raw = (ctx.message.text || '').trim();
  if (raw.length > MAX_DESC_LEN) {
    await ctx.reply(`❌ Deskripsi terlalu panjang (maks ${MAX_DESC_LEN} karakter). Kirim ulang deskripsi.`);
    return;
  }
  const description = raw === '-' ? '' : raw;
  await goToFeatureStep(ctx, { ...state, description });
}

// adminproduct:adddescskip
const productAddDescSkipCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_add_desc') {
    await ctx.reply('❌ Sesi tambah produk sudah kadaluarsa. Silakan mulai ulang dari Produk Management.');
    return;
  }
  await goToFeatureStep(ctx, { ...state, description: '' });
});

// Feature toggle inside the Add wizard's checklist step.
// adminproduct:addfeat:<featureId>
const productAddFeatureToggleCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_add_features') {
    await ctx.reply('❌ Sesi tambah produk sudah kadaluarsa. Silakan mulai ulang dari Produk Management.');
    return;
  }
  const featureId = ctx.callbackQuery.data.split(':')[2];
  if (!featureAccess.isValidFeatureId(featureId)) {
    await ctx.reply('❌ Fitur tidak dikenali.');
    return;
  }
  const current = new Set(state.selectedFeatures || []);
  if (current.has(featureId)) current.delete(featureId);
  else current.add(featureId);
  const selectedFeatures = Array.from(current);
  adminState.set(ctx.from.id, { ...state, selectedFeatures });
  await renderScreen(
    ctx,
    `Langkah 6/6 — *Feature Access*\n\nCentang fitur yang tersedia untuk produk ini, lalu Simpan. Atau lewati untuk memberi akses penuh (tidak dibatasi).`,
    { parse_mode: 'Markdown', ...productAddFeatureChecklistKeyboard(selectedFeatures) }
  );
});

// adminproduct:addfeatdone
const productAddFeatureDoneCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_add_features') {
    await ctx.reply('❌ Sesi tambah produk sudah kadaluarsa. Silakan mulai ulang dari Produk Management.');
    return;
  }
  const json = featureAccess.serializeFeatureAccess(state.selectedFeatures || []);
  await finalizeProductAdd(ctx, state, json);
});

// adminproduct:addfeatskip — explicit "no restriction" (feature_access stays NULL).
const productAddFeatureSkipCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_add_features') {
    await ctx.reply('❌ Sesi tambah produk sudah kadaluarsa. Silakan mulai ulang dari Produk Management.');
    return;
  }
  await finalizeProductAdd(ctx, state, null);
});

// Admin typed text instead of using the checklist buttons.
async function handleProductAddFeaturesText(ctx) {
  await ctx.reply('❌ Gunakan tombol di atas untuk memilih fitur, lalu tekan Simpan atau Lewati.');
}

// ======================================================================
// EDIT PRODUCT — pick a field, then change only that field.
// ======================================================================

// adminproduct:edit:<id>
const productEditCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  const p = productService.getById(id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, `✏️ *Edit Produk — ${escapeMdV2(p.name)}*\n\nPilih field yang ingin diubah:`, {
    parse_mode: 'Markdown',
    ...productEditFieldKeyboard(p),
  });
});

const EDIT_FIELD_PROMPT = {
  name: `Kirim *nama* baru untuk produk ini.`,
  description: `Kirim *deskripsi* baru, atau kirim \`-\` / tekan tombol di bawah untuk mengosongkannya.`,
  price: `Kirim *harga* baru per bulan dalam Rupiah (angka saja, contoh: 15000).`,
  duration: `Kirim *durasi* aktif baru dalam hari (angka saja, contoh: 30).`,
};

// adminproduct:editfield:<id>:<field>
const productEditFieldCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , idStr, field] = ctx.callbackQuery.data.split(':');
  const id = Number(idStr);
  const p = productService.getById(id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }

  if (field === 'garansi') {
    adminState.clear(ctx.from.id);
    await renderScreen(
      ctx,
      `🛡️ *Garansi — ${escapeMdV2(p.name)}*\n\nStatus saat ini: ${p.garansi ? 'Ya' : 'Tidak'}\n\nUbah ke:`,
      { parse_mode: 'Markdown', ...productEditGaransiKeyboard(p) }
    );
    return;
  }

  if (field === 'features') {
    // null (unrestricted) starts the editor with everything checked, since
    // that's what unrestricted actually grants today.
    const configured = featureAccess.parseFeatureAccess(p);
    const selectedFeatures = configured === null ? featureAccess.listFeatures().map((f) => f.id) : configured;
    adminState.set(ctx.from.id, { action: 'admin_product_edit_features', productId: id, selectedFeatures });
    await renderScreen(
      ctx,
      `🔐 *Feature Access — ${escapeMdV2(p.name)}*\n\nCentang/hilangkan fitur, lalu Simpan Perubahan atau Batal.`,
      { parse_mode: 'Markdown', ...productEditFeatureChecklistKeyboard(p, selectedFeatures) }
    );
    return;
  }

  const prompt = EDIT_FIELD_PROMPT[field];
  if (!prompt) {
    await ctx.reply('❌ Field tidak dikenali.');
    return;
  }

  adminState.set(ctx.from.id, { action: 'admin_product_edit_value', productId: id, field });
  const current =
    field === 'price'
      ? formatRupiah(p.price)
      : field === 'duration'
      ? `${p.duration_days} hari`
      : field === 'description'
      ? p.description || '-'
      : p.name;
  const options = { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) };
  await renderScreen(ctx, `Nilai saat ini: \`${current}\`\n\n${prompt}`, options);
  if (field === 'description') {
    await ctx.reply('🗑️ Atau kosongkan langsung:', productEditDescClearKeyboard(p));
  }
});

async function applyProductFieldUpdate(ctx, productId, field, value) {
  const fieldToColumn = { name: 'name', description: 'description', price: 'price', duration: 'duration_days' };
  const updateFields = field === 'features' ? { featureAccess: value } : { [fieldToColumn[field]]: value };
  const p = productService.update(productId, updateFields);
  adminState.clear(ctx.from.id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus sebelum perubahan disimpan).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  logger.info(`Admin ${ctx.from.id} edited product #${p.id} field=${field}`);
  await ctx.reply(`✅ Produk *${escapeMdV2(p.name)}* berhasil diperbarui\\.`, { parse_mode: 'MarkdownV2' });
  await renderProductView(ctx, p.id);
}

async function handleProductEditValueText(ctx, state) {
  const p = productService.getById(state.productId);
  if (!p) {
    adminState.clear(ctx.from.id);
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }

  const { field } = state;
  if (field === 'name') {
    const name = (ctx.message.text || '').trim();
    if (!name) {
      await ctx.reply('❌ Nama produk tidak boleh kosong. Kirim nama produk.');
      return;
    }
    if (name.length > MAX_NAME_LEN) {
      await ctx.reply(`❌ Nama terlalu panjang (maks ${MAX_NAME_LEN} karakter). Kirim ulang nama produk.`);
      return;
    }
    await applyProductFieldUpdate(ctx, state.productId, field, name);
    return;
  }

  if (field === 'description') {
    const raw = (ctx.message.text || '').trim();
    if (raw.length > MAX_DESC_LEN) {
      await ctx.reply(`❌ Deskripsi terlalu panjang (maks ${MAX_DESC_LEN} karakter). Kirim ulang deskripsi.`);
      return;
    }
    const description = raw === '-' ? null : raw;
    await applyProductFieldUpdate(ctx, state.productId, field, description);
    return;
  }

  if (field === 'price') {
    const price = parsePriceInput(ctx.message.text);
    if (price === null || !Number.isFinite(price)) {
      await ctx.reply('❌ Harga harus berupa angka positif. Contoh: 15000. Kirim ulang harga.');
      return;
    }
    if (price <= 0) {
      await ctx.reply('❌ Harga harus lebih dari 0. Kirim ulang harga.');
      return;
    }
    if (price > MAX_PRICE) {
      await ctx.reply('❌ Harga terlalu besar. Kirim ulang harga yang wajar.');
      return;
    }
    await applyProductFieldUpdate(ctx, state.productId, field, price);
    return;
  }

  if (field === 'duration') {
    const raw = String(ctx.message.text || '').trim();
    if (!/^\d+$/.test(raw)) {
      await ctx.reply('❌ Durasi harus berupa angka hari (contoh: 30). Kirim ulang durasi.');
      return;
    }
    const durationDays = Number(raw);
    if (durationDays <= 0) {
      await ctx.reply('❌ Durasi harus lebih dari 0 hari. Kirim ulang durasi.');
      return;
    }
    if (durationDays > MAX_DURATION_DAYS) {
      await ctx.reply('❌ Durasi terlalu panjang. Kirim ulang durasi yang wajar (maks 3650 hari).');
      return;
    }
    await applyProductFieldUpdate(ctx, state.productId, field, durationDays);
    return;
  }

  // Unknown field somehow ended up in state — fail safe instead of silently
  // dropping the admin's input.
  adminState.clear(ctx.from.id);
  await ctx.reply('❌ Terjadi kesalahan pada sesi edit. Silakan coba lagi dari Produk Management.');
}

// adminproduct:editdescskip:<id>  — clear description directly, no text needed.
const productEditDescSkipCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  await applyProductFieldUpdate(ctx, id, 'description', null);
});

// adminproduct:editgaransi:<id>:<ya|tidak>
const productEditGaransiCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , idStr, value] = ctx.callbackQuery.data.split(':');
  const id = Number(idStr);
  const p = productService.getById(id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  const garansi = value === 'ya';
  const updated = productService.update(id, { garansi });
  adminState.clear(ctx.from.id);
  logger.info(`Admin ${ctx.from.id} edited product #${id} field=garansi`);
  await ctx.answerCbQuery('✅ Garansi diperbarui');
  await renderProductView(ctx, updated.id);
});

// adminproduct:editfeat:<id>:<featureId>
const productEditFeatureToggleCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const [, , idStr, featureId] = ctx.callbackQuery.data.split(':');
  const id = Number(idStr);
  const p = productService.getById(id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_edit_features' || state.productId !== id) {
    await ctx.reply('❌ Sesi edit sudah kadaluarsa. Silakan buka ulang dari Produk Management.');
    return;
  }
  if (!featureAccess.isValidFeatureId(featureId)) {
    await ctx.reply('❌ Fitur tidak dikenali.');
    return;
  }
  const current = new Set(state.selectedFeatures || []);
  if (current.has(featureId)) current.delete(featureId);
  else current.add(featureId);
  const selectedFeatures = Array.from(current);
  adminState.set(ctx.from.id, { ...state, selectedFeatures });
  await renderScreen(
    ctx,
    `🔐 *Feature Access — ${escapeMdV2(p.name)}*\n\nCentang/hilangkan fitur, lalu Simpan Perubahan atau Batal.`,
    { parse_mode: 'Markdown', ...productEditFeatureChecklistKeyboard(p, selectedFeatures) }
  );
});

// adminproduct:editfeatsave:<id>
const productEditFeatureSaveCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  const state = adminState.get(ctx.from.id);
  if (!state || state.action !== 'admin_product_edit_features' || state.productId !== id) {
    await ctx.reply('❌ Sesi edit sudah kadaluarsa. Silakan buka ulang dari Produk Management.');
    return;
  }
  const json = featureAccess.serializeFeatureAccess(state.selectedFeatures || []);
  await applyProductFieldUpdate(ctx, id, 'features', json);
});

// adminproduct:editfeatcancel:<id> — discard staged checklist, keep DB unchanged.
const productEditFeatureCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  adminState.clear(ctx.from.id);
  await renderProductView(ctx, id);
});

// Admin typed text instead of using the checklist buttons.
async function handleProductEditFeaturesText(ctx) {
  await ctx.reply('❌ Gunakan tombol di atas untuk memilih fitur.');
}

// adminproduct:toggle:<id>
const productToggleCallback = safeHandler(async (ctx) => {
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  const p = productService.toggleActive(id);
  if (!p) {
    await ctx.answerCbQuery('❌ Produk tidak ditemukan');
    return;
  }
  await ctx.answerCbQuery('✅ Status diubah');
  await renderProductView(ctx, id);
});

// ======================================================================
// REMOVE PRODUCT — retire the catalog row without breaking historical
// entitlement references. The existing active toggle can later re-enable it.
// ======================================================================

// adminproduct:delconfirm:<id>
const productDeleteConfirmCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  const p = productService.getById(id);
  if (!p) {
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  const orderCount = productService.countOrders(id);
  const warning =
    orderCount > 0
      ? `\n\n⚠️ Produk ini memiliki *${orderCount}* riwayat order\\. Produk akan dinonaktifkan dari toko tanpa memutus riwayat atau entitlement fitur\\.`
      : '';
  await renderScreen(ctx, `⚠️ Yakin ingin menonaktifkan produk *${escapeMdV2(p.name)}*?${warning}`, {
    parse_mode: 'MarkdownV2',
    ...productDeleteConfirmKeyboard(p),
  });
});

// adminproduct:del:<id>
const productDeleteCallback = safeHandler(async (ctx) => {
  const id = Number(ctx.callbackQuery.data.split(':')[2]);
  const p = productService.getById(id);
  if (!p) {
    await ctx.answerCbQuery('❌ Produk tidak ditemukan');
    await renderScreen(ctx, '❌ Produk tidak ditemukan (mungkin sudah dihapus).', {
      parse_mode: 'Markdown',
      ...productHomeKeyboard(),
    });
    return;
  }
  const category = p.category;
  const orderCount = productService.countOrders(id);
  productService.remove(id);
  adminState.clear(ctx.from.id);
  await ctx.answerCbQuery('🗃️ Produk dinonaktifkan');
  logger.info(`Admin ${ctx.from.id} retired product #${id} (${p.name}); preserved ${orderCount} historical order reference(s)`);
  await renderProductList(ctx, category, 0);
});

const productCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, '📦 *Produk Management*\n\nPilih kategori:', { parse_mode: 'Markdown', ...productHomeKeyboard() });
});

module.exports = {
  productHomeCallback,
  productCatCallback,
  productListCallback,
  productViewCallback,
  productAddCallback,
  productAddGaransiCallback,
  productAddDescSkipCallback,
  productAddFeatureToggleCallback,
  productAddFeatureDoneCallback,
  productAddFeatureSkipCallback,
  productEditCallback,
  productEditFieldCallback,
  productEditGaransiCallback,
  productEditDescSkipCallback,
  productEditFeatureToggleCallback,
  productEditFeatureSaveCallback,
  productEditFeatureCancelCallback,
  productToggleCallback,
  productDeleteConfirmCallback,
  productDeleteCallback,
  productCancelCallback,
  handleProductAddNameText,
  handleProductAddPriceText,
  handleProductAddDurationText,
  handleProductAddGaransiText,
  handleProductAddDescText,
  handleProductAddFeaturesText,
  handleProductEditValueText,
  handleProductEditFeaturesText,
  promptProductAddStep,
};
