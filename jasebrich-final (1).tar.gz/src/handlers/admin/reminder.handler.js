const crypto = require('crypto');
const { Markup } = require('telegraf');
const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { replyButton, button } = require('../../utils/buttons');
const { renderScreen } = require('../../utils/render');
const { adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const adminState = require('../../state/adminState');
const reminderService = require('../../services/subscriptionReminder.service');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const { formatIndonesiaDate, formatRemainingDuration } = require('../../utils/placeholders');
const { escapeHtml } = require('../../utils/telegramFormatting');

function homeKeyboard(config) {
  return Markup.keyboard([
    [replyButton.primary(config.enabled ? '🟢 Reminder Otomatis' : '🔴 Reminder Otomatis')],
    [replyButton.primary('⚙️ Atur Threshold')],
    [replyButton.primary('📨 Reminder Manual')],
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

function manualKeyboard(rows) {
  const out = rows.map((row) => [button.primary(`👤 ${row.user_id} — ${row.label || 'Userbot'} (${formatRemainingDuration(row.expires_at)})`, ADMIN_CALLBACK.REMINDER_MANUAL_SELECT(row.id))]);
  out.push([button.danger('🔙 Kembali', ADMIN_CALLBACK.REMINDER_HOME)]);
  return Markup.inlineKeyboard(out);
}

function lastRunLine(last) {
  if (!last) return '\n🕒 Sweep terakhir: belum ada';
  return `\n🕒 Sweep terakhir: ${formatIndonesiaDate(last.created_at)} — ${last.status}, terkirim ${last.sent}, dilewati ${last.skipped}, gagal ${last.failed}` +
    (last.error ? `\n⚠️ ${last.error}` : '');
}

function homeText() {
  const s = reminderService.homeSummary();
  const next = s.next ? `\n📌 Terdekat: #${s.next.id} — ${formatIndonesiaDate(s.next.expires_at)} (${formatRemainingDuration(s.next.expires_at)})` : '';
  return `⏰ *Subscription Expiry Reminder*\n\n` +
    `⚙️ Otomatis: *${s.enabled ? 'AKTIF' : 'NONAKTIF'}*\n` +
    `⏱️ Threshold: *${s.thresholdsLabel}*\n` +
    `👥 Eligible sekarang: *${s.eligibleCount}* userbot${next}` + lastRunLine(reminderService.lastRunSummary());
}

const reminderHomeCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...homeKeyboard(reminderService.getConfig()) });
});

const reminderToggleCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const current = reminderService.getConfig();
  reminderService.setEnabled(!current.enabled);
  await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...homeKeyboard(reminderService.getConfig()) });
});

const reminderSetThresholdsCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_reminder_thresholds' });
  await ctx.reply(
    '⚙️ Kirim threshold reminder dipisahkan koma, misalnya `7d,3d,1d` atau `168h,72h,24h`. Satuan: d=hari, h=jam, m=menit.',
    { parse_mode: 'Markdown', ...adminInputKeyboard(adminState.get(ctx.from.id)) }
  );
});

async function handleReminderText(ctx, state) {
  if (!state || state.action !== 'admin_reminder_thresholds') return false;
  try {
    const config = reminderService.setThresholds(ctx.message?.text || '');
    adminState.clear(ctx.from.id);
    await ctx.reply(`✅ Threshold disimpan: ${reminderService.formatThresholds(config.thresholds)}.`);
    await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...homeKeyboard(config) });
  } catch (err) {
    await ctx.reply(`❌ ${String(err?.message || 'Threshold tidak valid.')}`, adminInputKeyboard(state));
  }
  return true;
}

const reminderManualHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const rows = reminderService.manualCandidates(30);
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, rows.length ? '📨 *Reminder Manual*\n\nPilih userbot yang akan menerima reminder sekarang.' : '📨 *Reminder Manual*\n\nTidak ada userbot aktif yang berada dalam window threshold saat ini.', { parse_mode: 'Markdown', ...manualKeyboard(rows) });
});

const reminderManualSelectCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const id = Number(String(ctx.callbackQuery.data).split(':')[2]);
  const row = reminderService.manualCandidates(50).find((r) => Number(r.id) === id);
  if (!row) { await renderScreen(ctx, '❌ Userbot tidak lagi eligible untuk reminder manual.', {}); return; }
  const nonce = crypto.randomBytes(4).toString('hex');
  await renderScreen(ctx,
    `⚠️ <b>Konfirmasi Reminder Manual</b>\n\n👤 User: ${row.user_id}\n📦 Userbot: ${escapeHtml(String(row.label || `#${row.id}`))}\n⏳ Sisa: ${escapeHtml(formatRemainingDuration(row.expires_at))}\n📅 Berakhir: ${escapeHtml(formatIndonesiaDate(row.expires_at))}\n\nKirim reminder sekarang?`,
    { parse_mode: 'HTML', ...Markup.inlineKeyboard([[button.success('✅ Kirim Reminder', ADMIN_CALLBACK.REMINDER_MANUAL_CONFIRM(row.id, nonce))],[button.danger('❌ Batal', ADMIN_CALLBACK.REMINDER_CANCEL)]]) }
  );
});

const reminderManualConfirmCallback = safeHandler(async (ctx) => {
  const parts = String(ctx.callbackQuery.data).split(':');
  const id = Number(parts[2]);
  const nonce = String(parts[3] || '');
  if (!/^([0-9a-f]{8})$/i.test(nonce)) { await ctx.answerCbQuery('Konfirmasi tidak valid.', { show_alert: true }); return; }
  await ctx.answerCbQuery('Memproses reminder...');
  const result = await reminderService.sendManualReminder(ctx.telegram, id, ctx.from.id, nonce);
  if (result.ok) await ctx.reply(`✅ Reminder untuk userbot #${id} berhasil dikirim.`);
  else if (result.reason === 'already_claimed') await ctx.reply('ℹ️ Reminder ini sudah diproses; klik ganda tidak mengirim ulang.');
  else await ctx.reply(`❌ Reminder tidak dikirim (${result.reason || 'error'}).`);
  await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...homeKeyboard(reminderService.getConfig()) });
});

const reminderCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...homeKeyboard(reminderService.getConfig()) });
});

module.exports = {
  reminderHomeCallback, reminderToggleCallback, reminderSetThresholdsCallback,
  reminderManualHomeCallback, reminderManualSelectCallback, reminderManualConfirmCallback,
  reminderCancelCallback, handleReminderText,
};
