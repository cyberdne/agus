const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { adminPanelKeyboard } = require('../../keyboards/admin.keyboard');
const orderService = require('../../services/order.service');
const orderRepo = require('../../database/repositories/order.repository');
const notificationService = require('../../services/notification.service');
const logger = require('../../utils/logger');
const ubotFlow = require('../ubotFlow.handler');

function parseOrderId(data) {
  const parts = String(data || '').split(':');
  const id = Number(parts[2]);
  return Number.isInteger(id) && id > 0 ? id : null;
}

async function restoreAdminScreen(ctx, text) {
  await renderScreen(ctx, text, { parse_mode: 'Markdown', ...adminPanelKeyboard() }, 'admin');
}

async function verifyCallback(ctx, order) {
  try {
    return await notificationService.validateChannelOrderCallback(ctx.telegram, ctx, order);
  } catch (err) {
    await ctx.answerCbQuery(`❌ ${err.message || 'Callback tidak valid.'}`, { show_alert: true });
    return null;
  }
}

async function resumePendingUserbotActivation(telegram, order) {
  if (!order || order.category !== 'userbot' || order.status !== 'fulfilled' || !order.fulfillment_ref) return false;
  const ownedRepo = require('../../database/repositories/ownedUserbot.repository');
  const pending = ownedRepo.findById(order.fulfillment_ref);
  if (!pending || pending.status !== 'pending_otp') return false;
  await ubotFlow.beginPhoneStep(telegram, order.user_id, pending.id, 'purchase', { returnTo: 'main' });
  return true;
}

async function notifyApprovedOrder(telegram, fresh, result) {
  if (!fresh || !result) return;
  if (result.type === 'userbot') {
    try {
      await resumePendingUserbotActivation(telegram, { ...fresh, category: 'userbot', fulfillment_ref: result.pendingOwnedId });
    } catch (err) { logger.warn(`Userbot activation trigger #${fresh.id} gagal: ${(err && err.message) || err}`); }
    try {
      await telegram.sendMessage(fresh.user_id, `✅ *Pembayaran Order #${fresh.id} disetujui.*\n\nPesanan userbot kamu sudah diproses. Sekarang lanjutkan aktivasi dengan membagikan nomor telepon akun Telegram yang akan digunakan sebagai userbot.`, { parse_mode: 'Markdown' });
    } catch (err) { logger.warn(`Approval user notification #${fresh.id} gagal: ${(err && err.message) || err}`); }
    return;
  }
  try {
    const message = result.type === 'jaseb'
      ? `✅ *Pembayaran Order #${fresh.id} disetujui.*\n\nPesanan Jaseb kamu sudah diproses. Detail hasil pesanan telah dikirim ke chat ini.`
      : result.type === 'renewal'
        ? `✅ *Pembayaran Order #${fresh.id} disetujui.*\n\nPerpanjangan userbot kamu sudah berhasil diproses.`
        : `✅ *Pembayaran Order #${fresh.id} disetujui.*\n\nPesanan kamu sedang diproses sesuai paket yang dibeli.`;
    await telegram.sendMessage(fresh.user_id, message, { parse_mode: 'Markdown' });
  } catch (err) { logger.warn(`Approval user notification #${fresh.id} gagal: ${(err && err.message) || err}`); }
}

async function notifyRejectedOrder(telegram, fresh) {
  if (!fresh) return;
  try { await telegram.sendMessage(fresh.user_id, `❌ *Pembayaran Order #${fresh.id} ditolak.*\n\nSilakan periksa kembali pembayaran atau hubungi admin jika membutuhkan bantuan.`, { parse_mode: 'Markdown' }); }
  catch (err) { logger.warn(`Reject user notification #${fresh.id} gagal: ${(err && err.message) || err}`); }
}


const adminOrderConfirmCallback = safeHandler(async (ctx) => {
  const orderId = parseOrderId(ctx.callbackQuery.data);
  if (!orderId) {
    await ctx.answerCbQuery('❌ Order ID tidak valid.', { show_alert: true });
    return;
  }
  const order = orderRepo.findById(orderId);
  if (!order) {
    await ctx.answerCbQuery('❌ Order tidak ditemukan.', { show_alert: true });
    return;
  }
  const callbackCheck = await verifyCallback(ctx, order);
  if (!callbackCheck) return;

  if (!['awaiting_confirmation', 'paid'].includes(order.status)) {
    if (order.status === 'fulfilled' && order.category === 'userbot') {
      try {
        const resumed = await resumePendingUserbotActivation(ctx.telegram, order);
        await ctx.answerCbQuery(resumed ? '✅ Aktivasi userbot dilanjutkan.' : 'ℹ️ Order sudah selesai diproses.', { show_alert: true });
      } catch (err) {
        logger.warn(`Resume userbot activation #${order.id} gagal: ${(err && err.message) || err}`);
        await ctx.answerCbQuery('ℹ️ Order sudah fulfilled, tetapi activation belum dapat dilanjutkan sekarang.', { show_alert: true });
      }
      return;
    }
    await ctx.answerCbQuery('❌ Transaksi sudah diproses atau tidak berada pada status yang dapat di-approve.', { show_alert: true });
    return;
  }

  let result;
  try {
    result = await orderService.fulfillOrder(ctx.telegram, orderId);
  } catch (err) {
    const fresh = orderRepo.findById(orderId);
    logger.error(`Admin approval order #${orderId} failed:`, err && err.message ? err.message : err);
    // Fulfillment can commit the canonical state before a subsequent Telegram
    // delivery/runtime step fails. Never report a committed approval as a
    // clean failure to a channel operator.
    if (fresh && ['fulfilled', 'paid'].includes(fresh.status)) {
      if (callbackCheck.channelCallback) {
        const label = fresh.status === 'fulfilled' ? 'APPROVED' : 'APPROVED • MENUNGGU FULFILLMENT';
        await notificationService.updateTransactionNotification(ctx.telegram, fresh, { status: label, actorId: ctx.from.id });
      }
      await ctx.answerCbQuery('✅ Approval sudah tercatat di database.', { show_alert: true });
      return;
    }
    await ctx.answerCbQuery('❌ Approval gagal diproses. Order tetap aman.', { show_alert: true });
    return;
  }

  if (!result.ok) {
    const text = result.reason === 'already_fulfilled'
      ? 'Order sudah fulfilled.'
      : result.reason === 'out_of_stock'
        ? 'Pembayaran tercatat, tetapi stok belum tersedia. Order tetap paid dan menunggu fulfillment.'
        : result.reason === 'already_processing'
          ? 'Order sedang diproses admin lain.'
          : result.reason === 'invalid_state'
            ? 'State order sudah berubah dan callback ini tidak lagi valid.'
            : 'Order gagal diproses.';
    await ctx.answerCbQuery(`❌ ${text}`, { show_alert: true });
    const fresh = orderRepo.findById(orderId);
    if (callbackCheck.channelCallback && fresh && fresh.status !== 'awaiting_confirmation') {
      const label = fresh.status === 'paid' ? 'APPROVED • MENUNGGU FULFILLMENT' : fresh.status.toUpperCase();
      await notificationService.updateTransactionNotification(ctx.telegram, fresh, { status: label, actorId: ctx.from.id });
    }
    return;
  }

  const fresh = orderRepo.findById(orderId) || result.order;
  await ctx.answerCbQuery('✅ Approval berhasil.');
  const label = fresh.status === 'fulfilled' ? 'APPROVED' : fresh.status === 'paid' ? 'APPROVED • MENUNGGU FULFILLMENT' : fresh.status.toUpperCase();
  if (callbackCheck.channelCallback) {
    await notificationService.updateTransactionNotification(ctx.telegram, fresh, { status: label, actorId: ctx.from.id });
  } else {
    await restoreAdminScreen(ctx, `✅ *Order #${orderId}* telah dikonfirmasi dan diproses.\n\nStatus: *${fresh.status}*`);
  }

  await notifyApprovedOrder(ctx.telegram, fresh, result);
  logger.info(`Admin ${ctx.from.id} approved order #${orderId}${callbackCheck.channelCallback ? ' from transaction channel' : ''}`);
});

const adminOrderRejectCallback = safeHandler(async (ctx) => {
  const orderId = parseOrderId(ctx.callbackQuery.data);
  if (!orderId) {
    await ctx.answerCbQuery('❌ Order ID tidak valid.', { show_alert: true });
    return;
  }
  const order = orderRepo.findById(orderId);
  if (!order) {
    await ctx.answerCbQuery('❌ Order tidak ditemukan.', { show_alert: true });
    return;
  }
  const callbackCheck = await verifyCallback(ctx, order);
  if (!callbackCheck) return;

  if (order.status !== 'awaiting_confirmation') {
    await ctx.answerCbQuery('❌ Transaksi sudah diproses.', { show_alert: true });
    return;
  }

  const result = orderService.rejectPendingOrder({ orderId });
  if (!result.ok) {
    await ctx.answerCbQuery('❌ Transaksi sudah berubah atau diproses admin lain.', { show_alert: true });
    return;
  }
  const fresh = result.order || orderRepo.findById(orderId);
  await ctx.answerCbQuery('❌ Transaksi ditolak.');
  if (callbackCheck.channelCallback) {
    await notificationService.updateTransactionNotification(ctx.telegram, fresh, { status: 'REJECTED', actorId: ctx.from.id });
  } else {
    await restoreAdminScreen(ctx, `❌ *Order #${orderId}* ditolak.`);
  }
  await notifyRejectedOrder(ctx.telegram, fresh);
  logger.info(`Admin ${ctx.from.id} rejected order #${orderId}${callbackCheck.channelCallback ? ' from transaction channel' : ''}`);
});

module.exports = { adminOrderConfirmCallback, adminOrderRejectCallback, resumePendingUserbotActivation, notifyApprovedOrder, notifyRejectedOrder };
