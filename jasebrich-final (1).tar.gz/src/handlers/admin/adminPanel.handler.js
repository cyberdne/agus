const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { Markup } = require('telegraf');
const { adminPanelKeyboard } = require('../../keyboards/admin.keyboard');
const { replyButton } = require('../../utils/buttons');
const adminState = require('../../state/adminState');
const logger = require('../../utils/logger');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const user = require('./userManagement.handler');
const { panelUbotHomeCallback } = require('./panelUbot.handler');
const statistics = require('./statistics.handler');

const ADMIN_PANEL_TEXT = '🔧 *Admin Panel*\n\nPilih kategori yang ingin dikelola.';

// Root-level singleton domains open their real feature directly. A domain
// gets its own category screen only when it contains multiple sibling features;
// this removes redundant ROOT -> CATEGORY -> SINGLE FEATURE hops while keeping
// the domain grouping meaningful for multi-feature areas.
const ADMIN_CATEGORIES = Object.freeze({
  userbot: {
    title: '🤖 *Userbot*',
    description: 'Kontrol userbot dan perpanjangan subscription.',
    buttons: [['🎛️ Kontrol Panel Ubot'], ['⏳ Perpanjang Userbot']],
  },
  commerce: {
    title: '🛒 *Commerce*',
    description: 'Produk dan stok layanan.',
    buttons: [['📦 Produk Management'], ['📇 Stok Userbot Jaseb']],
  },
  orders: {
    title: '💳 *Order & Payment*',
    description: 'Pembayaran dan transaksi order.',
    buttons: [['💳 Payment', '🧾 Transaksi']],
  },
  notifications: {
    title: '📢 *Notifications*',
    description: 'Notifikasi, broadcast, dan reminder.',
    buttons: [['🔔 Notifikasi'], ['📣 Broadcast', '⏰ Reminder']],
  },
  settings: {
    title: '⚙️ *Settings*',
    description: 'Konfigurasi dan tools administrasi.',
    buttons: [
      ['🎨 Custom Submenu', '🎬 Sticker /start'],
      ['🎁 Durasi Trial', '💎 Emoji Premium'],
      ['📢 Wajib Join'],
      ['🎨 Custom Icon Tombol'],
      ['💾 Backup Pengaturan'],
    ],
  },
});

function adminCategoryKeyboard(category) {
  const def = ADMIN_CATEGORIES[category];
  if (!def) return Markup.keyboard([[replyButton.danger('🔙 Kembali')]]).resize();
  return Markup.keyboard([
    ...def.buttons.map((row) => row.map((label) => replyButton.primary(label))),
    [replyButton.danger('🔙 Kembali')],
  ]).resize();
}

const renderAdminCategory = (category) => safeHandler(async (ctx) => {
  const def = ADMIN_CATEGORIES[category];
  if (!def) return adminPanelScreen(ctx);
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, `${def.title}\n\n${def.description}`, {
    parse_mode: 'Markdown',
    ...adminCategoryKeyboard(category),
  }, `admin:category:${category}`);
  logger.debug(`Admin ${ctx.from.id} opened Admin Panel category ${category}`);
});

// Legacy export names are retained for callers/imports that still refer to
// "category callbacks", but singleton domains now open their actual feature
// directly instead of rendering an intermediate one-button category.
const adminUsersCategoryCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await user.userListCallback(ctx);
});
const adminUserbotCategoryCallback = renderAdminCategory('userbot');
const adminCommerceCategoryCallback = renderAdminCategory('commerce');
const adminOrdersCategoryCallback = renderAdminCategory('orders');
const adminNotificationsCategoryCallback = renderAdminCategory('notifications');
const adminStatisticsCategoryCallback = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await statistics.statisticsCallback(ctx);
});
const adminSettingsCategoryCallback = renderAdminCategory('settings');

// Handles all three entry points into the Admin Panel: the /admin
// command, the automatic "🔧 Admin Panel" reply-keyboard button shown
// to admins, and the inline "back" button from Settings — all edit
// or send a single consistent screen.
const adminPanelScreen = safeHandler(async (ctx) => {
  if (ctx.callbackQuery) {
    await ctx.answerCbQuery();
  }
  adminState.clear(ctx.from.id);
  await renderScreen(ctx, ADMIN_PANEL_TEXT, { parse_mode: 'Markdown', ...adminPanelKeyboard() }, ADMIN_CALLBACK.PANEL_HOME);
  logger.debug(`Admin ${ctx.from.id} opened Admin Panel`);
});

module.exports = {
  adminPanelHandler: adminPanelScreen,
  adminPanelCallback: adminPanelScreen,
  adminUsersCategoryCallback,
  adminUserbotCategoryCallback,
  adminCommerceCategoryCallback,
  adminOrdersCategoryCallback,
  adminNotificationsCategoryCallback,
  adminStatisticsCategoryCallback,
  adminSettingsCategoryCallback,
  ADMIN_CATEGORIES,
};
