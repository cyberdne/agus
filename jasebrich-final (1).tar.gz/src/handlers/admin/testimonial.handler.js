// Admin Panel → Notifikasi → Testimoni. Konfigurasi channel, tombol, preview. Publish dilakukan
// oleh testimonial.service (dipicu saat order fulfilled), bukan dari layar admin ini.
const { safeHandler } = require('../../utils/errors');
const { answerCancelled } = require('../../services/cancelNotice.service');
const { renderScreen } = require('../../utils/render');
const { testimonialHomeKeyboard, adminInputKeyboard } = require('../../keyboards/admin.keyboard');
const testimonial = require('../../services/testimonial.service');
const { getCustomContent } = require('../../services/custom-submenu.service');
const { contentToken } = require('../../utils/callbackToken');
const adminState = require('../../state/adminState');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const logger = require('../../utils/logger');

function escapeMarkdown(text) {
  return String(text || '').replace(/([_*[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

function homeText() {
  const channel = testimonial.getChannel();
  const buttons = testimonial.getButtons();
  const template = getCustomContent(testimonial.TEMPLATE_ID) ? 'Custom' : 'Default';
  return (
    '🧾 *Testimoni*\n\n' +
    `Status: *${!testimonial.isEnabled() ? 'DIMATIKAN' : channel ? 'AKTIF' : 'NONAKTIF'}*\n` +
    `Channel: *${channel ? escapeMarkdown(channel.title) : 'Belum diset'}*\n` +
    `Template: *${template}*\n` +
    `Gambar: *${testimonial.getImageFileId() ? 'Diset' : 'Belum diset'}*\n` +
    `Tombol CTA: *${buttons.length}*\n\n` +
    'Testimoni otomatis dikirim untuk transaksi yang sudah fulfilled. Gambar yang dipakai adalah gambar yang Anda set di sini.'
  );
}

async function renderHome(ctx) {
  await renderScreen(ctx, homeText(), { parse_mode: 'Markdown', ...testimonialHomeKeyboard(testimonial.getChannel(), testimonial.isEnabled()) });
}

const testimonialHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

const testimonialSetChannelCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_notification_testimonial_channel' });
  await ctx.reply('📢 Kirim @username channel atau chat ID channel (-100...) untuk Testimoni. Bot akan memvalidasi channel, status admin, dan izin posting.', {
    reply_markup: adminInputKeyboard(adminState.get(ctx.from.id)).reply_markup,
  });
});

const testimonialSetButtonsCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_notification_testimonial_buttons' });
  await ctx.reply(
    '🔘 Kirim tombol CTA, satu per baris (maksimal 8). Format:\n' +
    '• `Label | BOT | style | ROW:1`\n' +
    '• `Label | STORE | style | ROW:1`\n' +
    '• `Label | RENEWAL | style | ROW:2`\n' +
    '• `Label | URL | https://contoh.com | style | ROW:2`\n\n' +
    'Style: primary, success, danger. Ketik `kosong` untuk menghapus semua tombol.',
    { parse_mode: 'Markdown', reply_markup: adminInputKeyboard(adminState.get(ctx.from.id)).reply_markup },
  );
});

const testimonialSetImageCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  adminState.set(ctx.from.id, { action: 'admin_notification_testimonial_image' });
  await ctx.reply('🖼️ Kirim gambar (foto) yang akan dipakai di setiap post Testimoni.', {
    reply_markup: adminInputKeyboard(adminState.get(ctx.from.id)).reply_markup,
  });
});

async function handleTestimonialPhoto(ctx, state) {
  if (!state || state.action !== 'admin_notification_testimonial_image') return false;
  const photos = Array.isArray(ctx.message?.photo) ? ctx.message.photo : [];
  const best = photos[photos.length - 1];
  if (!best || !best.file_id) {
    await ctx.reply('❌ Foto tidak terbaca. Kirim ulang sebagai foto.');
    return true;
  }
  try {
    testimonial.setImageFileId(best.file_id);
    adminState.clear(ctx.from.id);
    await ctx.reply('✅ Gambar Testimoni disimpan.');
    await renderHome(ctx);
  } catch (err) {
    logger.warn(`Testimoni gambar gagal disimpan: ${(err && err.message) || err}`);
    await ctx.reply(`❌ ${String((err && err.message) || 'Gambar tidak bisa disimpan.')}`);
  }
  return true;
}

const testimonialToggleCallback = safeHandler(async (ctx) => {
  const on = !testimonial.isEnabled();
  testimonial.setEnabled(on);
  await ctx.answerCbQuery(on ? 'Testimoni dinyalakan.' : 'Testimoni dimatikan.');
  logger.info(`Testimoni ${on ? 'diaktifkan' : 'dimatikan'} oleh admin ${ctx.from.id}`);
  await renderHome(ctx);
});

const testimonialResetCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Pengaturan Testimoni di-reset.');
  testimonial.resetSettings();
  await renderHome(ctx);
});

const testimonialPreviewCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  try {
    const result = await testimonial.previewLatest(ctx.telegram, ctx.chat.id);
    if (!result.ok) {
      const reason = result.reason === 'caption_too_long'
        ? 'Caption melebihi 1024 karakter. Persingkat template.'
        : result.reason === 'image_not_configured'
          ? 'Gambar Testimoni belum diset. Atur gambar dulu.'
          : 'Preview belum tersedia: belum ada order fulfilled. Tidak ada data palsu yang dibuat.';
      await ctx.reply(`ℹ️ ${reason}`);
      return;
    }
    await ctx.reply(`👁️ Preview dari order nyata #${result.orderId}. Ini hanya tampilan ke Anda, tidak dikirim ke channel.`);
  } catch (err) {
    logger.warn(`Preview Testimoni gagal: ${(err && err.message) || err}`);
    await ctx.reply(`❌ Preview gagal: ${(err && err.message) || 'tidak diketahui'}`);
  }
});

const testimonialCustomCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply('🎨 Buka editor template Testimoni (sama dengan Custom Submenu):', {
    reply_markup: { inline_keyboard: [[{ text: '🎨 Buka Editor Testimoni', callback_data: `custom_submenu:select:${contentToken(testimonial.TEMPLATE_ID)}` }]] },
  });
});

async function handleTestimonialText(ctx, state) {
  if (!state || !['admin_notification_testimonial_channel', 'admin_notification_testimonial_buttons'].includes(state.action)) return false;
  const text = typeof ctx.message?.text === 'string' ? ctx.message.text.trim() : '';
  if (!text) return true;
  try {
    if (state.action === 'admin_notification_testimonial_channel') {
      const saved = await testimonial.setChannel(ctx.telegram, text);
      adminState.clear(ctx.from.id);
      await ctx.reply(`✅ Channel Testimoni disimpan: ${saved.title}`);
    } else {
      const lines = text.toLowerCase() === 'kosong' ? [] : text.split('\n').map((l) => l.trim()).filter(Boolean);
      const list = lines.map((line) => testimonial.parseButtonLine(line));
      testimonial.setButtons(list);
      adminState.clear(ctx.from.id);
      await ctx.reply(`✅ ${list.length} tombol CTA Testimoni disimpan.`);
    }
    await renderHome(ctx);
    return true;
  } catch (err) {
    logger.warn(`Testimoni admin input gagal: ${(err && err.message) || err}`);
    await ctx.reply(`❌ ${String((err && err.message) || 'Konfigurasi tidak valid.')}\n\nCoba lagi dengan data yang benar.`);
    return true;
  }
}

const testimonialCancelCallback = safeHandler(async (ctx) => {
  await answerCancelled(ctx);
  adminState.clear(ctx.from.id);
  await renderHome(ctx);
});

module.exports = {
  testimonialHomeCallback,
  testimonialSetChannelCallback,
  testimonialSetButtonsCallback,
  testimonialSetImageCallback,
  testimonialToggleCallback,
  testimonialResetCallback,
  testimonialPreviewCallback,
  testimonialCustomCallback,
  testimonialCancelCallback,
  handleTestimonialText,
  handleTestimonialPhoto,
};
