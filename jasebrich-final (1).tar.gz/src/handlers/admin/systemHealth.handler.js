'use strict';
const { Markup } = require('telegraf');
const { safeHandler } = require('../../utils/errors');
const { renderScreen } = require('../../utils/render');
const { button: rawButton } = require('../../utils/buttons');
const { ADMIN_CALLBACK } = require('../../constants/admin.callback');
const health = require('../../services/systemHealth.service');

const button = {
  primary: (l, cb, o) => rawButton.primary(l, cb, { ...o, customizable: false }),
  success: (l, cb, o) => rawButton.success(l, cb, { ...o, customizable: false }),
  danger: (l, cb, o) => rawButton.danger(l, cb, { ...o, customizable: false }),
};

function homeKeyboard(s) {
  return Markup.inlineKeyboard([
    [button.primary(`Pemantauan: ${s.enabled ? '🟢 ON' : '⚪ OFF'}`, ADMIN_CALLBACK.SYSTEM_HEALTH_TOGGLE)],
    [button.primary(`🔁 Heartbeat: ${s.heartbeatHours} jam`, ADMIN_CALLBACK.SYSTEM_HEALTH_HEARTBEAT)],
    [button.success('🔄 Cek Sekarang', ADMIN_CALLBACK.SYSTEM_HEALTH_CHECK)],
    [button.danger('🔙 Kembali', ADMIN_CALLBACK.SETTINGS_BACKUP_HOME)],
  ]);
}

function homeText(s, notice = '') {
  const last = s.lastCheckedAt ? `${s.lastCheckedAt.slice(0, 16).replace('T', ' ')} UTC` : 'Belum pernah';
  const overall = s.overall === 'ok' ? '🟢 Normal' : s.overall === 'warn' ? '🟡 Perlu perhatian' : '🔴 Kritis';
  return `${notice ? `${notice}\n\n` : ''}🩺 <b>Kesehatan Sistem</b>\n\n` +
    `Memeriksa scheduler, database, disk, pengingat, backup, dan pengiriman userbot setiap siklus.\n` +
    `Kartu status dikirim ke setiap admin dan diedit saat berubah. Insiden kritis hanya memicu satu pesan baru.\n\n` +
    `Status: <b>${overall}</b>\n🕒 Pemeriksaan terakhir: ${last}`;
}

async function show(ctx, notice = '') {
  const s = health.getSettings();
  await renderScreen(ctx, homeText(s, notice), { parse_mode: 'HTML', ...homeKeyboard(s) });
}

const systemHealthHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await show(ctx);
});

const systemHealthToggleCallback = safeHandler(async (ctx) => {
  health.setEnabled(!health.getSettings().enabled);
  await show(ctx);
});

const systemHealthHeartbeatCallback = safeHandler(async (ctx) => {
  health.cycleHeartbeat();
  await show(ctx);
});

const systemHealthCheckCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery('Memeriksa...').catch(() => {});
  const result = await health.runCheck({ telegram: ctx.telegram, schedulerStatus: require('../../scheduler').getStatus() });
  if (result.skipped) return show(ctx, 'ℹ️ Pemantauan sedang nonaktif.');
  await show(ctx, `✅ Pemeriksaan selesai. Status: ${result.overall}.`);
});

module.exports = {
  systemHealthHomeCallback, systemHealthToggleCallback,
  systemHealthHeartbeatCallback, systemHealthCheckCallback,
};
