const { Markup } = require('telegraf');
const { safeHandler } = require('../utils/errors');
const { renderScreen } = require('../utils/render');
const { button } = require('../utils/buttons');
const { CALLBACK } = require('../constants/menu');
const { defineSubmenu, buildReplyOptions } = require('../services/custom-submenu.service');
const logger = require('../utils/logger');

const DEFAULT_TEXT =
  `📖 *Panduan Membuat Userbot*\n\n` +
  `Ikuti langkah-langkah mudah ini untuk mengaktifkan userbot Anda!\n\n` +
  `1️⃣ *Beli Layanan* » Tekan 🛒 Toko dan pilih paket yang sesuai.\n` +
  `2️⃣ *Mulai Proses* » Kembali ke menu awal dan tekan 🤖 Buat Userbot.\n` +
  `3️⃣ *Setujui Syarat* » Baca kebijakan kami, lalu tekan Saya Setuju.\n` +
  `4️⃣ *Kirim Kontak* » Bagikan nomor telepon akun yang ingin dijadikan userbot.\n` +
  `5️⃣ *Verifikasi Akun* » Masukkan kode OTP dari Telegram dan password 2FA Anda (jika ada).\n` +
  `6️⃣ *Simpan Token* » Userbot aktif! Anda akan menerima Token Garansi, simpan baik-baik.\n\n` +
  `🔔 Siap untuk promosi tanpa batas! Menu promosi akan otomatis muncul.\n` +
  `🎫 Jika akses Anda pernah dicabut, buka 🎫 Klaim Token dan masukkan Token Garansi Anda untuk mengaktifkannya kembali.`;

const submenu = defineSubmenu('guide', '📖 Panduan Buat', DEFAULT_TEXT, 'Markdown', { feature: 'Menu Utama' });

const guideHandler = safeHandler(async (ctx) => {
  const content = submenu.getContent(ctx);
  const keyboard = Markup.inlineKeyboard([[button.danger('🔙 Kembali', CALLBACK.NAV_HOME, { customizable: false })]]);

  await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...keyboard });
  logger.debug(`User ${ctx.from.id} opened Panduan Buat`);
});

module.exports = { guideHandler };
