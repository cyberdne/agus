const { safeHandler } = require('../utils/errors');
const { renderMainMenu } = require('../services/mainMenu.service');
const userService = require('../services/user.service');
const logger = require('../utils/logger');
const startStickerService = require('../services/startSticker.service');

const START_STICKER_DISPLAY_MS = 3000;

// Sends the admin-configured /start sticker, then schedules only that exact
// sent message for deletion. The main /start flow does not wait for the
// display interval; delete failures are handled asynchronously so an API
// error can never become an unhandled rejection or delay the main menu.
async function sendStartStickerIfConfigured(ctx) {
  const fileId = startStickerService.getStartStickerFileId();
  if (!fileId || !ctx.chat) return;

  try {
    const sent = await ctx.replyWithSticker(fileId);
    const messageId = sent && sent.message_id;
    const chatId = ctx.chat.id;
    if (!messageId) return;

    const timer = setTimeout(() => {
      Promise.resolve(ctx.telegram.deleteMessage(chatId, messageId)).catch((err) => {
        logger.warn('Failed to delete /start sticker asynchronously:', (err && err.message) || err);
      });
    }, START_STICKER_DISPLAY_MS);
    if (timer && typeof timer.unref === 'function') timer.unref();
  } catch (err) {
    logger.error('Failed to send /start sticker:', (err && err.message) || err);
  }
}

const startHandler = safeHandler(async (ctx) => {
  // Access is enforced by joinGateMiddleware(), which is intentionally
  // registered before all commands/callback handlers in index.js. Keeping
  // authorization at the middleware boundary prevents new entry points from
  // accidentally bypassing the join gate while avoiding duplicate Telegram
  // membership checks on every /start.
  const telegramUser = ctx.from;
  userService.registerOrUpdateUser(telegramUser);

  await sendStartStickerIfConfigured(ctx);

  // renderMainMenu() uses the canonical "start" custom submenu. This keeps
  // /start and every return-to-home path on the exact same custom content,
  // including Telegram entities and per-user placeholders.
  await renderMainMenu(ctx);
  logger.debug(`User ${telegramUser.id} started the bot`);
});

module.exports = { startHandler, sendStartStickerIfConfigured, START_STICKER_DISPLAY_MS };
