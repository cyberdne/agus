const { Markup } = require('telegraf');
const { safeHandler } = require('../utils/errors');
const { renderScreen } = require('../utils/render');
const { button } = require('../utils/buttons');
const { CALLBACK } = require('../constants/menu');
const { defineSubmenu, buildReplyOptions } = require('../services/custom-submenu.service');
const logger = require('../utils/logger');

const DEFAULT_TEXT =
  `⭐ *Fitur Unggulan JASEB*\n\n` +
  `Berikut fitur-fitur utama yang akan tersedia:\n\n` +
  `📢 Auto Broadcast\n` +
  `👥 Auto Join\n` +
  `💬 Auto Reply\n` +
  `📋 Manajemen Grup\n` +
  `⚡ Broadcast Mode\n` +
  `🤖 Multi Ubot\n` +
  `📊 Monitoring\n` +
  `🔐 Sistem Akun/Userbot\n\n` +
  `_Fitur di atas masih dalam tahap pengembangan dan akan dirilis secara bertahap._`;

const submenu = defineSubmenu('features', '⭐ Fitur Unggulan', DEFAULT_TEXT, 'Markdown', { feature: 'Menu Utama' });

const featuresHandler = safeHandler(async (ctx) => {
  const content = submenu.getContent(ctx);
  const keyboard = Markup.inlineKeyboard([[button.danger('🔙 Kembali', CALLBACK.NAV_HOME, { customizable: false })]]);

  await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...keyboard });
  logger.debug(`User ${ctx.from.id} opened Fitur Unggulan`);
});

module.exports = { featuresHandler };
