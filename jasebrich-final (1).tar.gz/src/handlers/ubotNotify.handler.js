'use strict';
const { Markup } = require('telegraf');
const { safeHandler } = require('../utils/errors');
const { renderScreen } = require('../utils/render');
const { button: rawButton } = require('../utils/buttons');
const { escapeHtml } = require('../utils/telegramFormatting');
const { CALLBACK } = require('../constants/menu');
const ubotNotify = require('../services/ubotNotify.service');
const policy = require('../services/ubotNotify.policy');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const poolRepo = require('../database/repositories/userbotPool.repository');

const button = {
  primary: (l, cb) => rawButton.primary(l, cb, { customizable: false }),
  danger: (l, cb) => rawButton.danger(l, cb, { customizable: false }),
};

const LABELS = {
  channel_bot: '🤖 Bot',
  channel_saved: '💾 Pesan Tersimpan',
  channel_owner: '👤 Pemilik Userbot',
  on_success: '✅ Sukses',
  on_fail: '❌ Gagal',
  on_flood: '⏳ FloodWait',
};

function loadAsset(kind, id) {
  return kind === 'pool' ? poolRepo.findById(Number(id)) : ownedRepo.findById(Number(id));
}

/** Only the buyer who owns the userbot may view or change its notifications. */
function ownsAsset(ctx, kind, asset) {
  if (!asset) return false;
  const owner = kind === 'pool' ? asset.assigned_user_id : asset.user_id;
  return Number(owner) === Number(ctx.from.id);
}

function screen(kind, id, settings, asset) {
  const toggleRow = (keys) => keys.map((k) => button.primary(
    `${LABELS[k]}: ${settings[k] ? '🟢 ON' : '⚪ OFF'}`,
    CALLBACK.PANEL_NOTIFY_TOGGLE(kind, id, k)
  ));
  const keyboard = Markup.inlineKeyboard([
    toggleRow(['channel_bot', 'channel_saved']),
    toggleRow(['channel_owner']),
    toggleRow(['on_success', 'on_fail']),
    toggleRow(['on_flood']),
    [button.danger('🔙 Kembali', CALLBACK.PANEL_PROMOTION_STATUS_BACK(kind, id))],
  ]);
  const text = `📣 <b>Notifikasi Pengiriman</b>\n📦 ${escapeHtml(String(asset.label || 'Userbot'))} (#${id})\n\n` +
    `<b>Kirim ke</b> (minimal satu aktif)\n` +
    `🤖 Bot: lewat bot ke pembeli\n💾 Pesan Tersimpan: di chat tersimpan userbot\n👤 Pemilik Userbot: userbot mengirim log langsung ke pembeli\n\n` +
    `<b>Yang dicatat</b>\nSukses, gagal, dan FloodWait. Log diedit di satu pesan, bukan dikirim baru. Teks log bisa diubah di Custom Submenu.`;
  return { text, keyboard };
}

const notifyScreenCallback = safeHandler(async (ctx) => {
  const [, kind, id] = ctx.match;
  const asset = loadAsset(kind, id);
  if (!ownsAsset(ctx, kind, asset)) return ctx.answerCbQuery('Userbot tidak ditemukan.', { show_alert: true }).catch(() => {});
  await ctx.answerCbQuery().catch(() => {});
  const { text, keyboard } = screen(kind, id, ubotNotify.getSettings(kind, id), asset);
  await renderScreen(ctx, text, { parse_mode: 'HTML', ...keyboard });
});

const notifyToggleCallback = safeHandler(async (ctx) => {
  const [, kind, id, key] = ctx.match;
  const asset = loadAsset(kind, id);
  if (!ownsAsset(ctx, kind, asset)) return ctx.answerCbQuery('Userbot tidak ditemukan.', { show_alert: true }).catch(() => {});
  const { error } = ubotNotify.toggle(kind, id, key);
  await ctx.answerCbQuery(error || 'Tersimpan').catch(() => {});
  const { text, keyboard } = screen(kind, id, ubotNotify.getSettings(kind, id), asset);
  await renderScreen(ctx, text, { parse_mode: 'HTML', ...keyboard });
});

module.exports = { notifyScreenCallback, notifyToggleCallback };
