const { safeHandler } = require('../utils/errors');
const { renderMainMenu } = require('../services/mainMenu.service');
const { MENU } = require('../constants/menu');
const panelState = require('../state/panelState');
const flowCancellation = require('../services/flowCancellation.service');
const logger = require('../utils/logger');

const backToMainHandler = safeHandler(async (ctx) => {
  flowCancellation.cancelAll(ctx.from.id);
  await renderMainMenu(ctx);
  logger.debug(`User ${ctx.from.id} returned to main menu`);
});

const navHomeCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  flowCancellation.cancelAll(ctx.from.id);
  // Best-effort: strip the inline keyboard off the screen we're leaving.
  try {
    await ctx.editMessageReplyMarkup();
  } catch (err) {
    // The callback message may already be unmodifiable; the fresh home
    // message below is still the authoritative navigation destination.
  }
  await renderMainMenu(ctx);
});

module.exports = { backToMainHandler, navHomeCallback, MENU };
