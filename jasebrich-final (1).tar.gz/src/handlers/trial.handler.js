const { Markup } = require('telegraf');
const { safeHandler } = require('../utils/errors');
const { renderWithReplyKeyboard } = require('../utils/render');
const { replyButton } = require('../utils/buttons');
const { mainKeyboard } = require('../keyboards/main.keyboard');
const { isAdminId } = require('../middlewares/admin.middleware');
const userRepository = require('../database/repositories/user.repository');
const userbotService = require('../services/userbot.service');
const trialConfigService = require('../services/trialConfig.service');
const ubotFlow = require('./ubotFlow.handler');
const buyerState = require('../state/buyerState');
const logger = require('../utils/logger');
const { defineSubmenu, defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');
const { MENU } = require('../constants/menu');
const { replyCancelled } = require('../services/cancelNotice.service');

const TRIAL_AGREE = '⭐ Setuju Trial';
const TRIAL_TERMS_AGREE = '⭐ Saya Setuju';
const TRIAL_CANCEL = MENU.BATAL;

// Must be FUNCTIONS, not built once at require time — see the matching
// note on buildCategoryPurchaseKeyboard() in main.keyboard.js. Both
// "⭐ Setuju Trial" and "⭐ Saya Setuju" below are customizable buttons;
// a static object would permanently ignore any icon set later via
// Custom Icon Tombol.
function trialPolicyKeyboard() {
  return Markup.keyboard([
    [replyButton.success(TRIAL_AGREE)],
    [replyButton.danger(TRIAL_CANCEL, { customizable: false })],
  ]).resize();
}

function trialTermsKeyboard() {
  return Markup.keyboard([
    [replyButton.success(TRIAL_TERMS_AGREE)],
    [replyButton.danger(TRIAL_CANCEL, { customizable: false })],
  ]).resize();
}

// Default texts use the {durasi_trial} placeholder (see utils/placeholders.js)
// instead of baking the configured duration in directly, so these three
// screens can be fully customized via Admin Panel -> Settings -> Custom
// Submenu WITHOUT the custom text going stale whenever the admin changes
// Durasi Trial — the placeholder always resolves to whatever duration is
// live at render time, for both the default and any admin-saved text.
const TRIAL_POLICY_DEFAULT_TEXT =
  `🔔 *Kebijakan Trial Userbot* 🔔\n\n` +
  `💎 Akses trial selama *{durasi_trial}*.\n` +
  `🔴 Mendapatkan plan Basic (WM).\n` +
  `💎 Setelah {durasi_trial}, akses akan berakhir dan data trial akan dihapus.\n` +
  `🔴 Risiko & Syarat: Baca Di Sini\n\n` +
  `📝 Tekan tombol *Setuju Trial* untuk memulai.`;

const TRIAL_TERMS_DEFAULT_TEXT =
  `📜 *Kebijakan & Ketentuan Kami* 📜\n\n` +
  `🔴 Membeli/menjalankan userbot berarti Anda menyetujui segala risiko.\n` +
  `🔴 Panduan lengkap bisa langsung chat developer ADMIN.\n` +
  `🔴 Ketika terdeteksi melakukan hal ilegal seperti penipuan, akses userbot akan dicabut *(No Refund)*.\n` +
  `🔴 Garansi hanya berlaku untuk userbot, tidak ada refund uang.\n` +
  `🔴 Risiko & Syarat: Baca Di Sini\n\n` +
  `🔔 Jika Anda *Setuju* dengan kebijakan di atas, tekan tombol di bawah ini.`;

const TRIAL_ACTIVATED_DEFAULT_TEXT =
  `🔔 *Trial Diaktifkan!* 🔔\n\n` +
  `🎉 Selamat! Trial Anda telah aktif selama *{durasi_trial}*.\n\n` +
  `Silakan baca dan setujui Kebijakan & Ketentuan Kami untuk melanjutkan.`;

const trialPolicySubmenu = defineSubmenu('trial_policy', '🎁 Kebijakan Trial', TRIAL_POLICY_DEFAULT_TEXT, 'Markdown', { feature: 'Trial', supportedPlaceholders: ['durasi_trial'] });
const trialTermsSubmenu = defineSubmenu('trial_terms', '📜 Ketentuan Trial', TRIAL_TERMS_DEFAULT_TEXT, 'Markdown', { feature: 'Trial', supportedPlaceholders: [] });
const trialActivatedSubmenu = defineSubmenu('trial_activated', '🎉 Trial Diaktifkan', TRIAL_ACTIVATED_DEFAULT_TEXT, 'Markdown', { feature: 'Trial', supportedPlaceholders: ['durasi_trial'] });
const trialTpl = {
  menuUnavailable: defineTemplate('trial.menu_unavailable', 'Trial', 'Trial Belum Dibuka', 'ℹ️ Silakan pilih 🎁 Coba Gratis dari menu utama.'),
  alreadyClaimed: defineTemplate('trial.already_claimed', 'Trial', 'Trial Sudah Pernah Digunakan', '🎁 *Coba Gratis*\n\nKamu sudah pernah menggunakan free trial.\n\nFree trial hanya dapat digunakan *1× seumur hidup* per akun.'),
  alreadyClaimedCallback: defineTemplate('trial.already_claimed_callback', 'Trial', 'Trial Sudah Pernah Digunakan', '❌ Free trial sudah pernah digunakan.'),
  continuationUnavailable: defineTemplate('trial.continuation_unavailable', 'Trial', 'Trial Tidak Dapat Dilanjutkan', 'ℹ️ Silakan lanjutkan proses melalui menu 🎁 Coba Gratis.'),
};

const claimTrialHandler = safeHandler(async (ctx) => {
  const telegramId = ctx.from.id;

  if (userRepository.hasClaimedTrial(telegramId)) {
    const content = trialTpl.alreadyClaimed.getContent(ctx);
    await renderWithReplyKeyboard(ctx, content.text, { ...buildReplyOptions(content), ...mainKeyboard(isAdminId(telegramId), true, userbotService.hasControllablePanelAsset(telegramId)) });
    logger.debug(`User ${telegramId} tried to re-claim trial (already claimed)`);
    return;
  }

  buyerState.set(telegramId, { step: 'trial_policy' });
  const policyContent = trialPolicySubmenu.getContent(ctx);
  await renderWithReplyKeyboard(ctx, policyContent.text, { ...buildReplyOptions(policyContent), ...trialPolicyKeyboard() });
  logger.debug(`User ${telegramId} opened Coba Gratis policy`);
});

/** Terms screen + its own keyboard. Also the landing point of Kembali from the phone step. */
async function renderTrialTerms(ctx) {
  const termsContent = trialTermsSubmenu.getContent(ctx);
  await renderWithReplyKeyboard(ctx, termsContent.text, { ...buildReplyOptions(termsContent), ...trialTermsKeyboard() });
}

const trialAgreeHandler = safeHandler(async (ctx) => {
  const state = buyerState.get(ctx.from.id);
  if (!state || state.step !== 'trial_policy') {
    {const c=trialTpl.menuUnavailable.getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}
    return;
  }

  if (userRepository.hasClaimedTrial(ctx.from.id)) {
    buyerState.clear(ctx.from.id);
    {const c=trialTpl.alreadyClaimedCallback.getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}
    return;
  }

  // trial_claimed_at is intentionally NOT set here anymore — only on
  // successful activation (see userbotService.activateOwned()). Setting it
  // this early meant an incomplete/failed phone-OTP attempt permanently
  // burned the user's one-time trial with nothing to show for it
  // (audit.txt finding #6). Re-tapping "Setuju Trial" before finishing an
  // earlier attempt resumes that same pending/active row instead of
  // creating a duplicate.
  const durationHours = trialConfigService.getTrialDurationHours();
  const pending = userbotService.findOwnTrialInProgress(ctx.from.id)
    || userbotService.createTrialOwned({ userId: ctx.from.id, durationHours });

  buyerState.set(ctx.from.id, { step: 'trial_terms', ownedId: pending.id, flow: 'trial' });

  const activatedContent = trialActivatedSubmenu.getContent(ctx);
  await ctx.reply(activatedContent.text, buildReplyOptions(activatedContent));
  await renderTrialTerms(ctx);
  logger.info(`User ${ctx.from.id} accepted trial policy -> terms pending for trial #${pending.id}`);
});

const trialTermsAgreeHandler = safeHandler(async (ctx) => {
  const state = buyerState.get(ctx.from.id);
  if (!state || state.step !== 'trial_terms' || state.flow !== 'trial') {
    {const c=trialTpl.continuationUnavailable.getContent(ctx);await ctx.reply(c.text,buildReplyOptions(c));}
    return;
  }

  // Use the exact same contact/phone activation step as purchased userbots
  // so Trial and Buat Userbot never diverge in behavior.
  await ubotFlow.beginTrialContactStep(ctx.telegram, ctx.from.id, state.ownedId);
  logger.info(`User ${ctx.from.id} accepted trial terms -> contact verification for #${state.ownedId}`);
});

const trialCancelHandler = safeHandler(async (ctx) => {
  const state = buyerState.get(ctx.from.id);
  if (state && state.flow === 'trial') {
    await ubotFlow.cancelFlow(ctx);
    return;
  }
  buyerState.clear(ctx.from.id);
  await replyCancelled(ctx);
  const { renderMainMenu } = require('../services/mainMenu.service');
  await renderMainMenu(ctx);
});

module.exports = {
  renderTrialTerms,
  claimTrialHandler,
  trialAgreeHandler,
  trialTermsAgreeHandler,
  trialCancelHandler,
  TRIAL_AGREE,
  TRIAL_TERMS_AGREE,
  TRIAL_CANCEL,
};
