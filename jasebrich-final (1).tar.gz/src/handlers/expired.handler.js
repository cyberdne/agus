const { safeHandler } = require('../utils/errors');
const userbotService = require('../services/userbot.service');
const subscription = require('../services/subscription.service');
const notice = require('../services/subscriptionNotice.service');
const { Markup } = require('telegraf');
const { button } = require('../utils/buttons');
const { CALLBACK } = require('../constants/menu');
const { formatIndonesiaDate, formatRemainingDuration } = require('../utils/placeholders');
const { defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');

const expiredTpl = {
  empty: defineTemplate('userbot.expiry_empty', 'Userbot', 'Masa Aktif Tidak Tersedia', 'ℹ️ Anda belum memiliki userbot aktif yang dapat diperiksa masa berlakunya.'),
  overview: defineTemplate('userbot.expiry_overview', 'Userbot', 'Ringkasan Masa Aktif', '⏳ *Masa Aktif Userbot Anda*\n\n{userbot_list}\n\n{hasil}', { supportedPlaceholders: ['userbot_list','hasil'] }),
};

function stateLabel(row) {
  return subscription.getSubscriptionState(row) === subscription.STATE.EXPIRED ? 'EXPIRED' : 'AKTIF';
}

/**
 * /expired, /masaaktif — read-only overview of the caller's userbots.
 * Status is derived from the timestamp (never from the persisted status
 * alone), and expired userbots get a renewal button.
 */
const expiredHandler = safeHandler(async (ctx) => {
  const owned = subscription.listRenewable(ctx.from.id);
  const assets = userbotService.getUserAssets(ctx.from.id);
  const leased = (assets.leased || []).filter((a) => a.status !== 'disabled');

  if (!owned.length && !leased.length) {
    const content = expiredTpl.empty.getContent(ctx); await ctx.reply(content.text,buildReplyOptions(content));
    return;
  }

  const lines = [
    ...owned.map((row, i) => `${i + 1}. *${row.label || 'Userbot'} #${row.id}*\n   Status: ${stateLabel(row)}\n   Expired: ${formatIndonesiaDate(row.expires_at)}\n   Sisa: *${formatRemainingDuration(row.expires_at)}*`),
    ...leased.map((row, i) => `${owned.length + i + 1}. *${row.label || 'Userbot'} #${row.id}*\n   Status: ${row.status === 'active' ? 'AKTIF' : String(row.status || '-').toUpperCase()}\n   Expired: ${formatIndonesiaDate(row.expires_at)}\n   Sisa: *${formatRemainingDuration(row.expires_at)}*`),
  ];
  const expiredRows = owned.filter((r) => stateLabel(r) === 'EXPIRED');
  const keyboard = expiredRows.length
    ? Markup.inlineKeyboard(expiredRows.map((r) => [button.success(`${notice.RENEW_LABEL} #${r.id}`, CALLBACK.SUBSCRIPTION_RENEW(r.id))]))
    : {};

  const content = expiredTpl.overview.getContent(ctx,{placeholderValues:{userbot_list:lines.join('\n\n'),hasil:expiredRows.length ? 'Userbot yang kadaluarsa terkunci sampai diperpanjang.' : 'Buka 🎛️ Kontrol Panel untuk memilih userbot yang ingin dikelola.'}});
  await ctx.reply(content.text, { ...buildReplyOptions(content), ...keyboard });
});

module.exports = { expiredHandler };
