const { safeHandler } = require('../utils/errors');
const { Markup } = require('telegraf');
const { replyButton } = require('../utils/buttons');
const buyerState = require('../state/buyerState');
const orderRepo = require('../database/repositories/order.repository');
const notificationService = require('../services/notification.service');
const { renderScreen, renderWithReplyKeyboard, isTextMessage } = require('../utils/render');
const screenState = require('../state/screenState');
const {
  storeCancelConfirmationKeyboard,
  storeProductListKeyboard,
  storeProductDetailKeyboard,
  storePolicyKeyboard,
  storePaymentKeyboard,
  storeCancelAllConfirmationKeyboard,
  storePendingOrderRecoveryKeyboard,
  storeCategoryBackKeyboard,
} = require('../keyboards/inline.keyboard');
const { storeKeyboard } = require('../keyboards/main.keyboard');
const { defineSubmenu, defineTemplate, buildReplyOptions, buildCaptionOptions } = require('../services/custom-submenu.service');
const productService = require('../services/product.service');
const orderService = require('../services/order.service');
const paymentService = require('../services/payment.service');
const premiumEmojiConfig = require('../services/premiumEmojiConfig.service');
const userService = require('../services/user.service');
const userbotService = require('../services/userbot.service');
const { escapeMdV2, boldMdV2, emojiMdV2 } = require('../utils/emojiMarkdown');
const { MENU } = require('../constants/menu');
const { CATEGORIES, CATEGORY_LABEL, formatRupiah } = require('../services/product.service');
const { formatIndonesiaDate } = require('../utils/placeholders');
const renewalTarget = require('../services/renewalTarget.service');
const subscription = require('../services/subscription.service');
const { CALLBACK } = require('../constants/menu');
const logger = require('../utils/logger');
const { CANCELLED_TEXT, answerCancelled, getCancelledText } = require('../services/cancelNotice.service');
const { createActionIdempotency } = require('../utils/actionIdempotency');

// Store entry is a side-effecting UI action: one Telegram update/callback must
// not be allowed to create two Store renders when the same update reaches the
// dispatch path twice or when Telegram retries a callback after the source
// message has already been consumed. Idempotency is keyed by Telegram's stable
// update/callback identity (or the callback source message for Store Home),
// never by text matching, a global boolean, or an arbitrary delay.
const storeActionIdempotency = createActionIdempotency({ ttlMs: 60 * 1000, maxEntries: 2000 });

function storeActionKey(ctx, mode = 'update') {
  if (mode === 'source-message') {
    const chatId = ctx?.chat?.id ?? ctx?.callbackQuery?.message?.chat?.id;
    const messageId = ctx?.callbackQuery?.message?.message_id;
    if (chatId != null && messageId != null) return `store-source:${chatId}:${messageId}`;
  }
  const updateId = ctx?.update?.update_id;
  if (updateId != null) return `store-update:${updateId}`;
  const callbackId = ctx?.callbackQuery?.id;
  if (callbackId) return `store-callback:${callbackId}`;
  return null;
}

async function runStoreActionIdempotently(ctx, action, mode = 'update') {
  return storeActionIdempotency.run(storeActionKey(ctx, mode), action);
}

// Quantity rule (1–24 months) lives in order.service.js and is enforced by
// createOrder() itself. Callback data is untrusted, so every handler below
// also validates with the SAME strict rule and REJECTS (never clamps) an
// out-of-range/malformed qty.
const { QTY_MIN, QTY_MAX, InvalidQuantityError, parseQtyStrict, validateQty } = orderService;

const DEFAULT_TEXT =
  `🛒 *Toko JASEB*\n\n` +
  `Pilih layanan yang diinginkan melalui tombol di bawah.`;

const submenu = defineSubmenu('store', '🛒 Toko', DEFAULT_TEXT);

const storeTpl = {
  cbOrderInvalid: defineTemplate('store.cb_order_invalid', 'Pembayaran', 'Alert Order Tidak Valid', 'Order tidak valid.', { messageType: 'callback_alert', maxLength: 200 }),
  cbOrderProcessed: defineTemplate('store.cb_order_processed', 'Pembayaran', 'Alert Order Sudah Diproses', 'Order sudah diproses atau tidak dapat diubah.', { messageType: 'callback_alert', maxLength: 200 }),
  cbProofRequestFailed: defineTemplate('store.cb_proof_request_failed', 'Pembayaran', 'Alert Bukti Pembayaran Gagal', 'Order tidak dapat diproses.', { messageType: 'callback_alert', maxLength: 200 }),
  cbCancelInvalid: defineTemplate('store.cb_cancel_invalid', 'Pembayaran', 'Alert Pembatalan Tidak Valid', '❌ Order tidak valid.', { messageType: 'callback_alert', maxLength: 200 }),
  cbCancelNotFound: defineTemplate('store.cb_cancel_not_found', 'Pembayaran', 'Alert Order Tidak Ditemukan', '❌ Order tidak ditemukan.', { messageType: 'callback_alert', maxLength: 200 }),
  cbCancelNotOwner: defineTemplate('store.cb_cancel_not_owner', 'Pembayaran', 'Alert Akses Order Ditolak', '❌ Order ini bukan milik Anda.', { messageType: 'callback_alert', maxLength: 200 }),
  cbCancelProcessed: defineTemplate('store.cb_cancel_processed', 'Pembayaran', 'Alert Order Tidak Dapat Dibatalkan', '❌ Order ini sudah diproses dan tidak dapat dibatalkan.', { messageType: 'callback_alert', maxLength: 200 }),
  invalidCategory: defineTemplate('store.category_invalid', 'Store', 'Kategori Tidak Dikenali', '❌ Kategori tidak dikenali.'),
  renewalNone: defineTemplate('store.renewal_none', 'Store', 'Langganan Tidak Dapat Diperpanjang', '❌ Kamu belum memiliki langganan userbot aktif untuk diperpanjang.'),
  jasebStockEmpty: defineTemplate('store.jaseb_stock_empty', 'Stok Jaseb', 'Stok Jaseb Kosong', '🔥 *Beli Jaseb*\n\n❌ Stok userbot Jaseb sedang kosong. Silakan coba lagi nanti atau gunakan 🛒 Beli Userbot.'),
  productsEmpty: defineTemplate('store.products_empty', 'Store', 'Paket Tidak Tersedia', ({}, extra) => `${extra.placeholderValues?.kategori || 'Layanan'}\n\n📦 Belum ada paket tersedia saat ini. Silakan cek kembali nanti.`, { supportedPlaceholders: ['kategori'] }),
  // Keep the legacy generic template registered for backward compatibility,
  // but new purchases use service-specific templates so Userbot and Jaseb can
  // be customized independently without sharing a presentation context.
  productsList: defineTemplate('store.products_list', 'Store', 'Daftar Produk (Legacy)', ({}, extra) => { const category = extra.placeholderValues?.kategori || 'Layanan'; const list = extra.placeholderValues?.product_list || ''; return `${category}\n\n📦 *Pilih paket:*\n${list}`; }, { supportedPlaceholders: ['kategori', 'product_list'], parseMode: 'MarkdownV2' }),
  userbotProductsList: defineTemplate('store.userbot_products_list', 'Store', 'Paket Userbot', ({}, extra) => { const list = extra.placeholderValues?.product_list || ''; return `🤖 *Beli Userbot*\n\n📦 *Pilih paket:*\n${list}`; }, { supportedPlaceholders: ['product_list'], parseMode: 'MarkdownV2' }),
  jasebProductsList: defineTemplate('store.jaseb_products_list', 'Store', 'Paket Jaseb', ({}, extra) => { const list = extra.placeholderValues?.product_list || ''; return `🔥 *Beli Jaseb*\n\n📦 *Pilih paket:*\n${list}`; }, { supportedPlaceholders: ['product_list'], parseMode: 'MarkdownV2' }),
  renewalProductsList: defineTemplate('store.renewal_products_list', 'Store', 'Paket Perpanjangan', ({}, extra) => { const list = extra.placeholderValues?.product_list || ''; return `🔄 *Perpanjang Langganan*\n\n📦 *Pilih paket:*\n${list}`; }, { supportedPlaceholders: ['product_list'], parseMode: 'MarkdownV2' }),
  garansiProductsEmpty: defineTemplate('store.garansi_products_empty', 'Store', 'Paket Garansi Tidak Tersedia', '{kategori}\n\n📦 Belum ada paket tersedia saat ini\\. Silakan cek kembali nanti\\.', { supportedPlaceholders: ['kategori'], parseMode: 'MarkdownV2' }),
  garansiProductsList: defineTemplate('store.garansi_products_list', 'Store', 'Daftar Paket Berdasarkan Garansi', '{kategori}\n\nPilih salah satu paket di bawah ini:\n\n{product_list}', { supportedPlaceholders: ['kategori','product_list'], parseMode: 'MarkdownV2' }),
  renewalPicker: defineTemplate('store.renewal_picker', 'Store', 'Pilih Userbot Perpanjangan', '🔄 *Perpanjang Langganan*\n\n{userbot_list}', { supportedPlaceholders: ['userbot_list'] }),
  pendingOrderExists: defineTemplate('store.pending_order_exists', 'Store', 'Order Masih Berjalan', ({}, extra) => {
    const q = extra.placeholderValues || {};
    const count = q.order_count || '1';
    const list = q.order_list || `Order \#${escapeMdV2(q.order_id || '-')}`;
    return `⚠️ *Anda masih memiliki ${escapeMdV2(count)} order yang belum selesai\.*\n\n${list}\n\nGunakan tombol di bawah untuk melanjutkan order yang masih valid atau membatalkan order yang memang masih dapat dibatalkan\.`;
  }, { supportedPlaceholders: ['order_id', 'order_count', 'order_list'], parseMode: 'MarkdownV2' }),
  cancelAllConfirmation: defineTemplate('store.cancel_all_confirmation', 'Store', 'Konfirmasi Batalkan Semua Order', ({}, extra) => {
    const q = extra.placeholderValues || {};
    const count = escapeMdV2(q.cancellable_count || '0');
    return `⚠️ *Konfirmasi Pembatalan Semua Order*\n\nAnda akan membatalkan ${count} order yang masih berstatus dapat dibatalkan\.\n\nOrder yang sudah menunggu verifikasi pembayaran tidak akan ikut dibatalkan\.`;
  }, { supportedPlaceholders: ['cancellable_count'], parseMode: 'MarkdownV2' }),
  proofUnavailable: defineTemplate('store.payment_proof_unavailable', 'Pembayaran', 'Bukti Pembayaran Tidak Tersedia', '❌ Order ini sudah tidak menunggu bukti pembayaran.'),
  orderExpired: defineTemplate('store.order_expired', 'Pembayaran', 'Order Kedaluwarsa', '⏰ *Order \#{order_id} sudah kedaluwarsa\.*\n\nBatas waktu order: {masa_berlaku}\.\nSilakan membuat order baru\.', { supportedPlaceholders: ['order_id','masa_berlaku','status'], parseMode: 'MarkdownV2' }),
  cancelConfirmation: defineTemplate('store.cancel_confirmation', 'Pembayaran', 'Konfirmasi Pembatalan Order', '⚠️ *Konfirmasi Pembatalan*\n\nYakin ingin membatalkan order ini?'),
  productMissing: defineTemplate('store.product_missing', 'Store', 'Produk Tidak Ditemukan', '❌ Produk tidak ditemukan atau sudah tidak tersedia.'),
  qtyInvalid: defineTemplate('store.qty_invalid', 'Store', 'Jumlah Tidak Valid', '❌ Jumlah tidak valid.'),
  orderSummary: defineTemplate('store.order_summary', 'Store', 'Konfirmasi Pesanan', ({}, extra) => { const p=extra.product||{}; const qty=Number(extra.qty||1); const cfg=extra.emojiConfig||premiumEmojiConfig.configForGaransi(p.garansi); return `${emojiMdV2(cfg)} ${boldMdV2(extra.mode==='renewal'?'Konfirmasi Perpanjangan':'Konfirmasi Pesanan')}

📦 Paket: ${escapeMdV2(p.name||'-')}
🔢 Jumlah: ${qty} bulan \\(${Number(p.duration_days||0)*qty} hari\\)
💰 Total: ${escapeMdV2(formatRupiah(Number(p.price||0)*qty))}

${p.description?`${escapeMdV2(p.description)}

`:''}Jika sudah benar, tekan tombol ${boldMdV2('Lanjut Bayar')}\\.`; }, { supportedPlaceholders: ['produk','harga','jumlah','total','durasi_hari','kategori'], parseMode: 'MarkdownV2' }),

  paymentInstruction: defineTemplate('store.payment_instruction', 'Pembayaran', 'Instruksi Pembayaran', ({}, extra) => { const order=extra.order||{}; const a=extra.renewalAsset; const q=extra.placeholderValues||{}; return `💳 *Pembayaran Order #${order.id||q.order_id||'-'}*\n\n${a?`🔄 Perpanjang Userbot: *${a.label||'Userbot'} #${a.id}*\n`:''}Total: *${formatRupiah(order.total_price||0)}*\n\n${q.qris_note?q.qris_note+'\n\n':''}${q.bank_info?q.bank_info+'\n\n':''}Setelah transfer, tekan *Saya Sudah Bayar*.`; }, { supportedPlaceholders: ['order_id','total','qris_note','bank_info','produk','jumlah','durasi_hari'], messageType: 'caption_or_text' }),
  proofPrompt: defineTemplate('store.payment_proof_prompt', 'Pembayaran', 'Instruksi Bukti Pembayaran', '🧾 *Bukti Pembayaran Order #{order_id}*\n\nKirim bukti transfer sekarang dalam bentuk *foto, dokumen, atau video*.', { supportedPlaceholders: ['order_id'] }),
  proofStepCaption: defineTemplate('store.payment_proof_step_caption', 'Pembayaran', 'Langkah Bukti Pembayaran', '🧾 *Order #{order_id}*\n\nSilakan kirim bukti pembayaran melalui pesan berikutnya.', { supportedPlaceholders: ['order_id'], messageType: 'caption' }),
  proofFailed: defineTemplate('store.payment_proof_failed', 'Pembayaran', 'Bukti Pembayaran Gagal', '❌ Bukti pembayaran tidak dapat disimpan. Pastikan order masih menunggu bukti dan kirim ulang media yang valid.'),
  proofReceived: defineTemplate('store.payment_proof_received', 'Pembayaran', 'Bukti Pembayaran Diterima', '✅ *Order #{order_id}*\n\n{hasil}', { supportedPlaceholders: ['order_id','hasil'] }),
  cancelled: defineTemplate('store.order_cancelled', 'Pembayaran', 'Order Dibatalkan', '❌ Order #{order_id} dibatalkan.', { supportedPlaceholders: ['order_id'] }),
  cbStatusExpired: defineTemplate('store.cb_status_expired', 'Pembayaran', 'Status Order Kedaluwarsa', '⏰ Order ini sudah kedaluwarsa dan tidak dapat dilanjutkan.', { messageType: 'callback_alert', maxLength: 200 }),
  cbStatusAwaiting: defineTemplate('store.cb_status_awaiting', 'Pembayaran', 'Status Bukti Menunggu Verifikasi', '⏳ Bukti pembayaran sudah diterima dan sedang menunggu verifikasi admin.', { messageType: 'callback_alert', maxLength: 200 }),
  cbStatusGeneric: defineTemplate('store.cb_status_generic', 'Pembayaran', 'Status Order', 'Status order saat ini: {status}.', { messageType: 'callback_alert', maxLength: 200, supportedPlaceholders: ['status'] }),
  cbCancelAllNone: defineTemplate('store.cb_cancel_all_none', 'Pembayaran', 'Tidak Ada Order Untuk Dibatalkan', 'ℹ️ Tidak ada order pending yang tersisa untuk dibatalkan.', { messageType: 'callback_alert', maxLength: 200 }),
  cbCancelAllSingle: defineTemplate('store.cb_cancel_all_single', 'Pembayaran', 'Satu Order Untuk Dibatalkan', 'Gunakan tombol Batal pada order yang ingin dibatalkan.', { messageType: 'callback_alert', maxLength: 200 }),
};

// Store front screen — reply keyboard (persistent, under the message
// box), not inline: "Beli Userbot" / "Beli Jaseb". Always (re)sent so
// the reply keyboard is correctly (re)attached even coming from a
// different feature's reply keyboard (e.g. Kontrol Panel).
async function renderStoreScreen(ctx) {
  // Store is rendered with a reply keyboard, so an inline callback cannot edit
  // the previous inline message into the new Store screen. Remove that obsolete
  // callback-owning message first; otherwise Back/Home/cancel callbacks leave
  // the old submenu visible next to the new Store screen and look duplicated.
  const sourceMessage = ctx && ctx.callbackQuery && ctx.callbackQuery.message;
  if (sourceMessage && sourceMessage.message_id && ctx.chat && ctx.chat.id) {
    try {
      await ctx.telegram.deleteMessage(ctx.chat.id, sourceMessage.message_id);
    } catch (err) {
      const desc = String((err && err.description) || (err && err.message) || '');
      if (!/message to delete not found|message can't be deleted|message cannot be deleted|MESSAGE_ID_INVALID|message is too old/i.test(desc)) {
        throw err;
      }
      logger.debug(`Store callback source #${sourceMessage.message_id} tidak dapat dihapus: ${desc}`);
    }
  }

  const content = submenu.getContent(ctx);
  // Renewable (active OR expired): an owner whose userbot lapsed must still
  // see "Perpanjang Langganan" instead of "Beli Userbot".
  const hasUserbot = userService.hasRenewableUserbot(ctx.from.id);
  await renderWithReplyKeyboard(ctx, content.text, { ...buildReplyOptions(content), ...storeKeyboard(hasUserbot) }, null, 'store');
}

async function renderOrderExpired(ctx, order) {
  if (!order) return;
  buyerState.clear(ctx.from.id);
  const content = storeTpl.orderExpired.getContent(ctx, {
    order,
    placeholderValues: {
      order_id: String(order.id),
      masa_berlaku: escapeMdV2(formatIndonesiaDate(order.expires_at)),
      status: 'EXPIRED',
    },
  });
  await renderScreen(ctx, content.text, {
    ...buildReplyOptions(content),
    ...storeCategoryBackKeyboard(),
  }, 'store');
}

async function renderPendingOrderRecovery(ctx, orders = null) {
  // The database/service is the source of truth. Never render a caller-supplied
  // recovery array without re-checking expiration and ownership; this also
  // makes stale callbacks harmless after an order crosses its deadline.
  //
  // IMPORTANT: this function owns ONLY the recovery render. It must not render
  // the Store screen when there is nothing to recover. The previous behavior
  // did exactly that, while storeHandler() also called renderStoreScreen()
  // after receiving `false`, so one Store action produced TWO Store renders.
  // Keeping the empty result side-effect free gives the caller a single,
  // explicit render decision and removes the hidden double-render path.
  const openOrders = orderService.listOpenOrders(ctx.from.id);
  if (!openOrders.length) return false;

  const orderList = openOrders.map((order) => {
    const product = escapeMdV2(order.product_name || 'Produk');
    const total = escapeMdV2(formatRupiah(order.total_price));
    const status = order.status === 'pending' ? 'MENUNGGU PEMBAYARAN' : 'MENUNGGU VERIFIKASI';
    return `🧾 *Order \#${escapeMdV2(order.id)}*\n📦 ${product}\n🔢 ${escapeMdV2(order.qty)} bulan\n💰 ${total}\n📌 Status: ${escapeMdV2(status)}`;
  }).join('\n\n');

  const cancellableCount = openOrders.filter((order) => order.status === 'pending').length;
  const content = storeTpl.pendingOrderExists.getContent(ctx, {
    placeholderValues: {
      order_id: String(openOrders[0].id),
      order_count: String(openOrders.length),
      order_list: orderList,
    },
    openOrders,
  });
  await renderScreen(ctx, content.text, {
    ...buildReplyOptions(content),
    ...storePendingOrderRecoveryKeyboard(openOrders),
  }, 'store');
  logger.info(`User ${ctx.from.id} has ${openOrders.length} open order(s); recovery screen rendered (cancellable=${cancellableCount}).`);
  return true;
}

async function renderPendingOrderRecoveryOrStore(ctx, orders = null) {
  if (await renderPendingOrderRecovery(ctx, orders)) return true;
  await renderStoreScreen(ctx);
  return false;
}

const storeHandler = safeHandler(async (ctx) => {
  await runStoreActionIdempotently(ctx, async () => {
    await renderPendingOrderRecoveryOrStore(ctx);
    logger.debug(`User ${ctx.from.id} opened Store`);
  });
});

// "Kembali" from the S&K screen (inline) also needs to go back to the
// Store front screen — same rendering as the reply-keyboard entry point.
// The callback source message itself is a stable idempotency boundary: after
// one Store-Home callback consumes that message, another callback from the
// same stale message must never create a second Store screen.
const storeHomeCallback = safeHandler(async (ctx) => {
  await runStoreActionIdempotently(ctx, async () => {
    await ctx.answerCbQuery();
    await renderStoreScreen(ctx);
  }, 'source-message');
});

// Shared by the "store:cat:<category>" callback AND the "🤖 Buat Ubot"
// reply-keyboard shortcut (which, per the original bot's flow, is just
// a direct entry point into the userbot subscription catalog).
async function renderCategoryProducts(ctx, category, { origin = 'store' } = {}) {
  origin = origin === 'main' ? 'main' : 'store';
  const isRenewal = category === CATEGORIES.RENEWAL;
  if (category !== CATEGORIES.USERBOT && category !== CATEGORIES.JASEB && !isRenewal) {
    const content = storeTpl.invalidCategory.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
    return;
  }

  // Renewal reuses the USERBOT catalog (same packages/prices) — the
  // buyer isn't buying a new userbot, just more months on the one
  // they already have. Re-check ownership here too: this screen can
  // be reached straight from an inline callback, not only the reply
  // button that already gated it.
  if (isRenewal) {
    const target = renewalTarget.resolve(ctx.from.id);
    if (target.status === 'none') {
      const content = storeTpl.renewalNone.getContent(ctx);
      await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
      return;
    }
    if (target.status === 'pick') {
      // Several userbots and no explicit choice yet: never guess.
      await renderRenewalPicker(ctx, target.rows);
      return;
    }
  }

  const catalogCategory = isRenewal ? CATEGORIES.USERBOT : category;
  if (catalogCategory === CATEGORIES.JASEB) {
    const availableStock = userbotService.getAvailableJasebStockCount();
    if (availableStock <= 0) {
      const content = storeTpl.jasebStockEmpty.getContent(ctx, {
        placeholderValues: { stok: '0' },
        stockCount: 0,
      });
      await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
      return;
    }
  }
  const products = productService.listActive(catalogCategory);
  const label = isRenewal ? MENU.PERPANJANG_LANGGANAN : category === CATEGORIES.USERBOT ? '🤖 Beli Userbot' : '🔥 Beli Jaseb';

  if (products.length === 0) {
    const content = storeTpl.productsEmpty.getContent(ctx, {
      placeholderValues: { kategori: label },
      categoryLabelDisplay: label,
    });
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
    return;
  }

  const renderedList = products.map((p) => {
    const cfg = premiumEmojiConfig.configForGaransi(p.garansi);
    const warranty = p.garansi ? ' • Bergaransi' : '';
    return `${emojiMdV2(cfg)} ${boldMdV2(p.name)} — ${escapeMdV2(formatRupiah(p.price))}/bln${warranty}`;
  }).join('\n');
  const listTemplate = isRenewal
    ? storeTpl.renewalProductsList
    : category === CATEGORIES.USERBOT
      ? storeTpl.userbotProductsList
      : storeTpl.jasebProductsList;
  const content = listTemplate.getContent(ctx, {
    placeholderValues: { kategori: label, product_list: renderedList },
    categoryLabelDisplay: escapeMdV2(label),
    productListRendered: renderedList,
  });
  await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeProductListKeyboard(category, products, isRenewal ? 'renewal' : undefined, origin) }, 'store');
}

// "Pilih Userbot yang ingin diperpanjang" — buyer owns several userbots.
async function renderRenewalPicker(ctx, rows) {
  const { Markup } = require('telegraf');
  const { button } = require('../utils/buttons');
  const { formatIndonesiaDate } = require('../utils/placeholders');
  const now = Date.now();
  const keyboard = Markup.inlineKeyboard(
    rows.map((r) => [
      button.primary(
        `${subscription.isActiveNow(r, now) ? '✅' : '⛔'} ${r.label || 'Userbot'} #${r.id} — ${formatIndonesiaDate(r.expires_at)}`,
        CALLBACK.SUBSCRIPTION_RENEW(r.id)
      ),
    ])
  );
  const userbotList = rows.map((r) => `${subscription.isActiveNow(r, now) ? '✅' : '⛔'} ${r.label || 'Userbot'} #${r.id} — ${formatIndonesiaDate(r.expires_at)}`).join('\n');
  const content = storeTpl.renewalPicker.getContent(ctx, { placeholderValues: { userbot_list: userbotList } });
  await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...keyboard }, 'store');
}

// Legacy category callback retained for backward compatibility and renewal.
const storeCategoryCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const parts = String(ctx.callbackQuery.data || '').split(':');
  const category = parts[2];
  const origin = parts[3] === 'main' ? 'main' : 'store';
  await renderCategoryProducts(ctx, category, { origin });
});

// Dedicated service callbacks make the two Store catalogs explicit at the
// routing layer instead of relying on a shared generic category action.
const storeUserbotCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  await renderCategoryProducts(ctx, CATEGORIES.USERBOT);
});

const storeJasebCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  await renderCategoryProducts(ctx, CATEGORIES.JASEB);
});

// Entry point for the Store's service buttons. Category context is immediately
// bound to the product catalog; the purchase policy is shown once later, just
// before payment, so the same policy is not requested twice.
const storeCategoryPolicyHandler = safeHandler(async (ctx) => {
  const text = ctx.message.text;
  const category = text === CATEGORY_LABEL.userbot ? CATEGORIES.USERBOT
    : text === CATEGORY_LABEL.jaseb ? CATEGORIES.JASEB
    : text === MENU.PERPANJANG_LANGGANAN ? CATEGORIES.RENEWAL
    : null;
  if (!category) return;
  const tracked = screenState.get(ctx.chat && ctx.chat.id);
  const origin = tracked && tracked.feature === 'main' ? 'main' : 'store';
  await renderCategoryProducts(ctx, category, { origin });
});

// Store front screen entry point — lists every active product (across
// both userbot & jaseb categories) filtered by garansi status.
async function renderGaransiProducts(ctx, garansi) {
  const products = productService.listActiveByGaransi(garansi);
  const cfg = premiumEmojiConfig.configForGaransi(garansi);
  const emoji = emojiMdV2(cfg);
  const label = garansi ? `${emoji} Spesial Bergaransi` : `${emoji} Spesial Non\\-Garansi`;

  if (products.length === 0) {
    const content = storeTpl.garansiProductsEmpty.getContent(ctx,{placeholderValues:{kategori:label}});
    await renderScreen(ctx,content.text,{...buildReplyOptions(content),...storeCategoryBackKeyboard()},'store');
    return;
  }

  const renderedList = products.map((p) => {
    const pCfg = premiumEmojiConfig.configForGaransi(p.garansi);
    return `${emojiMdV2(pCfg)} ${boldMdV2(p.name)} — ${escapeMdV2(formatRupiah(p.price))}/bln`;
  }).join('\n');
  const content = storeTpl.garansiProductsList.getContent(ctx,{placeholderValues:{kategori:label,product_list:renderedList}});
  await renderScreen(ctx,content.text,{...buildReplyOptions(content),...storeProductListKeyboard(garansi,products)},'store');
}

// store:garansi:<0|1>
const storeGaransiCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const garansi = ctx.callbackQuery.data.split(':')[2] === '1';
  await renderGaransiProducts(ctx, garansi);
});

function parseStorePurchaseCallback(data) {
  let parts = String(data || '').split(':');
  const action = parts[1] || '';
  const id = parts[2];
  const qty = parts[3];
  if (!['prod', 'qty', 'policy', 'pay'].includes(action)) return null;

  // Navigation context is an optional trailing segment. Strip only known
  // values so legacy category/mode positions remain exactly compatible.
  let origin = 'store';
  const tail = parts[parts.length - 1];
  if (tail === 'main' || tail === 'store') {
    origin = tail;
    parts = parts.slice(0, -1);
  }

  // `qty` callbacks carry the delta at index 4 and the category/mode after it;
  // all other purchase callbacks carry category/mode directly after qty.
  const categoryIndex = action === 'qty' ? 5 : 4;
  const modeIndex = categoryIndex + 1;
  let category = parts[categoryIndex] || null;
  let mode = parts[modeIndex] || null;

  // Backward compatibility for old callbacks whose optional segment was only
  // the renewal mode. Never infer a different product category from a label.
  if (category === 'renewal' && !mode) {
    mode = 'renewal';
    category = CATEGORIES.RENEWAL;
  }
  if (mode === 'renewal') category = CATEGORIES.RENEWAL;
  return { action, id, qty, category, mode, origin, parts };
}

function resolveStorePurchaseProduct(id, category, mode) {
  return productService.resolvePurchaseProduct(id, category, mode);
}

function orderSummaryText(product, qty, mode, ctx) {
  const cfg = premiumEmojiConfig.configForGaransi(product.garansi);
  const renderedDefault = `${emojiMdV2(cfg)} ${boldMdV2(mode === 'renewal' ? 'Konfirmasi Perpanjangan' : 'Konfirmasi Pesanan')}\n\n` +
    `📦 Paket: ${escapeMdV2(product.name)}\n` +
    `🔢 Jumlah: ${qty} bulan \\(${product.duration_days * qty} hari\\)\n` +
    `💰 Total: ${escapeMdV2(formatRupiah(product.price * qty))}\n\n` +
    (product.description ? `${escapeMdV2(product.description)}\n\n` : '') +
    `Jika sudah benar, tekan tombol ${boldMdV2('Lanjut Bayar')}\\.`;
  const content = storeTpl.orderSummary.getContent(ctx, {
    product,
    qty,
    mode,
    productEmoji: emojiMdV2(cfg), emojiConfig: cfg,
    placeholderValues: {
      produk: product.name || '-', harga: formatRupiah(product.price), jumlah: String(qty),
      total: formatRupiah(product.price * qty), durasi_hari: String(product.duration_days * qty),
      kategori: product.category || mode || '-',
    },
  });
  return { content, renderedDefault };
}

// store:prod:<id>:<qty>[:category][:mode]
const storeProductCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const parsed = parseStorePurchaseCallback(ctx.callbackQuery.data);
  if (!parsed) {
    const content = storeTpl.productMissing.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard() }, 'store');
    return;
  }
  const origin = parsed.origin === 'main' ? 'main' : 'store';
  const { product, category } = resolveStorePurchaseProduct(parsed.id, parsed.category, parsed.mode);
  const qty = validateQty(parsed.qty);
  if (qty === null) {
    const content = storeTpl.qtyInvalid.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
    return;
  }
  const mode = category === CATEGORIES.RENEWAL ? 'renewal' : undefined;
  const summary = orderSummaryText(product, qty, mode, ctx);
  await renderScreen(ctx, summary.content.text, {
    ...buildReplyOptions(summary.content),
    ...storeProductDetailKeyboard(product, qty, mode, origin),
  }, 'store');
});

// store:qty:<id>:<qty>:<delta>[:category][:mode]
const storeQtyCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const parts = String(ctx.callbackQuery.data).split(':');
  const parsed = parseStorePurchaseCallback(ctx.callbackQuery.data);
  const origin = parsed && parsed.origin === 'main' ? 'main' : 'store';
  const delta = parsed ? parseQtyStrict(parts[4]) : null;
  const category = parsed?.category || null;
  const mode = parsed?.mode || (category === CATEGORIES.RENEWAL ? 'renewal' : undefined);
  const baseQty = parsed ? validateQty(parsed.qty) : null;
  if (!parsed || baseQty === null || delta === null || ![-1, 0, 1].includes(delta)) {
    const content = storeTpl.qtyInvalid.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
    return;
  }
  const { product } = resolveStorePurchaseProduct(parsed.id, category, mode);
  const qty = Math.min(QTY_MAX, Math.max(QTY_MIN, baseQty + delta));
  const summary = orderSummaryText(product, qty, mode, ctx);
  await renderScreen(ctx, summary.content.text, {
    ...buildReplyOptions(summary.content),
    ...storeProductDetailKeyboard(product, qty, mode, origin),
  }, 'store');
});

const POLICY_TEXT =
  `📃 *Kebijakan & Ketentuan Kami*\n\n` +
  `• Membeli berarti Anda menyetujui segala risiko.\n` +
  `• Ketika terdeteksi melakukan hal ilegal seperti penipuan, akses akan dicabut (No Refund).\n` +
  `• Garansi hanya berlaku untuk userbot, tidak ada refund uang.\n\n` +
  `Jika Anda *Setuju*, tekan tombol di bawah untuk melanjutkan ke pembayaran.`;

const paymentPolicyTemplate = defineTemplate('store.payment_policy', 'Pembayaran', 'Kebijakan Pembayaran', POLICY_TEXT, { supportedPlaceholders: ['kategori'] });

// store:policy:<id>:<qty>[:category][:mode]
const storePolicyCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const parsed = parseStorePurchaseCallback(ctx.callbackQuery.data);
  if (!parsed) {
    const content = storeTpl.productMissing.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard() }, 'store');
    return;
  }
  const origin = parsed.origin === 'main' ? 'main' : 'store';
  const { product, category } = resolveStorePurchaseProduct(parsed.id, parsed.category, parsed.mode);
  const qty = validateQty(parsed.qty);
  if (qty === null) {
    const content = storeTpl.qtyInvalid.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
    return;
  }
  const mode = category === CATEGORIES.RENEWAL ? 'renewal' : undefined;
  const content = paymentPolicyTemplate.getContent(ctx, { placeholderValues: { kategori: category === CATEGORIES.JASEB ? 'Beli Jaseb' : 'Beli Userbot' } });
  await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storePolicyKeyboard(product, qty, mode, origin) }, 'store');
});

async function renderQrisPaymentScreen(ctx, order, paymentContent) {
  const qrisFileId = paymentService.getQrisFileId();
  if (!qrisFileId) {
    await renderScreen(ctx, paymentContent.text, {
      ...buildReplyOptions(paymentContent),
      ...storePaymentKeyboard(order.id),
    }, 'store');
    return;
  }

  const sourceMessage = ctx.callbackQuery && ctx.callbackQuery.message;
  if (sourceMessage && Array.isArray(sourceMessage.photo) && sourceMessage.photo.length) {
    await ctx.editMessageCaption(paymentContent.text, {
      ...buildCaptionOptions(paymentContent),
      ...storePaymentKeyboard(order.id),
    });
    return;
  }

  try {
    const sent = await ctx.replyWithPhoto(qrisFileId, {
      caption: paymentContent.text,
      ...buildCaptionOptions(paymentContent),
      ...storePaymentKeyboard(order.id),
    });
    if (ctx.chat) screenState.set(ctx.chat.id, sent.message_id, 'store');
  } catch (err) {
    if (!paymentService.isInvalidTelegramMediaReferenceError(err)) throw err;
    const desc = String((err && (err.description || err.message)) || err);
    logger.error(`QRIS media invalid untuk order #${order.id} user ${ctx.from.id}; konfigurasi qris_file_id dihapus agar recovery tidak mengulang request rusak. ${desc}`);
    paymentService.clearQrisFileId();
    await renderScreen(ctx, paymentContent.text, {
      ...buildReplyOptions(paymentContent),
      ...storePaymentKeyboard(order.id),
    }, 'store');
  }
}

// store:pay:<id>:<qty>[:category][:mode] — creates the order and shows QRIS/payment info.
const storePayCallback = safeHandler(async (ctx) => {
  await ctx.answerCbQuery();
  const parsed = parseStorePurchaseCallback(ctx.callbackQuery.data);
  if (!parsed) {
    const content = storeTpl.productMissing.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard() }, 'store');
    return;
  }
  const origin = parsed.origin === 'main' ? 'main' : 'store';
  const { product, category } = resolveStorePurchaseProduct(parsed.id, parsed.category, parsed.mode);
  const qty = validateQty(parsed.qty);
  if (qty === null) {
    const content = storeTpl.qtyInvalid.getContent(ctx);
    await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard(origin === 'main' ? CALLBACK.NAV_HOME : CALLBACK.STORE_HOME) }, 'store');
    return;
  }
  const mode = category === CATEGORIES.RENEWAL ? 'renewal' : undefined;
  let renewalAsset = null;
  if (category === CATEGORIES.RENEWAL) {
    const target = renewalTarget.resolve(ctx.from.id);
    if (target.status === 'none') {
      const content = storeTpl.renewalNone.getContent(ctx);
      await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard() }, 'store');
      return;
    }
    if (target.status === 'pick') {
      await renderRenewalPicker(ctx, target.rows);
      return;
    }
    renewalAsset = target.asset;
  }
  let order;
  try {
    order = orderService.createOrder({
      userId: ctx.from.id,
      product,
      qty,
      category,
      mode,
      targetUserbotId: renewalAsset ? renewalAsset.id : null,
    });
  } catch (err) {
    if (err instanceof InvalidQuantityError) {
      const content = storeTpl.qtyInvalid.getContent(ctx);
      await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard() }, 'store');
      return;
    }
    if (err instanceof orderService.PendingOrderExistsError) {
      buyerState.clear(ctx.from.id);
      await renderPendingOrderRecoveryOrStore(ctx, err.orders || (err.order ? [err.order] : []));
      return;
    }
    if (err instanceof orderService.JasebOutOfStockError || err.code === 'JASEB_OUT_OF_STOCK') {
      buyerState.clear(ctx.from.id);
      const content = storeTpl.jasebStockEmpty.getContent(ctx);
      await renderScreen(ctx, content.text, { ...buildReplyOptions(content), ...storeCategoryBackKeyboard() }, 'store');
      return;
    }
    throw err;
  }

  const qrisNote = paymentService.getQrisNote();
  const bankInfo = paymentService.getBankInfo();
  const paymentContent = storeTpl.paymentInstruction.getContent(ctx, {
    order,
    renewalAsset,
    placeholderValues: {
      order_id: String(order.id), total: formatRupiah(order.total_price),
      qris_note: qrisNote || '-', bank_info: bankInfo || '-',
      produk: order.product_name || product.name || '-', jumlah: String(qty), durasi_hari: String(order.duration_days),
    },
  });
  await renderQrisPaymentScreen(ctx, order, paymentContent);
  logger.info(`Order #${order.id} created by user ${ctx.from.id} (${order.category}, qty ${qty}, unit=${order.unit_price})`);
});

// store:paid:<orderId>
const storePaidCallback = safeHandler(async (ctx) => {
  const orderId = Number(ctx.callbackQuery.data.split(':')[2]);
  if (!Number.isInteger(orderId) || orderId <= 0) {
    {const c=storeTpl.cbOrderInvalid.getContent(ctx);await ctx.answerCbQuery(c.text,{show_alert:true});}
    return;
  }
  const existing = orderService.refreshOrder(orderId);
  if (!existing || Number(existing.user_id) !== Number(ctx.from.id)) {
    {const c=storeTpl.cbOrderInvalid.getContent(ctx);await ctx.answerCbQuery(c.text,{show_alert:true});}
    return;
  }
  if (existing.status === 'expired') {
    await ctx.answerCbQuery();
    await renderOrderExpired(ctx, existing);
    return;
  }
  if (existing.status !== 'pending') {
    {const c=storeTpl.cbOrderProcessed.getContent(ctx);await ctx.answerCbQuery(c.text,{show_alert:true});}
    return;
  }
  const requested = orderService.requestPaymentProof({ orderId, userId: ctx.from.id });
  if (!requested.ok) {
    if (requested.reason === 'expired') {
      await ctx.answerCbQuery();
      await renderOrderExpired(ctx, requested.order);
      return;
    }
    {const c=storeTpl.cbProofRequestFailed.getContent(ctx);await ctx.answerCbQuery(c.text,{show_alert:true});}
    return;
  }
  buyerState.set(ctx.from.id, { step: 'await_payment_proof', orderId: requested.order.id });
  await ctx.answerCbQuery();
  const promptContent = storeTpl.proofPrompt.getContent(ctx, { placeholderValues: { order_id: String(requested.order.id) } });
  const prompt = promptContent.text;
  const stepCaption = storeTpl.proofStepCaption.getContent(ctx, {
    placeholderValues: { order_id: String(requested.order.id) },
  });
  // A payment step can originate from either the QRIS photo or a text screen.
  // Only call editMessageCaption when the callback actually belongs to a photo
  // message. Known Telegram editability failures are logged and the proof
  // prompt is still sent; malformed entity/API errors are propagated.
  const sourceMessage = ctx.callbackQuery && ctx.callbackQuery.message;
  if (sourceMessage && Array.isArray(sourceMessage.photo) && sourceMessage.photo.length) {
    try {
      await ctx.editMessageCaption(stepCaption.text, buildCaptionOptions(stepCaption));
    } catch (err) {
      const desc = String((err && err.description) || (err && err.message) || '');
      if (!/message (?:can't|cannot) be edited|message to edit not found|message is too old|MESSAGE_ID_INVALID|message is not modified/i.test(desc)) {
        throw err;
      }
      logger.warn(`Order #${requested.order.id}: payment caption tidak dapat diedit, prompt bukti tetap dikirim. ${desc}`);
    }
  }
  await ctx.reply(prompt, {
    ...buildReplyOptions(promptContent),
    ...Markup.keyboard([
      [replyButton.danger('❌ Batal')],
    ]).resize(),
  });
  logger.info(`Order #${requested.order.id} awaiting payment proof from user ${ctx.from.id}`);
});

function resolvePaymentProofOrder(ctx) {
  if (ctx.chat && ctx.chat.type && ctx.chat.type !== 'private') return null;
  const state = buyerState.get(ctx.from.id);
  if (state && state.step === 'await_payment_proof' && Number.isInteger(Number(state.orderId))) {
    return orderService.refreshOrder(Number(state.orderId));
  }
  const candidate = orderRepo.findPendingPaymentProofByUser(ctx.from.id);
  return candidate ? orderService.refreshOrder(candidate.id) : null;
}

async function handlePaymentProofMessage(ctx, proofType, fileId, caption, entities) {
  const candidate = resolvePaymentProofOrder(ctx);
  if (!candidate) return false;
  if (Number(candidate.user_id) !== Number(ctx.from.id) || candidate.status !== 'pending' || !candidate.payment_proof_requested_at || candidate.payment_proof_file_id) {
    buyerState.clear(ctx.from.id);
    const content = storeTpl.proofUnavailable.getContent(ctx);
    await ctx.reply(content.text, buildReplyOptions(content));
    return true;
  }
  const submitted = orderService.submitPaymentProof({
    orderId: candidate.id,
    userId: ctx.from.id,
    proofType,
    fileId,
    caption,
    entities,
    durationMinutes: notificationService.getTransactionDurationMinutes(),
  });
  if (!submitted.ok) {
    if (submitted.reason === 'expired') {
      await renderOrderExpired(ctx, submitted.order);
      return true;
    }
    const content = storeTpl.proofFailed.getContent(ctx);
    await ctx.reply(content.text, buildReplyOptions(content));
    return true;
  }
  buyerState.clear(ctx.from.id);
  let channelResult = { ok: false, reason: 'disabled' };
  try {
    channelResult = await notificationService.ensureTransactionNotification(ctx.telegram, submitted.order);
  } catch (err) {
    logger.warn(`Transaction notification #${submitted.order.id} error: ${(err && err.message) || err}`);
  }
  // When a transaction channel is configured it is the canonical operator
  // notification target. Do not also DM admins: that creates duplicate
  // verification surfaces for the same order. The existing admin-DM flow is
  // retained only as the explicit fallback when no transaction channel exists.
  const transactionChannelConfigured = Boolean(notificationService.getChannel('transaction'));
  if (!transactionChannelConfigured) {
    await orderService.notifyAdminsOfNewOrder(ctx.telegram, submitted.order, ctx.from);
  }
  const statusText = channelResult.ok
    ? 'Bukti sudah tersimpan dan sedang menunggu verifikasi admin.'
    : 'Bukti sudah tersimpan. Order tetap dapat diverifikasi dari alur admin yang tersedia.';
  const content = storeTpl.proofReceived.getContent(ctx, { placeholderValues: { order_id: String(submitted.order.id), hasil: statusText } });
  await ctx.reply(content.text, buildReplyOptions(content));
  logger.info(`Payment proof stored for order #${submitted.order.id} by user ${ctx.from.id}`);
  return true;
}

async function handlePaymentProofPhoto(ctx) {
  const photos = ctx.message && ctx.message.photo;
  if (!Array.isArray(photos) || !photos.length) return false;
  const media = photos[photos.length - 1];
  return handlePaymentProofMessage(ctx, 'photo', media.file_id, ctx.message.caption, ctx.message.caption_entities || []);
}

async function handlePaymentProofDocument(ctx) {
  const doc = ctx.message && ctx.message.document;
  if (!doc) return false;
  return handlePaymentProofMessage(ctx, 'document', doc.file_id, ctx.message.caption, ctx.message.caption_entities || []);
}

async function handlePaymentProofVideo(ctx) {
  const video = ctx.message && ctx.message.video;
  if (!video) return false;
  return handlePaymentProofMessage(ctx, 'video', video.file_id, ctx.message.caption, ctx.message.caption_entities || []);
}

// store:resume:<orderId> resumes a buyer-cancellable payment screen from an
// old/stale recovery keyboard. It re-checks owner + status on the server; a
// forged/old callback can never resume another user's order or a final state.
const storeResumeCallback = safeHandler(async (ctx) => {
  const orderId = Number(ctx.callbackQuery.data.split(':')[2]);
  if (!Number.isInteger(orderId) || orderId <= 0) {
    const c = storeTpl.cbOrderInvalid.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return;
  }
  const order = orderService.refreshOrder(orderId);
  if (!order || Number(order.user_id) !== Number(ctx.from.id)) {
    const c = storeTpl.cbCancelNotOwner.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return;
  }
  if (order.status === 'expired') {
    await ctx.answerCbQuery();
    await renderOrderExpired(ctx, order);
    return;
  }
  if (order.status !== 'pending') {
    const message = order.status === 'awaiting_confirmation'
      ? '⏳ Order ini sudah menerima bukti pembayaran dan sedang menunggu verifikasi admin.'
      : 'ℹ️ Order ini sudah tidak dapat dilanjutkan.';
    await ctx.answerCbQuery(message, { show_alert: true });
    await renderPendingOrderRecoveryOrStore(ctx);
    return;
  }
  await ctx.answerCbQuery();
  await renderPaymentScreen(ctx, order);
});

// store:status:<orderId> is informational only. It deliberately never mutates
// state, and is useful for an old recovery keyboard whose order has already
// reached admin verification.
const storeOrderStatusCallback = safeHandler(async (ctx) => {
  const orderId = Number(ctx.callbackQuery.data.split(':')[2]);
  const order = Number.isInteger(orderId) ? orderService.refreshOrder(orderId) : null;
  if (!order) {
    const c = storeTpl.cbOrderInvalid.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return;
  }
  if (Number(order.user_id) !== Number(ctx.from.id)) {
    const c = storeTpl.cbCancelNotOwner.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return;
  }
  const statusTemplate = order.status === 'expired'
    ? storeTpl.cbStatusExpired
    : order.status === 'awaiting_confirmation' ? storeTpl.cbStatusAwaiting : storeTpl.cbStatusGeneric;
  const statusContent = statusTemplate.getContent(ctx, { placeholderValues: { status: String(order.status || '-') } });
  await ctx.answerCbQuery(statusContent.text, { show_alert: true });
  await renderPendingOrderRecoveryOrStore(ctx);
});

// store:cancel:<orderId> opens a confirmation. The actual destructive mutation is
// done only by store:cancel_yes:<orderId>, which re-checks ownership + status.
async function showPaymentCancelConfirmation(ctx, orderId) {
  const id = Number(orderId);
  if (!Number.isInteger(id) || id <= 0) {
    const c = storeTpl.cbCancelInvalid.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return false;
  }
  const order = orderService.refreshOrder(id);
  if (!order) {
    buyerState.clear(ctx.from.id);
    const c = storeTpl.cbCancelNotFound.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return false;
  }
  if (Number(order.user_id) !== Number(ctx.from.id)) {
    const c = storeTpl.cbCancelNotOwner.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return false;
  }
  if (order.status === 'expired') {
    buyerState.clear(ctx.from.id);
    await ctx.answerCbQuery();
    await renderOrderExpired(ctx, order);
    return false;
  }
  if (order.status !== 'pending') {
    buyerState.clear(ctx.from.id);
    const c = storeTpl.cbCancelProcessed.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    await renderPendingOrderRecoveryOrStore(ctx);
    return false;
  }
  buyerState.set(ctx.from.id, { step: 'await_payment_cancel_confirm', orderId: order.id, flow: 'store', category: order.category });
  const content = storeTpl.cancelConfirmation.getContent(ctx, { placeholderValues: { order_id: String(order.id) } });
  if (ctx.callbackQuery) await ctx.answerCbQuery();
  await renderScreen(ctx, content.text, {
    ...buildReplyOptions(content),
    ...storeCancelConfirmationKeyboard(order.id),
  }, 'store');
  return true;
}

const storeCancelCallback = safeHandler(async (ctx) => {
  await showPaymentCancelConfirmation(ctx, ctx.callbackQuery.data.split(':')[2]);
});

// store:cancel_yes:<orderId> is the only buyer-facing mutation path. The
// service performs the ownership + status compare-and-swap again, so stale
// callbacks and double-clicks cannot resurrect/cancel another state.
const storeCancelYesCallback = safeHandler(async (ctx) => {
  const orderId = Number(ctx.callbackQuery.data.split(':')[2]);
  if (!Number.isInteger(orderId) || orderId <= 0) {
    const c = storeTpl.cbCancelInvalid.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    return;
  }

  const result = orderService.cancelOwnOrder({ orderId, userId: ctx.from.id });
  if (!result.ok) {
    buyerState.clear(ctx.from.id);
    if (result.reason === 'expired') {
      await ctx.answerCbQuery();
      await renderOrderExpired(ctx, result.order);
      return;
    }
    const content = result.reason === 'not_found' ? storeTpl.cbCancelNotFound
      : result.reason === 'not_owner' ? storeTpl.cbCancelNotOwner
      : storeTpl.cbCancelProcessed;
    const c = content.getContent(ctx);
    await ctx.answerCbQuery(c.text, { show_alert: true });
    // A stale/double callback may have raced with payment-proof submission or
    // another cancellation. Rebuild from the database so the buyer cannot be
    // stranded in the confirmation state after the failed transition.
    await renderPendingOrderRecoveryOrStore(ctx);
    return;
  }

  buyerState.clear(ctx.from.id);
  await answerCancelled(ctx);

  // The checkout message is a transactional screen. After a successful
  // cancellation, remove that obsolete screen before rendering the Store
  // reply-keyboard. This avoids leaving two competing checkout/store messages
  // visible. If Telegram cannot delete the old message, it is replaced with a
  // terminal cancellation notice as a safe fallback.
  const sourceMessage = ctx.callbackQuery && ctx.callbackQuery.message;
  let removed = false;
  if (sourceMessage && sourceMessage.message_id && ctx.chat && ctx.chat.id) {
    try {
      await ctx.telegram.deleteMessage(ctx.chat.id, sourceMessage.message_id);
      removed = true;
    } catch (err) {
      const desc = String((err && err.description) || (err && err.message) || '');
      if (!/message to delete not found|message can't be deleted|message cannot be deleted|MESSAGE_ID_INVALID|message is too old/i.test(desc)) {
        throw err;
      }
      logger.warn(`Order #${orderId} dibatalkan tetapi pesan checkout tidak dapat dihapus; mencoba menutup pesan lama. ${desc}`);
    }
  }

  if (!removed && sourceMessage) {
    try {
      if (Array.isArray(sourceMessage.photo) && sourceMessage.photo.length) {
        await ctx.editMessageCaption(getCancelledText(ctx));
      } else if (typeof sourceMessage.text === 'string') {
        await ctx.editMessageText(getCancelledText(ctx));
      }
    } catch (err) {
      const desc = String((err && err.description) || (err && err.message) || '');
      if (!/message (?:can't|cannot) be edited|message to edit not found|message is too old|MESSAGE_ID_INVALID|message is not modified|there is no text in the message to edit|there is no caption in the message to edit/i.test(desc)) {
        throw err;
      }
      logger.warn(`Order #${orderId} cancellation screen fallback: ${desc}`);
    }
  }

  // Re-attach the real Store reply keyboard after cancellation so the buyer
  // can start a new order immediately. The obsolete transactional screen has
  // already been deleted/replaced, so only one current Store screen remains.
  await renderStoreScreen(ctx);
  logger.info(`Order #${orderId} cancelled by user ${ctx.from.id}`);
});

const storeCancelAllCallback = safeHandler(async (ctx) => {
  const openOrders = orderService.listOpenOrders(ctx.from.id);
  const cancellable = openOrders.filter((order) => order.status === 'pending');
  if (cancellable.length < 2) {
    const messageContent = cancellable.length === 1
      ? storeTpl.cbCancelAllSingle.getContent(ctx)
      : storeTpl.cbCancelAllNone.getContent(ctx);
    await ctx.answerCbQuery(messageContent.text, { show_alert: true });
    await renderPendingOrderRecoveryOrStore(ctx, openOrders);
    return;
  }
  buyerState.set(ctx.from.id, { step: 'await_payment_cancel_all_confirm', flow: 'store' });
  const content = storeTpl.cancelAllConfirmation.getContent(ctx, { placeholderValues: { cancellable_count: String(cancellable.length) } });
  await ctx.answerCbQuery();
  await renderScreen(ctx, content.text, {
    ...buildReplyOptions(content),
    ...storeCancelAllConfirmationKeyboard(),
  }, 'store');
});

const storeCancelAllYesCallback = safeHandler(async (ctx) => {
  const result = orderService.cancelAllOwnPendingOrders({ userId: ctx.from.id });
  buyerState.clear(ctx.from.id);
  if (!result.cancelledCount) {
    const content = storeTpl.cbCancelAllNone.getContent(ctx);
    await ctx.answerCbQuery(content.text, { show_alert: true });
    await renderPendingOrderRecoveryOrStore(ctx, result.orders);
    return;
  }
  await ctx.answerCbQuery(getCancelledText(ctx));
  await renderPendingOrderRecoveryOrStore(ctx, result.orders);
  logger.info(`User ${ctx.from.id} cancelled ${result.cancelledCount} pending order(s) in bulk.`);
});

const storeCancelAllNoCallback = safeHandler(async (ctx) => {
  buyerState.clear(ctx.from.id);
  await ctx.answerCbQuery();
  await renderPendingOrderRecoveryOrStore(ctx);
});

const storeCancelNoCallback = safeHandler(async (ctx) => {
  const orderId = Number(ctx.callbackQuery.data.split(':')[2]);
  const order = Number.isInteger(orderId) ? orderService.refreshOrder(orderId) : null;
  if (!order || Number(order.user_id) !== Number(ctx.from.id)) {
    const c=storeTpl.cbCancelProcessed.getContent(ctx); await ctx.answerCbQuery(c.text,{show_alert:true}); return;
  }
  if (order.status === 'expired') {
    await ctx.answerCbQuery();
    await renderOrderExpired(ctx, order);
    return;
  }
  if (order.status !== 'pending') {
    const c=storeTpl.cbCancelProcessed.getContent(ctx); await ctx.answerCbQuery(c.text,{show_alert:true}); return;
  }
  await ctx.answerCbQuery();
  buyerState.clear(ctx.from.id);
  await renderPaymentScreen(ctx, order);
});

async function renderPaymentScreen(ctx, order) {
  const fresh = order ? orderService.refreshOrder(order.id) : null;
  if (!fresh || Number(fresh.user_id) !== Number(ctx.from.id)) {
    throw new Error('Order pembayaran tidak lagi berada pada status yang dapat dilanjutkan oleh pengguna ini.');
  }
  if (fresh.status === 'expired') {
    await renderOrderExpired(ctx, fresh);
    return;
  }
  if (fresh.status !== 'pending') {
    throw new Error('Order pembayaran tidak lagi berada pada status pending yang dapat dilanjutkan.');
  }
  order = fresh;
  buyerState.set(ctx.from.id, { step: 'await_payment', orderId: order.id, flow: 'store', category: order.category });
  const renewalAsset = order.target_userbot_id ? renewalTarget.resolve(ctx.from.id).asset : null;
  const paymentContent = storeTpl.paymentInstruction.getContent(ctx, {
    order,
    renewalAsset,
    placeholderValues: {
      order_id: String(order.id), total: formatRupiah(order.total_price),
      qris_note: paymentService.getQrisNote() || '-', bank_info: paymentService.getBankInfo() || '-',
      produk: order.product_name || '-', jumlah: String(order.qty), durasi_hari: String(order.duration_days),
    },
  });
  await renderQrisPaymentScreen(ctx, order, paymentContent);
}

async function showPaymentProofCancelConfirmation(ctx) {
  const state = buyerState.get(ctx.from.id);
  const order = state && Number.isInteger(Number(state.orderId)) ? orderService.refreshOrder(Number(state.orderId)) : null;
  if (!order || Number(order.user_id) !== Number(ctx.from.id) || order.status !== 'pending') {
    buyerState.clear(ctx.from.id);
    const content = storeTpl.proofUnavailable.getContent(ctx);
    await ctx.reply(content.text, buildReplyOptions(content));
    return true;
  }
  buyerState.set(ctx.from.id, { step: 'await_payment_proof_cancel_confirm', orderId: order.id });
  const confirmation = storeTpl.cancelConfirmation.getContent(ctx);
  await renderScreen(ctx, confirmation.text, {
    ...buildReplyOptions(confirmation),
    ...storeCancelConfirmationKeyboard(order.id),
  }, 'store');
  return true;
}

module.exports = {
  storeHandler,
  storeHomeCallback,
  storeCategoryCallback,
  storeUserbotCallback,
  storeJasebCallback,
  storeCategoryPolicyHandler,
  renderCategoryProducts,
  storeGaransiCallback,
  renderGaransiProducts,
  storeProductCallback,
  storeQtyCallback,
  storePolicyCallback,
  storePayCallback,
  storePaidCallback,
  storeResumeCallback,
  storeOrderStatusCallback,
  storeCancelAllCallback,
  storeCancelAllYesCallback,
  storeCancelAllNoCallback,
  handlePaymentProofPhoto,
  handlePaymentProofDocument,
  handlePaymentProofVideo,
  storeCancelCallback,
  showPaymentCancelConfirmation,
  storeCancelYesCallback,
  storeCancelNoCallback,
  showPaymentProofCancelConfirmation,
  renderPaymentScreen,
};
