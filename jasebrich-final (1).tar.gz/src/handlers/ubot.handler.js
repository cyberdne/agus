const { safeHandler } = require('../utils/errors');
const { renderWithReplyKeyboard } = require('../utils/render');
const { subscriptionRequiredKeyboard } = require('../keyboards/main.keyboard');
const userbotService = require('../services/userbot.service');
const ubotFlow = require('./ubotFlow.handler');
const { defineSubmenu, buildReplyOptions } = require('../services/custom-submenu.service');
const logger = require('../utils/logger');

const SUBSCRIPTION_REQUIRED_TEXT =
  `🔔 *Diperlukan Langganan*\n\n` +
  `🤝 Anda harus berlangganan untuk dapat membuat userbot.\n\n` +
  `📝 Pilih salah satu tombol di bawah ini untuk melanjutkan proses pembelian.`;

// Registers this screen under Admin Panel -> Settings -> Custom Submenu.
// This is the actual content of the "🤖 Buat Ubot" entry point whenever
// there's no pending login step — previously it was hardcoded and could
// never be customized, unlike every other top-level menu screen.
const submenu = defineSubmenu('create_ubot', '🤖 Buat Ubot', SUBSCRIPTION_REQUIRED_TEXT, 'Markdown', { feature: 'Userbot', supportedPlaceholders: [] });

/**
 * "🤖 Buat Ubot" reply-keyboard shortcut. This menu has exactly one
 * job: add a new userbot. It never lists or lets the user pick among
 * userbots they already own — that's what "🎛️ Kontrol Panel" is for.
 *
 * A purchased-but-not-yet-added userbot (order confirmed, phone/OTP
 * login never finished — e.g. the buyer typed /cancel or just backed
 * out of that flow) is a pending step, not a finished one: reopening
 * this menu always resumes it first, regardless of whether the buyer
 * already owns other active userbots. Only when there's no pending
 * step does it fall through to the "Diperlukan Langganan" prompt,
 * which points the buyer at the Store's category buttons.
 */
const ubotHandler = safeHandler(async (ctx) => {
  const assets = userbotService.getUserAssets(ctx.from.id);
  const pendingOwned = assets.owned.find((o) => o.status === 'pending_otp');

  if (pendingOwned) {
    const isTrial = pendingOwned.label === '🎁 Trial Userbot' && !pendingOwned.order_id;
    await ubotFlow.beginPhoneStep(ctx.telegram, ctx.from.id, pendingOwned.id, isTrial ? 'trial' : 'purchase', { returnTo: 'main' });
    logger.debug(
      `User ${ctx.from.id} opened Buat Ubot -> resumed ${isTrial ? 'trial' : 'purchase'} phone/OTP step for #${pendingOwned.id}`
    );
    return;
  }

  // Subscription is fine but the Telegram session died: guide to re-auth
  // (same phone -> OTP flow; subscription/config/token are untouched).
  const subscription = require('../services/subscription.service');
  const invalid = assets.owned.find(
    (o) => o.status === 'active' && o.runtime_stop_reason === 'SESSION_INVALID' && subscription.isActiveNow(o)
  );
  if (invalid) {
    await ubotFlow.beginPhoneStep(ctx.telegram, ctx.from.id, invalid.id, 'reauth');
    logger.debug(`User ${ctx.from.id} opened Buat Ubot -> re-auth for userbot #${invalid.id}`);
    return;
  }

  const content = submenu.getContent(ctx);
  await renderWithReplyKeyboard(ctx, content.text, {
    ...buildReplyOptions(content),
    ...subscriptionRequiredKeyboard(),
  }, null, 'main');
  logger.debug(`User ${ctx.from.id} opened Buat Ubot -> no pending session, showed Diperlukan Langganan`);
});

module.exports = { ubotHandler };
