const { safeHandler } = require('../utils/errors');
const { defineTemplate, buildReplyOptions } = require('../services/custom-submenu.service');
const statisticsService = require('../services/statistics.service');
const logger = require('../utils/logger');
const { checkHealth } = require('../database');

const pingTemplate = defineTemplate(
  'system.ping',
  'Sistem',
  '🏓 /ping',
  ({}, extra) => {
    const d = extra.ping;
    const esc = (v) => String(v == null ? '-' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return [
      '<b>🏓 PONG</b>',
      '',
      `Bot API send: <b>${d.botPingMs == null ? '-' : `${d.botPingMs} ms`}</b>`,
      `Database: <b>${d.dbPingMs == null ? 'unavailable' : `${d.dbPingMs} ms`}</b>`,
      `Uptime: <b>${esc(d.uptime)}</b>`,
      `Memory RSS: <b>${d.memoryRssMb == null ? '-' : `${d.memoryRssMb} MB`}</b>`,
      `Heap: <b>${d.heapUsedMb == null ? '-' : `${d.heapUsedMb} / ${d.heapTotalMb} MB`}</b>`,
      `CPU load: <b>${d.cpuLoadPercent == null ? '-' : `${d.cpuLoadPercent}%`}</b>`,
    ].join('\n');
  },
  {
    parseMode: 'HTML',
    supportedPlaceholders: ['bot_ping', 'db_ping', 'uptime', 'memory', 'cpu'],
    maxLength: 4096,
  }
);

function getPingRenderContext() {
  let dbPingMs = null;
  try {
    dbPingMs = checkHealth();
  } catch (err) {
    logger.warn('Ping custom-submenu database health check failed:', err);
  }
  const system = statisticsService.getSystemSnapshot();
  return {
    botPingMs: null,
    dbPingMs: dbPingMs == null ? null : Number(dbPingMs.toFixed(2)),
    uptime: system.uptime,
    memoryRssMb: system.processMemoryMb,
    heapUsedMb: system.heapUsedMb,
    heapTotalMb: system.heapTotalMb,
    cpuLoadPercent: system.cpuLoadPercent,
  };
}

const pingHandler = safeHandler(async (ctx) => {
  const initialData = getPingRenderContext();

  const beforeSend = process.hrtime.bigint();
  const initial = pingTemplate.getContent(ctx, { ping: initialData, placeholderValues: {
    bot_ping: '-', db_ping: initialData.dbPingMs == null ? 'unavailable' : `${initialData.dbPingMs} ms`,
    uptime: initialData.uptime, memory: initialData.memoryRssMb, cpu: initialData.cpuLoadPercent,
  } });
  const sent = await ctx.reply(initial.text, buildReplyOptions(initial));
  const botPingMs = Number(process.hrtime.bigint() - beforeSend) / 1e6;
  const finalData = { ...initialData, botPingMs: Number(botPingMs.toFixed(2)) };
  const final = pingTemplate.getContent(ctx, { ping: finalData, placeholderValues: {
    bot_ping: finalData.botPingMs, db_ping: finalData.dbPingMs == null ? 'unavailable' : finalData.dbPingMs,
    uptime: finalData.uptime, memory: finalData.memoryRssMb, cpu: finalData.cpuLoadPercent,
  } });

  if (sent && ctx.telegram && ctx.chat) {
    try {
      await ctx.telegram.editMessageText(ctx.chat.id, sent.message_id, undefined, final.text, buildReplyOptions(final));
    } catch (err) {
      // The first message already contains real DB/system metrics. A failed
      // second edit must not produce a duplicate response.
      logger.debug('Ping final edit skipped:', err);
    }
  }
});

module.exports = pingHandler;
module.exports.getPingRenderContext = getPingRenderContext;
