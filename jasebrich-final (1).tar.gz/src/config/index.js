require('dotenv').config();

function parseAdminIds(raw) {
  if (!raw) return [];
  return raw
    .split(',')
    .map((id) => id.trim())
    .filter(Boolean)
    .map((id) => Number(id))
    .filter((id) => Number.isInteger(id));
}

const config = {
  botToken: process.env.BOT_TOKEN || '',
  dbPath: process.env.DB_PATH || 'data/jaseb.sqlite',
  adminIds: parseAdminIds(process.env.ADMIN_IDS),
  // From https://my.telegram.org — required only for the "Beli
  // Userbot" phone/OTP login flow (src/services/gramjs.service.js).
  telegramApiId: process.env.TELEGRAM_API_ID ? Number(process.env.TELEGRAM_API_ID) : null,
  telegramApiHash: process.env.TELEGRAM_API_HASH || '',
  telegramDeviceModel: process.env.TELEGRAM_DEVICE_MODEL || 'JASEBRICH',
  // Telegram user id of an admin/group to notify for order/payment
  // confirmations. Falls back to all ADMIN_IDS if unset.
  paymentNotifyIds: parseAdminIds(process.env.PAYMENT_NOTIFY_IDS),
};

function validateConfig() {
  const errors = [];

  if (!config.botToken || config.botToken === 'YOUR_BOT_TOKEN') {
    errors.push('BOT_TOKEN belum diisi. Salin .env.example menjadi .env lalu isi BOT_TOKEN.');
  }

  if (config.adminIds.length === 0) {
    errors.push('ADMIN_IDS belum dikonfigurasi. Minimal satu Telegram user ID admin wajib diisi untuk deployment production.');
  }

  const hasApiId = config.telegramApiId !== null && config.telegramApiId !== undefined && config.telegramApiId !== '';
  const hasApiHash = Boolean(config.telegramApiHash);
  if (hasApiId !== hasApiHash) {
    errors.push('TELEGRAM_API_ID dan TELEGRAM_API_HASH harus diisi bersama-sama untuk userbot GramJS.');
  } else if (hasApiId && (!Number.isInteger(config.telegramApiId) || config.telegramApiId <= 0)) {
    errors.push('TELEGRAM_API_ID harus berupa bilangan bulat positif yang valid.');
  }

  return errors;
}

module.exports = { config, validateConfig };
