const repo = require('../database/repositories/settings.repository');

const KEYS = {
  TRIAL_DURATION_HOURS: 'trial_duration_hours',
  LEGACY_TRIAL_DURATION_DAYS: 'trial_duration_days',
};

// Reference flow: free trial is 1 hour by default.
const DEFAULT_TRIAL_DURATION_HOURS = 1;

function getTrialDurationHours() {
  const rawHours = repo.get(KEYS.TRIAL_DURATION_HOURS);
  if (rawHours !== undefined && rawHours !== null && rawHours !== '') {
    const parsed = Number(rawHours);
    if (Number.isFinite(parsed) && parsed >= 1) return Math.round(parsed);
  }

  // Backward compatibility with the previous days-based setting.
  const rawDays = repo.get(KEYS.LEGACY_TRIAL_DURATION_DAYS);
  const days = Number(rawDays);
  if (Number.isFinite(days) && days >= 1) return Math.round(days * 24);

  return DEFAULT_TRIAL_DURATION_HOURS;
}

function setTrialDurationHours(hours) {
  const parsed = Number(hours);
  if (!Number.isFinite(parsed) || parsed < 1) {
    throw new Error('Durasi trial minimal 1 jam.');
  }
  repo.set(KEYS.TRIAL_DURATION_HOURS, String(Math.round(parsed)));
}

// Kept as compatibility exports for older code/plugins.
function getTrialDurationDays() {
  return Math.max(1, Math.ceil(getTrialDurationHours() / 24));
}

function setTrialDurationDays(days) {
  const parsed = Number(days);
  if (!Number.isFinite(parsed) || parsed < 1) {
    throw new Error('Durasi trial minimal 1 hari.');
  }
  setTrialDurationHours(Math.round(parsed) * 24);
}

module.exports = {
  getTrialDurationHours,
  setTrialDurationHours,
  getTrialDurationDays,
  setTrialDurationDays,
  DEFAULT_TRIAL_DURATION_HOURS,
};
