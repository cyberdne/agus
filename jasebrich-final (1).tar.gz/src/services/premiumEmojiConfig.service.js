const repo = require('../database/repositories/settings.repository');
const { validateSingleEmoji } = require('../utils/emojiValidation');

const KEYS = {
  GARANSI_EMOJI: 'premium_emoji_garansi_v2',
  NON_GARANSI_EMOJI: 'premium_emoji_non_garansi_v2',
};

const DEFAULT_GARANSI = { icon: '⭐', customEmojiId: null };
const DEFAULT_NON_GARANSI = { icon: '💎', customEmojiId: null };

// v1 (pre-fix) used to store the raw emoji string directly, without a
// grapheme check or custom_emoji_id — kept read-only here so upgrades
// don't lose an admin's previous choice.
const LEGACY_KEYS = {
  GARANSI_EMOJI: 'premium_emoji_garansi',
  NON_GARANSI_EMOJI: 'premium_emoji_non_garansi',
};

function readConfig(key, legacyKey, fallback) {
  const raw = repo.get(key);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.icon === 'string' && parsed.icon.trim()) {
        return { icon: parsed.icon.trim(), customEmojiId: parsed.customEmojiId || null };
      }
    } catch (_) {
      // fall through to legacy/fallback
    }
  }
  const legacy = repo.get(legacyKey);
  if (legacy && legacy.trim()) return { icon: legacy.trim(), customEmojiId: null };
  return fallback;
}

function writeConfig(key, value, customEmojiId) {
  const check = validateSingleEmoji(value);
  if (!check.ok) throw new Error(check.reason);
  repo.set(key, JSON.stringify({ icon: check.value, customEmojiId: customEmojiId || null }));
}

function getGaransiConfig() {
  return readConfig(KEYS.GARANSI_EMOJI, LEGACY_KEYS.GARANSI_EMOJI, DEFAULT_GARANSI);
}

function getNonGaransiConfig() {
  return readConfig(KEYS.NON_GARANSI_EMOJI, LEGACY_KEYS.NON_GARANSI_EMOJI, DEFAULT_NON_GARANSI);
}

function getGaransiEmoji() {
  return getGaransiConfig().icon;
}

function getNonGaransiEmoji() {
  return getNonGaransiConfig().icon;
}

function setGaransiEmoji(value, customEmojiId) {
  writeConfig(KEYS.GARANSI_EMOJI, value, customEmojiId);
}

function setNonGaransiEmoji(value, customEmojiId) {
  writeConfig(KEYS.NON_GARANSI_EMOJI, value, customEmojiId);
}

// Pick the right emoji (fallback-safe display text) for a product/order's
// garansi flag. Safe to interpolate directly into message text or button
// labels — it's always the plain-text glyph, never a lone entity.
function forGaransi(garansi) {
  return garansi ? getGaransiEmoji() : getNonGaransiEmoji();
}

// Full config (icon + customEmojiId) for a garansi flag — use this when
// building an inline button so the real animated Premium emoji can be
// attached via `icon_custom_emoji_id` (see src/utils/buttons.js).
function configForGaransi(garansi) {
  return garansi ? getGaransiConfig() : getNonGaransiConfig();
}

module.exports = {
  getGaransiEmoji,
  getNonGaransiEmoji,
  getGaransiConfig,
  getNonGaransiConfig,
  setGaransiEmoji,
  setNonGaransiEmoji,
  forGaransi,
  configForGaransi,
  DEFAULT_GARANSI,
  DEFAULT_NON_GARANSI,
};
