/**
 * Real Telegram user-account login (MTProto), used by the "Beli Userbot"
 * flow to turn the BUYER's own phone number into an active userbot session.
 *
 * Requires API_ID + API_HASH from https://my.telegram.org (per bot
 * deployment, NOT per user) set in .env. Without them this service refuses
 * cleanly instead of crashing the bot.
 *
 * One in-progress login attempt is kept in memory per Telegram user id.
 * Authentication attempts are serialized per session so concurrent updates
 * cannot race the attempt counter or complete after the session is cancelled.
 */

const { config } = require('../config');
const logger = require('../utils/logger');

let TelegramClient = null;
let gramjsLoaded = false;

function loadGramJs() {
  if (gramjsLoaded) return true;
  try {
    // Lazy require keeps this service loadable when the optional runtime
    // dependency is absent and lets the bot return a controlled error.
    // eslint-disable-next-line global-require
    ({ TelegramClient } = require('telegram'));
    gramjsLoaded = true;
    return true;
  } catch (err) {
    logger.error('GramJS ("telegram" package) not installed. Run: npm install telegram');
    return false;
  }
}

const LOGIN_TTL_MS = 10 * 60 * 1000;
const MAX_AUTH_ATTEMPTS = 5;
const sessions = new Map(); // telegramId -> { client, phoneCodeHash, phone, timer, otpAttempts, passwordAttempts, authQueue, closed }

function isConfigured() {
  return Boolean(config.telegramApiId && config.telegramApiHash);
}

function rawErrorText(err) {
  return String(
    (err && err.errorMessage) ||
    (err && err.rpcError && err.rpcError.errorMessage) ||
    (err && err.description) ||
    (err && err.response && err.response.description) ||
    (err && err.message) ||
    (err && err.code) ||
    ''
  ).trim();
}

function humanizeDuration(seconds) {
  const total = Math.max(1, Number(seconds) || 0);
  if (total < 60) return `${total} detik`;
  const minutes = Math.ceil(total / 60);
  if (minutes < 60) return `${minutes} menit`;
  const hours = Math.ceil(minutes / 60);
  if (hours < 24) return `${hours} jam`;
  const days = Math.ceil(hours / 24);
  return `${days} hari`;
}

function networkError(raw) {
  return /ECONNRESET|ECONNREFUSED|ECONNABORTED|ETIMEDOUT|ENETUNREACH|EHOSTUNREACH|EAI_AGAIN|ENOTFOUND|socket hang up|network|timed? ?out|timeout|connection/i.test(raw);
}

function makeSafeError(code, message) {
  const err = new Error(message);
  err.code = code;
  err.userMessage = message;
  err.safeForUser = true;
  return err;
}

/**
 * Map a raw GramJS/MTProto/network failure to a stable internal code and a
 * user-safe Indonesian message. Raw details are deliberately NOT returned to
 * callers as user-facing text.
 */
function classifyGramJsError(err, phase = 'login') {
  const raw = rawErrorText(err);
  const upper = raw.toUpperCase();

  const flood = upper.match(/FLOOD_WAIT_(\d+)/);
  if (flood) {
    const seconds = Number(flood[1]);
    return {
      code: 'FLOOD_WAIT',
      message: `Telegram sedang membatasi permintaan sementara. Tunggu sekitar ${humanizeDuration(seconds)} sebelum mencoba lagi.`,
      retryAfterSeconds: seconds,
    };
  }

  if (upper === 'PHONE_NUMBER_BANNED' || /PHONE_NUMBER_BANNED/.test(upper)) {
    return { code: 'PHONE_NUMBER_BANNED', message: 'Nomor Telegram tersebut diblokir oleh Telegram dan tidak dapat digunakan untuk login.' };
  }
  if (upper === 'PHONE_NUMBER_INVALID' || /PHONE_NUMBER_INVALID/.test(upper)) {
    return { code: 'PHONE_NUMBER_INVALID', message: 'Nomor telepon tidak valid. Periksa kembali format nomor dan coba lagi.' };
  }
  if (upper === 'PHONE_NUMBER_FLOOD' || /PHONE_NUMBER_FLOOD/.test(upper)) {
    return { code: 'PHONE_NUMBER_FLOOD', message: 'Nomor ini terlalu sering meminta kode login. Tunggu beberapa saat sebelum mencoba lagi.' };
  }
  if (upper === 'PHONE_NUMBER_UNOCCUPIED' || /PHONE_NUMBER_UNOCCUPIED/.test(upper)) {
    return { code: 'PHONE_NUMBER_UNOCCUPIED', message: 'Nomor ini belum terdaftar di Telegram dan tidak dapat digunakan sebagai userbot.' };
  }
  if (upper === 'PHONE_CODE_INVALID' || /PHONE_CODE_INVALID/.test(upper)) {
    return { code: 'PHONE_CODE_INVALID', message: 'Kode OTP salah. Periksa kembali kode dari Telegram lalu coba lagi.' };
  }
  if (upper === 'PHONE_CODE_EXPIRED' || /PHONE_CODE_EXPIRED/.test(upper)) {
    return { code: 'PHONE_CODE_EXPIRED', message: 'Kode OTP sudah kadaluarsa. Silakan kirim ulang nomor HP untuk mendapat kode baru.' };
  }
  if (upper === 'SESSION_PASSWORD_NEEDED' || /SESSION_PASSWORD_NEEDED/.test(upper)) {
    return { code: '2FA_REQUIRED', message: 'Akun ini membutuhkan password verifikasi 2 langkah.' };
  }
  if (upper === 'PASSWORD_HASH_INVALID' || upper === 'PASSWORD_INVALID' || /PASSWORD_HASH_INVALID|PASSWORD_INVALID/.test(upper)) {
    return { code: 'PASSWORD_INVALID', message: 'Password 2FA salah. Periksa kembali password cloud Telegram Anda lalu coba lagi.' };
  }
  if (/PASSWORD_EMPTY/.test(upper)) {
    return { code: 'PASSWORD_INVALID', message: 'Password 2FA tidak boleh kosong. Masukkan password yang benar.' };
  }
  if (networkError(raw)) {
    return { code: 'NETWORK_ERROR', message: 'Koneksi ke Telegram sedang bermasalah. Silakan coba lagi beberapa saat lagi.' };
  }

  logger.error(`Unhandled GramJS ${phase} error:`, err && err.stack ? err.stack : err);
  return { code: 'GRAMJS_UNKNOWN', message: 'Telegram tidak dapat memproses login saat ini. Silakan coba lagi beberapa saat lagi.' };
}

function getUserFacingErrorMessage(err) {
  if (err && err.safeForUser && typeof err.userMessage === 'string') return err.userMessage;
  const code = String((err && err.code) || '').toUpperCase();
  if (code === 'OTP_ATTEMPT_LIMIT') return 'Batas percobaan OTP tercapai. Sesi login dibatalkan demi keamanan. Mulai lagi dari nomor HP.';
  if (code === 'PASSWORD_ATTEMPT_LIMIT') return 'Batas percobaan password 2FA tercapai. Sesi login dibatalkan demi keamanan. Mulai lagi dari nomor HP.';
  if (code === '2FA_REQUIRED') return 'Akun ini membutuhkan password verifikasi 2 langkah.';
  if (code === 'PHONE_CODE_INVALID') return 'Kode OTP salah. Periksa kembali kode dari Telegram lalu coba lagi.';
  if (code === 'PHONE_CODE_EXPIRED') return 'Kode OTP sudah kadaluarsa. Silakan kirim ulang nomor HP untuk mendapat kode baru.';
  if (code === 'PASSWORD_INVALID') return 'Password 2FA salah. Periksa kembali password cloud Telegram Anda lalu coba lagi.';
  if (code === 'SESSION_INVALID' || code === 'SESSION_CORRUPT' || code === 'SESSION_UNAUTHORIZED') return 'Session tidak valid atau tidak dapat digunakan.';
  if (code === 'DUPLICATE_USERBOT') return 'Akun Telegram tersebut sudah terdaftar sebagai userbot/stok dan tidak dapat ditambahkan dua kali.';
  if (code === 'FLOOD_WAIT') return err.userMessage || 'Telegram sedang membatasi permintaan sementara. Silakan coba lagi nanti.';
  if (code === 'NETWORK_ERROR') return 'Koneksi ke Telegram sedang bermasalah. Silakan coba lagi beberapa saat lagi.';
  return 'Telegram tidak dapat memproses login saat ini. Silakan coba lagi beberapa saat lagi.';
}

function disconnectClient(entry, context) {
  if (!entry || !entry.client || entry.disconnectRequested) return;
  entry.disconnectRequested = true;
  try {
    Promise.resolve(entry.client.disconnect()).catch((err) => {
      logger.warn(`GramJS disconnect failed (${context || 'login'}):`, err && err.message ? err.message : err);
    });
  } catch (err) {
    logger.warn(`GramJS disconnect threw (${context || 'login'}):`, err && err.message ? err.message : err);
  }
}

function removeSession(telegramId, entry, context) {
  const current = sessions.get(telegramId);
  if (current !== entry) return false;
  entry.closed = true;
  if (entry.timer) clearTimeout(entry.timer);
  sessions.delete(telegramId);
  disconnectClient(entry, context);
  return true;
}

function requireCurrentSession(telegramId, expectedEntry) {
  const entry = sessions.get(telegramId);
  if (!entry || entry !== expectedEntry || entry.closed) {
    throw makeSafeError('LOGIN_SESSION_EXPIRED', 'Sesi login sudah kadaluarsa atau dibatalkan. Silakan kirim ulang nomor HP.');
  }
  return entry;
}

function queueSessionOperation(telegramId, operation) {
  const entry = sessions.get(telegramId);
  if (!entry) throw makeSafeError('LOGIN_SESSION_EXPIRED', 'Sesi login sudah kadaluarsa atau dibatalkan. Silakan kirim ulang nomor HP.');

  const run = entry.authQueue.then(async () => {
    requireCurrentSession(telegramId, entry);
    return operation(entry);
  });
  entry.authQueue = run.catch(() => undefined);
  return run;
}

async function startPhoneLogin(telegramId, phoneNumber) {
  if (!isConfigured()) {
    throw makeSafeError('CONFIG_MISSING', 'API Telegram belum dikonfigurasi di server. Hubungi admin.');
  }
  if (!loadGramJs()) {
    throw makeSafeError('MODULE_MISSING', 'Modul Telegram belum terpasang di server. Hubungi admin.');
  }

  const client = new TelegramClient(new (require('telegram/sessions').StringSession)(''), config.telegramApiId, config.telegramApiHash, {
    connectionRetries: 3,
    deviceModel: config.telegramDeviceModel || 'JASEBRICH',
  });

  try {
    await client.connect();
    const result = await client.sendCode(
      { apiId: config.telegramApiId, apiHash: config.telegramApiHash },
      phoneNumber
    );

    const previous = sessions.get(telegramId);
    if (previous) removeSession(telegramId, previous, 'replaced');

    const entry = {
      client,
      phoneCodeHash: result.phoneCodeHash,
      phone: phoneNumber,
      timer: null,
      otpAttempts: 0,
      passwordAttempts: 0,
      authQueue: Promise.resolve(),
      closed: false,
      disconnectRequested: false,
    };

    entry.timer = setTimeout(() => {
      if (sessions.get(telegramId) !== entry) return;
      logger.debug(`GramJS login session for ${telegramId} expired after 10 minutes`);
      removeSession(telegramId, entry, 'ttl-expired');
    }, LOGIN_TTL_MS);
    if (entry.timer && typeof entry.timer.unref === 'function') entry.timer.unref();
    sessions.set(telegramId, entry);
    return true;
  } catch (err) {
    disconnectClient({ client, disconnectRequested: false }, 'startPhoneLogin-failed');
    const mapped = classifyGramJsError(err, 'startPhoneLogin');
    throw makeSafeError(mapped.code, mapped.message);
  }
}

async function submitOtp(telegramId, code) {
  return queueSessionOperation(telegramId, async (entry) => {
    try {
      const { Api } = require('telegram/tl');
      await entry.client.invoke(
        new Api.auth.SignIn({
          phoneNumber: entry.phone,
          phoneCodeHash: entry.phoneCodeHash,
          phoneCode: code,
        })
      );
    } catch (err) {
      const mapped = classifyGramJsError(err, 'submitOtp');
      if (mapped.code === '2FA_REQUIRED') {
        throw makeSafeError('2FA_REQUIRED', mapped.message);
      }
      if (mapped.code === 'PHONE_CODE_INVALID') {
        entry.otpAttempts += 1;
        if (entry.otpAttempts >= MAX_AUTH_ATTEMPTS) {
          removeSession(telegramId, entry, 'otp-attempt-limit');
          throw makeSafeError('OTP_ATTEMPT_LIMIT', 'Batas percobaan OTP tercapai. Sesi login dibatalkan demi keamanan. Mulai lagi dari nomor HP.');
        }
        throw makeSafeError('PHONE_CODE_INVALID', mapped.message);
      }
      if (mapped.code === 'PHONE_CODE_EXPIRED') {
        removeSession(telegramId, entry, 'otp-expired');
        throw makeSafeError('PHONE_CODE_EXPIRED', mapped.message);
      }
      throw makeSafeError(mapped.code, mapped.message);
    }

    requireCurrentSession(telegramId, entry);
    try {
      const sessionString = entry.client.session.save();
      const me = await entry.client.getMe();
      removeSession(telegramId, entry, 'otp-success');
      return {
        sessionString,
        telegramUserbotId: me && me.id ? Number(me.id) : null,
        account: me ? {
          id: me.id ? Number(me.id) : null,
          username: me.username || null,
          firstName: me.firstName || null,
          lastName: me.lastName || null,
          phone: me.phone || entry.phone || null,
        } : null,
      };
    } catch (err) {
      removeSession(telegramId, entry, 'otp-finalize-failed');
      const mapped = classifyGramJsError(err, 'submitOtp-finalize');
      throw makeSafeError(mapped.code, mapped.message);
    }
  });
}

async function submitPassword(telegramId, password) {
  return queueSessionOperation(telegramId, async (entry) => {
    try {
      const { computeCheck } = require('telegram/Password');
      const { Api } = require('telegram/tl');
      const passwordInfo = await entry.client.invoke(new Api.account.GetPassword());
      const passwordSrpCheck = await computeCheck(passwordInfo, password);
      await entry.client.invoke(new Api.auth.CheckPassword({ password: passwordSrpCheck }));
    } catch (err) {
      const mapped = classifyGramJsError(err, 'submitPassword');
      if (mapped.code === 'PASSWORD_INVALID') {
        entry.passwordAttempts += 1;
        if (entry.passwordAttempts >= MAX_AUTH_ATTEMPTS) {
          removeSession(telegramId, entry, 'password-attempt-limit');
          throw makeSafeError('PASSWORD_ATTEMPT_LIMIT', 'Batas percobaan password 2FA tercapai. Sesi login dibatalkan demi keamanan. Mulai lagi dari nomor HP.');
        }
        throw makeSafeError('PASSWORD_INVALID', mapped.message);
      }
      throw makeSafeError(mapped.code, mapped.message);
    }

    requireCurrentSession(telegramId, entry);
    try {
      const sessionString = entry.client.session.save();
      const me = await entry.client.getMe();
      removeSession(telegramId, entry, 'password-success');
      return {
        sessionString,
        telegramUserbotId: me && me.id ? Number(me.id) : null,
        account: me ? {
          id: me.id ? Number(me.id) : null,
          username: me.username || null,
          firstName: me.firstName || null,
          lastName: me.lastName || null,
          phone: me.phone || entry.phone || null,
        } : null,
      };
    } catch (err) {
      removeSession(telegramId, entry, 'password-finalize-failed');
      const mapped = classifyGramJsError(err, 'submitPassword-finalize');
      throw makeSafeError(mapped.code, mapped.message);
    }
  });
}

function cancelLogin(telegramId) {
  const entry = sessions.get(telegramId);
  if (!entry) return false;
  return removeSession(telegramId, entry, 'cancelled');
}

async function verifySessionString(sessionString) {
  if (!isConfigured()) {
    throw makeSafeError('CONFIG_MISSING', 'API Telegram belum dikonfigurasi di server. Hubungi admin.');
  }
  if (!loadGramJs()) {
    throw makeSafeError('MODULE_MISSING', 'Modul Telegram belum terpasang di server. Hubungi admin.');
  }
  if (typeof sessionString !== 'string' || !sessionString.trim()) {
    throw makeSafeError('SESSION_INVALID', 'Session tidak valid atau tidak dapat digunakan.');
  }

  let client = null;
  try {
    const { StringSession } = require('telegram/sessions');
    const { Api } = require('telegram/tl');
    const normalized = sessionString.trim();
    let stringSession;
    try {
      stringSession = new StringSession(normalized);
    } catch (err) {
      const safe = makeSafeError('SESSION_CORRUPT', 'Session tidak valid atau rusak sehingga tidak dapat digunakan.');
      safe.cause = err;
      throw safe;
    }

    client = new TelegramClient(stringSession, config.telegramApiId, config.telegramApiHash, {
      connectionRetries: 3,
      deviceModel: config.telegramDeviceModel || 'JASEBRICH',
    });
    await client.connect();

    // GetState confirms the MTProto connection is functional. checkAuthorization
    // is used when exposed by this GramJS version; getMe is the final identity
    // and authorization proof for versions where that helper is unavailable.
    await client.invoke(new Api.updates.GetState());
    if (typeof client.checkAuthorization === 'function') {
      const authorized = await client.checkAuthorization();
      if (authorized === false) {
        throw makeSafeError('SESSION_INVALID', 'Session tidak terotorisasi dan tidak dapat digunakan.');
      }
    }
    if (typeof client.getMe !== 'function') {
      throw makeSafeError('SESSION_INVALID', 'Session tidak dapat diverifikasi karena capability akun Telegram tidak tersedia.');
    }
    const me = await client.getMe();
    if (!me || me.id == null) {
      throw makeSafeError('SESSION_INVALID', 'Identitas akun Telegram tidak dapat diverifikasi dari session tersebut.');
    }

    const savedSession = typeof client.session?.save === 'function' ? client.session.save() : normalized;
    if (typeof savedSession !== 'string' || !savedSession.trim()) {
      throw makeSafeError('SESSION_CORRUPT', 'Session berhasil terhubung tetapi tidak dapat disimpan sebagai StringSession yang valid.');
    }

    return {
      sessionString: savedSession.trim(),
      telegramUserbotId: me.id != null ? Number(me.id) : null,
      account: {
        id: me.id != null ? Number(me.id) : null,
        username: me.username || null,
        firstName: me.firstName || null,
        lastName: me.lastName || null,
        phone: me.phone || null,
      },
    };
  } catch (err) {
    if (err && err.safeForUser) throw err;
    const raw = rawErrorText(err).toUpperCase();
    if (SESSION_STRING_INVALID_RE.test(raw)) {
      throw makeSafeError('SESSION_INVALID', 'Session tidak valid, sudah dicabut, atau tidak dapat digunakan.');
    }
    const mapped = classifyGramJsError(err, 'verifySessionString');
    if (mapped.code === 'NETWORK_ERROR') throw makeSafeError('NETWORK_ERROR', mapped.message);
    if (mapped.code === 'FLOOD_WAIT') throw makeSafeError('FLOOD_WAIT', mapped.message);
    throw makeSafeError('SESSION_INVALID', 'Session tidak valid atau tidak dapat digunakan.');
  } finally {
    disconnectClient({ client, disconnectRequested: false }, 'verify-session-string');
  }
}

const SESSION_STRING_INVALID_RE = /AUTH_KEY_UNREGISTERED|AUTH_KEY_INVALID|AUTH_KEY_DUPLICATED|SESSION_REVOKED|SESSION_EXPIRED|USER_DEACTIVATED|USER_DEACTIVATED_BAN|UNAUTHORIZED|SESSION_PASSWORD_NEEDED/i;

module.exports = {
  LOGIN_TTL_MS,
  MAX_AUTH_ATTEMPTS,
  isConfigured,
  startPhoneLogin,
  submitOtp,
  submitPassword,
  verifySessionString,
  cancelLogin,
  classifyGramJsError,
  getUserFacingErrorMessage,
};
