const productRepo = require('../database/repositories/product.repository');
const orderRepo = require('../database/repositories/order.repository');
const { MENU } = require('../constants/menu');

const CATEGORIES = {
  USERBOT: 'userbot',
  JASEB: 'jaseb',
  // Not a real product category (no catalog rows of its own) — reuses
  // the USERBOT catalog but tags the resulting order differently so
  // fulfillment extends an existing owned userbot instead of creating
  // a new one. See services/order.service.js#fulfillOrder.
  RENEWAL: 'renewal',
};

const CATEGORY_LABEL = {
  [CATEGORIES.USERBOT]: '🤖 Beli Userbot',
  [CATEGORIES.JASEB]: '🔥 Beli Jaseb',
  [CATEGORIES.RENEWAL]: MENU.PERPANJANG_LANGGANAN,
};


class ProductUnavailableError extends Error {
  constructor(productId, message = 'Produk tidak tersedia atau sudah dinonaktifkan.') {
    super(`${message} (#${productId})`);
    this.name = 'ProductUnavailableError';
    this.code = 'PRODUCT_UNAVAILABLE';
  }
}

class InvalidProductCategoryError extends Error {
  constructor(productId, category) {
    super(`Produk #${productId} tidak termasuk kategori pembelian ${category}.`);
    this.name = 'InvalidProductCategoryError';
    this.code = 'INVALID_PRODUCT_CATEGORY';
  }
}

function normalizePurchaseCategory(category, mode, fallbackCategory = null) {
  if (mode === 'renewal') return CATEGORIES.RENEWAL;
  if (category === CATEGORIES.USERBOT || category === CATEGORIES.JASEB) return category;
  if (fallbackCategory === CATEGORIES.USERBOT || fallbackCategory === CATEGORIES.JASEB) return fallbackCategory;
  return null;
}

function resolvePurchaseProduct(productId, category, mode) {
  const id = Number(productId);
  if (!Number.isInteger(id) || id <= 0) throw new ProductUnavailableError(productId);
  const product = productRepo.findById(id);
  if (!product || !product.is_active) throw new ProductUnavailableError(id);
  const requestedCategory = normalizePurchaseCategory(category, mode, product.category);
  if (!requestedCategory) throw new InvalidProductCategoryError(id, String(category || mode || '-'));
  if (requestedCategory !== CATEGORIES.RENEWAL && product.category !== requestedCategory) {
    throw new InvalidProductCategoryError(id, requestedCategory);
  }
  if (requestedCategory === CATEGORIES.RENEWAL && product.category !== CATEGORIES.USERBOT) {
    throw new InvalidProductCategoryError(id, requestedCategory);
  }
  return { product, category: requestedCategory };
}
function formatRupiah(amount) {
  return `Rp ${Number(amount || 0).toLocaleString('id-ID')}`;
}

/** Number of orders (any status) that reference this product — surfaced to
 * admin before delete so they know if there's purchase history involved. */
function countOrders(id) {
  return orderRepo.countByProduct(id);
}

function remove(id) {
  // Product rows are entitlement history. Never physically delete a product
  // that may still be referenced by fulfilled orders/userbots: doing so would
  // sever the entitlement chain and could silently change feature access.
  // "Remove" therefore means "retire from the storefront".
  return productRepo.remove(id);
}

module.exports = {
  CATEGORIES,
  CATEGORY_LABEL,
  formatRupiah,
  ProductUnavailableError,
  InvalidProductCategoryError,
  normalizePurchaseCategory,
  resolvePurchaseProduct,
  listActive: (category) => productRepo.listByCategory(category, { activeOnly: true }),
  listAll: (category) => productRepo.listByCategory(category, { activeOnly: false }),
  listActiveByGaransi: (garansi) => productRepo.listByGaransi(garansi, { activeOnly: true }),
  listPage: (category, offset, limit) => productRepo.listPage(category, offset, limit),
  count: (category) => productRepo.countByCategory(category),
  countOrders,
  getById: (id) => productRepo.findById(id),
  // `featureAccess` (camelCase, JSON string or null) is accepted here and
  // mapped onto the raw `feature_access` column name the repository/DB row
  // actually uses — see database/repositories/product.repository.js.
  create: (data) => productRepo.create(data),
  update: (id, { featureAccess, ...fields }) =>
    productRepo.update(id, featureAccess !== undefined ? { ...fields, feature_access: featureAccess } : fields),
  toggleActive: (id) => productRepo.toggleActive(id),
  remove,
};
