'use strict';
/**
 * Userbot delivery log.
 *
 * Every outcome is appended to an in-memory log. Once per FLUSH_MS, each
 * enabled channel gets ONE message that is edited to show the latest lines.
 * A burst of sends costs at most one edit per minute per channel.
 *
 * Channels:
 *   channel_bot    the bot messages the userbot's buyer
 *   channel_saved  the userbot writes to its own Saved Messages
 *   channel_owner  the userbot messages its buyer directly
 */
const { getDb } = require('../database');
const logger = require('../utils/logger');
const notifyCard = require('./notifyCard.service');
const policy = require('./ubotNotify.policy');
const { renderLine } = require('./ubotNotify.templates');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const poolRepo = require('../database/repositories/userbotPool.repository');

const FLUSH_MS = 60 * 1000;
const buffers = new Map(); // "kind:id" -> { kind, id, entries, success, failed, dirty, client }
let telegram = null;
let timer = null;
let flushing = false;

function setTelegram(t) { telegram = t; }
function bufferKey(kind, id) { return `${kind}:${Number(id)}`; }

function getSettings(kind, id) {
  const row = getDb().prepare('SELECT * FROM ubot_notify_settings WHERE kind = ? AND asset_id = ?').get(String(kind), Number(id));
  return policy.normalizeSettings(row);
}

function markDirty(kind, id) {
  const buf = buffers.get(bufferKey(kind, id));
  if (buf) buf.dirty = true;
}

function toggle(kind, id, key) {
  const current = getSettings(kind, id);
  const { settings, error } = policy.toggleSettings(current, key);
  if (error) return { settings: current, error };
  const cols = policy.TOGGLES;
  getDb().prepare(
    `INSERT INTO ubot_notify_settings (kind, asset_id, ${cols.join(', ')}, updated_at)
     VALUES (?, ?, ${cols.map(() => '?').join(', ')}, datetime('now'))
     ON CONFLICT(kind, asset_id) DO UPDATE SET ${cols.map((c) => `${c} = excluded.${c}`).join(', ')}, updated_at = excluded.updated_at`
  ).run(String(kind), Number(id), ...cols.map((c) => (settings[c] ? 1 : 0)));
  markDirty(kind, id);
  return { settings, error: null };
}

/** event: { type: 'success' } | { type: 'failed', target, error } | { type: 'flood', target, seconds } */
function recordEvent(record, event) {
  try {
    const k = bufferKey(record.kind, record.id);
    const buf = buffers.get(k) || { kind: record.kind, id: Number(record.id), entries: [], success: 0, failed: 0, dirty: false, client: null };
    if (event.type === 'success') buf.success += 1;
    if (event.type === 'failed') buf.failed += 1;
    buf.entries = policy.appendEntry(buf.entries, {
      type: event.type,
      target: event.target,
      reason: event.type === 'failed' ? policy.shortReason(event.error) : null,
      seconds: event.seconds,
    });
    buf.client = record.client || buf.client;
    buf.dirty = true;
    buffers.set(k, buf);
  } catch (err) {
    // Logging must never break a promotion send.
    logger.warn(`Catat log pengiriman gagal: ${err.message}`);
  }
}

function resolveBuyer(kind, id) {
  if (kind === 'pool') return poolRepo.findById(Number(id))?.assigned_user_id || null;
  return ownedRepo.findById(Number(id))?.user_id || null;
}

function resolveLabel(kind, id) {
  const row = kind === 'pool' ? poolRepo.findById(Number(id)) : ownedRepo.findById(Number(id));
  return row?.label || null;
}

const FLOOD_RE = /flood|retry after|too many requests|429/i;

async function deliverChannel(channel, buf, buyerId, text) {
  const key = (suffix) => `ubot:${buf.kind}:${buf.id}:${suffix}`;
  if (channel === 'channel_bot') {
    if (!telegram) throw new Error('Bot belum siap.');
    await notifyCard.upsertCard({ key: key('bot'), chatId: buyerId, transport: notifyCard.botTransport(telegram, buyerId, null), text });
  } else if (channel === 'channel_saved') {
    if (!buf.client) throw new Error('Client userbot tidak tersedia.');
    await notifyCard.upsertCard({ key: key('saved'), chatId: 'me', transport: notifyCard.userbotTransport(buf.client, 'me', null), text });
  } else if (channel === 'channel_owner') {
    if (!buf.client) throw new Error('Client userbot tidak tersedia.');
    await notifyCard.upsertCard({ key: key('owner'), chatId: buyerId, transport: notifyCard.userbotTransport(buf.client, buyerId, null), text });
  }
}

/**
 * Pushes dirty logs to their channels. A flood wait keeps the log dirty so the
 * next tick retries; other failures are logged and wait for the next event.
 */
async function flushOnce() {
  if (flushing) return { skipped: 'running' };
  flushing = true;
  const report = [];
  try {
    for (const buf of buffers.values()) {
      if (!buf.dirty) continue;
      const settings = getSettings(buf.kind, buf.id);
      const channels = policy.activeChannels(settings);
      if (!channels.length) { buf.dirty = false; continue; }
      const buyerId = resolveBuyer(buf.kind, buf.id);
      const lines = policy.visibleLines(buf.entries, settings).map((e) => renderLine(e.type, {
        target: e.target, reason: e.reason, seconds: e.seconds,
      }));
      const text = policy.formatCard({ label: resolveLabel(buf.kind, buf.id), id: buf.id, lines });
      let retry = false;
      for (const ch of channels) {
        if (!buyerId && ch !== 'channel_saved') {
          report.push({ kind: buf.kind, id: buf.id, channel: ch, ok: false, error: 'pembeli tidak ditemukan' });
          continue;
        }
        try {
          await deliverChannel(ch, buf, buyerId, text);
          report.push({ kind: buf.kind, id: buf.id, channel: ch, ok: true });
        } catch (err) {
          if (FLOOD_RE.test(String(err?.message || err))) retry = true;
          logger.warn(`Log ${ch} untuk ${buf.kind}#${buf.id} gagal: ${err.message}`);
          report.push({ kind: buf.kind, id: buf.id, channel: ch, ok: false, error: err.message });
        }
      }
      buf.dirty = retry;
    }
  } finally {
    flushing = false;
  }
  return report;
}

function recentStats() {
  let success = 0;
  let failed = 0;
  for (const buf of buffers.values()) { success += buf.success; failed += buf.failed; }
  return { success, failed };
}

function start() {
  if (timer) return;
  timer = setInterval(() => {
    flushOnce().catch((err) => logger.error('Flush log pengiriman gagal:', err));
  }, FLUSH_MS);
  timer.unref?.();
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
}

module.exports = {
  FLUSH_MS, setTelegram, getSettings, toggle, recordEvent, markDirty,
  flushOnce, recentStats, start, stop,
};
