'use strict';
/**
 * Persistence and runtime hooks for Smart Delay. The flag and the learned
 * delay live in their own table, keyed by (kind, asset id), so they never
 * collide with the manual panel settings.
 */
const { getDb } = require('../database');
const policy = require('./smartDelay.policy');

function readRow(kind, id) {
  return getDb().prepare('SELECT * FROM smart_delay_state WHERE kind = ? AND asset_id = ?').get(String(kind), Number(id)) || null;
}

function stateOf(row) {
  return row ? { current: row.current_seconds, streak: row.success_streak } : null;
}

function isEnabled(kind, id) {
  const row = readRow(kind, id);
  return Boolean(row && row.enabled);
}

function save(kind, id, enabled, state) {
  getDb().prepare(
    `INSERT INTO smart_delay_state (kind, asset_id, enabled, current_seconds, success_streak, updated_at)
     VALUES (?, ?, ?, ?, ?, datetime('now'))
     ON CONFLICT(kind, asset_id) DO UPDATE SET enabled = excluded.enabled,
       current_seconds = excluded.current_seconds, success_streak = excluded.success_streak, updated_at = excluded.updated_at`
  ).run(String(kind), Number(id), enabled ? 1 : 0, state.current, state.streak);
}

/** Turning ON starts at the floor; turning OFF keeps the learned value for next time. */
function setEnabled(kind, id, enabled, range) {
  const row = readRow(kind, id);
  // normalizeState starts from the floor when there is no stored value yet.
  const state = policy.normalizeState(stateOf(row), range);
  save(kind, id, enabled, state);
  return { enabled, state };
}

function nextGroupDelay(kind, id, range, random = Math.random) {
  const row = readRow(kind, id);
  return policy.chooseGroupDelay({ enabled: Boolean(row && row.enabled), state: stateOf(row), range, random });
}

// Bookkeeping runs inside the send loop: a DB hiccup here must never stop a promotion.
function onSuccess(kind, id, range) {
  try {
    const row = readRow(kind, id);
    if (!row || !row.enabled) return;
    save(kind, id, true, policy.onSuccess(stateOf(row), range));
  } catch (_) { /* best effort; the delay simply keeps its last value */ }
}

function onFlood(kind, id, range, seconds) {
  try {
    const row = readRow(kind, id);
    if (!row || !row.enabled) return;
    save(kind, id, true, policy.onFlood(stateOf(row), range, seconds));
  } catch (_) { /* best effort */ }
}

function describe(kind, id, range) {
  const row = readRow(kind, id);
  return policy.describe({ enabled: Boolean(row && row.enabled), state: stateOf(row), range });
}

module.exports = { isEnabled, setEnabled, nextGroupDelay, onSuccess, onFlood, describe };
