/** Real GramJS runtime for the Kontrol Panel. */
const fs = require('fs');
const { config } = require('../config');
const logger = require('../utils/logger');
const automationConfig = require('./automationConfig.service');
const panelConfig = require('./panelConfig.service');
const poolPanelConfig = require('./poolPanelConfig.service');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const poolRepo = require('../database/repositories/userbotPool.repository');
const pmPermitState = require('../database/repositories/pmPermitState.repository');
const baseReplyCooldown = require('../database/repositories/baseReplyCooldown.repository');
const subscription = require('./subscription.service');
const delayPolicy = require('./delayPolicy.service');
const crypto = require('crypto');
const runtimeJobRepo = require('../database/repositories/userbotRuntimeJob.repository');
const featureAccessSvc = require('./featureAccess.service');
const { getDb } = require('../database');

let TelegramClient = null;
let StringSession = null;
let NewMessage = null;
let Api = null;
const clients = new Map();
// Internal safety floor for WTB Base Reply: the MINIMUM gap enforced
// between two successful replies in the SAME chat, regardless of the
// admin-configured "🔄 Auto Reset" duration (panel_settings.wtb_auto_reset_minutes,
// exposed via autoResetHandler/PANEL_FEATURE.AUTO_RESET). Its only job is
// to absorb near-simultaneous duplicate triggers (concurrent Telegram
// updates, a keyword reappearing seconds later) — it is NOT the
// business-level "don't nag this chat too often" cooldown, which stays
// fully driven by Auto Reset as before. Kept short and responsive per
// product requirement: seconds, not minutes.
const WTB_REPLY_MIN_COOLDOWN_MS = 3 * 60 * 1000;
// How often stale per-chat cooldown entries are swept from
// record.wtbLastReplyAt so long-running processes with many distinct
// chats over time don't grow that Map forever (see pruneWtbCooldowns()).
const WTB_COOLDOWN_PRUNE_INTERVAL_MS = 10 * 60 * 1000;
// Periodic MTProto session health check for every connected asset. Control-panel
// operations also verify the session on-demand, so this timer covers idle
// userbots whose session is revoked while no automation event is occurring.
const SESSION_HEALTH_INTERVAL_MS = 60 * 1000;
const SESSION_AUTH_CACHE_MS = 60 * 1000;

function loadGramJs() {
  if (TelegramClient) return true;
  try {
    ({ TelegramClient } = require('telegram'));
    ({ StringSession } = require('telegram/sessions'));
    ({ NewMessage } = require('telegram/events'));
    ({ Api } = require('telegram/tl'));
    return true;
  } catch (err) {
    logger.error('GramJS belum terpasang: npm install telegram');
    return false;
  }
}
function configured() { return Boolean(config.telegramApiId && config.telegramApiHash) && loadGramJs(); }
function keyFor(kind,id){ return `${kind}:${id}`; }
function repoFor(kind){ return kind === 'owned' ? ownedRepo : poolRepo; }
function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

// Inter-group promotion waits are owned by the runtime record so Stop Promosi
// and teardown can wake a currently sleeping promotion loop immediately.
// The generic sleep() above remains unchanged for unrelated pacing paths.
function cancelPromotionDelayWaits(record){
  const waits=record && record.promotionDelayWaits;
  if(!waits || !waits.size) return;
  for(const wait of waits){
    clearTimeout(wait.timer);
    waits.delete(wait);
    wait.resolve(false);
  }
}
function waitPromotionDelay(record, ms){
  if(!record || !record.flags.auto_promosi || ms<=0) return Promise.resolve(false);
  if(!record.promotionDelayWaits) record.promotionDelayWaits=new Set();
  return new Promise(resolve=>{
    const wait={timer:null,resolve};
    wait.timer=setTimeout(()=>{
      record.promotionDelayWaits.delete(wait);
      resolve(true);
    },ms);
    record.promotionDelayWaits.add(wait);
  });
}

// Ephemeral UI state for the live Control Panel status screen. The durable
// checkpoint remains userbot_runtime_jobs; this state only explains what the
// worker is doing between durable checkpoints without introducing another DB
// state machine. On restart the status renderer derives a safe phase from the
// persisted job/timestamps.
function setPromotionUiState(record, patch){
  if(!record) return;
  record.promotionUi = {
    ...(record.promotionUi || {}),
    ...(patch || {}),
    updatedAtMs: Date.now(),
  };
}
function clearPromotionUiState(record){
  if(record) record.promotionUi = null;
}

// ---------------------------------------------------------------------------
// Subscription enforcement (runtime layer)
//
// The runtime must never keep a userbot alive on the strength of the persisted
// `status` alone: the persisted status is only reconciled by the scheduler /
// lazy access checks, so an asset whose expires_at has passed could otherwise
// keep promoting in the background. assetLiveness() derives liveness from the
// TIMESTAMP too, and is consulted by syncAsset(), withClient(), every promo
// cycle/send, every incoming event, and a per-asset expiry timer.
// ---------------------------------------------------------------------------
function assetLiveness(kind, asset, nowMs = Date.now()) {
  if (!asset) return { live: false, reason: 'NOT_FOUND' };
  if (Number(asset.owner_is_banned) === 1) return { live: false, reason: 'OWNER_BANNED' };
  const statusOk = kind === 'owned' ? asset.status === 'active' : asset.status === 'assigned';
  if (!statusOk) return { live: false, reason: asset.status === 'expired' ? 'SUBSCRIPTION_EXPIRED' : 'NOT_ACTIVE' };
  if (subscription.isExpiredAt(asset.expires_at, nowMs)) return { live: false, reason: 'SUBSCRIPTION_EXPIRED' };
  return { live: true, reason: null };
}
function isLiveFresh(kind, id) {
  return assetLiveness(kind, repoFor(kind).findById(id)).live;
}

// Telegram/GramJS errors that definitively mean the STORED SESSION is dead
// (revoked / logged out / account gone). Anything else (network, FloodWait,
// generic RPC timeouts) is transient and must NOT flag the session invalid.
const SESSION_INVALID_RE = /AUTH_KEY_UNREGISTERED|AUTH_KEY_INVALID|AUTH_KEY_DUPLICATED|SESSION_REVOKED|SESSION_EXPIRED|USER_DEACTIVATED|USER_DEACTIVATED_BAN/i;
const SESSION_UNAUTHORIZED_RE = /AUTH_KEY_UNREGISTERED|AUTH_KEY_INVALID|SESSION_REVOKED|SESSION_EXPIRED|USER_DEACTIVATED|USER_DEACTIVATED_BAN|AUTH_KEY_DUPLICATED/i;
function isSessionInvalidError(err) {
  if (!err) return false;
  if (err.code === 'SESSION_INVALID' || err.code === 'SESSION_CORRUPT' || err.code === 'SESSION_MISSING') return true;
  return SESSION_INVALID_RE.test(String(err.errorMessage || err.message || err));
}
async function assertSessionAuthorized(client, expectedTelegramUserbotId = null) {
  try {
    // GetState proves the MTProto connection is usable; checkAuthorization is
    // the actual account authorization gate. Some GramJS versions expose it
    // directly on TelegramClient, while getMe remains the final capability and
    // identity proof for all supported versions.
    await client.invoke(new Api.updates.GetState());
    if (typeof client.checkAuthorization === 'function') {
      const authorized = await client.checkAuthorization();
      if (authorized === false) {
        const e = new Error('Sesi Telegram belum terotorisasi.');
        e.code = 'SESSION_UNAUTHORIZED';
        throw e;
      }
    }
    if (typeof client.getMe !== 'function') {
      const e = new Error('GramJS client tidak menyediakan capability getMe.');
      e.code = 'RUNTIME_CAPABILITY_ERROR';
      throw e;
    }
    const me = await client.getMe();
    if (!me || me.id == null) {
      const e = new Error('Identitas Telegram userbot tidak dapat diverifikasi.');
      e.code = 'SESSION_UNAUTHORIZED';
      throw e;
    }
    if (expectedTelegramUserbotId != null && Number(me.id) !== Number(expectedTelegramUserbotId)) {
      const e = new Error('Identitas akun Telegram tidak sesuai dengan userbot yang terdaftar.');
      e.code = 'SESSION_IDENTITY_MISMATCH';
      throw e;
    }
    return me;
  } catch (err) {
    if (err && err.code === 'SESSION_IDENTITY_MISMATCH') throw err;
    if (err && err.code === 'SESSION_UNAUTHORIZED') {
      const e = new Error('Sesi Telegram userbot tidak lagi terotorisasi. Login ulang diperlukan.');
      e.code = 'SESSION_INVALID';
      e.cause = err;
      throw e;
    }
    if (isSessionInvalidError(err) || SESSION_UNAUTHORIZED_RE.test(String(err?.errorMessage || err?.message || err || ''))) {
      const e = new Error('Sesi Telegram userbot tidak valid atau sudah dicabut. Login ulang diperlukan.');
      e.code = 'SESSION_INVALID';
      e.cause = err;
      throw e;
    }
    throw err;
  }
}

// Per-asset serialization. syncAsset/teardownAsset for the SAME asset never
// interleave, which is what guarantees (a) exactly one client/listener per
// asset, (b) no duplicate start/stop, and (c) that an expiry teardown racing
// an admin extension always ends by re-reading the DB and converging on it.
const assetLocks = new Map();
function withAssetLock(key, fn) {
  const prev = assetLocks.get(key) || Promise.resolve();
  const run = prev.catch(() => {}).then(fn);
  const tail = run.catch(() => {});
  assetLocks.set(key, tail);
  tail.then(() => { if (assetLocks.get(key) === tail) assetLocks.delete(key); });
  return run;
}

const MAX_TIMEOUT_MS = 2 ** 31 - 1;
function clearExpiryTimer(record){ if(record.expiryTimer){ clearTimeout(record.expiryTimer); record.expiryTimer=null; } }
function armExpiryTimer(record, asset){
  clearExpiryTimer(record);
  record.expiresAtMs = null;
  const exp = subscription.parseTimestamp(asset.expires_at);
  if (exp === null || Number.isNaN(exp)) return;
  record.expiresAtMs = exp;
  const wait = Math.max(0, exp - Date.now());
  record.expiryTimer = setTimeout(() => onExpiryTimer(record.kind, record.id, exp), Math.min(wait, MAX_TIMEOUT_MS));
  if (typeof record.expiryTimer.unref === 'function') record.expiryTimer.unref();
}
function onExpiryTimer(kind, id, expMs){
  const r = clients.get(keyFor(kind, id));
  if (r) r.expiryTimer = null;
  if (Date.now() < expMs) { // setTimeout fired early / chunked wait: re-arm from DB truth
    const asset = repoFor(kind).findById(id);
    if (r && asset && assetLiveness(kind, asset).live) armExpiryTimer(r, asset);
    return;
  }
  try {
    require('./userbotLifecycle.service').handleExpiryDue(kind, id)
      .catch((err) => logger.error(`Expiry handling ${keyFor(kind, id)}: ${err.message}`));
  } catch (err) { logger.error(`Expiry handling ${keyFor(kind, id)}: ${err.message}`); }
}
// Event-path safety net: an incoming event that arrives after expires_at but
// before the timer callback ran is dropped and triggers the same handling.
function lapsedRecord(record){
  if (record.expiresAtMs === null || record.expiresAtMs === undefined) return false;
  if (Date.now() < record.expiresAtMs) return false;
  if (!record.expiring) {
    record.expiring = true;
    setImmediate(() => { record.expiring = false; onExpiryTimer(record.kind, record.id, record.expiresAtMs); });
  }
  return true;
}
function clearSessionHealthTimer(record){
  if(record && record.sessionHealthTimer){ clearTimeout(record.sessionHealthTimer); record.sessionHealthTimer=null; }
}
function armSessionHealthTimer(record){
  clearSessionHealthTimer(record);
  if(!record || !record.client) return;
  record.sessionHealthTimer=setTimeout(()=>onSessionHealthTimer(record.kind,record.id), SESSION_HEALTH_INTERVAL_MS);
  if(typeof record.sessionHealthTimer.unref==='function') record.sessionHealthTimer.unref();
}
async function onSessionHealthTimer(kind,id){
  const r=clients.get(keyFor(kind,id));
  if(!r || !r.client) return;
  r.sessionHealthTimer=null;
  try{
    await assertSessionAuthorized(r.client, repoFor(kind).findById(id)?.telegram_userbot_id);
  }catch(err){
    if(isSessionInvalidError(err)) noteSessionInvalid(r);
    else logger.warn(`Session health ${keyFor(kind,id)}: verifikasi gagal sementara, sesi tidak ditandai invalid: ${err.message}`);
    return;
  }
  const current=clients.get(keyFor(kind,id));
  if(current===r && r.client) armSessionHealthTimer(r);
}

function noteSessionInvalid(record){
  if (!record || !['owned','pool'].includes(record.kind) || record.sessionInvalidNoted) return;
  record.sessionInvalidNoted = true;
  require('./userbotLifecycle.service').handleSessionInvalid(record.kind, record.id)
    .catch((err) => logger.error(`Session-invalid handling ${keyFor(record.kind, record.id)}: ${err.message}`));
}

function toBigInteger(value) {
  try {
    const bigInt = require('big-integer');
    return bigInt(String(value));
  } catch (_) {
    return BigInt(String(value));
  }
}

// Telegram Bot API and MTProto both use UTF-16 offsets/lengths for message
// entities, so the entity ranges can be copied without re-indexing text.
// We deliberately preserve every entity type that GramJS can represent.
function botEntitiesToGramJs(entities) {
  if (!Array.isArray(entities) || !entities.length || !Api) return [];
  const out=[];
  for (const e of entities) {
    if (!e || typeof e.offset !== 'number' || typeof e.length !== 'number') continue;
    const a={offset:e.offset,length:e.length};
    try {
      switch(e.type) {
        case 'mention': out.push(new Api.MessageEntityMention(a)); break;
        case 'hashtag': out.push(new Api.MessageEntityHashtag(a)); break;
        case 'cashtag': out.push(new Api.MessageEntityCashtag(a)); break;
        case 'bot_command': out.push(new Api.MessageEntityBotCommand(a)); break;
        case 'url': out.push(new Api.MessageEntityUrl(a)); break;
        case 'email': out.push(new Api.MessageEntityEmail(a)); break;
        case 'phone_number': out.push(new Api.MessageEntityPhone(a)); break;
        case 'bold': out.push(new Api.MessageEntityBold(a)); break;
        case 'italic': out.push(new Api.MessageEntityItalic(a)); break;
        case 'underline': out.push(new Api.MessageEntityUnderline(a)); break;
        case 'strikethrough': out.push(new Api.MessageEntityStrike(a)); break;
        case 'spoiler': out.push(new Api.MessageEntitySpoiler(a)); break;
        case 'code': out.push(new Api.MessageEntityCode(a)); break;
        case 'pre': out.push(new Api.MessageEntityPre({...a,language:String(e.language||'')})); break;
        case 'text_link': if(e.url) out.push(new Api.MessageEntityTextUrl({...a,url:String(e.url)})); break;
        case 'custom_emoji': if(e.custom_emoji_id) out.push(new Api.MessageEntityCustomEmoji({...a,documentId:toBigInteger(e.custom_emoji_id)})); break;
        case 'blockquote': out.push(new Api.MessageEntityBlockquote({...a,collapsed:Boolean(e.is_expandable||e.expandable)})); break;
        // Bot API text_mention contains user data outside the entity itself.
        // There is no lossless MTProto conversion without resolving that user;
        // skip it instead of fabricating a mention/link.
        case 'text_mention': break;
        default: break;
      }
    } catch (err) {
      logger.warn(`Entity ${e.type} dilewati: ${err.message}`);
    }
  }
  return out;
}
function parseClockRange(raw) {
  if (!raw) return null;
  const m=String(raw).trim().match(/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/);
  if(!m) return null;
  const a=Number(m[1])*60+Number(m[2]), b=Number(m[3])*60+Number(m[4]);
  if([a,b].some(x=>x>1439)) return null;
  return {start:a,end:b};
}
function jakartaMinutesAndParts(date=new Date()) {
  const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(date);
  const get=t=>Number(parts.find(p=>p.type===t)?.value||0);
  return {minutes:get('hour')*60+get('minute'),year:get('year'),month:get('month'),day:get('day')};
}
// Jam aktif dipakai hanya jika timer_enabled tidak dinonaktifkan; window tetap tersimpan.
function effectiveTimer(asset){ return asset && asset.timer_enabled!==0 ? asset.timer_config : null; }
function parseClockWindow(raw) {
  const r=parseClockRange(raw); if(!r) return true;
  const n=jakartaMinutesAndParts().minutes;
  return r.start<=r.end ? n>=r.start&&n<=r.end : n>=r.start||n<=r.end;
}
function msUntilNextTimerStart(raw) {
  const r=parseClockRange(raw); if(!r) return 0;
  const now=new Date(); const cur=jakartaMinutesAndParts(now).minutes;
  const inside=r.start<=r.end ? cur>=r.start&&cur<=r.end : cur>=r.start||cur<=r.end;
  if(inside) return 0;
  let delta=r.start-cur; if(delta<=0) delta+=1440;
  return delta*60*1000;
}

async function buildClient(sessionString){
  let stringSession;
  try {
    stringSession = new StringSession(sessionString);
  } catch (err) {
    const e = new Error('Session string userbot rusak/tidak dapat dibaca.');
    e.code = 'SESSION_CORRUPT';
    e.cause = err;
    throw e;
  }
  const c=new TelegramClient(stringSession,config.telegramApiId,config.telegramApiHash,{connectionRetries:3, deviceModel: config.telegramDeviceModel || 'JASEBRICH'});
  await c.connect(); return c;
}
async function assertSessionAuthorizedCached(record, expectedTelegramUserbotId = null, force = false) {
  const expected = expectedTelegramUserbotId == null ? null : String(expectedTelegramUserbotId);
  const now = Date.now();
  if (!force && record.sessionVerifiedAt && now - record.sessionVerifiedAt < SESSION_AUTH_CACHE_MS &&
      (record.sessionVerifiedUserbotId == null || String(record.sessionVerifiedUserbotId) === expected)) {
    return record.sessionVerifiedIdentity || null;
  }
  const me = await assertSessionAuthorized(record.client, expectedTelegramUserbotId);
  record.sessionVerifiedAt = Date.now();
  record.sessionVerifiedUserbotId = expected;
  record.sessionVerifiedIdentity = me || null;
  return me;
}

async function ensureManagedClientLocked(kind, id, asset) {
  const k = keyFor(kind, id);
  let record = clients.get(k);
  if (record?.client) {
    if (record.client.connected === false && typeof record.client.connect === 'function') {
      await record.client.connect();
      record.sessionVerifiedAt = 0;
      record.sessionVerifiedIdentity = null;
    }
    record.assetSnapshot = { ...asset, __kind: kind };
    record.expiresAtMs = subscription.parseTimestamp(asset.expires_at);
    armExpiryTimer(record, asset);
    armSessionHealthTimer(record);
    return record;
  }

  const client = await buildClient(asset.session_string);
  try {
    const identity = await assertSessionAuthorized(client, asset.telegram_userbot_id);
    record = ensureRecord(kind, id);
    record.client = client;
    record.assetSnapshot = { ...asset, __kind: kind };
    record.flags = {
      auto_promosi: Boolean(asset.auto_promosi),
      wtb_reply: Boolean(asset.wtb_reply),
      pm_permit: Boolean(asset.pm_permit),
    };
    record.sessionVerifiedAt = Date.now();
    record.sessionVerifiedUserbotId = asset.telegram_userbot_id == null ? null : String(asset.telegram_userbot_id);
    record.sessionVerifiedIdentity = identity || null;
    record.sessionInvalidNoted = false;
    armExpiryTimer(record, asset);
    armSessionHealthTimer(record);
    return record;
  } catch (err) {
    try { await client.disconnect(); } catch (_) {}
    throw err;
  }
}

async function withClient(kind,id,fn){
  if(!configured()) throw new Error('TELEGRAM_API_ID/API_HASH belum dikonfigurasi.');
  const k = keyFor(kind,id);
  try {
    return await withAssetLock(k, async () => {
      const asset=repoFor(kind).findById(id);
      const liveness=assetLiveness(kind,asset);
      if(!liveness.live && liveness.reason==='SUBSCRIPTION_EXPIRED'){ const e=new Error('Langganan userbot sudah kadaluarsa. Perpanjang langganan untuk menggunakannya kembali.'); e.code='SUBSCRIPTION_EXPIRED'; throw e; }
      if(!liveness.live || !asset.session_string) throw new Error('Userbot belum aktif atau sesi Telegram tidak tersedia.');
      const record = await ensureManagedClientLocked(kind, id, asset);
      await assertSessionAuthorizedCached(record, asset.telegram_userbot_id);
      return await fn(record.client,asset);
    });
  } catch(err){
    if(isSessionInvalidError(err)){
      try { await require('./userbotLifecycle.service').handleSessionInvalid(kind,id); }
      catch (handlerErr) { logger.error(`Session-invalid handling ${k}: ${handlerErr.message}`); }
    }
    throw err;
  }
}

/** Verify a stored MTProto session and keep the verified client managed/reusable. */
async function _verifyAssetSession(kind,id){
  if(!configured()) return { verified:false, status:'RUNTIME_UNAVAILABLE' };
  const asset=repoFor(kind).findById(id);
  if(!asset || !asset.session_string) { const e=new Error('Sesi Telegram tidak tersedia.'); e.code='SESSION_MISSING'; throw e; }
  const reused = Boolean(clients.get(keyFor(kind,id))?.client);
  const record = await ensureManagedClientLocked(kind, id, asset);
  await assertSessionAuthorizedCached(record, asset.telegram_userbot_id);
  return { verified:true, reused, runtimeReconnected: record.client?.connected === true };
}
function verifyAssetSession(kind,id){
  return withAssetLock(keyFor(kind,id),()=>_verifyAssetSession(kind,id)).catch(async (err)=>{
    if(isSessionInvalidError(err)){
      try { await require('./userbotLifecycle.service').handleSessionInvalid(kind,id); }
      catch (handlerErr) { logger.error(`Session-invalid handling ${keyFor(kind,id)}: ${handlerErr.message}`); }
    }
    throw err;
  });
}

function configForAsset(asset){ return asset && asset.__kind === 'pool' ? poolPanelConfig : panelConfig; }
function getConfiguredGroups(assetId, asset, kind = asset && asset.__kind){
  const cfg = configForAsset(asset);
  const rows=cfg.listGroups(assetId).filter(g=>g.enabled);
  const source = rows.length ? rows : (asset.target ? String(asset.target).split(/\n+/).map(x=>x.trim()).filter(Boolean).map(target=>({target,title:null,topic_id:asset.topic_grup||null})) : []);
  // `unusable` is a permanent target decision for this userbot. It is not a
  // temporary cooldown: permanently unsendable targets are removed from the
  // saved configuration at the point they are proven unusable. Keep this
  // health filter as a defensive guard for an in-flight/legacy row, but never
  // resurrect a known-bad target merely because a TTL expired.
  return source.filter((g) => {
    const key = String(g.canonical_id || g.target || '');
    const health = runtimeJobRepo.findTargetHealth(kind, assetId, key) || runtimeJobRepo.findTargetHealthByTarget(kind, assetId, g.target);
    return !health || health.status !== 'unusable';
  });
}

function removePromotionTarget(kind, id, target, reason = null){
  const normalized = String(target || '').trim();
  if (!normalized) return false;
  const asset = repoFor(kind).findById(id);
  if (!asset) return false;
  const assetWithKind = {...asset, __kind:kind};
  const cfg = configForAsset(assetWithKind);
  const row = cfg.listGroups(id).find((g) => String(g.target || '').trim() === normalized);
  let removed = 0;
  if (row) removed = cfg.deleteGroup(id, row.id) ? 1 : 0;
  // Owned userbots still carry the legacy `userbots.target` field. Keep that
  // compatibility field synchronized too, otherwise getConfiguredGroups() can
  // resurrect a removed target when no panel_groups row remains.
  if (asset.target) {
    const targets = String(asset.target).split(/\n+/).map((x)=>x.trim()).filter(Boolean);
    const next = targets.filter((x)=>x !== normalized);
    if (next.length !== targets.length && typeof repoFor(kind).updateConfig === 'function') {
      repoFor(kind).updateConfig(id, { target: next.length ? next.join('\n') : null });
      removed = 1;
    }
  }
  if (removed && reason) logger.warn(`Auto Promosi ${keyFor(kind,id)}: target ${normalized} dihapus dari konfigurasi (${reason}).`);
  return Boolean(removed);
}
function effectiveWtbReplies(assetId, asset){
  const cfg = configForAsset(asset);
  const rows=cfg.listReplies(assetId).filter(r=>r.enabled);
  if(rows.length) return rows;
  return [{keywords:automationConfig.getWtbKeywords().join(','),response:automationConfig.getWtbReplyText()}];
}
function chooseReply(assetId,text,asset){
  const rows=effectiveWtbReplies(assetId,asset);
  const lower=String(text||'').toLowerCase();
  return rows.find(r=>String(r.keywords).split(',').some(k=>k.trim()&&lower.includes(k.trim().toLowerCase())))||null;
}

function passesWtbFilters(text, settings){
  const value=String(text||'').trim();
  if(!value) return false;
  const max=Number(settings.wtb_max_chars||0);
  if(max>0 && value.length>max) return false;
  if(settings.wtb_filter_links && /(https?:\/\/|www\.|t\.me\/)/i.test(value)) return false;
  if(settings.wtb_filter_usernames && /(^|\s)@[A-Za-z0-9_]{3,}/.test(value)) return false;
  const banned=String(settings.wtb_banned_words||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
  const lower=value.toLowerCase();
  if(banned.some(word=>lower.includes(word))) return false;
  return true;
}

async function isWtbTargetAllowed(record,event,settings){
  if(settings.channel_disabled && event.isChannel) return false;
  const target=String(settings.wtb_target_channel||'').trim();
  if(!target) return true;
  const wanted=target.toLowerCase();
  if(String(event.chatId)===wanted) return true;
  if(wanted.startsWith('@')) {
    try {
      const entity=await record.client.getEntity(wanted);
      const entityId=entity?.id!==undefined ? String(entity.id) : '';
      return entityId===String(event.chatId);
    } catch (_) { return false; }
  }
  return false;
}

async function sendAutoReaction(record,event,emoji){
  try {
    const peer=await record.client.getInputEntity(event.chatId);
    const reaction=[new Api.ReactionEmoji({emoticon:String(emoji||'❤️')})];
    await record.client.invoke(new Api.messages.SendReaction({peer,msgId:Number(event.message.id),reaction,addToRecent:false,big:false}));
  } catch(err) {
    logger.warn(`Auto React gagal ${keyFor(record.kind,record.id)}: ${err.message}`);
  }
}
// USER_BANNED_IN_CHANNEL dari ForwardMessages bukan berarti userbot di-ban dari grup —
// melainkan fitur "Lindungi Konten" (NOFORWARDS) Telegram memblokir forward dari sumber.
// sendMessage biasa ke grup yang sama tetap berhasil, jadi ini eligible fallback ke teks.
const FORWARD_FALLBACK_ELIGIBLE_RE = /CHAT_FORWARDS_RESTRICTED|MESSAGE_FORWARDS_RESTRICTED|FORWARDS_RESTRICTED|MESSAGE_FORWARD_RESTRICTED|FORWARD_RESTRICTED|USER_BANNED_IN_CHANNEL/i;
const RETRY_AFTER_RE = /RETRY[_ ]AFTER[\s:=]*([0-9]+)/i;

function extractFloodWaitSeconds(err){
  const raw=String(err?.errorMessage || err?.message || err?.description || err || '');
  const upper=raw.toUpperCase();
  const flood=upper.match(/FLOOD_WAIT[_\s:]*([0-9]+)/);
  if(flood) return Math.max(0,Math.floor(Number(flood[1])));
  const retry=raw.match(RETRY_AFTER_RE);
  if(retry) return Math.max(0,Math.floor(Number(retry[1])));
  const direct=[err?.seconds,err?.retry_after,err?.retryAfter,err?.parameters?.retry_after,err?.response?.parameters?.retry_after];
  for(const value of direct){ const n=Number(value); if(Number.isFinite(n) && n>0) return Math.floor(n); }
  return 0;
}

function forwardFallbackEligible(err){
  return FORWARD_FALLBACK_ELIGIBLE_RE.test(String(err?.errorMessage || err?.message || err?.description || err || ''));
}

function getConfiguredTextFallback(asset){
  const text=String(asset?.broadcast_text || '').trim();
  if(!text) return null;
  let entities=[];
  try { entities=JSON.parse(asset?.broadcast_text_entities || '[]'); } catch (_) { entities=[]; }
  return { text, entities: Array.isArray(entities) ? entities : [] };
}

async function sendConfiguredMessage(client, target, asset, topicId = null){
  const msg=configForAsset(asset).getMessage(asset.id);
  if(!msg) throw new Error('Pesan promosi belum diatur.');
  if(msg.kind==='forward') {
    if(!msg.source_chat_id || !msg.source_message_id) throw new Error('Pesan forward belum lengkap.');
    try {
      await client.forwardMessages(target,{messages:[Number(msg.source_message_id)],fromPeer:msg.source_chat_id,replyTo:topicId ? Number(topicId) : undefined});
      return { delivery:'forward' };
    } catch(err) {
      // Only a forward-specific Telegram restriction can trigger fallback.
      // FloodWait/retry_after, network, auth and target-permission errors stay
      // on their original error path so they can never turn into an extra send.
      if(!forwardFallbackEligible(err) || extractFloodWaitSeconds(err)>0) throw err;
      const fallback=getConfiguredTextFallback(asset);
      if(!fallback) { err.forwardFallbackEligible=true; throw err; }
      await client.sendMessage(target,{message:fallback.text,formattingEntities:fallback.entities.length?botEntitiesToGramJs(fallback.entities):undefined,replyTo:topicId ? Number(topicId) : undefined});
      return { delivery:'text-fallback' };
    }
  }
  let text=msg.text||'';
  const entities = botEntitiesToGramJs((()=>{try{return JSON.parse(msg.entities||'[]')}catch(_){return []}})());
  const captionEntities = botEntitiesToGramJs((()=>{try{return JSON.parse(msg.caption_entities||'[]')}catch(_){return []}})());
  // Watermark is intentionally appended outside the stored entity ranges so
  // original formatting, links and premium custom emoji remain intact.
  // Toggle Aktif/Nonaktif is persisted in watermark_enabled; the stored text is
  // kept while disabled so re-enabling restores it without re-typing.
  if(asset.watermark && asset.watermark_enabled!==0 && msg.kind==='text') text = text ? `${text}\n\n${asset.watermark}` : asset.watermark;
  if(msg.kind==='media' && msg.media_path && fs.existsSync(msg.media_path)) {
    const opts={file:msg.media_path,caption:text||undefined,formattingEntities:captionEntities.length?captionEntities:undefined,replyTo:topicId ? Number(topicId) : undefined};
    if(msg.media_type==='voice') opts.voiceNote=true;
    await client.sendFile(target,opts);
  } else {
    if(!text) throw new Error('Pesan teks kosong.');
    await client.sendMessage(target,{message:text,formattingEntities:entities.length?entities:undefined,replyTo:topicId ? Number(topicId) : undefined});
  }
  return { delivery:'text' };
}

function promotionGroupKey(kind, group) {
  if (kind === 'owned' && group && group.id != null) return String(group.id);
  return String(group && group.target || '');
}

function promotionWorksetHash(kind, groups) {
  const workset = groups.map((group) => ({
    key: promotionGroupKey(kind, group),
    target: String(group && group.target || ''),
    topicId: group && group.topic_id == null ? null : Number(group.topic_id),
  }));
  return crypto.createHash('sha256').update(JSON.stringify(workset)).digest('hex');
}

function resolvePromotionResumeIndex(kind, groups, job) {
  if (!job) return 0;
  if (job.cursor_key != null) {
    const key = String(job.cursor_key);
    const exact = groups.findIndex((group) => promotionGroupKey(kind, group) === key);
    if (exact >= 0) return exact;
  }
  const cursor = Number(job.cursor);
  if (Number.isInteger(cursor) && cursor >= 0 && cursor < groups.length) return cursor;
  return 0;
}

function promotionResumeDelay(job, fallbackMs) {
  if (!job || !job.next_run_at) return Math.max(0, Number(fallbackMs || 0));
  const ts = Date.parse(String(job.next_run_at));
  if (!Number.isFinite(ts)) return 0;
  return Math.max(0, ts - Date.now());
}

function promotionErrorClass(err){
  const raw = String(err?.errorMessage || err?.message || err || '');
  const upper = raw.toUpperCase();
  const seconds = extractFloodWaitSeconds(err);
  if (seconds > 0 || upper.includes('FLOOD_WAIT') || upper.includes('RETRY_AFTER')) return { type:'temporary', floodWaitSeconds:seconds };
  if (err && err.forwardFallbackEligible === true) return { type:'forward_fallback' };
  if (isSessionInvalidError(err)) return { type:'session' };
  // USER_BANNED_IN_CHANNEL dari ForwardMessages bukan ban userbot dari grup —
  // itu adalah NOFORWARDS (Lindungi Konten) dari chat sumber. sendMessage biasa
  // ke grup yang sama tetap berhasil. Tandai sebagai forward_fallback agar target
  // tidak dihapus dan kode pengirim mencoba fallback ke teks.
  if (/USER_BANNED_IN_CHANNEL/i.test(upper) && err && err.forwardFallbackEligible !== false) {
    return { type:'forward_fallback' };
  }
  if (/CHAT_WRITE_FORBIDDEN|CHAT_RESTRICTED|CHAT_SEND_MEDIA_FORBIDDEN|CHAT_SEND_PLAIN_FORBIDDEN|USER_NOT_PARTICIPANT|CHANNEL_PRIVATE|CHAT_ID_INVALID|PEER_ID_INVALID|CHANNEL_INVALID|CHAT_ADMIN_REQUIRED|RIGHT_FORBIDDEN|SLOWMODE_WAIT/i.test(upper)) {
    if (/SLOWMODE_WAIT/i.test(upper)) return { type:'temporary', floodWaitSeconds: Number((upper.match(/SLOWMODE_WAIT[_\s:]*([0-9]+)/)||[])[1] || 0) };
    return { type:'permanent' };
  }
  return { type:'temporary', floodWaitSeconds:0 };
}

async function sendTypingIndicator(client, target){
  if (!Api?.messages?.SetTyping || !Api?.SendMessageTypingAction) return;
  try {
    const peer = await client.getInputEntity(target);
    await client.invoke(new Api.messages.SetTyping({ peer, action: new Api.SendMessageTypingAction() }));
  } catch (err) {
    logger.debug(`Typing indicator dilewati: ${err.message}`);
  }
}

async function resolvePromotionTargetHealth(record, group){
  const target = String(group.target || '').trim();
  const entity = await record.client.getEntity(target);
  if (!isRealGroupEntity(entity)) {
    const key = String(entity?.id ?? target);
    runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:key,target,status:'unusable',error:'Target bukan grup/supergrup yang dapat menerima promosi.'});
    return {usable:false,key};
  }
  const key = String(entity.id ?? target);
  let permissionCheckTransient = false;
  try {
    if (typeof record.client.getPermissions === 'function') {
      const permissions = await record.client.getPermissions(entity, 'me');
      const bannedRights = permissions?.bannedRights || permissions?.participant?.bannedRights;
      if (bannedRights?.sendMessages === true || permissions?.sendMessages === false) {
        runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:key,target,status:'unusable',error:'Userbot tidak memiliki izin mengirim pesan ke target.'});
        return {usable:false,key};
      }
    }
  } catch (err) {
    const classification = promotionErrorClass(err);
    if (classification.type === 'permanent') {
      runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:key,target,status:'unusable',error:err.message});
      return {usable:false,key};
    }
    permissionCheckTransient = true;
    runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:key,target,status:'transient',error:err.message});
  }
  if (!permissionCheckTransient) {
    runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:key,target,status:'healthy'});
  }
  // Entity resolution succeeded, so an actual send is still the strongest
  // capability check available when permissions cannot be inspected due to a
  // transient Telegram/API failure. Do not falsely mark the target healthy;
  // a successful send below will promote it back to healthy.
  return {usable:true,key,entity,permissionCheckTransient};
}

const ubotNotify = require('./ubotNotify.service');
const smartDelay = require('./smartDelay.service');

async function runAutoPromosiCycle(record, runGeneration = record.scheduleGeneration){
  const promotionGeneration = runGeneration;
  const isCurrentRun = () => promotionGeneration === record.scheduleGeneration && Boolean(record.flags.auto_promosi);
  let asset=repoFor(record.kind).findById(record.id); if(!asset||!record.flags.auto_promosi) return {sent:0,total:0};
  asset={...asset,__kind:record.kind};
  if(!assetLiveness(record.kind,asset).live) return {sent:0,total:0,skipped:true};
  const cfg = configForAsset(asset);
  const settings=cfg.getSettings(asset.id);
  if(!parseClockWindow(effectiveTimer(asset))) return {sent:0,total:0,skipped:true};
  let groups=getConfiguredGroups(asset.id,asset,record.kind);
  if(settings.channel_disabled){
    const filtered=[];
    for(const g of groups){ try { const entity=await record.client.getEntity(g.target); if(entity?.broadcast) continue; } catch(_) {} filtered.push(g); }
    groups=filtered;
  }
  if(!groups.length) {
    const existing = runtimeJobRepo.find(record.kind, record.id);
    if (runtimeJobRepo.isRecoverable(existing)) runtimeJobRepo.complete(record.kind, record.id, existing.cycle_id);
    logger.warn(`Auto Promosi ${keyFor(record.kind,record.id)}: belum ada grup target.`);
    return {sent:0,total:0};
  }

  const worksetHash = promotionWorksetHash(record.kind, groups);
  const existing = runtimeJobRepo.find(record.kind, record.id);
  const cycle = runtimeJobRepo.ensureRecoverableCycle(record.kind, record.id, {
    firstCursorKey: promotionGroupKey(record.kind, groups[0]),
    worksetHash,
    totalTargets: groups.length,
  });
  if (!cycle.resumed && cycle.job && Number(cycle.job.total_targets || 0) !== groups.length) {
    // The repository's current cycle is authoritative; this branch is only
    // for legacy rows created before counters existed.
    getDb().prepare('UPDATE userbot_runtime_jobs SET total_targets=? WHERE owner_kind=? AND owner_id=? AND cycle_id=?').run(groups.length, record.kind, record.id, cycle.job.cycle_id);
  }
  const job = cycle.job;
  const startIndex = resolvePromotionResumeIndex(record.kind, groups, cycle.resumed ? job : null);
  setPromotionUiState(record, { phase: 'MENYIAPKAN', currentTarget: startIndex < groups.length ? String(groups[startIndex].target || '-') : '-', waitReason: null, waitUntilMs: null });
  if (startIndex >= groups.length) {
    const roundDelay=cfg.getRoundDelaySeconds(asset.id);
    const waitUntilMs = isCurrentRun() ? Date.now() + roundDelay * 1000 : null;
    const nextRunAt = waitUntilMs == null ? null : new Date(waitUntilMs).toISOString();
    if (waitUntilMs != null) setPromotionUiState(record, { phase: 'JEDA PUTARAN', currentTarget: '-', waitReason: roundDelay > 0 ? `Jeda putaran ${roundDelay} detik` : 'Menyiapkan putaran berikutnya', waitUntilMs });
    else clearPromotionUiState(record);
    runtimeJobRepo.complete(record.kind, record.id, job.cycle_id, {nextRunAt});
    return {sent:0,total:groups.length,resumed:cycle.resumed};
  }

  if (existing && runtimeJobRepo.isRecoverable(existing) && existing.workset_hash && existing.workset_hash !== worksetHash) {
    logger.info(`Auto Promosi ${keyFor(record.kind,record.id)}: target set berubah, checkpoint lama dibuat siklus baru.`);
  } else if (cycle.resumed) {
    logger.info(`Auto Promosi ${keyFor(record.kind,record.id)}: melanjutkan checkpoint target ${startIndex + 1}/${groups.length}.`);
  }

  let sent=0;
  // Atur Jeda -> Jeda Antar Grup is persisted as an inclusive min/max range.
  // A fresh sample is taken for EVERY inter-group interval; the stored range
  // itself is never replaced by the sampled runtime value.
  const groupDelayRange=delayPolicy.readGroupDelayRange(settings, cfg.RECOMMENDED_GROUP_DELAY_SECONDS);

  for(let i=0;i<groups.length;i++){
    if(i<startIndex) continue;
    const g=groups[i];
    if(!isCurrentRun()) break;
    setPromotionUiState(record, { phase: 'MEMERIKSA TARGET', currentTarget: String(g.target || '-'), waitReason: null, waitUntilMs: null });
    const freshAsset = repoFor(record.kind).findById(record.id);
    if(!freshAsset || !assetLiveness(record.kind,freshAsset).live || !freshAsset.auto_promosi || lapsedRecord(record)) {
      logger.info(`Auto Promosi ${keyFor(record.kind,record.id)}: dihentikan (subscription/runtime/feature tidak aktif).`);
      break;
    }

    runtimeJobRepo.updateActivity(record.kind, record.id, job.cycle_id);
    let sessionInvalid = false;
    let targetHealth = null;
    let classification = null;
    try {
      targetHealth = await resolvePromotionTargetHealth(record, g);
      if (!targetHealth.usable) {
        removePromotionTarget(record.kind, record.id, g.target, 'pre-flight target unusable');
        runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:targetHealth.key,target:g.target,status:'unusable',error:'Target permanently tidak dapat digunakan oleh userbot.'});
        runtimeJobRepo.recordTargetResult(record.kind, record.id, job.cycle_id, {failed:true,blocked:true,removed:true,failedCount:1});
        logger.warn(`Auto Promosi ${keyFor(record.kind,record.id)}: target ${g.target} ditandai unusable, dihapus, dan dilewati.`);
        const nextIndex = i + 1;
        if (nextIndex < groups.length) {
          const checkpointed = runtimeJobRepo.checkpoint(record.kind, record.id, job.cycle_id, {cursor:nextIndex,cursorKey:promotionGroupKey(record.kind,groups[nextIndex]),nextRunAt:null});
          if (!checkpointed) throw new Error('Checkpoint Auto Promosi hilang setelah target unusable.');
        } else {
          const roundDelay=cfg.getRoundDelaySeconds(asset.id);
          const waitUntilMs = isCurrentRun() ? Date.now() + roundDelay * 1000 : null;
          const nextRunAt = waitUntilMs == null ? null : new Date(waitUntilMs).toISOString();
          if (waitUntilMs != null) setPromotionUiState(record, { phase: 'JEDA PUTARAN', currentTarget: '-', waitReason: roundDelay > 0 ? `Jeda putaran ${roundDelay} detik` : 'Menyiapkan putaran berikutnya', waitUntilMs });
          else clearPromotionUiState(record);
          runtimeJobRepo.complete(record.kind, record.id, job.cycle_id, {nextRunAt});
        }
        continue;
      }
      setPromotionUiState(record, { phase: 'MENGIRIM', currentTarget: String(g.target || '-'), waitReason: null, waitUntilMs: null });
      await sendTypingIndicator(record.client, g.target);
      let deliveryResult = null;
      try {
        deliveryResult = await sendConfiguredMessage(record.client,g.target,asset,g.topic_id || null);
      } catch(forwardErr) {
        // USER_BANNED_IN_CHANNEL / NOFORWARDS dari ForwardMessages: grup melarang forward
        // dari chat sumber (Lindungi Konten), tapi sendMessage biasa tetap bisa.
        // Coba fallback ke teks tanpa menghapus target.
        if (FORWARD_FALLBACK_ELIGIBLE_RE.test(String(forwardErr?.errorMessage || forwardErr?.message || ''))) {
          const fallback = getConfiguredTextFallback(asset);
          if (fallback) {
            logger.warn(`Auto Promosi ${keyFor(record.kind,record.id)}: forward ke ${g.target} diblokir (NOFORWARDS), fallback ke teks.`);
            await record.client.sendMessage(g.target, {
              message: fallback.text,
              formattingEntities: fallback.entities.length ? botEntitiesToGramJs(fallback.entities) : undefined,
              replyTo: g.topic_id ? Number(g.topic_id) : undefined,
            });
            deliveryResult = { delivery:'text-fallback' };
          } else {
            // Tidak ada teks fallback: tandai transient agar target tidak dihapus.
            forwardErr.forwardFallbackEligible = true;
            throw forwardErr;
          }
        } else {
          throw forwardErr;
        }
      }
      if (deliveryResult) {
        sent++;
        runtimeJobRepo.recordTargetResult(record.kind, record.id, job.cycle_id, {success:true,sentCount:1});
        runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:targetHealth.key,target:g.target,status:'healthy'});
        ubotNotify.recordEvent(record, {type:'success', target:g.target});
        smartDelay.onSuccess(record.kind, record.id, groupDelayRange);
      }
    } catch(err){
      classification = promotionErrorClass(err);
      logger.warn(`Auto Promosi gagal ${g.target}: ${err.message}`);
      if(isSessionInvalidError(err)) { noteSessionInvalid(record); sessionInvalid = true; break; }
      if (classification.type === 'temporary' && classification.floodWaitSeconds > 0) {
        runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:targetHealth?.key || g.target,target:g.target,status:'transient',error:err.message});
        const waitSeconds = Math.max(1, classification.floodWaitSeconds);
        ubotNotify.recordEvent(record, {type:'flood', seconds:waitSeconds, target:g.target});
        smartDelay.onFlood(record.kind, record.id, groupDelayRange, waitSeconds);
        const waitUntilMs = Date.now() + waitSeconds * 1000;
        const nextRunAt = new Date(waitUntilMs).toISOString();
        setPromotionUiState(record, { phase: 'MENUNGGU TELEGRAM', currentTarget: String(g.target || '-'), waitReason: `FloodWait Telegram ${waitSeconds} detik`, waitUntilMs });
        const checkpointed = runtimeJobRepo.checkpoint(record.kind, record.id, job.cycle_id, {cursor:i,cursorKey:promotionGroupKey(record.kind,g),nextRunAt});
        if (!checkpointed) throw new Error('Checkpoint Auto Promosi hilang saat Flood Wait.');
        logger.warn(`Auto Promosi ${keyFor(record.kind,record.id)}: Telegram meminta Flood Wait ${waitSeconds}s; job dipause dan akan dilanjutkan setelahnya.`);
        const completed = await waitPromotionDelay(record, waitSeconds * 1000);
        if (!completed || !isCurrentRun()) break;
        i -= 1;
        continue;
      }
      const permanent = classification.type === 'permanent';
      if (permanent) {
        removePromotionTarget(record.kind, record.id, g.target, err.message);
        runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:targetHealth?.key || g.target,target:g.target,status:'unusable',error:err.message});
      } else {
        runtimeJobRepo.upsertTargetHealth(record.kind, record.id, {targetKey:targetHealth?.key || g.target,target:g.target,status:'transient',error:err.message});
      }
      runtimeJobRepo.recordTargetResult(record.kind, record.id, job.cycle_id, {failed:true,blocked:permanent,removed:permanent,failedCount:1});
      ubotNotify.recordEvent(record, {type:'failed', target:g.target, error:err.message});
      // A permanently unusable target has no reason to consume the configured
      // inter-group delay. The configured delay remains unchanged for valid
      // targets; only this impossible target is fast-skipped.
      if (permanent) {
        const nextIndex = i + 1;
        if (nextIndex < groups.length && record.flags.auto_promosi) {
          const checkpointed = runtimeJobRepo.checkpoint(record.kind, record.id, job.cycle_id, {
            cursor: nextIndex,
            cursorKey: promotionGroupKey(record.kind, groups[nextIndex]),
            nextRunAt: null,
          });
          if (!checkpointed) throw new Error('Checkpoint Auto Promosi hilang setelah target permanent dihapus.');
        }
      }
    }

    // The checkpoint advances only AFTER the Telegram call has returned. This
    // gives restart recovery a durable next-target position. The tiny crash
    // window between a successful Telegram side effect and this DB write is
    // inherently ambiguous because Telegram does not expose a local idempotency
    // key for userbot sends; recovery therefore favors retaining the state and
    // never invents a false delivery result.
    const nextIndex = i + 1;
    if (sessionInvalid) break;

    const permanentTargetFailure = Boolean(classification && classification.type === 'permanent');
    if (permanentTargetFailure && i < groups.length - 1 && record.flags.auto_promosi) {
      // The permanent-failure branch already persisted the immediate
      // next-target checkpoint. Do not apply the normal delay and do not
      // complete the cycle here.
    } else if(i<groups.length-1 && record.flags.auto_promosi){
      // Smart OFF: identical to the manual sample. Smart ON: adaptive within the same range.
      const groupDelay=smartDelay.nextGroupDelay(record.kind,record.id,groupDelayRange);
      const waitUntilMs = Date.now() + Math.max(0, groupDelay) * 1000;
      const nextRunAt = new Date(waitUntilMs).toISOString();
      setPromotionUiState(record, { phase: groupDelay > 0 ? 'JEDA ANTAR GRUP' : 'MENYIAPKAN TARGET BERIKUTNYA', currentTarget: String(groups[nextIndex]?.target || '-'), waitReason: groupDelay > 0 ? `Jeda antar grup ${groupDelay} detik` : null, waitUntilMs: groupDelay > 0 ? waitUntilMs : null });
      const checkpointed = runtimeJobRepo.checkpoint(record.kind, record.id, job.cycle_id, {
        cursor: nextIndex,
        cursorKey: promotionGroupKey(record.kind, groups[nextIndex]),
        nextRunAt,
      });
      if (!checkpointed) throw new Error('Checkpoint Auto Promosi hilang sebelum target berikutnya dapat dipersistenkan.');
      if(groupDelay>0){
        const completed=await waitPromotionDelay(record,groupDelay*1000);
        if(!completed || !isCurrentRun()) break;
      }
    } else {
      const roundDelay=cfg.getRoundDelaySeconds(asset.id);
      const waitUntilMs = isCurrentRun() ? Date.now() + roundDelay * 1000 : null;
      const nextRunAt = waitUntilMs == null ? null : new Date(waitUntilMs).toISOString();
      if (waitUntilMs != null) setPromotionUiState(record, { phase: 'JEDA PUTARAN', currentTarget: '-', waitReason: roundDelay > 0 ? `Jeda putaran ${roundDelay} detik` : 'Menyiapkan putaran berikutnya', waitUntilMs });
      else clearPromotionUiState(record);
      runtimeJobRepo.complete(record.kind, record.id, job.cycle_id, {nextRunAt});
    }
  }

  logger.debug(`Auto Promosi ${keyFor(record.kind,record.id)}: ${sent}/${groups.length} terkirim.`);
  return {sent,total:groups.length,resumed:cycle.resumed};
}

async function scheduleAutoPromosi(record, delayMs=15000){
  if(record.warmup) clearTimeout(record.warmup);
  if(record.timer) clearTimeout(record.timer);
  record.warmup=null; record.timer=null;
  const generation=++record.scheduleGeneration;
  const persistedJob = runtimeJobRepo.find(record.kind, record.id);
  const startupDelay = promotionResumeDelay(persistedJob, delayMs);
  const waitAndRun=async (wait) => {
    if(wait>0) await sleep(wait);
    if(generation!==record.scheduleGeneration || !record.flags.auto_promosi || !record.client) return;
    let result;
    try { result=await runAutoPromosiCycle(record,generation); }
    catch(err){
      const job = runtimeJobRepo.find(record.kind, record.id);
      if (runtimeJobRepo.isRecoverable(job)) runtimeJobRepo.markFailed(record.kind, record.id, job.cycle_id, err && err.message ? err.message : String(err));
      logger.error(`Auto Promosi cycle ${keyFor(record.kind,record.id)}: ${err.message}`);
    }
    if(generation!==record.scheduleGeneration || !record.flags.auto_promosi || !record.client) return;
    const fresh=repoFor(record.kind).findById(record.id);
    if(!fresh || !assetLiveness(record.kind,fresh).live) return;
    const persistedAfterCycle=runtimeJobRepo.find(record.kind,record.id);
    if(persistedAfterCycle?.next_run_at){
      const persistedWait=promotionResumeDelay(persistedAfterCycle,0);
      const ui = record.promotionUi || {};
      if (!ui.phase || !ui.waitUntilMs || ui.waitUntilMs <= Date.now()) {
        setPromotionUiState(record, { phase: 'MENUNGGU JADWAL RUNTIME', currentTarget: '-', waitReason: `Menunggu ${Math.ceil(persistedWait/1000)} detik`, waitUntilMs: Date.now() + persistedWait });
      }
      record.timer=setTimeout(()=>waitAndRun(0),Math.max(0,persistedWait));
      if(typeof record.timer.unref==='function') record.timer.unref();
      return;
    }
    const timerWait=msUntilNextTimerStart(effectiveTimer(fresh));
    if(timerWait>0){ record.timer=setTimeout(()=>waitAndRun(timerWait),0); return; }
    const roundDelay=configForAsset(repoFor(record.kind).findById(record.id)).getRoundDelaySeconds(record.id);
    logger.debug(`Auto Promosi ${keyFor(record.kind,record.id)}: putaran selesai, jeda putaran tetap ${roundDelay}s.`);
    record.timer=setTimeout(()=>waitAndRun(roundDelay*1000),0);
  };
  record.warmup=setTimeout(()=>waitAndRun(0),Math.max(0,startupDelay));
}

async function attach(record){
  if(record.attached) return;
  const handler=async event=>{
    try{
      if(lapsedRecord(record)) return; // subscription ended: drop the event, expiry handling is already scheduled
      const message=event.message; if(!message||message.out) return;
      if((event.isGroup || event.isChannel) && record.flags.wtb_reply){
        const settings=configForAsset(repoFor(record.kind).findById(record.id)).getSettings(record.id);
        const text=(message.message||'');
        const allowed=passesWtbFilters(text,settings) && parseClockWindow(settings.wtb_timer) && await isWtbTargetAllowed(record,event,settings);
        const currentReplyAsset=repoFor(record.kind).findById(record.id);
        const reply=allowed ? chooseReply(record.id,text,{...currentReplyAsset,__kind:record.kind}) : null;
        if(reply){
          const chatKey=String(event.chatId);
          const now=Date.now();
          const resetMs=Math.max(0,Number(settings.wtb_auto_reset_minutes||3))*60000;
          const cooldownMs=Math.max(WTB_REPLY_MIN_COOLDOWN_MS,resetMs);
          const ruleKey=String(reply.id != null ? reply.id : 'default');
          const last=record.wtbLastReplyAt.get(`${chatKey}:${ruleKey}`);
          const coolingDown=Boolean(last) && now < last.claimedAt + cooldownMs;
          if(!coolingDown){
            const claim=baseReplyCooldown.tryClaim(record.kind,record.id,chatKey,ruleKey,cooldownMs,now);
            if(!claim.claimed) {
              // Persistent cooldown already owns/suppresses this trigger.
            } else {
            record.wtbLastReplyAt.set(`${chatKey}:${ruleKey}`,{pending:true,claimedAt:now});
            try{
              const replyEntities=botEntitiesToGramJs((()=>{try{return JSON.parse(reply.entities||'[]')}catch(_){return []}})());
              await message.reply({message:reply.response,formattingEntities:replyEntities.length?replyEntities:undefined});
              const sentAt=Date.now();
              baseReplyCooldown.markSent(record.kind,record.id,chatKey,ruleKey,sentAt);
              record.wtbLastReplyAt.set(`${chatKey}:${ruleKey}`,{pending:false,claimedAt:sentAt});
              if(settings.auto_react) await sendAutoReaction(record,event,settings.auto_react_emoji||'❤️');
            }catch(err){
              baseReplyCooldown.release(record.kind,record.id,chatKey,ruleKey);
              if(last) record.wtbLastReplyAt.set(`${chatKey}:${ruleKey}`,last); else record.wtbLastReplyAt.delete(`${chatKey}:${ruleKey}`);
              throw err;
            }
            }
          }
        }
      }
      if(event.isPrivate && record.flags.pm_permit){ await handlePmPermit(record,event); }
    }catch(err){
      logger.error(`Runtime message handler ${keyFor(record.kind,record.id)}: ${err.message}`);
      if(isSessionInvalidError(err)) noteSessionInvalid(record);
    }
  };
  record.eventBuilder=new NewMessage({incoming:true}); record.client.addEventHandler(handler,record.eventBuilder); record.handler=handler; record.attached=true;
  // Periodic sweep so wtbLastReplyAt never grows unbounded across many
  // distinct chats over a long-running process. Recomputes the real
  // per-chat cooldown from current settings each sweep (never a fixed
  // guess), so an entry is only ever dropped once its actual cooldown has
  // genuinely expired — an active Auto Reset window is never cut short.
  if(record.wtbCooldownPruneTimer) clearInterval(record.wtbCooldownPruneTimer);
  record.wtbCooldownPruneTimer=setInterval(()=>pruneWtbCooldowns(record),WTB_COOLDOWN_PRUNE_INTERVAL_MS);
  if(typeof record.wtbCooldownPruneTimer.unref==='function') record.wtbCooldownPruneTimer.unref();
}
function pruneWtbCooldowns(record){
  if(!record.wtbLastReplyAt.size) return;
  let resetMs=0;
  try{ const cfg=configForAsset(repoFor(record.kind).findById(record.id)||{__kind:record.kind}); resetMs=Math.max(0,Number(cfg.getSettings(record.id).wtb_auto_reset_minutes||0))*60000; }catch(_){}
  const cooldownMs=Math.max(WTB_REPLY_MIN_COOLDOWN_MS,resetMs);
  const now=Date.now();
  for(const [chatKey,entry] of record.wtbLastReplyAt){
    if(entry.pending) continue; // never prune an in-flight claim
    if(now-entry.claimedAt>cooldownMs) record.wtbLastReplyAt.delete(chatKey);
  }
}
// Telegram/GramJS error strings that mean sending is PERMANENTLY impossible
// for this peer (blocked us, deleted account, privacy settings) — as
// opposed to a transient error (FloodWait, network hiccup, generic RPC
// timeout) where the claim must be released so a later message from the
// same peer can try again instead of the user being silently ignored
// forever.
const PERMANENT_PM_ERROR = /USER_IS_BLOCKED|USER_DEACTIVATED|USER_DEACTIVATED_BAN|PRIVACY_RESTRICTED|USER_ID_INVALID|PEER_ID_INVALID/i;

/**
 * PM Permit for one incoming private message.
 *
 * Each peer is scoped to THIS userbot (owned/pool #id). A successful response
 * is allowed again only after the persistent rolling 24-hour window expires.
 * The state survives restart because the claim and last_responded_at live in
 * SQLite rather than an in-memory timer.
 *
 * Idempotency: pmPermitState.tryClaim() performs an atomic claim against the
 * UNIQUE(owner_kind, owner_id, peer_id) key. Only one concurrent handler can
 * own the send slot for a peer/window; a transient send failure releases the
 * claim without recording a successful response.
 */
async function handlePmPermit(record,event){
  // GramJS's NewMessageEvent itself has no getSender(); the sender resolver
  // lives on the wrapped message object. Calling event.getSender() throws
  // "event.getSender is not a function" on every single incoming PM,
  // which was being swallowed by attach()'s outer try/catch — so PM Permit
  // silently never ran at all, regardless of config/idempotency logic.
  const sender=await event.message.getSender();
  if(!sender||sender.bot||sender.self||sender.contact===true) return;
  const peerId=sender.id!==undefined && sender.id!==null ? String(sender.id) : null;
  if(!peerId) return; // no stable identifier to key idempotent state on — refuse to guess

  const claim=pmPermitState.tryClaim(record.kind,record.id,peerId);
  if(!claim.claimed) return; // already sent / already skipped / another in-flight claim owns this peer

  const cfg=configForAsset({...repoFor(record.kind).findById(record.id),__kind:record.kind}).getPmPermitMessage(record.id);
  if(!cfg || !cfg.text){
    // Nothing configured to send. Release the claim rather than burning it
    // as "sent", so PM Permit works retroactively once a message is set
    // without needing this peer to message again after some other event.
    pmPermitState.releaseClaim(record.kind,record.id,peerId);
    return;
  }

  try {
    await sendTypingIndicator(record.client, event.chatId);
    const entities=botEntitiesToGramJs((()=>{try{return JSON.parse(cfg.entities||'[]')}catch(_){return []}})());
    await event.message.reply({message:cfg.text,formattingEntities:entities.length?entities:undefined});
    pmPermitState.markSent(record.kind,record.id,peerId);
  } catch(err){
    const message=String(err && err.message || err);
    if(PERMANENT_PM_ERROR.test(message)){
      pmPermitState.markSkipped(record.kind,record.id,peerId);
      logger.warn(`PM Permit ${keyFor(record.kind,record.id)} -> ${peerId}: permanen, dilewati (${message}).`);
    } else {
      // Transient (FloodWait/network/RPC): release so a later message from
      // this same peer gets a genuine retry instead of silence forever,
      // but never re-send for THIS event — no loop, no immediate retry.
      pmPermitState.releaseClaim(record.kind,record.id,peerId);
      logger.warn(`PM Permit ${keyFor(record.kind,record.id)} -> ${peerId}: gagal sementara, akan dicoba lagi (${message}).`);
    }
  }
}

function ensureRecord(kind,id){ const k=keyFor(kind,id); let r=clients.get(k); if(!r){r={kind,id,client:null,flags:{auto_promosi:false,wtb_reply:false,pm_permit:false},timer:null,warmup:null,scheduleGeneration:0,attached:false,wtbLastReplyAt:new Map(),promotionDelayWaits:new Set(),promotionUi:null,expiryTimer:null,expiresAtMs:null,sessionHealthTimer:null,expiring:false,sessionInvalidNoted:false,sessionVerifiedAt:0,sessionVerifiedUserbotId:null,sessionVerifiedIdentity:null};clients.set(k,r);} return r; }

// UNLOCKED primitives — only ever called from inside withAssetLock().
async function _teardown(kind,id){
  const k=keyFor(kind,id),r=clients.get(k); if(!r)return;
  r.scheduleGeneration=(r.scheduleGeneration||0)+1;
  cancelPromotionDelayWaits(r);
  if(r.timer)clearTimeout(r.timer);
  if(r.warmup)clearTimeout(r.warmup);
  if(r.wtbCooldownPruneTimer)clearInterval(r.wtbCooldownPruneTimer);
  clearExpiryTimer(r);
  clearSessionHealthTimer(r);
  // Unregister the message listener before disconnecting so a late event can
  // never reach a handler of a runtime that has been torn down.
  if(r.client && r.handler){ try{ r.client.removeEventHandler(r.handler,r.eventBuilder); }catch(_){} r.handler=null; r.eventBuilder=null; r.attached=false; }
  r.flags={auto_promosi:false,wtb_reply:false,pm_permit:false};
  r.sessionVerifiedAt=0; r.sessionVerifiedIdentity=null;
  if(r.client){try{await r.client.disconnect();}catch(_){}}
  clients.delete(k);
}
async function _sync(kind,id){
  if(!configured()) return;
  const asset=repoFor(kind).findById(id); if(!asset){ runtimeJobRepo.cancel(kind,id,'userbot removed'); await _teardown(kind,id);return;}
  // Liveness is derived from status AND expires_at (see assetLiveness).
  const live=assetLiveness(kind,asset).live;
  const access = {
    auto_promosi: featureAccessSvc.checkAssetFeature(asset, 'auto_promosi', kind).allowed,
    base_reply: featureAccessSvc.checkAssetFeature(asset, 'base_reply', kind).allowed,
    pm_permit: featureAccessSvc.checkAssetFeature(asset, 'pm_permit', kind).allowed,
  };
  if (asset.auto_promosi && !access.auto_promosi) repoFor(kind).setFlags(id,{autoPromosi:false});
  if (asset.wtb_reply && !access.base_reply) repoFor(kind).setFlags(id,{wtbReply:false});
  if (asset.pm_permit && !access.pm_permit) repoFor(kind).setFlags(id,{pmPermit:false});
  const effectiveAsset = repoFor(kind).findById(id) || asset;
  const any=Boolean(effectiveAsset.auto_promosi||effectiveAsset.wtb_reply||effectiveAsset.pm_permit);
  const managedClientExists = Boolean(clients.get(keyFor(kind,id))?.client);
  // An explicit Auto Promosi OFF is a user command, not a process crash.
  // Cancel its checkpoint so the next deliberate Start begins a fresh cycle.
  if(!asset.auto_promosi) runtimeJobRepo.cancel(kind,id,'auto_promosi disabled');
  // An expired/non-live asset must never be resumed automatically. A missing
  // session, however, can be a login/recovery phase; preserve its checkpoint.
  if(!live||!asset.session_string||(!any && !managedClientExists)){await _teardown(kind,id);return;}
  const runtimeAsset={...effectiveAsset,__kind:kind};
  const r=ensureRecord(kind,id); r.flags={auto_promosi:Boolean(effectiveAsset.auto_promosi),wtb_reply:Boolean(effectiveAsset.wtb_reply),pm_permit:Boolean(effectiveAsset.pm_permit)};
  r.assetKind=kind;
  r.assetSnapshot=runtimeAsset;
  if(!r.client){
    let c=null;
    try{
      c=await buildClient(asset.session_string);
      const identity = await assertSessionAuthorized(c, asset.telegram_userbot_id);
      r.client=c;
      r.sessionVerifiedAt=Date.now();
      r.sessionVerifiedUserbotId=asset.telegram_userbot_id == null ? null : String(asset.telegram_userbot_id);
      r.sessionVerifiedIdentity=identity || null;
    }catch(err){
      if(c){try{await c.disconnect();}catch(_){}}
      clients.delete(keyFor(kind,id));
      throw err;
    }
  }
  if (r.client && r.client.connected === false && typeof r.client.connect === 'function') {
    await r.client.connect();
    r.sessionVerifiedAt=0;
    r.sessionVerifiedIdentity=null;
  }
  armExpiryTimer(r,asset);
  armSessionHealthTimer(r);
  r.sessionInvalidNoted=false;
  // A verified, live session supersedes any earlier SESSION_INVALID flag.
  if(kind==='owned' && asset.runtime_stop_reason) ownedRepo.setRuntimeStopReason(id,null);
  if(!any){
    // A managed client may be intentionally kept alive for control-panel work
    // even when no background automation is enabled. Do not disconnect it here;
    // only explicit lifecycle teardown, expiry, invalid-session handling, or
    // application shutdown is allowed to destroy the managed connection.
    r.scheduleGeneration=(r.scheduleGeneration||0)+1;
    cancelPromotionDelayWaits(r);
    if(r.timer)clearTimeout(r.timer);
    if(r.warmup)clearTimeout(r.warmup);
    r.timer=null; r.warmup=null;
    return;
  }
  await attach(r);
  r.scheduleGeneration=(r.scheduleGeneration||0)+1;
  cancelPromotionDelayWaits(r);
  if(r.timer)clearTimeout(r.timer);
  if(r.warmup)clearTimeout(r.warmup);
  r.timer=null;r.warmup=null;
  if(r.flags.auto_promosi){
    scheduleAutoPromosi(r,15000);
  }
}
function teardownAsset(kind,id){ return withAssetLock(keyFor(kind,id),()=>_teardown(kind,id)); }
function syncAsset(kind,id){
  return withAssetLock(keyFor(kind,id),()=>_sync(kind,id)).catch(async (err)=>{
    if(isSessionInvalidError(err)){
      try { await require('./userbotLifecycle.service').handleSessionInvalid(kind,id); }
      catch (handlerErr) { logger.error(`Session-invalid handling ${keyFor(kind,id)}: ${handlerErr.message}`); }
    }
    throw err;
  });
}

// Stops the runtime ONLY if the database says the asset is not live — used by
// sweeps as a safety net; never restarts anything and never resets timers of
// assets that are healthy.
function teardownIfNotLive(kind,id){
  return withAssetLock(keyFor(kind,id),async()=>{
    if(!clients.has(keyFor(kind,id))) return false;
    if(isLiveFresh(kind,id)) return false;
    await _teardown(kind,id); return true;
  });
}
async function reconcileDeadRuntimes(){
  let stopped=0;
  for(const k of Array.from(clients.keys())){
    const [kind,idStr]=k.split(':');
    if(await teardownIfNotLive(kind,Number(idStr))) stopped++;
  }
  return stopped;
}
function rescheduleAutoPromosiTimers(){ for(const r of clients.values()) syncAsset(r.kind,r.id).catch(e=>logger.warn(`reschedule ${keyFor(r.kind,r.id)}: ${e.message}`)); }
async function bootstrapAll(){
  if(!configured()){logger.warn('Userbot runtime: API Telegram belum dikonfigurasi.');return;}
  for(const row of ownedRepo.listAutomatedActive()) {
    // Expired rows are skipped here by assetLiveness() inside syncAsset();
    // a session already known to be dead is not retried on every boot.
    if(row.runtime_stop_reason==='SESSION_INVALID') continue;
    await syncAsset('owned',row.id).catch(e=>{
      logger.error(`bootstrap owned #${row.id}: ${e.message}`);
      if(isSessionInvalidError(e)) require('./userbotLifecycle.service').handleSessionInvalid('owned',row.id).catch(()=>{});
    });
  }
  for(const row of poolRepo.listAutomatedAssigned()) await syncAsset('pool',row.id).catch(e=>logger.error(`bootstrap pool #${row.id}: ${e.message}`));
}
async function shutdownAll(){for(const k of Array.from(clients.keys())){const [kind,id]=k.split(':');await teardownAsset(kind,Number(id));}}
function getRuntimeStats(){
  let running=0;
  let promotionRunning=0;
  let runtimeRecords=0;
  for(const r of clients.values()){
    runtimeRecords++;
    if(r.client) running++;
    if(r.client && r.flags && r.flags.auto_promosi) promotionRunning++;
  }
  return { runtimeRecords, running, promotionRunning };
}

function isRunning(kind,id){return clients.has(keyFor(kind,id));}

// Reflects the userbot's real, active promotion runtime (a live GramJS
// client with the auto_promosi flag on and its schedule engaged) — the
// single source of truth "🚀/⏹ Mulai Promosi / Stop Promosi" is toggled
// from. Never a separate boolean; always derived from the same `clients`
// registry syncAsset itself maintains, so it can never drift out of sync
// with what the runtime is actually doing (including after a process
// restart, since bootstrapAll() rebuilds this registry from the database
// before anything reads it).
function isAutoPromosiActive(kind,id){
  const r=clients.get(keyFor(kind,id));
  return Boolean(r && r.client && r.flags && r.flags.auto_promosi);
}
function isFeatureActive(kind,id,featureId){
  const r=clients.get(keyFor(kind,id));
  const flag={auto_promosi:'auto_promosi',base_reply:'wtb_reply',pm_permit:'pm_permit'}[String(featureId)];
  return Boolean(r && r.client && flag && r.flags && r.flags[flag]);
}

async function getForwardPreview(kind,id) {
  return withClient(kind,id,async (client,asset)=>{
    const msg=configForAsset({...asset,__kind:kind}).getMessage(asset.id);
    if(!msg || msg.kind!=='forward') return null;
    const source=await client.getMessages(msg.source_chat_id,{ids:[Number(msg.source_message_id)]});
    const item=Array.isArray(source)?source[0]:source;
    if(!item) return null;
    return {
      text:item.message||'',
      hasMedia:Boolean(item.media),
      sourceChatId:String(msg.source_chat_id),
      sourceMessageId:Number(msg.source_message_id),
      date:item.date||null,
    };
  });
}

async function sendToTarget(kind,id,target){ return withClient(kind,id,(client,asset)=>sendConfiguredMessage(client,target,asset)); }
async function broadcastPm(kind,id){
  return withClient(kind,id,async(client,asset)=>{
    const msg=panelConfig.getBroadcastPmMessage(id);
    if(!msg) throw new Error('Pesan Broadcast PM belum diatur.');
    let sent=0,total=0,failed=0;
    const delay=Math.max(1000,Number(panelConfig.getSettings(id).group_delay_seconds||5)*1000);
    for await (const dialog of client.iterDialogs({})) {
      const entity=dialog.entity;
      const isPrivate=Boolean(entity && entity.className==='User' && !entity.bot && !entity.self && !entity.deleted);
      if(!isPrivate) continue;
      total++;
      try {
        if(msg.kind==='forward' && msg.source_chat_id && msg.source_message_id){
          const input=await client.getInputEntity(entity);
          await client.forwardMessages(input,{messages:[Number(msg.source_message_id)],fromPeer:msg.source_chat_id});
        } else if(msg.kind==='media' && msg.media_path && fs.existsSync(msg.media_path)){
          const caption=msg.text||''; const ce=botEntitiesToGramJs((()=>{try{return JSON.parse(msg.caption_entities||'[]')}catch(_){return []}})());
          const opts={file:msg.media_path,caption:caption||undefined,formattingEntities:ce.length?ce:undefined};
          if(msg.media_type==='voice') opts.voiceNote=true;
          await client.sendFile(await client.getInputEntity(entity),opts);
        } else {
          const entities=botEntitiesToGramJs((()=>{try{return JSON.parse(msg.entities||'[]')}catch(_){return []}})());
          if(!msg.text) throw new Error('Pesan teks kosong.');
          await client.sendMessage(await client.getInputEntity(entity),{message:msg.text,formattingEntities:entities.length?entities:undefined});
        }
        sent++;
      } catch(e){ failed++; logger.warn(`Broadcast PM gagal ${dialog.id}: ${e.message}`); }
      await sleep(delay);
    }
    return {sent,total,failed};
  });
}

async function getDialogs(kind,id){ return withClient(kind,id,async client=>{const dialogs=await client.getDialogs({limit:500});return dialogs.map(d=>({id:String(d.id),title:d.title||String(d.id),isGroup:Boolean(d.isGroup),isChannel:Boolean(d.isChannel),username:d.entity?.username||null}));}); }
async function joinGroup(kind,id,target){return withClient(kind,id,async client=>{const entity=await client.getInputEntity(target);try{await client.invoke(new Api.channels.JoinChannel({channel:entity}));}catch(e){throw new Error(`Gagal bergabung: ${e.message}`);}return true;});}
async function leaveGroup(kind,id,target){return withClient(kind,id,async client=>{
  const entity=await client.getEntity(target);
  if(entity?.className==='Chat'){
    const me=await client.getMe();
    await client.invoke(new Api.messages.DeleteChatUser({chatId:toBigInteger(entity.id),userId:await client.getInputEntity(me),revokeHistory:false}));
  } else if(entity?.className==='Channel'){
    if(!entity.megagroup && !entity.broadcast) throw new Error('Target channel tidak dapat ditinggalkan sebagai grup.');
    await client.invoke(new Api.channels.LeaveChannel({channel:await client.getInputEntity(entity)}));
  } else {
    throw new Error('Target bukan grup Telegram yang dapat ditinggalkan.');
  }
  return true;
});}

// Distinguishes a real GROUP/SUPERGROUP (valid promo target) from a
// broadcast CHANNEL (never a valid target) using the actual GramJS entity,
// not just chat_id shape. Telegram entities: basic groups are className
// 'Chat'; supergroups AND broadcast channels are both className 'Channel',
// told apart only by the `megagroup` flag (true = supergroup/discussion
// group, falsy = broadcast channel). A linked discussion group of a
// channel is itself a real supergroup dialog (megagroup:true) the userbot
// is a member of, so it is picked up here on its own merit — the source
// broadcast channel dialog is excluded.
function isRealGroupEntity(entity) {
  if (!entity) return false;
  if (entity.className === 'Chat') return !entity.deactivated; // basic group, not migrated/deleted
  if (entity.className === 'Channel') return Boolean(entity.megagroup) && !entity.broadcast;
  return false;
}

// Real dialog scan used by "👥 Atur Grup" -> "🌐 Topik Grup" / "💡 Tambah
// Grup": lists every actual GROUP/SUPERGROUP (never a broadcast channel —
// see isRealGroupEntity) the userbot session is a member of via GramJS,
// and for forum (topic-enabled) supergroups also resolves a real usable
// topic id in the SAME client connection (one connect per scan, not one
// per group). No manual typing, no placeholder data — every row comes
// straight from the userbot's live Telegram dialogs.
async function scanGroups(kind, id) {
  return withClient(kind, id, async (client) => {
    const dialogs = await client.getDialogs({ limit: 500 });
    const out = [];
    for (const d of dialogs) {
      const entity = d.entity;
      if (!isRealGroupEntity(entity)) continue;
      const isForum = entity.className === 'Channel' && Boolean(entity.forum);
      const target = entity.username ? `@${entity.username}` : String(d.id);
      let topicId = null;
      if (isForum) {
        try {
          const result = await client.invoke(new Api.channels.GetForumTopics({
            channel: entity, offsetDate: 0, offsetId: 0, offsetTopic: 0, limit: 100,
          }));
          const topics = (result.topics || []).filter((t) => t.className === 'ForumTopic');
          const open = topics.find((t) => !t.closed) || topics[0];
          // Telegram's built-in "General" topic is always id 1 — safe
          // fallback if the account has no other topics visible yet or
          // the API call above fails for a permission-related reason.
          topicId = open ? Number(open.id) : null;
        } catch (err) {
          logger.warn(`GetForumTopics gagal untuk ${target}: ${err.message}`);
          topicId = null;
        }
        await sleep(250); // gentle pacing across many forum groups in one scan
      }
      out.push({ target, title: d.title || target, isForum, topicId, id: String(d.id) });
    }
    return out;
  });
}

// Telegram/GramJS error strings that mean a target is PERMANENTLY gone
// (userbot left/kicked, chat deleted, id no longer resolvable) — as
// opposed to a transient network/flood error, which must never cause a
// saved target to be dropped.
const PERMANENT_TARGET_ERROR = /CHANNEL_INVALID|CHAT_ID_INVALID|PEER_ID_INVALID|CHANNEL_PRIVATE|CHAT_RESTRICTED|CHAT_WRITE_FORBIDDEN|CHAT_SEND_MEDIA_FORBIDDEN|CHAT_SEND_PLAIN_FORBIDDEN|USER_BANNED_IN_CHANNEL|USER_NOT_PARTICIPANT|CHAT_ID_EMPTY|not a member|access denied|entity not found|Cannot find any entity/i;

// Re-validates every saved target group for this userbot against the
// userbot's real, live Telegram session — used by "💡 Tambah Grup" so a
// group the userbot has since left (or that stopped being a valid
// group/supergroup) is dropped automatically instead of lingering in the
// database forever. Returns which saved rows are still good and which are
// permanently invalid; rows that fail with a transient/ambiguous error are
// left untouched (reported separately) rather than guessed at.
async function validateGroupTargets(kind, id) {
  return withClient(kind, id, async (client) => {
    const asset = repoFor(kind).findById(id);
    const cfg = configForAsset({...asset,__kind:kind});
    const rows = cfg.listGroups(id);
    const valid = [];
    const invalid = [];
    const uncertain = [];
    for (const row of rows) {
      try {
        const entity = await client.getEntity(row.target);
        if (isRealGroupEntity(entity)) {
          const key=String(entity.id ?? row.target);
          let sendAllowed = true;
          try {
            if (typeof client.getPermissions === 'function') {
              const permissions = await client.getPermissions(entity, 'me');
              const bannedRights = permissions?.bannedRights || permissions?.participant?.bannedRights;
              sendAllowed = !(bannedRights?.sendMessages === true || permissions?.sendMessages === false);
            }
          } catch (permissionErr) {
            const permissionClass = promotionErrorClass(permissionErr);
            if (permissionClass.type === 'permanent') {
              removePromotionTarget(kind, id, row.target, permissionErr.message);
              runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:key,target:row.target,status:'unusable',error:permissionErr.message});
              invalid.push(row);
              continue;
            }
            runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:key,target:row.target,status:'transient',error:permissionErr.message});
            uncertain.push(row);
            continue;
          }
          if (!sendAllowed) {
            const reason='Userbot tidak memiliki izin mengirim pesan ke target.';
            removePromotionTarget(kind,id,row.target,reason);
            runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:key,target:row.target,status:'unusable',error:reason});
            invalid.push(row);
          } else {
            runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:key,target:row.target,status:'healthy'});
            valid.push(row);
          }
        } else {
          const key=String(entity?.id ?? row.target);
          removePromotionTarget(kind, id, row.target, 'validasi target bukan grup/supergrup');
          runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:key,target:row.target,status:'unusable',error:'Target bukan grup/supergrup yang dapat menerima promosi.'});
          invalid.push(row);
        }
      } catch (err) {
        const permanent=PERMANENT_TARGET_ERROR.test(String(err.message || ''));
        if (permanent) {
          removePromotionTarget(kind, id, row.target, err.message);
          runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:String(row.target),target:row.target,status:'unusable',error:err.message});
          invalid.push(row);
        } else {
          runtimeJobRepo.upsertTargetHealth(kind,id,{targetKey:String(row.target),target:row.target,status:'transient',error:err.message});
          uncertain.push(row);
        }
      }
    }
    return { valid, invalid, uncertain };
  });
}

async function scanUnusableGroups(kind, id) {
  return withClient(kind, id, async (client) => {
    const dialogs = await client.getDialogs({ limit: 500 });
    const out = [];
    for (const d of dialogs) {
      const entity = d.entity;
      if (!isRealGroupEntity(entity)) continue;
      const target = entity.username ? `@${entity.username}` : String(d.id);
      const idValue = String(entity.id ?? d.id);
      try {
        if (typeof client.getPermissions !== 'function') continue;
        const permissions = await client.getPermissions(entity, 'me');
        const bannedRights = permissions?.bannedRights || permissions?.participant?.bannedRights;
        if (bannedRights?.sendMessages === true || permissions?.sendMessages === false) {
          out.push({ id: idValue, target, title: d.title || target, reason: 'Tidak memiliki izin mengirim pesan.' });
        }
      } catch (err) {
        const classification = promotionErrorClass(err);
        if (classification.type === 'permanent') {
          out.push({ id: idValue, target, title: d.title || target, reason: err.message || 'Target tidak dapat digunakan.' });
        } else {
          logger.debug(`Scan unusable ${target} dilewati karena error sementara: ${err.message}`);
        }
      }
    }
    return out;
  });
}

// Real GramJS check (and, when possible, automatic join) confirming the
// userbot can actually read the forwarded message's source chat — used
// right before a "🌐 Pesan Forward" source is saved, so a forward target
// never silently fails at send time just because the userbot was never a
// member of the origin channel/group.
async function ensureForwardAccess(kind, id, { chatId, messageId, username }) {
  return withClient(kind, id, async (client) => {
    const target = username ? `@${username}` : chatId;
    const tryFetch = async (t) => {
      const res = await client.getMessages(t, { ids: [Number(messageId)] });
      const item = Array.isArray(res) ? res[0] : res;
      if (!item) throw new Error('Pesan asal tidak ditemukan (kemungkinan sudah dihapus).');
      return item;
    };
    try {
      await tryFetch(target);
      return { joined: false };
    } catch (err) {
      // Bot API never gives us an invite link for a private chat, so a
      // channel/group with no public @username genuinely can't be
      // auto-joined — say so plainly instead of pretending it worked.
      if (!username) {
        throw new Error('Userbot belum bergabung ke chat asal, dan chat ini tidak memiliki username publik sehingga tidak bisa digabungkan otomatis. Gabungkan userbot ke chat tersebut secara manual (mis. lewat 👥 Atur Grup → 🔗 Gabung Grup jika berupa grup), lalu forward ulang pesannya.');
      }
      try {
        const entity = await client.getInputEntity(`@${username}`);
        await client.invoke(new Api.channels.JoinChannel({ channel: entity }));
      } catch (joinErr) {
        throw new Error(`Gagal bergabung otomatis ke @${username}: ${joinErr.message}`);
      }
      await tryFetch(`@${username}`); // confirm the join actually unlocked access
      return { joined: true };
    }
  });
}

function getPromotionStatus(kind,id){
  const asset = repoFor(kind).findById(id);
  const job = runtimeJobRepo.find(kind,id);
  const groups = asset ? getConfiguredGroups(id,{...asset,__kind:kind},kind) : [];
  const total = Number(job?.total_targets || 0);
  const processed = Number(job?.processed_targets || 0);
  const remaining = Math.max(0, total - processed);
  const startedMs = job?.started_at ? Date.parse(String(job.started_at)) : NaN;
  const elapsedMs = Number.isFinite(startedMs) ? Math.max(0, Date.now() - startedMs) : 0;
  const throughput = processed > 0 && elapsedMs > 0 ? processed / (elapsedMs / 1000) : 0;
  const etaSeconds = throughput > 0 ? Math.ceil(remaining / throughput) : null;
  const progress = total > 0 ? Math.min(100, Math.floor((processed / total) * 100)) : 0;
  const lastActivity = job?.last_activity_at || job?.heartbeat_at || null;
  const nextRunMs = job?.next_run_at ? Date.parse(String(job.next_run_at)) : NaN;
  const roundPauseRemainingSeconds = job?.status === 'idle' && Number.isFinite(nextRunMs)
    ? Math.max(0, Math.ceil((nextRunMs - Date.now()) / 1000))
    : null;
  const roundPaused = job?.status === 'idle' && roundPauseRemainingSeconds != null && roundPauseRemainingSeconds > 0;
  const runtimeRecord = clients.get(keyFor(kind,id));
  const ui = runtimeRecord?.promotionUi || null;
  const uiWaitRemainingSeconds = ui?.waitUntilMs ? Math.max(0, Math.ceil((Number(ui.waitUntilMs) - Date.now()) / 1000)) : null;
  const timerWaitMs = asset ? msUntilNextTimerStart(effectiveTimer(asset)) : 0;
  let phase = ui?.phase || null;
  let currentTarget = ui?.currentTarget || null;
  let waitReason = ui?.waitReason || null;
  let waitRemainingSeconds = uiWaitRemainingSeconds;
  if (isAutoPromosiActive(kind,id)) {
    if (roundPaused) {
      phase = 'JEDA PUTARAN';
      currentTarget = '-';
      waitReason = `Menunggu putaran berikutnya (${roundPauseRemainingSeconds} detik)`;
      waitRemainingSeconds = roundPauseRemainingSeconds;
    } else if (timerWaitMs > 0 && !waitRemainingSeconds) {
      phase = 'MENUNGGU JADWAL';
      currentTarget = '-';
      waitReason = `Di luar jam timer, menunggu ${Math.ceil(timerWaitMs/1000)} detik`;
      waitRemainingSeconds = Math.ceil(timerWaitMs/1000);
    } else if (!phase) {
      phase = 'MENYIAPKAN';
    }
  }
  let status = 'TIDAK AKTIF';
  if (roundPaused && isAutoPromosiActive(kind,id)) status = 'JEDA PUTARAN';
  else if (isAutoPromosiActive(kind,id)) status = 'AKTIF';
  else if (job?.status === 'failed') status = 'GAGAL';
  else if (job?.status === 'cancelled') status = 'BERHENTI';
  else if (job?.status === 'idle' && total > 0 && processed >= total && !job?.next_run_at) status = 'SELESAI';
  return {
    status,
    totalGroups: total || groups.length, processedGroups: processed, successfulGroups: Number(job?.successful_targets || 0),
    failedGroups: Number(job?.failed_targets || 0), blockedGroups: Number(job?.blocked_targets || 0), removedGroups: Number(job?.removed_targets || 0),
    sentCount: Number(job?.sent_count || 0), failedCount: Number(job?.failed_count || 0), cycle: Number(job?.cycle_number || 0),
    progress, remainingGroups: remaining, startedAt: job?.started_at || null, lastActivity, etaSeconds,
    roundPauseRemainingSeconds,
    phase: phase || (status === 'AKTIF' ? 'MENYIAPKAN' : status),
    currentTarget: currentTarget || '-',
    waitReason: waitReason || (waitRemainingSeconds != null && waitRemainingSeconds > 0 ? `Menunggu ${waitRemainingSeconds} detik` : '-'),
    waitRemainingSeconds,
    remainingTime: etaSeconds == null ? null : etaSeconds, interval: asset ? delayPolicy.formatGroupDelayRange(delayPolicy.readGroupDelayRange(configForAsset({...asset,__kind:kind}).getSettings(id), configForAsset({...asset,__kind:kind}).RECOMMENDED_GROUP_DELAY_SECONDS)) : null,
    runtimeStatus: isRunning(kind,id) ? 'CONNECTED' : 'DISCONNECTED', userbotId: asset?.id ?? id, packageName: asset?.label || asset?.package_name || '-',
    expiresAt: asset?.expires_at || null, remaining: asset?.expires_at ? Math.max(0, Math.floor((Date.parse(asset.expires_at)-Date.now())/1000)) : null,
  };
}

module.exports={syncAsset,teardownAsset,teardownIfNotLive,reconcileDeadRuntimes,assetLiveness,isSessionInvalidError,verifyAssetSession,bootstrapAll,shutdownAll,rescheduleAutoPromosiTimers,getRuntimeStats,isRunning,isAutoPromosiActive,isFeatureActive,getPromotionStatus,sendToTarget,broadcastPm,getDialogs,scanGroups,scanUnusableGroups,validateGroupTargets,joinGroup,leaveGroup,ensureForwardAccess,sendConfiguredMessage,getForwardPreview,botEntitiesToGramJs};
