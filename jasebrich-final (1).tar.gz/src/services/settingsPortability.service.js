const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const { getDb } = require('../database');

/**
 * Full bot-configuration portability.
 *
 * The old implementation exported only the `settings` table. That missed
 * configuration stored in other dedicated tables (currently payment_config
 * and custom submenu content), so an export/import round-trip could never
 * reproduce the Admin Panel configuration exactly.
 *
 * This service deliberately backs up configuration, not runtime/business
 * data. Users, orders, userbots/sessions, logs and panel runtime data are
 * NOT included because restoring those would be data migration, not settings
 * portability, and could overwrite live operational state.
 */

const BACKUP_VERSION = 2;
const SNAPSHOT_PATH = path.resolve(process.cwd(), 'config', 'settings.snapshot.json');
const BACKUP_SECTIONS = Object.freeze(['settings', 'paymentConfig', 'submenuCustomizations']);

function cloneRows(rows) {
  return rows.map((row) => ({ ...row }));
}

function collectSnapshot() {
  const db = getDb();
  return {
    settings: Object.fromEntries(
      db.prepare('SELECT key, value FROM settings ORDER BY key ASC').all().map((row) => [row.key, row.value])
    ),
    paymentConfig: cloneRows(
      db.prepare('SELECT key, value, updated_at FROM payment_config ORDER BY key ASC').all()
    ),
    submenuCustomizations: cloneRows(
      normalizeSubmenuCustomizations(
        db.prepare('SELECT submenu_id, content_text, content_entities, updated_by, created_at, updated_at FROM submenu_customizations ORDER BY submenu_id ASC').all()
      )
    ),
  };
}

function buildPayload() {
  const snapshot = collectSnapshot();
  return {
    format: 'jaseb-settings-backup',
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    sections: BACKUP_SECTIONS.slice(),
    settings: snapshot.settings,
    paymentConfig: snapshot.paymentConfig,
    submenuCustomizations: snapshot.submenuCustomizations,
  };
}

function writePayload(payload) {
  const dir = path.dirname(SNAPSHOT_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const tempPath = `${SNAPSHOT_PATH}.tmp`;
  fs.writeFileSync(tempPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
  fs.renameSync(tempPath, SNAPSHOT_PATH);
  return payload;
}

function exportToFile() {
  return writePayload(buildPayload());
}

function readPayloadFromFile(filePath = SNAPSHOT_PATH) {
  if (!fs.existsSync(filePath)) {
    throw new Error('File backup tidak ditemukan.');
  }
  return parsePayload(fs.readFileSync(filePath, 'utf8'));
}

function parsePayload(input) {
  let payload;
  try {
    payload = typeof input === 'string' ? JSON.parse(input) : input;
  } catch (err) {
    throw new Error(`JSON backup tidak valid: ${err.message}`);
  }

  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new Error('Format backup tidak valid.');
  }

  // Backward compatibility with the previous snapshot format (v1), which
  // contained only { exportedAt, settings }. It can still be imported, but
  // naturally cannot restore sections that were never exported.
  if (!payload.version && payload.settings && typeof payload.settings === 'object' && !Array.isArray(payload.settings)) {
    return {
      format: 'jaseb-settings-backup',
      version: 1,
      exportedAt: payload.exportedAt || null,
      sections: ['settings'],
      settings: normalizeSettings(payload.settings),
      paymentConfig: null,
      submenuCustomizations: null,
    };
  }

  if (payload.format !== 'jaseb-settings-backup') {
    throw new Error('File bukan backup pengaturan JASEB.');
  }

  // Accept the normalized form of the legacy v1 snapshot as well. This is
  // important when importPayload() receives the result of parsePayload()
  // instead of the raw legacy object.
  if (Number(payload.version) === 1) {
    return {
      format: payload.format,
      version: 1,
      exportedAt: payload.exportedAt || null,
      sections: ['settings'],
      settings: normalizeSettings(payload.settings),
      paymentConfig: null,
      submenuCustomizations: null,
    };
  }

  if (Number(payload.version) !== BACKUP_VERSION) {
    throw new Error(`Versi backup ${payload.version || '-'} tidak didukung. Versi yang didukung: ${BACKUP_VERSION}.`);
  }

  const sections = Array.isArray(payload.sections) ? payload.sections : [];
  for (const section of BACKUP_SECTIONS) {
    if (!sections.includes(section)) {
      throw new Error(`Backup tidak lengkap: section ${section} tidak ada.`);
    }
  }

  return {
    format: payload.format,
    version: BACKUP_VERSION,
    exportedAt: payload.exportedAt || null,
    sections: sections.slice(),
    settings: normalizeSettings(payload.settings),
    paymentConfig: normalizePaymentConfig(payload.paymentConfig),
    submenuCustomizations: normalizeSubmenuCustomizations(payload.submenuCustomizations),
  };
}

function normalizeSettings(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Section settings tidak valid.');
  }
  const out = {};
  for (const [key, rawValue] of Object.entries(value)) {
    if (!key || key.length > 255) throw new Error('Key settings tidak valid.');
    if (rawValue !== null && typeof rawValue !== 'string') {
      throw new Error(`Value settings "${key}" harus berupa string atau null.`);
    }
    out[key] = rawValue;
  }
  return out;
}

function normalizePaymentConfig(value) {
  if (!Array.isArray(value)) throw new Error('Section paymentConfig tidak valid.');
  return value.map((row, index) => {
    if (!row || typeof row !== 'object' || Array.isArray(row)) {
      throw new Error(`paymentConfig[${index}] tidak valid.`);
    }
    if (typeof row.key !== 'string' || !row.key) throw new Error(`paymentConfig[${index}].key tidak valid.`);
    if (row.value !== null && typeof row.value !== 'string') throw new Error(`paymentConfig[${index}].value tidak valid.`);
    return {
      key: row.key,
      value: row.value,
      updated_at: typeof row.updated_at === 'string' && row.updated_at ? row.updated_at : null,
    };
  });
}

function normalizeSubmenuCustomizations(value) {
  if (!Array.isArray(value)) throw new Error('Section submenuCustomizations tidak valid.');

  const normalized = [];
  let canonicalStart = null;

  for (let index = 0; index < value.length; index += 1) {
    const row = value[index];
    if (!row || typeof row !== 'object' || Array.isArray(row)) {
      throw new Error(`submenuCustomizations[${index}] tidak valid.`);
    }
    if (typeof row.submenu_id !== 'string' || !row.submenu_id) throw new Error(`submenuCustomizations[${index}].submenu_id tidak valid.`);
    if (typeof row.content_text !== 'string') throw new Error(`submenuCustomizations[${index}].content_text tidak valid.`);
    if (typeof row.content_entities !== 'string') throw new Error(`submenuCustomizations[${index}].content_entities tidak valid.`);
    if (!Number.isInteger(Number(row.updated_by))) throw new Error(`submenuCustomizations[${index}].updated_by tidak valid.`);

    const normalizedRow = {
      submenu_id: row.submenu_id === 'main' ? 'start' : row.submenu_id,
      content_text: row.content_text,
      content_entities: row.content_entities,
      updated_by: Number(row.updated_by),
      created_at: typeof row.created_at === 'string' && row.created_at ? row.created_at : null,
      updated_at: typeof row.updated_at === 'string' && row.updated_at ? row.updated_at : null,
    };

    // If a legacy backup contains both IDs, the already-canonical /start row
    // is authoritative. Otherwise the old /main row is promoted to /start.
    if (normalizedRow.submenu_id === 'start') {
      if (row.submenu_id === 'start') canonicalStart = normalizedRow;
      else if (!canonicalStart) canonicalStart = normalizedRow;
    } else {
      normalized.push(normalizedRow);
    }
  }

  const seen = new Set();
  const out = [];
  if (canonicalStart) {
    out.push(canonicalStart);
    seen.add('start');
  }
  for (const row of normalized) {
    if (seen.has(row.submenu_id)) continue;
    seen.add(row.submenu_id);
    out.push(row);
  }
  return out;
}

function importPayload(payloadInput, opts = {}) {
  const force = opts.force !== false;
  const payload = parsePayload(payloadInput);
  const db = getDb();

  const restore = db.transaction((data) => {
    // Configuration sections are replaced exactly. No settings key from the
    // previous DB survives a v2 restore unless it is present in the backup.
    db.prepare('DELETE FROM settings').run();
    const insertSetting = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
    for (const [key, value] of Object.entries(data.settings)) insertSetting.run(key, value);

    // Payment configuration is a dedicated key/value table. Older v1
    // backups did not contain this section, so leave it untouched when the
    // section is absent. Version 2 always contains it and therefore replaces
    // it exactly.
    if (data.paymentConfig !== null) {
      db.prepare('DELETE FROM payment_config').run();
      const insertPayment = db.prepare(
        `INSERT INTO payment_config (key, value, updated_at) VALUES (?, ?, COALESCE(?, datetime('now')))`
      );
      for (const row of data.paymentConfig) {
        insertPayment.run(row.key, row.value, row.updated_at);
      }
    }

    // Custom Submenu preserves raw Telegram entities and timestamps exactly.
    // parse/normalize already maps a legacy /start id to canonical `start`; here
    // also collapse the obsolete duplicate purchase-policy id before writing.
    if (data.submenuCustomizations !== null) {
      db.prepare('DELETE FROM submenu_customizations').run();
      const insertSubmenu = db.prepare(`
        INSERT INTO submenu_customizations
          (submenu_id, content_text, content_entities, updated_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, COALESCE(?, datetime('now')), COALESCE(?, datetime('now')))
      `);
      const policyRows = data.submenuCustomizations.filter((row) => row.submenu_id === 'store.payment_policy');
      const legacyPolicyRows = data.submenuCustomizations.filter((row) => row.submenu_id === 'store.category_policy');
      const canonicalPolicy = policyRows[0] || legacyPolicyRows[0];
      const rows = data.submenuCustomizations.filter((row) => row.submenu_id !== 'store.category_policy' && row.submenu_id !== 'store.payment_policy');
      if (canonicalPolicy) rows.push({ ...canonicalPolicy, submenu_id: 'store.payment_policy' });
      for (const row of rows) {
        insertSubmenu.run(
          row.submenu_id,
          row.content_text,
          row.content_entities,
          row.updated_by,
          row.created_at,
          row.updated_at
        );
      }
    }
  });

  // `force` is retained for API compatibility with the old service. A v2
  // restore is always an exact configuration replacement; passing force=false
  // intentionally does not silently downgrade to the old partial behavior.
  void force;
  restore(payload);

  // The uploaded backup is now the canonical configuration snapshot too.
  // Without this write, the database would be restored correctly for the
  // current process but a later fresh deployment/database recreation could
  // silently fall back to an older snapshot. Keep DB + snapshot in sync.
  writePayload(payload);

  const result = {
    version: payload.version,
    exportedAt: payload.exportedAt,
    settings: Object.keys(payload.settings).length,
    paymentConfig: payload.paymentConfig ? payload.paymentConfig.length : 0,
    submenuCustomizations: payload.submenuCustomizations ? payload.submenuCustomizations.length : 0,
    imported: Object.keys(payload.settings).length +
      (payload.paymentConfig ? payload.paymentConfig.length : 0) +
      (payload.submenuCustomizations ? payload.submenuCustomizations.length : 0),
  };

  logger.info(
    `Settings backup restored: ${result.settings} settings, ${result.paymentConfig} payment config, ${result.submenuCustomizations} custom submenu.`
  );
  return result;
}

function importFromFileIfNeeded(opts = {}) {
  if (!fs.existsSync(SNAPSHOT_PATH)) return { imported: 0, skipped: 0, source: 'none' };

  try {
    const payload = readPayloadFromFile(SNAPSHOT_PATH);
    // Startup restore is deliberately non-destructive: only an empty/fresh
    // database should auto-restore. Once any managed configuration exists,
    // manual Import from Telegram is required to intentionally replace it.
    const db = getDb();
    const hasExistingConfig =
      db.prepare('SELECT 1 FROM settings LIMIT 1').get() ||
      db.prepare('SELECT 1 FROM payment_config LIMIT 1').get() ||
      db.prepare('SELECT 1 FROM submenu_customizations LIMIT 1').get();

    if (hasExistingConfig && !opts.force) return { imported: 0, skipped: true, source: 'startup' };

    const result = importPayload(payload, { force: true });
    return { ...result, source: 'startup' };
  } catch (err) {
    logger.warn(`settings.snapshot.json rusak/tidak bisa dipulihkan: ${err.message}`);
    return { imported: 0, skipped: 0, source: 'startup', error: err.message };
  }
}

module.exports = {
  BACKUP_VERSION,
  BACKUP_SECTIONS,
  SNAPSHOT_PATH,
  collectSnapshot,
  buildPayload,
  exportToFile,
  parsePayload,
  readPayloadFromFile,
  importPayload,
  importFromFileIfNeeded,
};
