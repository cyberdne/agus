'use strict';
/**
 * The three log lines are editable submenu templates, so the admin can change
 * the wording from the existing Custom Submenu screens. The defaults match
 * the agreed format; the fallback keeps logs working if a custom text is bad.
 */
const { defineTemplate, renderTemplate } = require('./custom-submenu.service');
const { fillTemplate } = require('./ubotNotify.policy');

const TEMPLATES = {
  success: { id: 'ubot_notify_log_success', label: '✅ Log Sukses Kirim', text: 'Sukses kirim ke {target} ✅' },
  failed: { id: 'ubot_notify_log_failed', label: '❌ Log Gagal Kirim', text: 'Gagal kirim ke {target} ({reason})' },
  flood: { id: 'ubot_notify_log_flood', label: '⏳ Log FloodWait', text: 'FloodWait {seconds} dtk, kirim ke {target} ditunda' },
};

for (const t of Object.values(TEMPLATES)) {
  defineTemplate(t.id, 'Notifikasi Pengiriman', t.label, t.text, {
    messageType: 'text',
    supportedPlaceholders: ['target', 'reason', 'seconds'],
    maxLength: 200,
  });
}

function renderLine(type, values) {
  const t = TEMPLATES[type];
  const placeholderValues = {
    target: values.target || '-',
    reason: values.reason || '-',
    seconds: values.seconds ?? 0,
  };
  const fallback = fillTemplate(t.text, placeholderValues);
  try {
    const out = renderTemplate(t.id, null, t.text, { placeholderValues }, 'Markdown');
    return out && typeof out.text === 'string' && out.text ? out.text : fallback;
  } catch (_) {
    return fallback;
  }
}

module.exports = { TEMPLATES, renderLine };
