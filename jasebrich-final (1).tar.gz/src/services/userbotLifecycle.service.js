/**
 * Userbot lifecycle orchestration: ties the persisted subscription state
 * (services/subscription.service.js) to the live GramJS runtime
 * (services/userbotRuntime.service.js).
 *
 *   ACTIVE ──(now >= expires_at)──▶ EXPIRED ──▶ runtime stopped, control locked
 *      ▲                                             │ config/session/history retained
 *      └──── extend()/renewal ◀──────────────────────┘ runtime restored from DB
 *
 * Reconciliation rule (this is what makes an expiry racing an extension
 * safe): every runtime action here is derived from a FRESH database read
 * inside the runtime's per-asset lock. The DB is the only truth; the
 * runtime is converged onto it, in whichever order the two operations land.
 */
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const poolRepo = require('../database/repositories/userbotPool.repository');
const subscription = require('./subscription.service');
const runtime = require('./userbotRuntime.service');
const notice = require('./subscriptionNotice.service');
const logger = require('../utils/logger');
const codec = require('../utils/tokenCodec');
const { Markup } = require('telegraf');
const { replyButton } = require('../utils/buttons');
const { MENU } = require('../constants/menu');
const { defineTemplate, buildReplyOptions } = require('./custom-submenu.service');

let telegramRef = null;
const lifecycleTpl = {
  sessionInvalid: defineTemplate('userbot.session_invalid', 'Userbot', 'Sesi Userbot Tidak Valid',
    '⚠️ *Sesi Userbot Tidak Valid*\n\n' +
    'Sesi Telegram untuk userbot *{akun} #{userbot_id}* sudah tidak valid (kemungkinan dicabut/logout dari perangkat).\n\n' +
    '✅ Langganan kamu *tetap aktif* dan pengaturan tetap tersimpan.\n' +
    '🔐 Segera login ulang dengan akun Telegram yang sama lewat tombol *🤖 Buat Userbot* agar kontrol panel dapat digunakan kembali.\n\n' +
    '⏳ Sisa masa aktif: *{expired}*\n📅 Berlaku sampai: *{expired_at}*',
    { supportedPlaceholders: ['akun','userbot_id','expired','expired_at'] }),
  poolSessionReplaced: defineTemplate('userbot.jaseb_session_replaced', 'Jaseb', 'Userbot Jaseb Otomatis Diganti',
    '⚠️ *Userbot Jaseb Tidak Aktif*\n\n' +
    'Userbot Jaseb sebelumnya *{asal}* mengalami sesi Telegram tidak aktif.\n\n' +
    '✅ Sistem otomatis mengambil stok userbot *{akun}* yang tersedia dan melanjutkan *sisa masa aktif yang sama*.\n' +
    '🔑 Token Garansi baru: <code>{token_garansi}</code>\n\n' +
    '⏳ Sisa masa aktif: *{expired}*\n📅 Berlaku sampai: *{expired_at}*\n\n' +
    'ℹ️ Pengaturan userbot pengganti di-reset ke default agar aman setelah sebelumnya digunakan untuk promosi.',
    { parseMode: 'HTML', supportedPlaceholders: ['asal','akun','token_garansi','expired','expired_at'] }),
  poolSessionReplacementUnavailable: defineTemplate('userbot.jaseb_session_replacement_unavailable', 'Jaseb', 'Stok Pengganti Tidak Tersedia',
    '⚠️ *Userbot Jaseb Tidak Aktif*\n\n' +
    'Sesi userbot *{akun}* tidak dapat digunakan lagi.\n\n' +
    '❌ Saat ini tidak tersedia stok userbot pengganti yang valid.\n' +
    '📞 Silakan hubungi admin/owner untuk solusi penggantian userbot.\n\n' +
    '⏳ Sisa masa aktif tetap dihitung berdasarkan langganan yang sedang berjalan: *{expired}*\n📅 Berlaku sampai: *{expired_at}*',
    { supportedPlaceholders: ['akun','expired','expired_at'] }),
};

/** Called once at boot with bot.telegram so background paths can notify users. */
function setTelegram(telegram) {
  telegramRef = telegram || null;
}

async function safeNotify(userId, text, options = {}) {
  if (!telegramRef || !userId) return false;
  try {
    await telegramRef.sendMessage(userId, text, options);
    return true;
  } catch (err) {
    logger.warn(`Gagal mengirim notifikasi ke user ${userId}: ${(err && err.message) || err}`);
    return false;
  }
}

/**
 * Persist EXPIRED (if due) and make sure the runtime is stopped.
 * Idempotent: safe to call from scheduler, lazy access checks and the
 * per-asset expiry timer simultaneously.
 * Notifies the owner only for the caller that performed the transition.
 */
async function expireAndStop(userbotId, { notify = false } = {}) {
  const result = subscription.expireIfDue(userbotId);
  // Converge the runtime onto DB truth. No-op unless the DB says "not live"
  // AND a runtime is registered — never restarts anything.
  await runtime.teardownIfNotLive('owned', userbotId).catch((err) =>
    logger.error(`Gagal menghentikan runtime owned #${userbotId} saat expiry: ${err.message}`)
  );
  if (result.transitioned && result.row) {
    try {
      const reminderService = require('./subscriptionReminder.service');
      // Always persist the expiry notice as a durable event. Lazy access checks
      // call with notify:false; before this fix those transitions never created
      // an event, and the sweep only looks at still-active rows, so the buyer
      // was never told their subscription had ended.
      const eventKey = await reminderService.ensureExpiredReminderEvent(result.row);
      if (notify) await reminderService.sendExpiredReminder(telegramRef, result.row, eventKey);
    } catch (err) {
      // Expiry is already durably committed. Do not issue a second direct send
      // here: the durable reminder event is the single delivery path and the
      // scheduler retries only when the event is still retryable.
      logger.error(`Gagal menyiapkan reminder expiry owned #${result.row.id}: ${err.message}`);
    }
  }
  return result;
}

/** Called by the runtime's exact-time expiry timer / event safety net. */
async function handleExpiryDue(kind, id) {
  if (kind === 'owned') return expireAndStop(id, { notify: true });
  // Pool leases: their return-to-stock policy is handled by the existing pool
  // sweep; the runtime just must not keep running past expiry.
  return runtime.teardownIfNotLive(kind, id);
}

/**
 * Scheduler sweep for owned userbots. Finds every active userbot whose
 * expiry has passed, persists EXPIRED, stops its runtime and notifies once.
 * Overlap/restart safe: each transition is an idempotent CAS in the DB.
 */
async function sweepExpiredOwned() {
  const now = Date.now();
  let transitioned = 0;
  for (const row of ownedRepo.listActiveWithExpiry()) {
    if (subscription.isTrial(row)) continue; // existing trial policy (delete) owns these
    if (!subscription.isExpiredAt(row.expires_at, now)) continue;
    try {
      const out = await expireAndStop(row.id, { notify: true });
      if (out.transitioned) transitioned++;
    } catch (err) {
      logger.error(`Sweep expiry owned #${row.id} gagal: ${err.message}`);
    }
  }
  // Safety net: any runtime still registered for an asset the DB says is not live.
  const stopped = await runtime.reconcileDeadRuntimes().catch((err) => {
    logger.error(`reconcileDeadRuntimes gagal: ${err.message}`);
    return 0;
  });
  return { transitioned, stoppedStale: stopped };
}

/**
 * The Telegram session of an otherwise-valid userbot is dead. Subscription
 * state is NOT changed (it may be perfectly ACTIVE) — only runtime_stop_reason
 * is set, the runtime is stopped, and the owner is told to log in again.
 */
async function handleSessionInvalid(kind, id, { notify = true } = {}) {
  if (kind === 'owned') {
    const flagged = ownedRepo.markSessionInvalid(id);
    await runtime.teardownAsset('owned', id).catch((err) => logger.warn(`Gagal teardown owned #${id} setelah session invalid: ${err.message}`));
    if (!flagged) return { handled: false, kind: 'owned', userbotId: id };
    const row = ownedRepo.findById(id);
    if (row) {
      logger.warn(`Userbot #${id}: sesi Telegram tidak valid (langganan tetap ${subscription.getSubscriptionState(row)})`);
      const ctxLike = { from: { id: row.user_id }, chat: { id: row.user_id } };
      const content = lifecycleTpl.sessionInvalid.getContent(ctxLike, { userbot: row });
      if (notify) {
        const reauthKeyboard = Markup.keyboard([
          [replyButton.primary(MENU.BUAT_UBOT)],
          [replyButton.danger(MENU.BATAL)],
        ]).resize();
        await safeNotify(row.user_id, content.text, { ...buildReplyOptions(content), ...reauthKeyboard });
      }
    }
    return { handled: true, kind: 'owned', userbotId: id, reauth: true };
  }

  if (kind !== 'pool') return { handled: false, kind, userbotId: id };
  const oldRow = poolRepo.findById(id);
  if (!oldRow || oldRow.status !== 'assigned' || !oldRow.assigned_user_id || !oldRow.expires_at) return false;
  if (subscription.isExpiredAt(oldRow.expires_at)) {
    // Expiry has its own canonical sweep/CAS path; never replace an already
    // expired lease as though it were a live subscription.
    return false;
  }

  const userId = oldRow.assigned_user_id;
  const oldLabel = oldRow.label || 'Jaseb';
  const candidates = poolRepo.listAvailableForPurchase();
  let replacement = null;

  for (const candidate of candidates) {
    if (candidate.id === id) continue;

    // A pool row can legitimately be available while an admin is using it for
    // promotion. It is still eligible inventory by design; stop that runtime
    // before the atomic assignment, then reset all persisted panel settings in
    // the same DB transition.
    try {
      if (typeof runtime.verifyAssetSession === 'function') {
        await runtime.verifyAssetSession('pool', candidate.id);
      }
    } catch (err) {
      if (runtime.isSessionInvalidError(err) || err.code === 'SESSION_MISSING') {
        poolRepo.disableAvailableInvalid(candidate.id);
        logger.warn(`Pool #${candidate.id}: sesi stok tidak valid/tidak tersedia, dinonaktifkan dan dilewati saat replacement.`);
        continue;
      }
      // Temporary Telegram/API/runtime failures are NOT proof of a dead
      // session. Do not disable or assign this candidate; wait for a future
      // recovery/replacement attempt rather than handing a buyer a stock that
      // was never actually verified.
      logger.warn(`Pool #${candidate.id}: verifikasi sesi kandidat sementara gagal, kandidat tidak dipakai: ${err.message}`);
      continue;
    }

    try {
      await runtime.teardownAsset('pool', candidate.id);
    } catch (err) {
      logger.warn(`Pool #${candidate.id}: gagal menghentikan runtime kandidat sebelum replacement: ${err.message}`);
      continue;
    }

    const token = codec.generate('JASEB');
    try {
      replacement = poolRepo.replaceInvalidAssignment(id, candidate.id, { token });
    } catch (err) {
      logger.error(`Pool replacement #${id} -> #${candidate.id} gagal dan di-rollback: ${err.message}`);
      continue;
    }
    if (replacement) break;
  }

  if (!replacement) {
    // Re-read after candidate races. If the lease expired while replacement was
    // being attempted, return it through the canonical expiry CAS path instead
    // of disabling an already-expired inventory row.
    const fresh = poolRepo.findById(id) || oldRow;
    if (fresh.expires_at && subscription.isExpiredAt(fresh.expires_at)) {
      await runtime.teardownIfNotLive('pool', id).catch(() => {});
      const nowIso = new Date().toISOString().slice(0, 19).replace('T', ' ');
      poolRepo.returnExpiredToPool(id, fresh.expires_at, nowIso);
      return { handled: true, kind: 'pool', userbotId: id, replacementId: null, expired: true };
    }
    // No valid available stock remains. Mark the dead lease disabled (CAS) so
    // nobody can accidentally keep using or reassigning its invalid session.
    poolRepo.disableInvalidAssignment(id);
    const current = poolRepo.findById(id) || fresh;
    logger.warn(`Pool #${id}: sesi tidak valid, stok pengganti tidak tersedia untuk user ${userId}.`);
    const ctxLike = { from: { id: userId }, chat: { id: userId } };
    const content = lifecycleTpl.poolSessionReplacementUnavailable.getContent(ctxLike, { userbot: current });
    if (notify) await safeNotify(userId, content.text, buildReplyOptions(content));
    return { handled: true, kind: 'pool', userbotId: id, replacementId: null };
  }

  const freshReplacement = poolRepo.findById(replacement.newId);
  if (!freshReplacement) {
    logger.error(`Pool replacement #${id}: row pengganti #${replacement.newId} hilang setelah commit.`);
    return true;
  }

  logger.warn(`Pool #${id} diganti dengan #${replacement.newId} untuk user ${userId}; expiry dipertahankan ${replacement.expiresAt}`);
  const ctxLike = { from: { id: userId }, chat: { id: userId } };
  const content = lifecycleTpl.poolSessionReplaced.getContent(ctxLike, {
    userbot: freshReplacement,
    placeholderValues: { asal: oldLabel },
  });
  if (notify) await safeNotify(userId, content.text, buildReplyOptions(content));
  return { handled: true, kind: 'pool', userbotId: id, replacementId: freshReplacement.id };
}

/**
 * After a subscription became ACTIVE again: rebuild the runtime from the
 * database (automation flags are persisted, so they are restored, exactly
 * one client/listener via the runtime's per-asset lock).
 *
 * Returns a status the caller can show:
 *   running | idle (no automation was enabled) | session_invalid |
 *   unavailable (runtime not configured) | failed | not_live | no_session
 */
async function restoreRuntime(userbotId) {
  const asset = ownedRepo.findById(userbotId);
  if (!asset) return { status: 'missing' };
  if (!runtime.assetLiveness('owned', asset).live) return { status: 'not_live' };
  const anyAutomation = Boolean(asset.auto_promosi || asset.wtb_reply || asset.pm_permit);
  if (!anyAutomation) return { status: 'idle' };
  if (!asset.session_string) return { status: 'no_session' };
  // A previously flagged SESSION_INVALID is re-verified by the real connect below
  // (no duplicate user notification: markSessionInvalid is a one-shot CAS).
  try {
    await runtime.syncAsset('owned', userbotId);
  } catch (err) {
    if (runtime.isSessionInvalidError(err)) {
      await handleSessionInvalid('owned', userbotId);
      return { status: 'session_invalid' };
    }
    logger.error(`Restore runtime owned #${userbotId} gagal: ${err.message}`);
    return { status: 'failed', error: err.message };
  }
  return runtime.isRunning('owned', userbotId) ? { status: 'running' } : { status: 'unavailable' };
}

/**
 * Extend + reconcile in the required order:
 *   atomic DB transaction (expiry, status, audit)  ->  runtime reconciliation.
 * A duplicate operation (same operationId) changes nothing and skips the runtime.
 */
async function extendAndReconcile(params) {
  const result = subscription.extend(params); // sync + atomic; throws (and rolls back) on failure
  if (result.duplicate) return { ...result, runtime: null };
  const runtimeResult = await restoreRuntime(params.userbotId);
  return { ...result, runtime: runtimeResult };
}

/** Human-readable runtime line for admin/user screens. */
function describeRuntime(runtimeResult) {
  switch (runtimeResult && runtimeResult.status) {
    case 'running':
      return '✅ Runtime berjalan kembali (otomasi dipulihkan dari database).';
    case 'idle':
      return 'ℹ️ Tidak ada otomasi yang aktif — runtime tidak perlu dijalankan.';
    case 'session_invalid':
      return '⚠️ Sesi Telegram userbot tidak valid — runtime tetap berhenti. User diminta login ulang.';
    case 'unavailable':
      return '⚠️ Runtime tidak dapat dijalankan (TELEGRAM_API_ID/API_HASH belum dikonfigurasi).';
    case 'failed':
      return `⚠️ Runtime gagal dipulihkan: ${runtimeResult.error}`;
    case 'no_session':
      return '⚠️ Userbot tidak memiliki sesi Telegram — user perlu setup/login ulang.';
    case 'not_live':
    case 'missing':
      return 'ℹ️ Runtime tidak dipulihkan (status userbot tidak aktif).';
    default:
      return '';
  }
}

module.exports = {
  setTelegram,
  expireAndStop,
  handleExpiryDue,
  sweepExpiredOwned,
  handleSessionInvalid,
  restoreRuntime,
  extendAndReconcile,
  describeRuntime,
};
