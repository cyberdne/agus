// Testimoni otomatis: satu-satunya jalur publish testimoni ke channel.
// Dipanggil hanya setelah order benar-benar 'fulfilled' (lihat order.service.js).
// Idempotensi: tabel testimonial_deliveries + claim atomik, bukan flag memori.
const crypto = require('crypto');
const { button } = require('../utils/buttons');
const settingsRepo = require('../database/repositories/settings.repository');
const orderRepo = require('../database/repositories/order.repository');
const userRepo = require('../database/repositories/user.repository');
const { getDb } = require('../database');
const { defineTemplate, getSubmenuContent } = require('./custom-submenu.service');
const notificationService = require('./notification.service');
const logger = require('../utils/logger');

const TEMPLATE_ID = 'notification.testimonial';
const SETTINGS_KEYS = Object.freeze({
  CHANNEL_ID: 'testimonial_channel_id',
  CHANNEL_TITLE: 'testimonial_channel_title',
  BUTTONS: 'testimonial_buttons',
  IMAGE_FILE_ID: 'testimonial_image_file_id', // admin-chosen image shown on every Testimoni post
  ENABLED: 'testimonial_enabled', // '1' on, '0' off; unset = on (existing installs keep working)
});
const CAPTION_MAX = 1024;
const MAX_ATTEMPTS = 5; // retryable failures stop after this many attempts (no endless retry loop)
const TARGETS = ['BOT', 'STORE', 'RENEWAL', 'URL'];
const STYLES = ['primary', 'success', 'danger'];
const PLACEHOLDERS = ['order_id', 'produk', 'jumlah', 'total', 'status', 'kategori', 'nama', 'nama_lengkap', 'username', 'mention', 'tanggal', 'waktu'];

const DEFAULT_TEXT = [
  '✨ *TRANSAKSI BERHASIL*',
  '',
  '✅ Pembayaran telah dikonfirmasi',
  '🛍️ Produk: {produk}',
  '🔢 Jumlah: {jumlah}',
  '💰 Total: {total}',
  '🆔 Order: #{order_id}',
  '🕒 {tanggal} • {waktu}',
  '',
  'Terima kasih telah mempercayakan transaksi kepada JASEBRICH. 🤝',
].join('\n');

// Registered in the canonical Custom Submenu engine (Admin Panel → Settings → Custom Submenu).
const template = defineTemplate(TEMPLATE_ID, 'Notifikasi', 'Testimoni Transaksi', DEFAULT_TEXT, {
  parseMode: 'Markdown',
  messageType: 'caption',
  maxLength: CAPTION_MAX,
  supportedPlaceholders: PLACEHOLDERS,
});

// ---------- configuration ----------

function getChannel() {
  const id = settingsRepo.get(SETTINGS_KEYS.CHANNEL_ID);
  const title = settingsRepo.get(SETTINGS_KEYS.CHANNEL_TITLE);
  return id ? { id: String(id), title: title || String(id) } : null;
}

async function setChannel(telegram, input) {
  // Same validation as the Notification channels: real channel, bot admin, posting permission.
  const chat = await notificationService.validateChannel(telegram, input);
  settingsRepo.set(SETTINGS_KEYS.CHANNEL_ID, String(chat.id));
  settingsRepo.set(SETTINGS_KEYS.CHANNEL_TITLE, String(chat.title || chat.id));
  return getChannel();
}

function resetChannel() {
  settingsRepo.set(SETTINGS_KEYS.CHANNEL_ID, null);
  settingsRepo.set(SETTINGS_KEYS.CHANNEL_TITLE, null);
  return true;
}

function getButtons() {
  const raw = settingsRepo.get(SETTINGS_KEYS.BUTTONS);
  if (!raw) return [];
  try { return validateButtons(JSON.parse(raw)); } catch (_) { return []; }
}

function setButtons(list) {
  settingsRepo.set(SETTINGS_KEYS.BUTTONS, JSON.stringify(validateButtons(list)));
  return getButtons();
}

function getImageFileId() {
  const v = settingsRepo.get(SETTINGS_KEYS.IMAGE_FILE_ID);
  return v ? String(v) : null;
}

function setImageFileId(fileId) {
  const value = String(fileId || '').trim();
  if (!value) throw new Error('File gambar tidak valid.');
  settingsRepo.set(SETTINGS_KEYS.IMAGE_FILE_ID, value);
  return value;
}

function resetSettings() {
  resetChannel();
  settingsRepo.set(SETTINGS_KEYS.BUTTONS, null);
  settingsRepo.set(SETTINGS_KEYS.IMAGE_FILE_ID, null);
  return true;
}

// On/off switch for the whole feature. Off = no send, no delivery row, no retry sweep.
function isEnabled() {
  const v = settingsRepo.get(SETTINGS_KEYS.ENABLED);
  return v === null || v === undefined || v === '' ? true : String(v) === '1';
}

function setEnabled(on) {
  settingsRepo.set(SETTINGS_KEYS.ENABLED, on ? '1' : '0');
  return !!on;
}

// Line format (admin input):
//   "🛒 Beli Sekarang | STORE | success | ROW:1"
//   "📢 Promo | URL | https://example.com | primary | ROW:2"
// CALLBACK is intentionally not accepted: a public channel button must never trigger
// an arbitrary internal action (approve/reject/delete/...).
function parseButtonLine(line) {
  const parts = String(line || '').split('|').map((x) => x.trim());
  if (parts.length < 4) throw new Error('Format tombol: Label | TARGET | style | ROW:n  (atau Label | URL | https://... | style | ROW:n)');
  const [label, targetRaw] = parts;
  const target = targetRaw.toUpperCase();
  if (!TARGETS.includes(target)) throw new Error(`Target tombol harus salah satu dari: ${TARGETS.join(', ')}.`);
  let value = null;
  let rest;
  if (target === 'URL') {
    value = parts[2];
    rest = parts.slice(3);
    if (!/^https:\/\/[^\s]+$/i.test(value || '')) throw new Error('Tombol URL harus memakai https://');
  } else {
    rest = parts.slice(2);
  }
  const style = String(rest[0] || '').toLowerCase();
  const rowPart = String(rest[1] || '').toUpperCase();
  if (!STYLES.includes(style)) throw new Error(`Style harus salah satu dari: ${STYLES.join(', ')}.`);
  const rowMatch = rowPart.match(/^ROW:(\d+)$/);
  if (!rowMatch) throw new Error('Baris tombol harus berformat ROW:n (contoh ROW:1).');
  const row = Number(rowMatch[1]);
  if (row < 1 || row > 8) throw new Error('Baris tombol harus 1–8.');
  return { label, target, value, style, row };
}

function validateButtons(list) {
  if (!Array.isArray(list)) throw new Error('Konfigurasi tombol tidak valid.');
  if (list.length > 8) throw new Error('Maksimal 8 tombol CTA.');
  return list.map((b) => {
    const label = String(b.label || '').trim();
    if (!label || label.length > 64) throw new Error('Label tombol wajib 1–64 karakter.');
    const target = String(b.target || '').toUpperCase();
    if (!TARGETS.includes(target)) throw new Error('Target tombol tidak valid.');
    if (!STYLES.includes(b.style)) throw new Error('Style tombol tidak valid.');
    const row = Number(b.row);
    if (!Number.isInteger(row) || row < 1 || row > 8) throw new Error('Baris tombol harus 1–8.');
    let value = null;
    if (target === 'URL') {
      value = String(b.value || '');
      if (!/^https:\/\/[^\s]+$/i.test(value)) throw new Error('Tombol URL harus memakai https://');
    }
    return { label, target, value, style: b.style, row };
  });
}

// Builds the inline keyboard from the saved config. Every button goes through utils/buttons.js.
// `withStyle` lets the send path retry without the style field when Telegram explicitly rejects it.
function buildKeyboard(buttons, botUsername, withStyle = true) {
  const rows = new Map();
  for (const b of buttons) {
    let url;
    if (b.target === 'BOT') url = `https://t.me/${botUsername}`;
    else if (b.target === 'STORE') url = `https://t.me/${botUsername}?start=store`;
    else if (b.target === 'RENEWAL') url = `https://t.me/${botUsername}?start=renewal`;
    else url = b.value;
    const fn = b.style === 'success' ? button.successUrl : b.style === 'danger' ? button.dangerUrl : button.primaryUrl;
    const btn = fn(b.label, url); // default options: stays eligible for Custom Icon Tombol
    if (!withStyle) delete btn.style;
    if (!rows.has(b.row)) rows.set(b.row, []);
    rows.get(b.row).push(btn);
  }
  const inline_keyboard = [...rows.keys()].sort((a, c) => a - c).map((k) => rows.get(k));
  return inline_keyboard.length ? { inline_keyboard } : null;
}

// ---------- rendering ----------

function mdEscape(value) {
  return String(value == null ? '-' : value).replace(/([_*`\[])/g, '\\$1');
}

function formatRupiah(n) {
  return `Rp ${Number(n || 0).toLocaleString('id-ID')}`;
}

function formatDate(d) {
  return new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: 'numeric' }).format(d);
}
function formatTime(d) {
  return `${new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false }).format(d)} WIB`;
}

const CATEGORY_LABEL = { jaseb: 'Jaseb', userbot: 'Userbot', renewal: 'Renewal' };

// Values come only from the order and its buyer row. Nothing sensitive (Telegram id, phone,
// session, token, userbot internals) is exposed. Dynamic text is Markdown-escaped.
function buildValues(order, buyer, when = new Date()) {
  const first = (buyer && buyer.first_name) || '';
  const last = (buyer && buyer.last_name) || '';
  const fullName = [first, last].filter(Boolean).join(' ') || 'Pelanggan';
  const displayName = first || fullName;
  return {
    order_id: String(order.id),
    produk: mdEscape(order.product_name || '-'),
    jumlah: mdEscape(`${order.qty || 1}`),
    total: mdEscape(formatRupiah(order.total_price)),
    status: 'BERHASIL',
    kategori: mdEscape(CATEGORY_LABEL[order.category] || order.category || '-'),
    nama: mdEscape(displayName),
    nama_lengkap: mdEscape(fullName),
    username: mdEscape(buyer && buyer.username ? `@${buyer.username}` : '-'),
    mention: mdEscape(displayName), // plain name only: no tg:// link, so no Telegram id is published
    tanggal: mdEscape(formatDate(when)),
    waktu: mdEscape(formatTime(when)),
  };
}

function renderCaption(order, buyer, when) {
  const values = buildValues(order, buyer, when);
  const content = getSubmenuContent(TEMPLATE_ID, { text: DEFAULT_TEXT, parse_mode: 'Markdown' }, null, { placeholderValues: values });
  return content;
}

// ---------- delivery ----------


function classifyError(err) {
  const desc = String((err && (err.description || err.message)) || '');
  const retry = err && err.parameters && err.parameters.retry_after;
  if (retry || /too many requests/i.test(desc)) return { kind: 'retryable', desc, retryAfter: Number(retry || 0) };
  if (/chat not found|not enough rights|have no rights|bot was kicked|bot is not a member|CHAT_WRITE_FORBIDDEN|chat_write_forbidden|need administrator|can't be edited/i.test(desc)) {
    return { kind: 'permanent', desc };
  }
  if (/ETIMEDOUT|ECONNRESET|ENOTFOUND|EAI_AGAIN|socket hang up|network|timeout/i.test(desc)) return { kind: 'retryable', desc };
  return { kind: 'permanent', desc };
}

// Narrow compatibility fallback: only when Telegram explicitly points at the "style" field.
async function sendImagePost(telegram, channelId, fileId, caption, markupBuilder) {
  const baseExtra = caption.parse_mode
    ? { parse_mode: caption.parse_mode }
    : { caption_entities: caption.entities || [] };
  const extra = (withStyle) => {
    const markup = markupBuilder(withStyle);
    return { caption: caption.text, ...baseExtra, ...(markup ? { reply_markup: markup } : {}) };
  };
  try {
    return await telegram.sendPhoto(channelId, fileId, extra(true));
  } catch (err) {
    const desc = String((err && (err.description || err.message)) || '');
    if (/\bstyle\b/i.test(desc)) {
      logger.warn(`Testimoni: Telegram menolak field style, ulangi sekali tanpa style: ${desc}`);
      return await telegram.sendPhoto(channelId, fileId, extra(false));
    }
    throw err;
  }
}

// Canonical entry point. Returns { ok, reason, ... }. Never throws for business outcomes.
async function publishForOrder(telegram, orderId, { now = new Date() } = {}) {
  const order = orderRepo.findById(orderId);
  if (!order) return { ok: false, reason: 'not_found' };
  if (order.status !== 'fulfilled') return { ok: false, reason: 'not_fulfilled', status: order.status };
  if (!isEnabled()) return { ok: false, reason: 'disabled' };

  const channel = getChannel();
  if (!channel) return { ok: false, reason: 'not_configured' };
  // Image is admin-chosen. Not configured = nothing is posted and no delivery row is created (later orders still work).
  const imageId = getImageFileId();
  if (!imageId) return { ok: false, reason: 'image_not_configured' };

  const db = getDb();
  db.prepare("INSERT OR IGNORE INTO testimonial_deliveries (order_id, status) VALUES (?, 'none')").run(order.id);
  const claimToken = crypto.randomUUID();
  // Claim atomically. A 'claimed' row older than 10 minutes is treated as abandoned (process died mid-send).
  const claimed = db.prepare(`
    UPDATE testimonial_deliveries
       SET status = 'claimed', claim_token = ?, claimed_at = datetime('now'), attempts = attempts + 1, updated_at = datetime('now')
     WHERE order_id = ?
       AND (status IN ('none','retryable') OR (status = 'claimed' AND claimed_at < datetime('now','-10 minutes')))
  `).run(claimToken, order.id);
  if (!claimed.changes) return { ok: false, reason: 'already_handled' };

  const writeFinal = (status, extra) => db.prepare(`
      UPDATE testimonial_deliveries
         SET status = ?, message_id = COALESCE(?, message_id), channel_id = ?, last_error = ?, sent_at = CASE WHEN ? = 'sent' THEN datetime('now') ELSE sent_at END,
             claim_token = NULL, updated_at = datetime('now')
       WHERE order_id = ? AND claim_token = ?
    `).run(status, extra.messageId || null, channel.id, extra.error || null, status, order.id, claimToken);
  const finish = (status, extra = {}) => {
    // A message that already reached the channel must be recorded as 'sent'. Retry the write a few times
    // so a transient DB error does not leave the row 'claimed' (which could allow a later duplicate).
    if (status === 'sent') {
      for (let i = 0; i < 3; i++) {
        try { writeFinal(status, extra); return; } catch (err) { logger.error(`Testimoni order #${order.id}: tulis status sent gagal (percobaan ${i + 1}): ${(err && err.message) || err}`); }
      }
      logger.error(`Testimoni order #${order.id}: pesan terkirim tetapi status tidak tersimpan. Periksa manual sebelum mencoba ulang.`);
      return;
    }
    // Retryable failures stop after MAX_ATTEMPTS.
    if (status === 'retryable') {
      const row = db.prepare('SELECT attempts FROM testimonial_deliveries WHERE order_id = ?').get(order.id);
      if (row && row.attempts >= MAX_ATTEMPTS) {
        writeFinal('failed_permanent', { ...extra, error: `max_attempts(${MAX_ATTEMPTS}): ${extra.error || ''}`.slice(0, 500) });
        logger.warn(`Testimoni order #${order.id}: gagal ${MAX_ATTEMPTS} kali, dihentikan.`);
        return;
      }
    }
    writeFinal(status, extra);
  };


  const buyer = userRepo.findByTelegramId(order.user_id) || null;
  const caption = renderCaption(order, buyer, now);
  if (caption.text.length > CAPTION_MAX) {
    logger.warn(`Testimoni order #${order.id} tidak dikirim: caption ${caption.text.length} > ${CAPTION_MAX} karakter.`);
    finish('failed_permanent', { error: 'caption_too_long' });
    return { ok: false, reason: 'caption_too_long' };
  }

  let botUsername;
  try {
    const me = await telegram.getMe();
    botUsername = me && me.username;
  } catch (err) {
    finish('retryable', { error: `getMe: ${(err && err.message) || err}` });
    return { ok: false, reason: 'retryable', error: String(err && err.message || err) };
  }
  if (!botUsername) { finish('failed_permanent', { error: 'bot_username_missing' }); return { ok: false, reason: 'bot_username_missing' }; }

  const buttons = getButtons();
  const markupBuilder = (withStyle) => buildKeyboard(buttons, botUsername, withStyle);

  try {
    const sent = await sendImagePost(telegram, channel.id, imageId, caption, markupBuilder);
    if (!sent || !sent.message_id) {
      finish('retryable', { error: 'no_message_returned' });
      return { ok: false, reason: 'retryable', error: 'no_message_returned' };
    }
    finish('sent', { messageId: sent.message_id });
    return { ok: true, messageId: sent.message_id, channelId: channel.id };
  } catch (err) {
    const c = classifyError(err);
    finish(c.kind === 'retryable' ? 'retryable' : 'failed_permanent', { error: c.desc });
    logger.warn(`Testimoni order #${order.id} gagal dikirim (${c.kind}): ${c.desc}`);
    return { ok: false, reason: c.kind, error: c.desc, retryAfter: c.retryAfter || 0 };
  }
}

// Preview: uses the newest real fulfilled order and the admin-set image. Never fabricates order data.
async function previewLatest(telegram, adminChatId) {
  const db = getDb();
  const imageId = getImageFileId();
  if (!imageId) return { ok: false, reason: 'image_not_configured' };
  // Preview uses a real fulfilled order (never a fabricated one).
  const order = db.prepare(`SELECT * FROM orders WHERE status = 'fulfilled' ORDER BY id DESC LIMIT 1`).get();
  if (!order) return { ok: false, reason: 'no_real_order' };
  const botMe = await telegram.getMe();
  const buyer = userRepo.findByTelegramId(order.user_id) || null;
  const caption = renderCaption(order, buyer, new Date());
  if (caption.text.length > CAPTION_MAX) return { ok: false, reason: 'caption_too_long' };
  const extra = { caption: caption.text, ...(caption.parse_mode ? { parse_mode: caption.parse_mode } : { caption_entities: caption.entities || [] }) };
  const markup = buildKeyboard(getButtons(), botMe.username, true);
  if (markup) extra.reply_markup = markup;
  const sent = await telegram.sendPhoto(adminChatId, imageId, extra);
  return { ok: true, orderId: order.id, messageId: sent && sent.message_id };
}


// Retries 'retryable' deliveries. Called from the scheduler tick; each order still goes through the same
// claim, so a concurrent manual publish cannot produce a second message.
async function sweepRetryable(telegram, limit = 10) {
  if (!isEnabled()) return [];
  const rows = getDb().prepare(`
    SELECT order_id FROM testimonial_deliveries
     WHERE status = 'retryable'
     ORDER BY updated_at ASC
     LIMIT ?
  `).all(limit);
  const out = [];
  for (const row of rows) {
    try { out.push({ orderId: row.order_id, ...(await publishForOrder(telegram, row.order_id)) }); }
    catch (err) { logger.error(`Sweep Testimoni order #${row.order_id}: ${(err && err.message) || err}`); }
  }
  return out;
}

module.exports = {
  MAX_ATTEMPTS,
  sweepRetryable,
  TEMPLATE_ID,
  SETTINGS_KEYS,
  PLACEHOLDERS,
  DEFAULT_TEXT,
  CAPTION_MAX,
  template,
  getChannel,
  setChannel,
  resetChannel,
  getButtons,
  setButtons,
  getImageFileId,
  isEnabled,
  setEnabled,
  setImageFileId,
  resetSettings,
  parseButtonLine,
  validateButtons,
  buildKeyboard,
  buildValues,
  renderCaption,
  classifyError,
  publishForOrder,
  previewLatest,
};
