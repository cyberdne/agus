'use strict';
/**
 * Pure decision logic for subscription expiry reminders. No database or
 * Telegram access here, so every rule can be unit-tested in isolation.
 */

/**
 * Permanent = retrying can never succeed (user blocked the bot, deactivated
 * account, chat not found). Temporary = network, flood-wait, 5xx: retry later.
 */
function classifyReminderDeliveryError(err) {
  const code = Number(err?.response?.error_code || err?.code || 0);
  const raw = String(err?.description || err?.message || err || '');
  if (code === 403 || /blocked|deactivated|chat not found|user is deactivated|bot was blocked/i.test(raw)) return 'permanent';
  if (code === 400 && !/retry|timeout|temporar|flood|too many requests/i.test(raw)) return 'permanent';
  return 'temporary';
}

/**
 * Pick the most imminent threshold currently crossed. Example with
 * thresholds [10080, 4320, 1440] minutes: 2000 min left -> 4320 (crossed,
 * smallest). Only one reminder per subscription per sweep, so missed
 * thresholds after downtime are not replayed as a burst.
 * Returns null when there are no thresholds.
 */
function chooseCurrentThreshold(remainingMs, thresholds) {
  const list = Array.isArray(thresholds) ? thresholds : [];
  if (!list.length) return null;
  const remainingMinutes = remainingMs / 60000;
  const crossed = list.filter((n) => remainingMinutes <= n).sort((a, b) => a - b);
  return crossed.length ? crossed[0] : Math.max(...list);
}

/** Combine automatic + expiry sweep results into one set of totals. */
function summarizeSweep(automatic, expired) {
  const a = automatic || {};
  const e = expired || {};
  const n = (v) => Number(v) || 0;
  return {
    sent: n(a.sent) + n(e.sent),
    skipped: n(a.skipped) + n(e.skipped),
    failed: n(a.failed) + n(e.failed),
    attempted: n(a.attempted) + n(e.attempted),
  };
}

/** ok = all sends fine; partial = some failed (retry next tick); error = a sweep threw. */
function classifyRunStatus({ error, failed }) {
  if (error) return 'error';
  if (Number(failed) > 0) return 'partial';
  return 'ok';
}

module.exports = {
  classifyReminderDeliveryError,
  chooseCurrentThreshold,
  summarizeSweep,
  classifyRunStatus,
};
