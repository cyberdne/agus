const userRepository = require('../database/repositories/user.repository');
const orderRepository = require('../database/repositories/order.repository');
const ownedUserbotRepository = require('../database/repositories/ownedUserbot.repository');
const userbotPoolRepository = require('../database/repositories/userbotPool.repository');
const userbotRuntime = require('./userbotRuntime.service');
const { getDb } = require('../database');
const logger = require('../utils/logger');
const subscription = require('./subscription.service');
const backupToken = require('./backupToken.service');

function registerOrUpdateUser(telegramUser) {
  const user = userRepository.upsertFromTelegramUser(telegramUser);
  logger.debug(`User ${telegramUser.id} (${telegramUser.username || 'no-username'}) registered/updated`);
  return user;
}

/**
 * Admin-initiated pre-registration ("add user"), e.g. to whitelist or
 * pre-note someone before they've ever pressed /start. Real duplicate
 * check against the UNIQUE(telegram_id) constraint — not a silent
 * upsert — because "Add" and "the user talked to the bot" are two
 * different events an admin needs to be able to tell apart.
 */
function adminRegisterUser(telegramId, { username, firstName, lastName } = {}) {
  if (!Number.isInteger(telegramId) || telegramId <= 0) {
    throw new Error('Telegram ID harus berupa angka positif.');
  }
  const existing = userRepository.findByTelegramId(telegramId);
  if (existing) {
    throw new Error(`User dengan ID ${telegramId} sudah terdaftar.`);
  }
  const user = userRepository.create({ telegramId, username, firstName, lastName });
  logger.info(`Admin pre-registered user ${telegramId}`);
  return user;
}

/**
 * Full profile aggregation for the admin User Management detail
 * screen: real counts pulled from orders / owned-userbots / leased
 * pool assets, not cached or estimated fields on the user row.
 */
function getUserProfile(telegramId) {
  const user = userRepository.findByTelegramId(telegramId);
  if (!user) return null;

  const orders = orderRepository.listByUser(telegramId);
  const ownedUserbots = ownedUserbotRepository.listByUser(telegramId);
  const leasedUserbots = userbotPoolRepository.listAssignedToUser(telegramId);

  const nowMs = Date.now();
  const pendingOrders = orders.filter((o) => {
    if (!['pending', 'awaiting_confirmation'].includes(o.status)) return false;
    if (!o.expires_at) return false;
    const expiryMs = new Date(o.expires_at).getTime();
    return Number.isFinite(expiryMs) && expiryMs > nowMs;
  }).length;

  return {
    user,
    stats: {
      totalOrders: orders.length,
      pendingOrders,
      totalSpent: orderRepository.sumPaidByUser(telegramId),
      activeOwnedUserbots: ownedUserbots.filter((u) => subscription.isActiveNow(u)).length,
      activeLeasedUserbots: leasedUserbots.length,
    },
    orders,
    ownedUserbots,
    leasedUserbots,
  };
}

/**
 * Banning a user is more than flipping a flag: it must immediately
 * stop anything that account is currently automating, otherwise a
 * banned buyer's Auto Promosi / WTB Reply / PM Permit could keep running
 * unattended. Durable access/automation disablement is committed in one DB
 * transaction; live client teardown is then awaited and independently
 * guarded by runtime liveness checks against the owner's ban state.
 */
async function banUser(telegramId, reason, adminId) {
  const user = userRepository.findByTelegramId(telegramId);
  if (!user) throw new Error(`User ${telegramId} tidak ditemukan.`);

  const ownedIds = ownedUserbotRepository.listByUser(telegramId).map((r) => r.id);
  const leasedIds = userbotPoolRepository.listAssignedToUser(telegramId).map((r) => r.id);

  const run = getDb().transaction(() => {
    userRepository.setBanned(telegramId, true, reason);
    ownedUserbotRepository.disableAllFlagsForUser(telegramId);
    userbotPoolRepository.disableAllFlagsForUser(telegramId);
  });
  run();

  // Stop any live automation immediately — a banned buyer's userbot
  // must not keep running Auto Promosi / WTB Reply / PM Permit. The durable
  // disablement is committed first; runtime teardown is then awaited so the
  // admin action does not report completion while a live client can still run.
  const teardown = [
    ...ownedIds.map((id) => ['owned', id]),
    ...leasedIds.map((id) => ['pool', id]),
  ];
  const results = await Promise.allSettled(teardown.map(([kind, id]) => userbotRuntime.teardownAsset(kind, id)));
  results.forEach((result, index) => {
    if (result.status === 'rejected') {
      const [kind, id] = teardown[index];
      logger.error(`Gagal hentikan runtime ${kind} #${id} setelah user ${telegramId} diblokir: ${result.reason?.message || result.reason}`);
    }
  });

  logger.info(`User ${telegramId} banned by admin ${adminId}${reason ? ` (reason: ${reason})` : ''}`);
  return userRepository.findByTelegramId(telegramId);
}

function unbanUser(telegramId, adminId) {
  const user = userRepository.findByTelegramId(telegramId);
  if (!user) throw new Error(`User ${telegramId} tidak ditemukan.`);
  userRepository.setBanned(telegramId, false);
  logger.info(`User ${telegramId} unbanned by admin ${adminId}`);
  return userRepository.findByTelegramId(telegramId);
}

/**
 * Cascading, transactional user deletion. Deleting a `users` row
 * without cleaning up dependents would either orphan rows (orders,
 * owned userbots) or, worse, permanently strand a leased pool
 * userbot in 'assigned' state forever since nothing else ever clears
 * assigned_user_id. So deletion here means:
 *   1. Any pool userbot currently leased to them is force-returned to
 *      stock immediately (so it becomes sellable again).
 *   2. Their owned userbots (buyer's own activated accounts) are
 *      removed.
 *   3. Their order history is removed.
 *   4. The user row itself is removed.
 * All four steps run in one transaction — either the whole cleanup
 * happens or none of it does.
 */
function deleteUserCascade(telegramId, adminId) {
  const user = userRepository.findByTelegramId(telegramId);
  if (!user) throw new Error(`User ${telegramId} tidak ditemukan.`);

  const leased = userbotPoolRepository.listAssignedToUser(telegramId);
  const owned = ownedUserbotRepository.listByUser(telegramId);
  const orderCount = orderRepository.countByUser(telegramId);

  const run = getDb().transaction(() => {
    for (const pool of leased) {
      userbotPoolRepository.returnToPool(pool.id);
    }
    // The userbots are about to disappear: retire their Backup Tokens in the same
    // transaction so they report "dicabut" instead of "tidak dikenal".
    for (const own of owned) backupToken.retireOnRemoval(own, backupToken.RETIRE_REASON.REVOKED);
    ownedUserbotRepository.deleteByUser(telegramId);
    orderRepository.deleteByUser(telegramId);
    userRepository.remove(telegramId);
  });
  run();

  for (const pool of leased) {
    userbotRuntime
      .teardownAsset('pool', pool.id)
      .catch((err) => logger.error(`Gagal hentikan runtime pool #${pool.id}: ${err.message}`));
  }
  for (const own of owned) {
    userbotRuntime
      .teardownAsset('owned', own.id)
      .catch((err) => logger.error(`Gagal hentikan runtime owned #${own.id}: ${err.message}`));
  }

  logger.info(
    `User ${telegramId} deleted by admin ${adminId} (cascade: ${leased.length} pool lease(s) returned, ${owned.length} owned userbot(s) removed, ${orderCount} order(s) removed)`
  );

  return {
    returnedPoolLeases: leased.length,
    removedOwnedUserbots: owned.length,
    removedOrders: orderCount,
  };
}


/** True when the buyer owns a userbot whose subscription is ACTIVE right now (time-aware). */
function hasActiveUserbot(telegramId) {
  return subscription.hasActiveUserbot(telegramId);
}

/**
 * True when the buyer owns at least one activated userbot they can renew —
 * ACTIVE or EXPIRED. This (not hasActiveUserbot) gates the Store's
 * "Perpanjang Langganan" entry: an expired owner must still be able to renew.
 */
function hasRenewableUserbot(telegramId) {
  return subscription.hasControllableUserbot(telegramId);
}

module.exports = {
  hasActiveUserbot,
  hasRenewableUserbot,
  registerOrUpdateUser,
  adminRegisterUser,
  getUserProfile,
  banUser,
  unbanUser,
  deleteUserCascade,
};
