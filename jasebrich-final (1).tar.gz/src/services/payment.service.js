const repo = require('../database/repositories/paymentConfig.repository');

const KEYS = {
  QRIS_FILE_ID: 'qris_file_id',
  QRIS_NOTE: 'qris_note',
  BANK_INFO: 'bank_info',
};

function getQrisFileId() {
  return repo.get(KEYS.QRIS_FILE_ID);
}

function setQrisFileId(fileId) {
  repo.set(KEYS.QRIS_FILE_ID, fileId);
}

function clearQrisFileId() {
  repo.set(KEYS.QRIS_FILE_ID, null);
}

function isInvalidTelegramMediaReferenceError(err) {
  const message = String((err && (err.description || err.message)) || err || '');
  return /wrong file identifier|wrong file_id|HTTP URL specified|bad request:.*file/i.test(message);
}

function getQrisNote() {
  return repo.get(KEYS.QRIS_NOTE) || '';
}

function setQrisNote(note) {
  repo.set(KEYS.QRIS_NOTE, note);
}

function getBankInfo() {
  return repo.get(KEYS.BANK_INFO) || '';
}

function setBankInfo(text) {
  repo.set(KEYS.BANK_INFO, text);
}

module.exports = { getQrisFileId, setQrisFileId, clearQrisFileId, isInvalidTelegramMediaReferenceError, getQrisNote, setQrisNote, getBankInfo, setBankInfo };
