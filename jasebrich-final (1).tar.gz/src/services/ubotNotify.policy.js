'use strict';
/**
 * Pure rules for userbot delivery logs: channels, event filters, short failure
 * reasons, placeholder filling and card layout. Rendering through the editable
 * submenu lives in ubotNotify.templates; this module only uses its fallback.
 */

const CHANNELS = ['channel_bot', 'channel_saved', 'channel_owner'];
const EVENTS = ['on_success', 'on_fail', 'on_flood'];
const TOGGLES = [...CHANNELS, ...EVENTS];
const DEFAULTS = { channel_bot: true, channel_saved: false, channel_owner: false, on_success: false, on_fail: true, on_flood: true };
const MAX_LINES = 20;     // lines shown on the card
const MAX_ENTRIES = 200;  // log kept in memory per userbot

function normalizeSettings(row) {
  const s = {};
  for (const k of TOGGLES) s[k] = row && row[k] !== undefined && row[k] !== null ? Boolean(row[k]) : DEFAULTS[k];
  return s;
}

function activeChannels(s) {
  return CHANNELS.filter((c) => s[c]);
}

/** Never leave an enabled notification without a destination. */
function toggleSettings(s, key) {
  if (!TOGGLES.includes(key)) throw new Error(`Toggle tidak dikenal: ${key}`);
  const next = { ...s, [key]: !s[key] };
  if (CHANNELS.includes(key) && activeChannels(next).length === 0) {
    return { settings: s, error: 'Minimal satu kanal notifikasi harus aktif.' };
  }
  return { settings: next, error: null };
}

/** Turns a raw Telegram/gramjs error into a short, human reason for the log. */
function shortReason(error) {
  const source = error && typeof error === 'object' ? (error.description || error.errorMessage || error.message) : error;
  const raw = String(source ?? '').replace(/\s+/g, ' ').trim();
  if (!raw) return 'alasan tidak diketahui';
  if (/CHAT_WRITE_FORBIDDEN|USER_BANNED_IN_CHANNEL|CHAT_SEND\w*FORBIDDEN|not enough rights|have no rights/i.test(raw)) return 'tidak punya izin kirim';
  if (/NOFORWARDS|lindungi konten/i.test(raw)) return 'diblokir mode lindungi konten';
  if (/SLOWMODE/i.test(raw)) return 'slowmode aktif';
  if (/USER_NOT_PARTICIPANT|CHANNEL_PRIVATE|CHAT_RESTRICTED|kicked|left the/i.test(raw)) return 'bukan lagi anggota';
  if (/Could not find|INPUT_ENTITY|PEER_ID_INVALID|CHAT_ID_INVALID|not found/i.test(raw)) return 'target tidak ditemukan';
  if (/PEER_FLOOD|Too many requests/i.test(raw)) return 'dibatasi Telegram';
  return raw.slice(0, 80);
}

/** Replaces {placeholders}; unknown names are kept as-is so typos stay visible. */
function fillTemplate(text, values) {
  return String(text).replace(/\{(\w+)\}/g, (match, key) =>
    Object.prototype.hasOwnProperty.call(values, key) ? String(values[key]) : match);
}

/** Newest entries first. Entry: { type: 'success'|'failed'|'flood', target, reason, seconds, at }. */
function appendEntry(entries, entry) {
  return [{ ...entry, at: entry.at || Date.now() }, ...(entries || [])].slice(0, MAX_ENTRIES);
}

/** Entries the admin chose to see, oldest first so the newest line sits at the bottom. */
function visibleLines(entries, settings) {
  const allowed = new Set([
    settings.on_success && 'success',
    settings.on_fail && 'failed',
    settings.on_flood && 'flood',
  ].filter(Boolean));
  return (entries || []).filter((e) => allowed.has(e.type)).slice(0, MAX_LINES).reverse();
}

/** Plain text on purpose: targets such as @group_name must not be parsed as markup. */
function formatCard({ label, id, lines }) {
  const head = `📣 Notifikasi Pengiriman — ${label || 'Userbot'} (#${id})`;
  return `${head}\n\n${lines && lines.length ? lines.join('\n') : 'Belum ada log pengiriman.'}`;
}

module.exports = {
  CHANNELS, EVENTS, TOGGLES, DEFAULTS, MAX_LINES,
  normalizeSettings, activeChannels, toggleSettings, shortReason,
  fillTemplate, appendEntry, visibleLines, formatCard,
};
