const crypto = require('crypto');
const userRepo = require('../database/repositories/user.repository');
const repo = require('../database/repositories/broadcast.repository');
const logger = require('../utils/logger');
const { normalizeTelegramEntities, isEntityTextInvalidError, buildHtmlFallbackPayload } = require('../utils/telegramFormatting');
const { button } = require('../utils/buttons');
const { Markup } = require('telegraf');

const PAGE_SIZE = 250;
const MAX_BUTTONS = 8;
const MAX_RETRIES = 2;
const MIN_INTERVAL_MS = 75;
let runner = Promise.resolve();
let started = false;
let nextRequestAt = 0;

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

function classifyTelegramError(err) {
  const code = Number(err?.response?.error_code || err?.code || 0);
  const text = String(err?.description || err?.response?.description || err?.message || '').toLowerCase();
  const blocked = code === 403 || /bot was blocked|user is deactivated|chat not found|forbidden/.test(text);
  const rate = code === 429 || /too many requests|retry after/.test(text);
  const transient = rate || code >= 500 || /timeout|timed out|network|econn|socket|temporar|try again/.test(text);
  return { code, text, blocked, rate, transient };
}

function retryAfterSeconds(err) {
  const n = Number(err?.response?.parameters?.retry_after || err?.parameters?.retry_after || 0);
  return Number.isFinite(n) && n > 0 ? Math.min(n, 300) : 0;
}

async function throttle() {
  const wait = Math.max(0, nextRequestAt - Date.now());
  if (wait) await sleep(wait);
  nextRequestAt = Date.now() + MIN_INTERVAL_MS;
}

function normalizePayload(message) {
  if (!message || typeof message !== 'object') throw new Error('Konten broadcast tidak valid.');
  if (message.text != null) {
    const text = String(message.text);
    if (!text.trim()) throw new Error('Teks broadcast tidak boleh kosong.');
    return { kind: 'text', text, entities: normalizeTelegramEntities(text, message.entities || []) };
  }
  if (message.caption != null && (message.photo || message.video || message.document || message.animation || message.audio || message.voice)) {
    const caption = String(message.caption || '');
    const entities = normalizeTelegramEntities(caption, message.caption_entities || []);
    if (message.photo) return { kind: 'photo', file_id: largestPhotoId(message.photo), caption, caption_entities: entities };
    if (message.video) return { kind: 'video', file_id: message.video.file_id, caption, caption_entities: entities };
    if (message.document) return { kind: 'document', file_id: message.document.file_id, caption, caption_entities: entities };
    if (message.animation) return { kind: 'animation', file_id: message.animation.file_id, caption, caption_entities: entities };
    if (message.audio) return { kind: 'audio', file_id: message.audio.file_id, caption, caption_entities: entities };
    if (message.voice) return { kind: 'voice', file_id: message.voice.file_id, caption, caption_entities: entities };
  }
  if (message.photo) return { kind: 'photo', file_id: largestPhotoId(message.photo), caption: '', caption_entities: [] };
  if (message.video) return { kind: 'video', file_id: message.video.file_id, caption: '', caption_entities: [] };
  if (message.document) return { kind: 'document', file_id: message.document.file_id, caption: '', caption_entities: [] };
  if (message.animation) return { kind: 'animation', file_id: message.animation.file_id, caption: '', caption_entities: [] };
  if (message.audio) return { kind: 'audio', file_id: message.audio.file_id, caption: '', caption_entities: [] };
  if (message.voice) return { kind: 'voice', file_id: message.voice.file_id, caption: '', caption_entities: [] };
  if (message.sticker) return { kind: 'sticker', file_id: message.sticker.file_id };
  throw new Error('Jenis pesan belum didukung untuk broadcast.');
}

function largestPhotoId(photo) {
  if (!Array.isArray(photo) || !photo.length) throw new Error('Foto broadcast tidak valid.');
  const last = photo[photo.length - 1];
  if (!last?.file_id) throw new Error('Foto broadcast tidak valid.');
  return last.file_id;
}

function normalizeButtons(rawButtons) {
  if (!Array.isArray(rawButtons) || rawButtons.length === 0) return [];
  if (rawButtons.length > MAX_BUTTONS) throw new Error(`Maksimal ${MAX_BUTTONS} tombol broadcast.`);

  const hasRows = rawButtons.some((item) => item?.row != null);
  const hasUnspecifiedRows = rawButtons.some((item) => item?.row == null);
  if (hasRows && hasUnspecifiedRows) {
    throw new Error('Jika menggunakan ROW:n, semua tombol dalam daftar harus memiliki ROW:n.');
  }

  return rawButtons.map((item) => {
    const text = String(item?.text || '').trim();
    if (!text || text.length > 64) throw new Error('Teks tombol harus 1-64 karakter.');

    let row;
    if (item?.row != null) {
      row = Number(item.row);
      if (!Number.isInteger(row) || row < 1 || row > MAX_BUTTONS) throw new Error(`ROW harus berupa angka 1-${MAX_BUTTONS}.`);
    }

    if (item.type === 'url') {
      let url;
      try { url = new URL(String(item.url || '').trim()); } catch (_) { throw new Error(`URL tombol "${text}" tidak valid.`); }
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error(`URL tombol "${text}" harus HTTP/HTTPS yang aman.`);
      return { text, type: 'url', url: url.toString(), ...(row == null ? {} : { row }) };
    }
    if (item.type === 'callback') {
      const action = String(item.action || '').trim().toLowerCase();
      if (!['store', 'renewal', 'home'].includes(action)) throw new Error(`Action callback "${action}" tidak didukung.`);
      return { text, type: 'callback', action, ...(row == null ? {} : { row }) };
    }
    throw new Error(`Tipe tombol "${item.type}" tidak didukung.`);
  });
}

function parseButtonLines(input) {
  const raw = String(input || '').trim();
  if (!raw || raw === '-' || raw.toLowerCase() === 'tanpa tombol') return [];
  const lines = raw.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  return normalizeButtons(lines.map((line) => {
    const parts = line.split('|').map((x) => x.trim());
    if (parts.length !== 3 && parts.length !== 4) {
      throw new Error('Format tombol: Nama | URL | https://... atau Nama | CALLBACK | action, opsional | ROW:n. Satu tombol per baris.');
    }
    const [text, type, value, layout] = parts;
    let row;
    if (layout != null) {
      const match = /^ROW\s*:\s*(\d+)$/i.exec(layout);
      if (!match) throw new Error('Layout tombol harus ditulis sebagai ROW:n, misalnya ROW:1.');
      row = Number(match[1]);
    }
    const t = type.toUpperCase();
    if (t === 'URL') return { text, type: 'url', url: value, ...(row == null ? {} : { row }) };
    if (t === 'CALLBACK') return { text, type: 'callback', action: value, ...(row == null ? {} : { row }) };
    throw new Error('Tipe tombol hanya URL atau CALLBACK.');
  }));
}

function buildRows(buttons, makeButton) {
  if (!buttons.length) return [];
  const explicitRows = buttons.some((b) => b.row != null);
  if (!explicitRows) {
    const rows = [];
    for (let i = 0; i < buttons.length; i += 2) rows.push(buttons.slice(i, i + 2).map((b, offset) => makeButton(b, i + offset)));
    return rows;
  }

  const grouped = new Map();
  buttons.forEach((b, index) => {
    const row = Number(b.row);
    if (!grouped.has(row)) grouped.set(row, []);
    grouped.get(row).push({ button: b, index });
  });
  return Array.from(grouped.keys()).sort((a, b) => a - b).map((row) =>
    grouped.get(row).map(({ button: b, index }) => makeButton(b, index))
  );
}

function buildRealMarkup(buttons, jobId) {
  if (!buttons.length) return undefined;
  const rows = buildRows(buttons, (b, index) => {
    if (b.type === 'url') return button.primaryUrl(b.text, b.url);
    const callbackData = realCallbackData(jobId, index);
    if (Buffer.byteLength(callbackData, 'utf8') > 64) throw new Error('Callback data broadcast melebihi batas Telegram.');
    return button.primary(b.text, callbackData);
  });
  return Markup.inlineKeyboard(rows);
}

function buildDraftMarkup(buttons, adminId) {
  if (!buttons.length) return undefined;
  const rows = buildRows(buttons, (b, index) => {
    if (b.type === 'url') return button.primaryUrl(b.text, b.url);
    const callbackData = `broadcast:draft:${Number(adminId)}:${index}`;
    if (Buffer.byteLength(callbackData, 'utf8') > 64) throw new Error('Callback data preview broadcast melebihi batas Telegram.');
    return button.primary(b.text, callbackData);
  });
  return Markup.inlineKeyboard(rows);
}

function realCallbackData(jobId, index) { return `broadcast:action:${Number(jobId)}:${Number(index)}`; }

async function sendNormalized(telegram, chatId, payload, buttons = [], source = null) {
  // Telegraf's Markup.inlineKeyboard() returns a Markup wrapper whose actual
  // Telegram payload lives in `.reply_markup`. Passing the wrapper itself as
  // the value of `reply_markup` creates a nested `reply_markup.reply_markup`
  // object; Telegram then cannot receive a usable inline keyboard. Preview
  // and real broadcast MUST unwrap the same builder output before calling the
  // low-level `telegram.send*` methods.
  const markup = source?.jobId ? buildRealMarkup(buttons, source.jobId) : undefined;
  const draftMarkup = source?.draftAdminId ? buildDraftMarkup(buttons, source.draftAdminId) : undefined;
  const markupWrapper = markup || draftMarkup;
  const reply_markup = markupWrapper?.reply_markup || undefined;
  const options = reply_markup ? { reply_markup } : {};
  try {
    switch (payload.kind) {
      case 'text':
        return await telegram.sendMessage(chatId, payload.text, {
          entities: payload.entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'photo':
        return await telegram.sendPhoto(chatId, payload.file_id, {
          caption: payload.caption || '', caption_entities: payload.caption_entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'video':
        return await telegram.sendVideo(chatId, payload.file_id, {
          caption: payload.caption || '', caption_entities: payload.caption_entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'document':
        return await telegram.sendDocument(chatId, payload.file_id, {
          caption: payload.caption || '', caption_entities: payload.caption_entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'animation':
        return await telegram.sendAnimation(chatId, payload.file_id, {
          caption: payload.caption || '', caption_entities: payload.caption_entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'audio':
        return await telegram.sendAudio(chatId, payload.file_id, {
          caption: payload.caption || '', caption_entities: payload.caption_entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'voice':
        return await telegram.sendVoice(chatId, payload.file_id, {
          caption: payload.caption || '', caption_entities: payload.caption_entities || [], ...(reply_markup ? { reply_markup } : {}),
        });
      case 'sticker':
        return await telegram.sendSticker(chatId, payload.file_id, options);
      case 'copy':
        return await telegram.copyMessage(chatId, payload.source_chat_id, payload.source_message_id, options);
      default:
        throw new Error(`Jenis payload broadcast tidak didukung: ${payload.kind}`);
    }
  } catch (err) {
    if (isEntityTextInvalidError(err) && payload.kind !== 'sticker' && payload.kind !== 'copy') {
      const fallback = buildHtmlFallbackPayload(payload);
      if (payload.kind === 'text') return telegram.sendMessage(chatId, fallback.text, { parse_mode: 'HTML', ...(reply_markup ? { reply_markup } : {}) });
      const method = { photo: 'sendPhoto', video: 'sendVideo', document: 'sendDocument', animation: 'sendAnimation', audio: 'sendAudio', voice: 'sendVoice' }[payload.kind];
      if (method) return telegram[method](chatId, payload.file_id, { caption: fallback.caption || '', parse_mode: 'HTML', ...(reply_markup ? { reply_markup } : {}) });
    }
    throw err;
  }
}

async function deliverOne(telegram, job, userId, payload, buttons) {
  repo.createDelivery(job.id, userId);
  const existing = repo.getDelivery(job.id, userId);
  if (existing?.status === 'sent' || existing?.status === 'skipped') return existing.status;
  if (existing?.status === 'sending') return 'ambiguous';
  const token = crypto.randomUUID();
  if (!repo.claimDelivery(job.id, userId, token)) {
    const latest = repo.getDelivery(job.id, userId);
    return latest?.status || 'pending';
  }
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    try {
      await throttle();
      await sendNormalized(telegram, userId, payload, buttons, { jobId: job.id });
      repo.markSent(job.id, userId, token);
      return 'sent';
    } catch (err) {
      const info = classifyTelegramError(err);
      if (info.blocked) { repo.markSkipped(job.id, userId, token, 'User memblokir bot atau akun/chat tidak lagi tersedia.'); return 'skipped'; }
      if (info.rate && attempt < MAX_RETRIES) {
        const retryAfter = retryAfterSeconds(err);
        if (retryAfter) await sleep(retryAfter * 1000);
        else await sleep(1000 * (attempt + 1));
        continue;
      }
      if (info.transient && attempt < MAX_RETRIES) { await sleep(500 * (attempt + 1)); continue; }
      repo.markFailed(job.id, userId, token, info.text || 'Telegram API error');
      return 'failed';
    }
  }
  repo.markFailed(job.id, userId, token, 'Retry broadcast habis.');
  return 'failed';
}

async function runJob(telegram, jobId) {
  const job = repo.findById(jobId);
  if (!job) return;
  if (!repo.markRunning(job.id)) return;
  if (job.target_max_user_id == null) {
    const snapshot = userRepo.getBroadcastRecipientSnapshot();
    repo.initializeTargetSnapshot(job.id, snapshot.count, snapshot.maxUserId);
    job.target_count = snapshot.count;
    job.target_max_user_id = snapshot.maxUserId;
  }
  repo.quarantineStaleSending();
  let afterId = 0;
  let fatal = null;
  try {
    for (;;) {
      const targets = userRepo.listBroadcastRecipientSnapshotPage(afterId, PAGE_SIZE, job.target_max_user_id);
      if (!targets.length) break;
      for (const user of targets) {
        afterId = Number(user.id);
        await deliverOne(telegram, job, Number(user.telegram_id), job.payload, job.buttons);
      }
    }
  } catch (err) {
    fatal = String(err?.message || err);
    logger.error(`Broadcast #${job.id} runner failed: ${fatal}`);
  }
  const counts = repo.countDeliveryStates(job.id);
  const finalStatus = fatal ? 'failed' : (counts.pending || counts.sending ? 'failed' : 'completed');
  repo.setCounts(job.id, { success: counts.sent, failed: counts.failed, skipped: counts.skipped, retries: 0, target: job.target_count });
  repo.complete(job.id, finalStatus, fatal);
  try {
    const duration = job.started_at ? Math.max(0, (Date.now() - Date.parse(job.started_at)) / 1000) : 0;
    await telegram.sendMessage(
      job.admin_id,
      `📣 *Broadcast #${job.id} ${finalStatus === 'completed' ? 'Selesai' : 'Berhenti'}*\n\n` +
      `🎯 Target: ${job.target_count}\n✅ Berhasil: ${counts.sent}\n❌ Gagal: ${counts.failed}\n⏭️ Dilewati: ${counts.skipped}\n⏱️ Durasi: ${duration.toFixed(1)} detik`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    logger.warn(`Broadcast #${job.id}: summary admin gagal dikirim: ${err.message}`);
  }
}

function startJob(telegram, jobId) {
  runner = runner.then(() => runJob(telegram, jobId)).catch((err) => logger.error('Broadcast queue runner failed:', err));
  return runner;
}

async function resumeJobs(telegram) {
  if (started) return;
  started = true;
  repo.quarantineStaleSending();
  for (const job of repo.listRunnableJobs()) startJob(telegram, job.id);
}

function preview(telegram, chatId, payload, buttons, adminId) {
  return sendNormalized(telegram, chatId, payload, buttons, { draftAdminId: adminId });
}

function createJob(args) {
  const idempotencyKey = String(args.idempotencyKey || `broadcast:${args.adminId}:${crypto.randomUUID()}`);
  return repo.createJob({ ...args, idempotencyKey });
}

function history(limit) { return repo.listHistory(limit); }
function status(jobId) { return repo.findById(jobId); }

module.exports = {
  MAX_BUTTONS,
  normalizePayload,
  normalizeButtons,
  parseButtonLines,
  buildDraftMarkup,
  buildRealMarkup,
  preview,
  createJob,
  startJob,
  resumeJobs,
  history,
  status,
  normalizePayload,
};
