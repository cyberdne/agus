const { defineTemplate, buildReplyOptions } = require('./custom-submenu.service');

/** Canonical cancellation notices. Defaults remain exact and can be customized
 * through the same Custom Submenu registry used by all other user-facing text.
 */
const cancelledTemplate = defineTemplate(
  'system.cancelled', 'System', 'Tindakan Dibatalkan',
  '❌ Tindakan dibatalkan oleh user.'
);
const noActiveTemplate = defineTemplate(
  'system.no_active', 'System', 'Tidak Ada Proses Aktif',
  'ℹ️ Tidak ada proses aktif yang berlangsung.'
);
const cancelledCallbackTemplate = defineTemplate(
  'system.cancelled_callback', 'System', 'Alert Tindakan Dibatalkan',
  '❌ Tindakan dibatalkan oleh user.',
  { messageType: 'callback_alert', maxLength: 200 }
);
const noActiveCallbackTemplate = defineTemplate(
  'system.no_active_callback', 'System', 'Alert Tidak Ada Proses Aktif',
  'ℹ️ Tidak ada proses aktif yang berlangsung.',
  { messageType: 'callback_alert', maxLength: 200 }
);

const CANCELLED_TEXT = '❌ Tindakan dibatalkan oleh user.';
const NO_ACTIVE_TEXT = 'ℹ️ Tidak ada proses aktif yang berlangsung.';

function getCancelledContent(ctx) { return cancelledTemplate.getContent(ctx); }
function getNoActiveContent(ctx) { return noActiveTemplate.getContent(ctx); }
function getCancelledText(ctx) { return getCancelledContent(ctx).text; }
function getNoActiveText(ctx) { return getNoActiveContent(ctx).text; }

function replyCancelled(ctx) {
  const content = getCancelledContent(ctx);
  return ctx.reply(content.text, buildReplyOptions(content));
}

function replyNoActive(ctx) {
  const content = getNoActiveContent(ctx);
  return ctx.reply(content.text, buildReplyOptions(content));
}

async function answerCancelled(ctx, options = { show_alert: false }) {
  if (!ctx || typeof ctx.answerCbQuery !== 'function') return false;
  try {
    const content = cancelledCallbackTemplate.getContent(ctx);
    await ctx.answerCbQuery(content.text, options);
    return true;
  } catch (_) {
    return false;
  }
}

async function answerNoActive(ctx, options = { show_alert: false }) {
  if (!ctx || typeof ctx.answerCbQuery !== 'function') return false;
  try {
    const content = noActiveCallbackTemplate.getContent(ctx);
    await ctx.answerCbQuery(content.text, options);
    return true;
  } catch (_) {
    return false;
  }
}

module.exports = {
  CANCELLED_TEXT,
  NO_ACTIVE_TEXT,
  replyCancelled,
  replyNoActive,
  answerCancelled,
  answerNoActive,
  getCancelledContent,
  getNoActiveContent,
  getCancelledText,
  getNoActiveText,
};
