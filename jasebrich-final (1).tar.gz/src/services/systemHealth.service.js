'use strict';
/**
 * System health monitor. Runs on every scheduler tick, evaluates the checks in
 * systemHealth.policy and maintains one card per admin.
 *
 * Message budget (anti-spam):
 *   - first run: one card is created per admin
 *   - status change: the card is edited
 *   - an incident starting (any check turns critical): ONE new message per admin
 *     so the admin is actually alerted, then the card carries the rest
 *   - an open problem: a heartbeat edit every heartbeat_hours, nothing more
 */
const fs = require('fs');
const path = require('path');
const { config } = require('../config');
const { getDb } = require('../database');
const logger = require('../utils/logger');
const policy = require('./systemHealth.policy');
const notifyCard = require('./notifyCard.service');
const autoBackup = require('./autoBackup.service');
const ubotNotify = require('./ubotNotify.service');
const reminderRepo = require('../database/repositories/subscriptionReminder.repository');

let telegram = null;
const HEARTBEAT_OPTIONS_HOURS = [3, 6, 12, 24];

function setTelegram(t) { telegram = t; }

function getState() {
  return getDb().prepare('SELECT * FROM system_health_state WHERE id = 1').get() || {};
}

function updateState(fields) {
  const cols = Object.keys(fields);
  if (!cols.length) return;
  getDb().prepare(`UPDATE system_health_state SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = 1`)
    .run(...cols.map((c) => fields[c]));
}

function getSettings() {
  const s = getState();
  return {
    enabled: s.enabled === undefined ? true : Boolean(s.enabled),
    heartbeatHours: Number(s.heartbeat_hours) || 6,
    overall: s.overall || 'ok',
    incidentStartedAt: s.incident_started_at || null,
    lastCheckedAt: s.last_checked_at || null,
  };
}

function setEnabled(enabled) { updateState({ enabled: enabled ? 1 : 0 }); }

function nextHeartbeat(current) {
  const i = HEARTBEAT_OPTIONS_HOURS.indexOf(Number(current));
  return HEARTBEAT_OPTIONS_HOURS[(i + 1) % HEARTBEAT_OPTIONS_HOURS.length];
}
function cycleHeartbeat() {
  updateState({ heartbeat_hours: nextHeartbeat(getSettings().heartbeatHours) });
}

function collectInput(schedulerStatus, nowMs) {
  let db = { ok: true, error: null };
  try { getDb().prepare('SELECT 1').get(); } catch (err) { db = { ok: false, error: err.message }; }

  let disk = { freeRatio: NaN };
  try {
    const dir = path.dirname(path.resolve(process.cwd(), config.dbPath));
    const st = fs.statfsSync(dir);
    if (st.blocks > 0) disk = { freeRatio: st.bavail / st.blocks };
  } catch (_) { /* unknown filesystem stats: reported as "tidak diketahui" */ }

  const backup = autoBackup.getConfig();
  return {
    nowMs,
    scheduler: schedulerStatus || {},
    db,
    disk,
    reminder: { lastRun: reminderRepo.lastRun() || null },
    backup: { enabled: backup.enabled, lastRunAt: backup.lastRunAt, lastStatus: backup.lastStatus, intervalHours: backup.intervalHours },
    ubot: ubotNotify.recentStats(),
  };
}

async function runCheck({ telegram: tg, schedulerStatus, nowMs = Date.now() } = {}) {
  const settings = getSettings();
  if (!settings.enabled) return { skipped: 'disabled' };
  const t = tg || telegram;
  const state = getState();
  const checks = policy.evaluateChecks(collectInput(schedulerStatus, nowMs));
  const overall = policy.overallStatus(checks);
  const signature = policy.signatureOf(checks);
  const nowIso = new Date(nowMs).toISOString();

  const incidentStart = overall === 'critical' && settings.overall !== 'critical';
  let incidentStartedAt = null;
  if (overall !== 'ok') incidentStartedAt = incidentStart ? nowIso : (settings.incidentStartedAt || nowIso);

  const action = policy.decideCardAction({
    prevSignature: state.signature || null,
    nextSignature: signature,
    lastEditMs: state.last_card_edit_at ? Date.parse(state.last_card_edit_at) : NaN,
    nowMs,
    heartbeatMs: settings.heartbeatHours * 3600 * 1000,
    overall,
  });

  if (action !== 'none' && t) {
    const text = policy.formatCard({ checks, overall, incidentStartedAt, nowLabel: nowIso.slice(11, 16) });
    for (const adminId of config.adminIds || []) {
      try {
        await notifyCard.upsertCard({
          key: `health:admin:${adminId}`,
          chatId: adminId,
          transport: notifyCard.botTransport(t, adminId),
          text,
        });
      } catch (err) {
        logger.warn(`Kartu kesehatan ke admin ${adminId} gagal: ${err.message}`);
      }
    }
  }

  if (incidentStart && t) {
    const names = checks.filter((c) => c.status === 'critical').map((c) => c.label).join(', ');
    for (const adminId of config.adminIds || []) {
      try {
        await t.sendMessage(adminId, `🚨 <b>Insiden kesehatan sistem</b>\nKritis: ${names}\nDetail ada di kartu Kesehatan Sistem.`, { parse_mode: 'HTML' });
      } catch (err) {
        logger.warn(`Alert insiden ke admin ${adminId} gagal: ${err.message}`);
      }
    }
  }

  updateState({
    signature,
    overall,
    incident_started_at: incidentStartedAt,
    last_checked_at: nowIso,
    ...(action !== 'none' ? { last_card_edit_at: nowIso } : {}),
  });
  return { overall, action, incidentStart };
}

module.exports = { HEARTBEAT_OPTIONS_HOURS, setTelegram, getSettings, setEnabled, cycleHeartbeat, runCheck };
