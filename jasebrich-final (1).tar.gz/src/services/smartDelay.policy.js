'use strict';
/**
 * Smart Delay: adaptive inter-group delay, pure rules.
 *
 * Contract with the manual setting (Atur Jeda -> Jeda Antar Grup, min..max):
 *   - Smart OFF  -> exactly the manual behaviour (delayPolicy.sampleGroupDelay).
 *   - Smart ON   -> starts at the manual minimum (floor). The manual maximum is
 *                   the ceiling. Smart never leaves [floor, ceiling].
 *   - Fixed value (min = max) has no range to move in, so the ceiling becomes
 *     max(3 x value, 60 s) capped at 24 h: headroom to back off after FloodWait.
 *   - Round delay (Jeda Antar Putaran) is never touched by Smart.
 */
const delayPolicy = require('./delayPolicy.service');

const MAX_SECONDS = delayPolicy.GROUP_DELAY_MAX_SECONDS;
const FLOOD_GROWTH = 1.5;          // a flood wait multiplies the delay by this...
const SUCCESS_STREAK_TO_DECAY = 10; // ...and this many clean sends in a row relax it
const DECAY_FACTOR = 0.9;
const JITTER_RATIO = 0.2;          // sampled value sits in [current, current * 1.2]

function bounds(range) {
  const floor = Number(range.min) || 0;
  const max = Number(range.max) || 0;
  const ceiling = max > floor ? max : Math.min(MAX_SECONDS, Math.max(floor * 3, 60));
  return { floor, ceiling };
}

function clamp(value, b) {
  return Math.min(b.ceiling, Math.max(b.floor, Math.round(Number(value) || 0)));
}

/** Manual changes take effect here: a stored value is clamped into the new range. */
function normalizeState(state, range) {
  const b = bounds(range);
  const current = state && Number.isFinite(Number(state.current)) ? clamp(state.current, b) : b.floor;
  const streak = state && Number.isInteger(Number(state.streak)) ? Math.max(0, Number(state.streak)) : 0;
  return { current, streak };
}

function onFlood(state, range, floodSeconds) {
  const b = bounds(range);
  const s = normalizeState(state, range);
  const grown = Math.max(s.current * FLOOD_GROWTH, s.current + (Number(floodSeconds) || 0));
  return { current: clamp(grown, b), streak: 0 };
}

function onSuccess(state, range) {
  const b = bounds(range);
  const s = normalizeState(state, range);
  const streak = s.streak + 1;
  if (streak < SUCCESS_STREAK_TO_DECAY) return { current: s.current, streak };
  return { current: clamp(Math.floor(s.current * DECAY_FACTOR), b), streak: 0 };
}

/**
 * Smart OFF returns the manual sample so the legacy path stays identical.
 * Smart ON samples in [current, current * (1 + JITTER)] capped at the ceiling.
 */
function chooseGroupDelay({ enabled, state, range, random = Math.random }) {
  if (!enabled) return delayPolicy.sampleGroupDelay(range, random);
  const b = bounds(range);
  const s = normalizeState(state, range);
  const upper = Math.min(b.ceiling, Math.round(s.current * (1 + JITTER_RATIO)));
  if (upper <= s.current) return s.current;
  const r = Number(random());
  if (!Number.isFinite(r) || r < 0 || r >= 1) throw new Error('Random source harus menghasilkan nilai pada [0, 1).');
  return s.current + Math.floor(r * (upper - s.current + 1));
}

function describe({ enabled, state, range }) {
  if (!enabled) return `NONAKTIF, memakai jeda yang sudah diset (${delayPolicy.formatGroupDelayRange(range)} detik).`;
  const b = bounds(range);
  const s = normalizeState(state, range);
  return `AKTIF, saat ini ${s.current} dtk (batas ${b.floor}-${b.ceiling} dtk). Naik otomatis saat FloodWait, turun pelan setelah ${SUCCESS_STREAK_TO_DECAY} kirim berhasil.`;
}

module.exports = {
  SUCCESS_STREAK_TO_DECAY, bounds, normalizeState, onFlood, onSuccess, chooseGroupDelay, describe,
};
