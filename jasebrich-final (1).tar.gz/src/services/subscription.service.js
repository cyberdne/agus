/**
 * Subscription service for OWNED userbots (userbots table).
 *
 * This is the single source of truth for "is this userbot's subscription
 * still valid?" and the only place that is allowed to change expires_at /
 * status of a userbot. It deliberately builds on the subscription data the
 * project already has (userbots.expires_at + userbots.status, fed by orders)
 * instead of introducing a second subscription system.
 *
 * Model
 * -----
 *  - userbots.status         : subscription lifecycle
 *                              pending_otp | active | expired | revoked
 *  - userbots.expires_at     : UTC ISO-8601 timestamp (NULL = no expiry set)
 *  - userbots.runtime_stop_reason : WHY the runtime is stopped
 *                              SUBSCRIPTION_EXPIRED | SESSION_INVALID | NULL
 *                              (separate column: subscription vs session
 *                              state must never be merged)
 *
 * The EFFECTIVE state is always derived from the timestamp at read time
 * (getSubscriptionState), never from the persisted `status` alone — so a
 * userbot whose expires_at has passed is EXPIRED the very instant
 * `now >= expires_at`, even if no scheduler tick has run yet. The persisted
 * status is then reconciled by expireIfDue() (lazy, on access) and by the
 * scheduler (cleanup), both of which are idempotent compare-and-swap writes.
 *
 * All timestamps are UTC (Date.now()/toISOString()); presentation timezone
 * conversion happens only when formatting for humans (utils/placeholders).
 */

const { getDb } = require('../database');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const eventRepo = require('../database/repositories/subscriptionEvent.repository');
const logger = require('../utils/logger');

const STATE = Object.freeze({
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
  SUSPENDED: 'SUSPENDED', // access revoked by admin (status = revoked)
  PENDING: 'PENDING', // bought but Telegram login not finished yet
  INACTIVE: 'INACTIVE',
});

const RUNTIME_STOP_REASON = Object.freeze({
  SUBSCRIPTION_EXPIRED: 'SUBSCRIPTION_EXPIRED',
  SESSION_INVALID: 'SESSION_INVALID',
});

const TRIAL_LABEL = '🎁 Trial Userbot';
const MAX_EXTENSION_DAYS = 3650;
const DAY_MS = 24 * 60 * 60 * 1000;
const FALLBACK_EXTENSION_DAYS = [7, 30, 90];

class SubscriptionError extends Error {
  constructor(code, message) {
    super(message || code);
    this.name = 'SubscriptionError';
    this.code = code;
  }
}

// ---------------------------------------------------------------- timestamps

/**
 * Parses either an ISO-8601 string (what this codebase writes) or SQLite's
 * `datetime('now')` format (`YYYY-MM-DD HH:MM:SS`, UTC) into epoch ms.
 * Returns null for null/empty, NaN for present-but-unparseable values.
 */
function parseTimestamp(value) {
  if (value === null || value === undefined || value === '') return null;
  const raw = String(value).trim();
  const normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw) ? `${raw.replace(' ', 'T')}Z` : raw;
  return new Date(normalized).getTime();
}

/**
 * Deterministic boundary: expired when now >= expires_at.
 * NULL expiry = unlimited (legacy rows). A present-but-corrupt expiry fails
 * CLOSED (treated as expired) rather than granting unlimited access.
 */
function isExpiredAt(expiresAt, nowMs = Date.now()) {
  const exp = parseTimestamp(expiresAt);
  if (exp === null) return false;
  if (Number.isNaN(exp)) return true;
  return nowMs >= exp;
}

function isTrial(row) {
  return Boolean(row) && row.label === TRIAL_LABEL && !row.order_id;
}

/** Effective subscription state, derived from time + persisted status. */
function getSubscriptionState(row, nowMs = Date.now()) {
  if (!row) return null;
  switch (row.status) {
    case 'revoked':
      return STATE.SUSPENDED;
    case 'pending_otp':
      return STATE.PENDING;
    case 'active':
    case 'expired':
      return isExpiredAt(row.expires_at, nowMs) ? STATE.EXPIRED : STATE.ACTIVE;
    default:
      return STATE.INACTIVE;
  }
}

function isActiveNow(row, nowMs = Date.now()) {
  return getSubscriptionState(row, nowMs) === STATE.ACTIVE;
}

/** Owned userbots a buyer may still renew (activated, not revoked). */
function isRenewable(row) {
  return Boolean(row) && (row.status === 'active' || row.status === 'expired');
}

// ----------------------------------------------------------------- extension

function assertValidDays(days) {
  const n = Number(days);
  if (!Number.isInteger(n) || n < 1 || n > MAX_EXTENSION_DAYS) {
    throw new SubscriptionError('INVALID_DURATION', `Durasi harus berupa angka bulat 1–${MAX_EXTENSION_DAYS} hari.`);
  }
  return n;
}

/**
 * The renewal rule:
 *   still valid  (expires_at >  now): new = expires_at + duration
 *   already over (expires_at <= now): new = now        + duration
 * Pure function of (row, days, now) — used both for the confirmation
 * preview and (re-evaluated against fresh DB state) for the real write.
 */
function computeExtension(row, days, nowMs = Date.now()) {
  const n = assertValidDays(days);
  const currentMs = parseTimestamp(row.expires_at);
  const stillValid = currentMs !== null && !Number.isNaN(currentMs) && currentMs > nowMs;
  const baseMs = stillValid ? currentMs : nowMs;
  const newMs = baseMs + n * DAY_MS;
  return {
    days: n,
    base: stillValid ? 'current_expiry' : 'now',
    previousExpiry: row.expires_at || null,
    previousState: getSubscriptionState(row, nowMs),
    newExpiryMs: newMs,
    newExpiry: new Date(newMs).toISOString(),
  };
}

/**
 * Atomically extends a subscription.
 *
 * Everything below runs inside ONE better-sqlite3 transaction:
 *   1. INSERT OR IGNORE the audit row keyed by operationId
 *        -> if it already existed the operation was already applied:
 *           NOTHING is modified and { duplicate: true } is returned
 *           (this is the idempotency guarantee; it survives restarts).
 *   2. UPDATE userbots (expires_at, status='active', expired_at=NULL,
 *      runtime_stop_reason cleared ONLY if it was SUBSCRIPTION_EXPIRED,
 *      sub_version+1, updated_at) with a version compare-and-swap.
 * If any statement throws, the whole transaction rolls back — the userbot
 * is never left half-changed and no audit row exists for a change that
 * did not happen.
 *
 * Because better-sqlite3 is synchronous and single-writer, this cannot
 * interleave with expireIfDue(): either the extension wins (the later
 * expiry CAS then matches 0 rows) or the expiry wins (extension then
 * computes from `now` and flips status back to active).
 *
 * This function does NOT touch the Telegram runtime; callers reconcile the
 * runtime afterwards from the freshly committed DB state
 * (services/userbotLifecycle.service.js).
 */
function extend({ userbotId, days, operationId, action = 'admin_extend', adminId = null, orderId = null, ownerUserId = null, nowMs = Date.now() }) {
  if (!operationId) throw new SubscriptionError('MISSING_OPERATION_ID', 'operationId wajib diisi.');
  const n = assertValidDays(days);
  const db = getDb();

  const run = db.transaction(() => {
    // Duplicate check FIRST: a replay of an already-applied operation must
    // always be reported as a duplicate, even if the userbot has since
    // changed state (e.g. expired again or been revoked).
    const existing = eventRepo.findByOperationId(operationId);
    if (existing) {
      return { duplicate: true, event: existing, row: ownedRepo.findById(userbotId) };
    }

    const row = ownedRepo.findById(userbotId);
    if (!row) throw new SubscriptionError('NOT_FOUND', `Userbot #${userbotId} tidak ditemukan.`);
    if (ownerUserId !== null && Number(row.user_id) !== Number(ownerUserId)) {
      throw new SubscriptionError('NOT_OWNER', `Userbot #${userbotId} bukan milik user ${ownerUserId}.`);
    }
    if (!isRenewable(row)) {
      throw new SubscriptionError('NOT_EXTENDABLE', `Userbot #${userbotId} berstatus "${row.status}" dan tidak dapat diperpanjang.`);
    }

    const calc = computeExtension(row, n, nowMs);
    const nowIso = new Date(nowMs).toISOString();

    eventRepo.insertIgnore({
      operationId,
      action,
      userbotId: row.id,
      ownerUserId: row.user_id,
      adminId,
      orderId,
      previousStatus: getSubscriptionState(row, nowMs),
      previousExpiry: row.expires_at || null,
      extensionDays: n,
      newStatus: STATE.ACTIVE,
      newExpiry: calc.newExpiry,
      createdAt: nowIso,
    });

    const res = db
      .prepare(
        `UPDATE userbots
            SET expires_at = ?, status = 'active', expired_at = NULL,
                runtime_stop_reason = CASE WHEN runtime_stop_reason = 'SUBSCRIPTION_EXPIRED' THEN NULL ELSE runtime_stop_reason END,
                sub_version = sub_version + 1, updated_at = ?
          WHERE id = ? AND sub_version = ?`
      )
      .run(calc.newExpiry, nowIso, row.id, row.sub_version || 0);
    if (res.changes !== 1) {
      // Someone changed the subscription between our read and write.
      throw new SubscriptionError('CONFLICT', 'Langganan berubah saat diproses. Silakan coba lagi.');
    }

    return {
      duplicate: false,
      event: eventRepo.findByOperationId(operationId),
      row: ownedRepo.findById(row.id),
      before: row,
      calc,
    };
  });

  const result = run();
  if (!result.duplicate) {
    logger.info(
      `Subscription extended: userbot #${result.row.id} +${n}d (${action}${adminId ? ` by admin ${adminId}` : ''}${orderId ? ` order #${orderId}` : ''}) -> ${result.row.expires_at}`
    );
  } else {
    logger.debug(`Subscription extend ignored (duplicate operation ${operationId}) for userbot #${userbotId}`);
  }
  return result;
}

// -------------------------------------------------------------------- expiry

/**
 * Persists the EXPIRED transition for a userbot whose expires_at has passed.
 * Idempotent compare-and-swap: only the caller that actually flips
 * active -> expired gets { transitioned: true }; every other call (double
 * scheduler tick, lazy access check, runtime timer, restart) is a no-op.
 *
 * Deliberately retains everything: session, token, configuration, groups,
 * messages, flags. Only status / runtime_stop_reason / expired_at change.
 * Trial userbots are skipped — their existing policy (delete on expiry, see
 * userbot.service#sweepExpiredTrials) stays untouched.
 */
function expireIfDue(userbotId, nowMs = Date.now()) {
  const db = getDb();
  const run = db.transaction(() => {
    const row = ownedRepo.findById(userbotId);
    if (!row) return { transitioned: false, reason: 'not_found' };
    if (row.status !== 'active') return { transitioned: false, reason: 'not_active', row };
    if (isTrial(row)) return { transitioned: false, reason: 'trial', row };
    if (!isExpiredAt(row.expires_at, nowMs)) return { transitioned: false, reason: 'not_due', row };

    const nowIso = new Date(nowMs).toISOString();
    const res = db
      .prepare(
        `UPDATE userbots
            SET status = 'expired', runtime_stop_reason = 'SUBSCRIPTION_EXPIRED', expired_at = ?,
                sub_version = sub_version + 1, updated_at = ?
          WHERE id = ? AND status = 'active' AND sub_version = ?`
      )
      .run(nowIso, nowIso, row.id, row.sub_version || 0);
    if (res.changes !== 1) return { transitioned: false, reason: 'conflict', row };

    // Audit (one row per expiry period; INSERT OR IGNORE keeps it single even
    // if a token-claim re-activated the same lapsed period and it expires again).
    eventRepo.insertIgnore({
      operationId: `expire:${row.id}:${row.expires_at}`,
      action: 'auto_expire',
      userbotId: row.id,
      ownerUserId: row.user_id,
      previousStatus: STATE.ACTIVE,
      previousExpiry: row.expires_at,
      newStatus: STATE.EXPIRED,
      newExpiry: row.expires_at,
      createdAt: nowIso,
    });
    return { transitioned: true, row: ownedRepo.findById(row.id) };
  });

  const result = run();
  if (result.transitioned) logger.info(`Userbot #${userbotId} subscription EXPIRED (access locked, configuration retained)`);
  return result;
}

// ------------------------------------------------------------------- queries

/** Owned userbots of a buyer that they may renew (active or expired, activated). */
function listRenewable(telegramId) {
  return ownedRepo.listRenewableByUser(telegramId);
}

/** Owned userbots currently ACTIVE (time-aware). */
function listActiveNow(telegramId, nowMs = Date.now()) {
  return ownedRepo.listRenewableByUser(telegramId).filter((r) => isActiveNow(r, nowMs));
}

function hasActiveUserbot(telegramId) {
  return listActiveNow(telegramId).length > 0;
}

/** True when the buyer owns at least one activated userbot (active OR expired) — drives Kontrol Panel / Perpanjang entry points. */
function hasControllableUserbot(telegramId) {
  return listRenewable(telegramId).length > 0;
}

/**
 * Extension durations offered to admins. Uses the package durations that
 * already exist in the Store catalog (active `userbot` products'
 * duration_days) so nothing is hardcoded when packages exist; falls back
 * to 7/30/90 only if no active package defines one.
 */
function getExtensionOptions() {
  let fromCatalog = [];
  try {
    const productService = require('./product.service');
    fromCatalog = productService
      .listActive(productService.CATEGORIES.USERBOT)
      .map((p) => Number(p.duration_days))
      .filter((d) => Number.isInteger(d) && d >= 1 && d <= MAX_EXTENSION_DAYS);
  } catch (err) {
    logger.warn(`Gagal membaca durasi paket untuk perpanjangan admin: ${err.message}`);
  }
  const unique = Array.from(new Set(fromCatalog)).sort((a, b) => a - b).slice(0, 5);
  return unique.length ? unique : FALLBACK_EXTENSION_DAYS.slice();
}

/**
 * Rows for the admin list, with derived state attached.
 * filter: 'a' = semua, 'e' = expired, 's' = aktif.
 */
function listForAdmin({ filter = 'a', page = 0, pageSize = 8, nowMs = Date.now() } = {}) {
  const all = ownedRepo.listForSubscriptionAdmin().map((r) => ({ ...r, state: getSubscriptionState(r, nowMs) }));
  const filtered = all.filter((r) => (filter === 'e' ? r.state === STATE.EXPIRED : filter === 's' ? r.state === STATE.ACTIVE : true));
  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(Math.max(0, page), totalPages - 1);
  return {
    rows: filtered.slice(safePage * pageSize, safePage * pageSize + pageSize),
    total,
    totalPages,
    page: safePage,
    counts: {
      all: all.length,
      expired: all.filter((r) => r.state === STATE.EXPIRED).length,
      active: all.filter((r) => r.state === STATE.ACTIVE).length,
    },
  };
}

module.exports = {
  STATE,
  RUNTIME_STOP_REASON,
  TRIAL_LABEL,
  MAX_EXTENSION_DAYS,
  SubscriptionError,
  parseTimestamp,
  isExpiredAt,
  isTrial,
  getSubscriptionState,
  isActiveNow,
  isRenewable,
  computeExtension,
  extend,
  expireIfDue,
  listRenewable,
  listActiveNow,
  hasActiveUserbot,
  hasControllableUserbot,
  getExtensionOptions,
  listForAdmin,
};
