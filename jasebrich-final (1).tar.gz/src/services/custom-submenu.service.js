const repo = require('../database/repositories/submenuCustomization.repository');
const submenuRegistry = require('../constants/submenu.registry');
const { applyPlaceholders, extractPlaceholders, PLACEHOLDER_DOCS } = require('../utils/placeholders');
const logger = require('../utils/logger');
const { normalizeTelegramEntities } = require('../utils/telegramFormatting');

const MAX_TEXT_LENGTH = 4096;

function resolveMaxLength(entry) {
  if (!entry) return MAX_TEXT_LENGTH;
  const value = Number(entry.maxLength);
  if (Number.isInteger(value) && value > 0) return value;
  // Registry entries are normalized at registration time. Reaching this branch
  // means metadata is corrupt/stale; never turn it into maxLength=0.
  throw new Error(`Metadata template tidak valid untuk context ${entry.id || '-'}: maxLength harus bilangan bulat > 0.`);
}


const SUPPORTED_ENTITY_TYPES = new Set([
  'mention', 'hashtag', 'cashtag', 'bot_command', 'url', 'email', 'phone_number',
  'bold', 'italic', 'underline', 'strikethrough', 'spoiler', 'blockquote',
  'expandable_blockquote', 'code', 'pre', 'text_link', 'text_mention', 'custom_emoji', 'date_time',
]);

function registryEntry(submenuId) {
  return submenuRegistry.getById(submenuId);
}

// The latest registry has separate contexts for the userbot picker and the
// selected-userbot control panel. Older deployments could have the old
// control-panel body saved under the picker key. That payload is identifiable
// by the audited legacy placeholder set below; migrate it once, only when the
// canonical destination is still empty. We never guess keys or rewrite an
// unrelated custom message.
const LEGACY_CONTROL_PANEL_PLACEHOLDERS = new Set([
  'auto_promosi', 'wtb_reply', 'pm_permit', 'telegram_userbot_id',
  'userbot_produk', 'expired_at',
]);

function maybeMigrateLegacyControlPanelTemplate(submenuId, row) {
  if (submenuId !== 'control_panel_select_asset' || !row || typeof row.content_text !== 'string') return row;
  const placeholders = extractPlaceholders(row.content_text);
  const legacyHitCount = placeholders.filter((name) => LEGACY_CONTROL_PANEL_PLACEHOLDERS.has(name)).length;
  if (legacyHitCount < 2) return row;
  try {
    const moved = repo.moveIfDestinationMissing('control_panel_select_asset', 'control_panel_main');
    if (moved) {
      logger.warn('Migrated legacy custom template control_panel_select_asset -> control_panel_main based on its audited control-panel placeholders.');
      return moved;
    }

    // If the canonical control-panel context already has a customization,
    // the legacy row must not remain active under the picker context. Keeping
    // it would repeatedly validate/render the same control-panel payload
    // against the wrong placeholder contract on every picker open. The
    // canonical destination remains authoritative.
    const canonical = repo.findBySubmenuId('control_panel_main');
    if (canonical) {
      repo.deleteBySubmenuId('control_panel_select_asset');
      logger.warn('Removed stale legacy custom template control_panel_select_asset because control_panel_main already exists.');
      return canonical;
    }
  } catch (err) {
    logger.error(`Failed legacy customization migration control_panel_select_asset -> control_panel_main: ${err.message}`);
  }
  return row;
}

function validateContent(content, submenuId = null) {
  if (!content || typeof content.text !== 'string') throw new Error('Custom submenu harus berupa pesan teks Telegram yang valid.');
  if (content.text.length === 0) throw new Error('Custom submenu tidak boleh kosong.');
  const entry = submenuId ? registryEntry(submenuId) : null;
  if (submenuId && !entry) throw new Error(`Context template tidak terdaftar: ${submenuId}`);
  const maxLength = resolveMaxLength(entry);
  if (content.text.length > maxLength) throw new Error(`Template maksimal ${maxLength} karakter untuk context ini.`);

  const rawEntities = Array.isArray(content.entities) ? content.entities : [];
  const entities = normalizeTelegramEntities(content.text, rawEntities);
  for (const entity of entities) {
    if (!SUPPORTED_ENTITY_TYPES.has(String(entity.type || ''))) {
      throw new Error(`Format Telegram tidak didukung untuk template ini: ${entity.type}`);
    }
  }
  if (entry && entry.messageType === 'callback_alert' && entities.length) {
    throw new Error('Callback alert hanya mendukung teks polos Telegram; formatting/entity tidak dapat dikirim melalui answerCallbackQuery.');
  }

  if (entry && Array.isArray(entry.supportedPlaceholders)) {
    const allowed = new Set(entry.supportedPlaceholders.map((token) => String(token).replace(/^\{|\}$/g, '')));
    const unknown = extractPlaceholders(content.text).filter((name) => !allowed.has(name));
    if (unknown.length) throw new Error(`Placeholder tidak didukung untuk ${entry.label}: ${unknown.map((x) => `{${x}}`).join(', ')}`);
  }

  return { text: content.text, entities };
}

function rowToContent(row) {
  if (!row) return null;
  let entities = [];
  try { entities = JSON.parse(row.content_entities || '[]'); }
  catch (err) { logger.error(`Failed to parse stored entities for submenu ${row.submenu_id}:`, err.message); }
  return { text: row.content_text, entities, updatedBy: row.updated_by, updatedAt: row.updated_at };
}
function getCustomContent(submenuId) {
  const row = maybeMigrateLegacyControlPanelTemplate(submenuId, repo.findBySubmenuId(submenuId));
  return rowToContent(row);
}
function hasCustomContent(submenuId) { return getCustomContent(submenuId) != null; }
function getTemplateMeta(submenuId) { return registryEntry(submenuId); }

function getDefaultContent(submenuId, ctx, extra = {}) {
  const entry = registryEntry(submenuId);
  if (!entry) throw new Error(`Context template tidak terdaftar: ${submenuId}`);
  const fallback = resolveDefault({ text: entry.defaultValue, parse_mode: entry.parseMode }, ctx, extra);
  if (!fallback || typeof fallback.text !== 'string' || fallback.text.length === 0) {
    throw new Error(`Default template tidak valid untuk context ${submenuId}.`);
  }
  const entities = Array.isArray(fallback.entities) && fallback.entities.length
    ? normalizeTelegramEntities(fallback.text, fallback.entities)
    : null;
  return {
    text: fallback.text,
    ...(entities ? { entities } : {}),
    parse_mode: fallback.parse_mode || entry.parseMode || 'Markdown',
  };
}

function escapeReferencePlaceholderTokens(text, parseMode) {
  if (typeof text !== 'string' || !text.includes('{')) return text;
  const mode = String(parseMode || '').toLowerCase();
  if (mode === 'html') return text;

  // The default template is stored in the exact same Markdown/MarkdownV2
  // form used by runtime. For the admin reference we intentionally keep the
  // raw placeholder tokens visible, but their names can contain '_' (for
  // example {userbot_id}). Telegram would interpret that underscore as
  // formatting when the token has not yet been replaced, producing
  // "can't parse entities". Escape only the placeholder token itself so
  // its visible text remains exactly {userbot_id}, while surrounding runtime
  // formatting is untouched.
  if (mode === 'markdown') {
    return text.replace(/\{([A-Za-z0-9_]+)\}/g, (token) => token.replace(/\\/g, '\\\\').replace(/([_*\[\]()`])/g, '\\$1'));
  }

  if (mode === 'markdownv2') {
    return text.replace(/\{([A-Za-z0-9_]+)\}/g, (token) => token.replace(/\\/g, '\\\\').replace(/([_\*\[\]\(\)~`>#+\-=|{}.!])/g, '\\$1'));
  }

  return text;
}

function prepareReferenceContent(content) {
  if (!content) return content;
  if (Array.isArray(content.entities)) {
    return { ...content, entities: normalizeTelegramEntities(content.text || '', content.entities) };
  }
  return {
    ...content,
    text: escapeReferencePlaceholderTokens(content.text, content.parse_mode),
  };
}

function getTemplateReference(submenuId, ctx, extra = {}) {
  const entry = registryEntry(submenuId);
  if (!entry) throw new Error(`Context template tidak terdaftar: ${submenuId}`);
  const defaultContent = getDefaultContent(submenuId, ctx, extra);
  const docs = getPlaceholderDocs(submenuId);
  const custom = getCustomContent(submenuId);
  let currentCustom = null;
  if (custom) {
    try {
      validateContent(custom, submenuId);
      currentCustom = { ...custom, entities: normalizeTelegramEntities(custom.text, custom.entities) };
    } catch (err) {
      logger.warn(`Custom template "${submenuId}" invalid while building editor reference: ${err.message}`);
    }
  }
  const activeContent = currentCustom || prepareReferenceContent(defaultContent);
  return {
    meta: entry,
    defaultContent,
    currentCustom,
    activeContent,
    placeholders: docs,
    maxLength: resolveMaxLength(entry),
  };
}

function setCustomContent(submenuId, content, updatedBy) {
  const meta = registryEntry(submenuId);
  if (!meta) throw new Error(`Submenu tidak terdaftar: ${submenuId}`);
  if (meta.scope !== 'USER' || meta.editable === false) throw new Error('Template ini tidak dapat dikustomisasi dari konteks user-facing.');
  const safeContent = validateContent(content, submenuId);
  const row = repo.upsert(submenuId, safeContent.text, JSON.stringify(safeContent.entities || []), updatedBy);
  try { require('./settingsPortability.service').exportToFile(); }
  catch (err) { logger.warn(`Gagal memperbarui snapshot setelah custom submenu "${submenuId}": ${err.message}`); }
  logger.info(`Custom Submenu "${submenuId}" updated by admin ${updatedBy}`);
  return rowToContent(row);
}

function deleteCustomContent(submenuId) {
  const meta = registryEntry(submenuId);
  if (!meta) throw new Error(`Submenu tidak terdaftar: ${submenuId}`);
  if (meta.scope !== 'USER' || meta.editable === false) throw new Error('Template ini tidak dapat direset dari konteks user-facing.');
  repo.deleteBySubmenuId(submenuId);
  try { require('./settingsPortability.service').exportToFile(); }
  catch (err) { logger.warn(`Gagal memperbarui snapshot setelah reset custom submenu "${submenuId}": ${err.message}`); }
  logger.info(`Custom Submenu "${submenuId}" reset to default`);
}

function resolveDefault(defaultContent, ctx, extra) {
  if (!defaultContent) return defaultContent;
  const raw = typeof defaultContent.text === 'function' ? defaultContent.text(ctx, extra) : defaultContent.text;
  return { ...defaultContent, text: typeof raw === 'string' ? raw : '' };
}

function getSubmenuContent(submenuId, defaultContent, ctx, extra = {}) {
  const entry = registryEntry(submenuId);
  const custom = getCustomContent(submenuId);
  if (custom) {
    try {
      validateContent(custom, submenuId);
      const resolved = (ctx || (extra && extra.placeholderValues)) ? applyPlaceholders(custom.text, custom.entities, ctx || null, extra) : { text: custom.text, entities: normalizeTelegramEntities(custom.text, custom.entities) };
      return { text: resolved.text, entities: resolved.entities };
    } catch (err) {
      logger.warn(`Custom template "${submenuId}" invalid; falling back to default: ${err.message}`);
    }
  }
  const fallback = resolveDefault(defaultContent, ctx, extra);
  if ((ctx || (extra && extra.placeholderValues)) && fallback && typeof fallback.text === 'string') {
    const resolved = applyPlaceholders(fallback.text, null, ctx || null, extra);
    return { ...fallback, text: resolved.text };
  }
  return fallback;
}

function prependContent(prefix, content) {
  const lead = String(prefix || '');
  if (!lead) return content;
  const text = `${lead}${content && typeof content.text === 'string' ? content.text : ''}`;
  const entities = Array.isArray(content && content.entities) ? content.entities : [];
  if (!entities.length) return { ...content, text, entities };
  const delta = lead.length;
  return { ...content, text, entities: entities.map((entity) => ({ ...entity, offset: Number(entity.offset || 0) + delta })) };
}

function buildReplyOptions(content) {
  // Entity-backed custom content must be sent with Telegram entities exactly
  // as stored. Default templates, however, are often authored with an
  // explicit parse_mode and an empty entity list. Prefer that parse mode when
  // there are no entities so HTML/Markdown default formatting is not silently
  // stripped by sending an empty `entities` array.
  if (content && Array.isArray(content.entities) && content.entities.length) return { entities: content.entities };
  if (content && content.parse_mode) return { parse_mode: content.parse_mode };
  if (content && Array.isArray(content.entities)) return { entities: content.entities };
  return { parse_mode: 'Markdown' };
}
function buildCaptionOptions(content) {
  if (content && Array.isArray(content.entities) && content.entities.length) return { caption_entities: content.entities };
  if (content && content.parse_mode) return { parse_mode: content.parse_mode };
  if (content && Array.isArray(content.entities)) return { caption_entities: content.entities };
  return { parse_mode: 'Markdown' };
}

function defineSubmenu(id, label, defaultText, defaultParseMode = 'Markdown', options = {}) {
  const metadata = {
    feature: options.feature || label.replace(/^\S+\s*/, '') || 'Umum',
    scope: options.scope || 'USER',
    messageType: options.messageType || 'text',
    editable: options.editable !== false,
    supportedPlaceholders: Array.isArray(options.supportedPlaceholders) ? options.supportedPlaceholders.map((x) => String(x).replace(/^\{|\}$/g, '')) : [],
    maxLength: options.maxLength == null ? null : Number(options.maxLength),
  };
  submenuRegistry.register({
    id, label, ...metadata,
    defaultValue: defaultText,
    parseMode: defaultParseMode,
  });
  return {
    id, label,
    getContent(ctx, extra = {}) { return getSubmenuContent(id, { text: defaultText, parse_mode: defaultParseMode }, ctx, extra); },
  };
}

function defineTemplate(id, feature, label, defaultText, options = {}) {
  const submenu = defineSubmenu(id, label, defaultText, options.parseMode || 'Markdown', {
    ...options,
    feature,
    supportedPlaceholders: options.supportedPlaceholders || [],
  });
  return submenu;
}

function renderTemplate(submenuId, ctx, defaultText, extra = {}, defaultParseMode = 'Markdown') {
  return getSubmenuContent(submenuId, { text: defaultText, parse_mode: defaultParseMode }, ctx, extra);
}

function getPlaceholderDocs(submenuId) {
  const meta = registryEntry(submenuId);
  if (!meta || !Array.isArray(meta.supportedPlaceholders)) return [];
  const allow = new Set(meta.supportedPlaceholders.map((x) => String(x).replace(/^\{|\}$/g, '')));
  return PLACEHOLDER_DOCS.filter((doc) => allow.has(String(doc.token).replace(/^\{|\}$/g, '')));
}

module.exports = {
  getCustomContent, setCustomContent, deleteCustomContent, hasCustomContent,
  getTemplateMeta, getDefaultContent, getTemplateReference, getSubmenuContent, getPlaceholderDocs, buildReplyOptions, buildCaptionOptions,
  escapeReferencePlaceholderTokens, prepareReferenceContent,
  validateContent, prependContent, defineSubmenu, defineTemplate, renderTemplate,
};
