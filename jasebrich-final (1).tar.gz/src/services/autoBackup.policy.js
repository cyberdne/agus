'use strict';
/**
 * Pure rules for automatic database backups: schedule, retention, file naming
 * and Telegram upload limits. No I/O so the logic is testable on its own.
 */

const INTERVAL_OPTIONS_HOURS = [6, 12, 24, 48, 168];
const RETENTION_OPTIONS = [3, 7, 14, 30];
const FILE_PREFIX = 'jaseb-auto-';
const FILE_SUFFIX = '.db';
// Telegram bot API upload limit is 50 MB; keep a margin for multipart overhead.
const TELEGRAM_UPLOAD_LIMIT_BYTES = 49 * 1024 * 1024;

function normalizeInterval(value) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 1 && n <= 168 ? n : 24;
}

function normalizeRetention(value) {
  const n = Number(value);
  return Number.isInteger(n) && n >= 1 && n <= 60 ? n : 7;
}

/** Cycle to the next preset; an unknown current value starts from the first preset. */
function nextIntervalOption(current) {
  const i = INTERVAL_OPTIONS_HOURS.indexOf(Number(current));
  return INTERVAL_OPTIONS_HOURS[(i + 1) % INTERVAL_OPTIONS_HOURS.length];
}

function nextRetentionOption(current) {
  const i = RETENTION_OPTIONS.indexOf(Number(current));
  return RETENTION_OPTIONS[(i + 1) % RETENTION_OPTIONS.length];
}

/** SQLite datetime('now') is UTC without a zone marker; treat it as UTC. */
function parseDbTimestamp(value) {
  if (!value) return NaN;
  const raw = String(value).trim();
  const iso = raw.includes('T') ? raw : raw.replace(' ', 'T');
  return Date.parse(/[zZ]$|[+-]\d{2}:?\d{2}$/.test(iso) ? iso : `${iso}Z`);
}

/**
 * Due when enabled and at least one interval has passed since the last run.
 * Failed runs also set last_run_at, so a broken disk retries once per interval
 * instead of every scheduler tick.
 */
function isBackupDue(cfg, nowMs) {
  if (!cfg || !cfg.enabled) return false;
  const last = parseDbTimestamp(cfg.last_run_at);
  if (!Number.isFinite(last)) return true;
  return nowMs - last >= normalizeInterval(cfg.interval_hours) * 3600 * 1000;
}

function buildBackupFileName(nowMs) {
  return `${FILE_PREFIX}${new Date(nowMs).toISOString().replace(/[:.]/g, '-')}${FILE_SUFFIX}`;
}

function isBackupFileName(name) {
  return typeof name === 'string' && name.startsWith(FILE_PREFIX) && name.endsWith(FILE_SUFFIX);
}

/**
 * Entries beyond the newest `keep` backups. Only files matching our own name
 * pattern are ever candidates, so unrelated files in the folder are untouched.
 */
function selectPrunable(entries, keep) {
  const k = normalizeRetention(keep);
  return entries
    .filter((e) => isBackupFileName(e.name))
    .sort((a, b) => (b.mtimeMs - a.mtimeMs) || (b.name < a.name ? -1 : b.name > a.name ? 1 : 0))
    .slice(k);
}

function canSendToTelegram(bytes) {
  const n = Number(bytes);
  return n > 0 && n <= TELEGRAM_UPLOAD_LIMIT_BYTES;
}

module.exports = {
  INTERVAL_OPTIONS_HOURS,
  RETENTION_OPTIONS,
  TELEGRAM_UPLOAD_LIMIT_BYTES,
  normalizeInterval,
  normalizeRetention,
  nextIntervalOption,
  nextRetentionOption,
  parseDbTimestamp,
  isBackupDue,
  buildBackupFileName,
  isBackupFileName,
  selectPrunable,
  canSendToTelegram,
};
