/**
 * Builds the user-facing "Userbot kadaluarsa" screen and its renewal button.
 * Shared by every entry point that has to lock a control action (Kontrol
 * Panel handlers, old inline callbacks, scheduler notification), so the
 * wording and — more importantly — the stable callback identifier
 * (`subscription:renew:<userbots.id>`) live in exactly one place.
 *
 * The visible label may carry any custom emoji (Custom Icon Tombol); routing
 * is by callback_data only, so emoji/label changes can never break it.
 */
const { Markup } = require('telegraf');
const { button } = require('../utils/buttons');
const { CALLBACK } = require('../constants/menu');
const { ADMIN_CALLBACK } = require('../constants/admin.callback');
const { defineSubmenu, buildReplyOptions } = require('./custom-submenu.service');
const userRepository = require('../database/repositories/user.repository');
const { formatIndonesiaDate } = require('../utils/placeholders');

const RENEW_LABEL = '🔄 Perpanjang Langganan';

// Registered under Admin Panel -> Settings -> Custom Submenu like every
// other user-facing screen. {akun}/{userbot_id}/{expired_at} resolve through
// utils/placeholders.js for the viewing user.
const expiredSubmenu = defineSubmenu(
  'userbot_expired_notice',
  '⛔ Userbot Kadaluarsa',
  '⛔ *Userbot Kamu Telah Kadaluarsa*\n\n' +
    '🤖 Userbot: *{akun}* #{userbot_id}\n' +
    '⏳ Masa aktif berakhir:\n*{expired_at}*\n\n' +
    'Untuk menggunakan kembali Userbot, silakan perpanjang langganan.\n\n' +
    '✅ Semua pengaturan (grup, pesan, reply, dll.) tetap tersimpan dan akan aktif kembali setelah perpanjangan.',
  'Markdown',
  { feature: 'Userbot', supportedPlaceholders: ['akun', 'userbot_id', 'expired_at', 'expired'] }
);

/** A ctx-shaped object for a user we are messaging outside of an update (scheduler / notifications). */
function ctxLikeFor(telegramId) {
  const stored = userRepository.findByTelegramId(telegramId) || {};
  return {
    from: {
      id: telegramId,
      first_name: stored.first_name || undefined,
      last_name: stored.last_name || undefined,
      username: stored.username || undefined,
    },
    chat: { id: telegramId },
  };
}

function renewKeyboard(userbotId) {
  return Markup.inlineKeyboard([[button.success(RENEW_LABEL, CALLBACK.SUBSCRIPTION_RENEW(userbotId))]]);
}

/** Owner-facing notice: { text, options } ready for ctx.reply / telegram.sendMessage. */
function buildExpiredNotice(ctxLike, asset) {
  const content = expiredSubmenu.getContent(ctxLike, { userbot: asset });
  return { text: content.text, options: { ...buildReplyOptions(content), ...renewKeyboard(asset.id) } };
}

/** Admin-facing notice (an admin controlling a user's userbot through Admin Panel). */
function buildAdminExpiredNotice(asset) {
  const text =
    `⛔ *Userbot #${asset.id} Kadaluarsa*\n\n` +
    `Masa aktif berakhir: *${formatIndonesiaDate(asset.expires_at)}*\n\n` +
    `Kontrol Panel dikunci untuk userbot yang kadaluarsa. Perpanjang lewat Admin Panel → Settings → Perpanjang Langganan Userbot.`;
  return {
    text,
    options: {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([[button.success('⏳ Perpanjang (Admin)', ADMIN_CALLBACK.SUBEXT_SELECT(asset.id))]]),
    },
  };
}

module.exports = { RENEW_LABEL, expiredSubmenu, ctxLikeFor, renewKeyboard, buildExpiredNotice, buildAdminExpiredNotice };
