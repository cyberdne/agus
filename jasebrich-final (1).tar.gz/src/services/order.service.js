const orderRepo = require('../database/repositories/order.repository');
const { config } = require('../config');
const { CATEGORIES, formatRupiah, resolvePurchaseProduct, ProductUnavailableError, InvalidProductCategoryError } = require('./product.service');
const userbotService = require('./userbot.service');
const logger = require('../utils/logger');

// Testimoni is a separate projection. Fire-and-forget so fulfillment never waits on Telegram,
// and it never throws into the fulfillment flow. Idempotency lives in testimonial_deliveries.
function queueTestimonial(telegram, orderId) {
  try {
    require('./testimonial.service').publishForOrder(telegram, orderId)
      .then((r) => { if (r && !r.ok && r.reason !== 'not_configured') logger.info(`Testimoni order #${orderId}: ${r.reason}`); })
      .catch((err) => logger.error(`Testimoni order #${orderId} error: ${(err && err.message) || err}`));
  } catch (err) {
    logger.error(`Testimoni order #${orderId} tidak dijadwalkan: ${(err && err.message) || err}`);
  }
}
const { button } = require('../utils/buttons');
const { escapeMdV2 } = require('../utils/emojiMarkdown');
const { getDb } = require('../database');
const poolRepo = require('../database/repositories/userbotPool.repository');

// Quantity ("bulan") business rule. Single source of truth: the store
// stepper (store.handler.js) AND createOrder() below both use it, so the
// limit is enforced at the service boundary and not only in the UI. Every
// order flow (new purchase + "Perpanjang Langganan" renewal) goes through
// createOrder() with the same product catalog and the same stepper.
const QTY_MIN = 1;
const QTY_MAX = 24;
const ORDER_EXPIRATION_HOURS = 1;
const ORDER_EXPIRATION_MINUTES = ORDER_EXPIRATION_HOURS * 60;

class PendingOrderExistsError extends Error {
  constructor(orderOrOrders) {
    const orders = Array.isArray(orderOrOrders)
      ? orderOrOrders.filter(Boolean)
      : orderOrOrders ? [orderOrOrders] : [];
    super(orders.length === 1
      ? `Masih ada order aktif #${orders[0].id}.`
      : orders.length > 1
        ? `Masih ada ${orders.length} order aktif.`
        : 'Anda masih memiliki order aktif.');
    this.name = 'PendingOrderExistsError';
    this.code = 'PENDING_ORDER_EXISTS';
    this.order = orders[0] || null;
    this.orders = orders;
  }
}

class JasebOutOfStockError extends Error {
  constructor() {
    super('Stok userbot Jaseb sedang kosong atau tidak dapat digunakan.');
    this.name = 'JasebOutOfStockError';
    this.code = 'JASEB_OUT_OF_STOCK';
  }
}

class InvalidQuantityError extends Error {
  constructor(qty) {
    super(`Quantity tidak valid: ${String(qty)} (harus bilangan bulat ${QTY_MIN}-${QTY_MAX})`);
    this.name = 'InvalidQuantityError';
    this.code = 'INVALID_QTY';
  }
}

/** Strict integer parse for UNTRUSTED input (callback data). Accepts only a
 * plain base-10 integer string or a safe integer number; never coerces
 * ("1abc", "1.5", "", NaN, Infinity, "  " are all null). */
function parseQtyStrict(raw) {
  if (typeof raw === 'number') return Number.isSafeInteger(raw) ? raw : null;
  if (typeof raw !== 'string' || !/^-?\d+$/.test(raw)) return null;
  const n = Number(raw);
  return Number.isSafeInteger(n) ? n : null;
}

/** Returns the qty if it is a valid order quantity, else null. No clamping. */
function validateQty(raw) {
  const n = parseQtyStrict(raw);
  return n !== null && n >= QTY_MIN && n <= QTY_MAX ? n : null;
}

// `category` lets a caller override the product's own category — used
// by the "🔄 Perpanjang Langganan" flow, which reuses the USERBOT
// product catalog (same packages/prices) but tags the order as
// CATEGORIES.RENEWAL so fulfillOrder() extends the buyer's existing
// owned userbot instead of creating a new pending one.
// Throws InvalidQuantityError BEFORE touching the DB when qty is not a
// number in range — no order row is created for an invalid quantity.
function createOrder({ userId, product, qty, category, mode, targetUserbotId }) {
  // Preserve the existing contract that invalid quantity is rejected before
  // any DB/sweep work is performed. Once the input is valid, terminalize stale
  // rows immediately before applying the one-open-order rule. The DB guard
  // remains authoritative and atomic.
  if (typeof qty !== 'number' || validateQty(qty) === null) throw new InvalidQuantityError(qty);
  expireStaleOrders();
  const resolved = resolvePurchaseProduct(product && product.id, category, mode);
  const authoritative = resolved.product;
  try {
    const created = getDb().transaction(() => {
      const order = orderRepo.create({
        userId,
        productId: authoritative.id,
        category: resolved.category,
        catalogCategory: authoritative.category,
        qty,
        targetUserbotId: targetUserbotId || null,
      });
      if (!order) return null;
      if (resolved.category === CATEGORIES.JASEB) {
        const reserved = poolRepo.reserveForOrder(order.id, order.expires_at);
        if (!reserved) throw new JasebOutOfStockError();
      }
      return order;
    })();
    if (created) return created;
  } catch (err) {
    if (err instanceof JasebOutOfStockError) throw err;
    throw err;
  }

  // A concurrent admin deactivation can make the authoritative product
  // unavailable between the pre-check above and the atomic INSERT.
  try {
    resolvePurchaseProduct(authoritative.id, resolved.category, mode);
  } catch (err) {
    if (err instanceof ProductUnavailableError || err instanceof InvalidProductCategoryError) throw err;
    throw err;
  }
  throw new PendingOrderExistsError(orderRepo.findOpenOrdersByUser(userId));
}

function markAwaitingConfirmation(orderId) {
  const current = refreshOrder(orderId);
  if (!current || current.status !== 'pending') return null;
  return orderRepo.setStatus(orderId, 'awaiting_confirmation');
}

function expireStaleOrders(nowIso = null) {
  const result = getDb().transaction(() => {
    const changed = orderRepo.expireStaleOrders(nowIso);
    const released = poolRepo.releaseReservationsForClosedOrders();
    return { changed, released };
  })();
  if (result.changed > 0) logger.info(`Order expiration sweep: ${result.changed} order expired secara atomik.`);
  return result.changed;
}

function refreshOrder(orderId, nowIso = null) {
  if (!Number.isInteger(Number(orderId)) || Number(orderId) <= 0) return null;
  const id = Number(orderId);
  getDb().transaction(() => {
    const expired = orderRepo.expireOrderIfDue(id, nowIso);
    if (expired) poolRepo.releaseReservationByOrder(id);
  })();
  return orderRepo.findById(id);
}

function requestPaymentProof({ orderId, userId }) {
  const existing = refreshOrder(orderId);
  if (!existing) return { ok: false, reason: 'not_found' };
  if (Number(existing.user_id) !== Number(userId)) return { ok: false, reason: 'not_owner' };
  if (existing.status === 'expired') return { ok: false, reason: 'expired', order: existing };
  if (existing.status !== 'pending') return { ok: false, reason: 'invalid_status', order: existing };
  const order = orderRepo.markPaymentProofRequested(orderId, userId);
  return order ? { ok: true, order } : { ok: false, reason: 'race', order: orderRepo.findById(orderId) };
}

function submitPaymentProof({ orderId, userId, proofType, fileId, caption, entities, durationMinutes }) {
  if (!Number.isInteger(orderId) || orderId <= 0) return { ok: false, reason: 'invalid_order' };
  if (!Number.isInteger(userId)) return { ok: false, reason: 'invalid_user' };
  const supported = new Set(['photo', 'document', 'video']);
  if (!supported.has(proofType)) return { ok: false, reason: 'invalid_proof_type' };
  if (typeof fileId !== 'string' || !fileId.trim()) return { ok: false, reason: 'invalid_proof' };
  const minutes = Number(durationMinutes);
  if (!Number.isInteger(minutes) || minutes <= 0 || minutes > 10080) return { ok: false, reason: 'invalid_duration' };
  const live = refreshOrder(orderId);
  if (!live) return { ok: false, reason: 'not_found' };
  if (Number(live.user_id) !== Number(userId)) return { ok: false, reason: 'not_owner' };
  if (live.status === 'expired') return { ok: false, reason: 'expired', order: live };
  if (live.status !== 'pending') return { ok: false, reason: 'invalid_state', order: live };
  const entitiesJson = JSON.stringify(Array.isArray(entities) ? entities : []);
  const receivedAt = new Date().toISOString();
  const expiresAt = new Date(Date.now() + minutes * 60 * 1000).toISOString();
  const order = orderRepo.submitPaymentProof({
    id: orderId,
    userId,
    proofType,
    fileId: fileId.trim(),
    caption: typeof caption === 'string' ? caption : null,
    entities: entitiesJson,
    receivedAt,
    durationMinutes: minutes,
    expiresAt,
  });
  if (!order) return { ok: false, reason: 'invalid_state', order: orderRepo.findById(orderId) };
  return { ok: true, order };
}

function rejectPendingOrder({ orderId }) {
  const existing = refreshOrder(orderId);
  if (!existing) return { ok: false, reason: 'not_found' };
  if (existing.status === 'expired') return { ok: false, reason: 'expired', order: existing };
  const result = getDb().transaction(() => {
    const changed = getDb().prepare(`
      UPDATE orders
      SET status = 'cancelled', updated_at = datetime('now')
      WHERE id = ?
        AND status = 'awaiting_confirmation'
        AND expires_at IS NOT NULL
        AND datetime(expires_at) > datetime('now')
    `).run(orderId).changes;
    if (changed) poolRepo.releaseReservationByOrder(orderId);
    return changed;
  })();
  return result > 0
    ? { ok: true, order: orderRepo.findById(orderId) }
    : { ok: false, reason: 'invalid_state', order: refreshOrder(orderId) };
}

function markCancelled(orderId) {
  return orderRepo.setStatus(orderId, 'cancelled');
}

function listOpenOrders(userId) {
  if (!Number.isInteger(userId) || userId <= 0) return [];
  expireStaleOrders();
  return orderRepo.findOpenOrdersByUser(userId);
}

function cancelAllOwnPendingOrders({ userId }) {
  if (!Number.isInteger(userId) || userId <= 0) return { ok: false, reason: 'invalid_user', cancelledCount: 0, orders: [] };
  expireStaleOrders();
  const cancelledCount = getDb().transaction(() => {
    const count = orderRepo.cancelAllOwnedPending(userId);
    if (count > 0) poolRepo.releaseReservationsForUser(userId);
    return count;
  })();
  return {
    ok: cancelledCount > 0,
    reason: cancelledCount > 0 ? 'cancelled' : 'no_cancellable_orders',
    cancelledCount,
    orders: orderRepo.findOpenOrdersByUser(userId),
  };
}

// A crashed/restarted process can leave an order claimed by
// claimForProcessing() (status 'processing') but never finished by
// fulfillOrder() — e.g. the process dies between the atomic claim and
// the eventual setFulfillment()/setStatus() call. fulfillOrder's own
// catch block already reverts status to 'paid' on a *handled* in-flight
// error for exactly this reason ("never leave the order stuck at
// 'processing'"); this constant/function apply the SAME recovery to an
// *unhandled* crash, so 'paid' is a status claimForProcessing already
// accepts and admin re-confirming (adminorder:confirm) retries it
// through the normal path — no new status, no new lifecycle branch.
// 15 minutes is the crash-recovery lease window. A live fulfillment keeps
// processing_heartbeat_at fresh while it is awaiting Telegram/GramJS work, so
// the scheduler can distinguish a live long-running operation from a crashed
// process without relying on the general-purpose updated_at column alone.
const PROCESSING_STALE_MINUTES = 15;
const PROCESSING_HEARTBEAT_INTERVAL_MS = Math.max(
  15_000,
  Math.min(60_000, Math.floor((PROCESSING_STALE_MINUTES * 60_000) / 3))
);

function reclaimStaleProcessingOrders(nowIso = null) {
  const result = getDb().transaction(() => {
    const reclaimed = orderRepo.reclaimStaleProcessing(PROCESSING_STALE_MINUTES, nowIso);
    const released = poolRepo.releaseReservationsForClosedOrders();
    return { reclaimed, released };
  })();
  if (result.reclaimed > 0) {
    logger.warn(`Order recovery: ${result.reclaimed} order stuck di 'processing' > ${PROCESSING_STALE_MINUTES} menit dikembalikan ke 'paid' untuk retry.`);
  }
  return result.reclaimed;
}

/**
 * Buyer-initiated cancel (store:cancel:<orderId> callback). Unlike
 * markCancelled() above — which is only ever called from admin-side
 * flows (adminorder:reject) that already trust their own orderId —
 * this path receives an orderId straight from Telegram callback data,
 * i.e. untrusted input a user could forge to target someone else's
 * order. Verifies existence, ownership (order.user_id === userId) and
 * that the order is still in the one status a buyer may self-cancel
 * from ('pending'), atomically, before ever writing.
 */
function cancelOwnOrder({ orderId, userId }) {
  const existing = refreshOrder(orderId);
  if (!existing) return { ok: false, reason: 'not_found' };
  if (Number(existing.user_id) !== Number(userId)) return { ok: false, reason: 'not_owner' };
  if (existing.status !== 'pending') return { ok: false, reason: 'invalid_status', order: existing };
  const cancelled = getDb().transaction(() => {
    const changed = orderRepo.cancelOwnedPending(orderId, userId);
    if (changed) poolRepo.releaseReservationByOrder(orderId);
    return changed;
  })();
  if (!cancelled) {
    // Lost a race (e.g. admin/system changed status between the read
    // above and the write) — re-read so the caller reports accurately.
    return { ok: false, reason: 'invalid_status', order: orderRepo.findById(orderId) };
  }
  return { ok: true, order: orderRepo.findById(orderId) };
}

function notifyIds() {
  return config.paymentNotifyIds.length > 0 ? config.paymentNotifyIds : config.adminIds;
}

async function notifyAdminsOfNewOrder(telegram, order, buyer) {
  const label = order.category === CATEGORIES.USERBOT ? '🤖 Beli Userbot'
    : order.category === CATEGORIES.RENEWAL ? '🔄 Perpanjang Langganan'
    : '🔥 Beli Jaseb';
  const text =
    `🔔 *Pesanan Baru Menunggu Konfirmasi*\n\n` +
    `👤 Buyer: ${escapeMdV2(buyer.first_name || '')} (@${escapeMdV2(buyer.username || '-')}, ID: ${escapeMdV2(buyer.id)})\n` +
    `📦 Kategori: ${escapeMdV2(label)}\n` +
    `🛍️ Produk: ${escapeMdV2(order.product_name)}\n` +
    (order.target_userbot_id ? `🤖 Target Userbot: #${escapeMdV2(order.target_userbot_id)}\n` : '') +
    `🔢 Jumlah: ${escapeMdV2(order.qty)} bulan\n` +
    `💰 Total: ${escapeMdV2(formatRupiah(order.total_price))}\n` +
    `🆔 Order: #${escapeMdV2(order.id)}`;

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
          button.success('✅ Konfirmasi Bayar', `adminorder:confirm:${order.id}`),
          button.danger('❌ Tolak', `adminorder:reject:${order.id}`),
        ],
      ],
    },
    parse_mode: 'MarkdownV2',
  };

  for (const adminId of notifyIds()) {
    try {
      await telegram.sendMessage(adminId, text, keyboard);
    } catch (err) {
      logger.warn(`Failed to notify admin ${adminId} of order #${order.id}: ${(err && err.message) || err}`);
    }
  }
}

/**
 * Admin confirmed payment. Branches by category:
 *  - jaseb: assign a pool userbot to the buyer, send + pin the
 *    activation message immediately (no further buyer action needed).
 *  - renewal: extend the buyer's existing active owned userbot's
 *    expiry by the paid duration — no OTP flow, nothing new to set up.
 *  - userbot: create the pending owned-userbot record and hand back
 *    to the caller so it can kick off the phone/OTP login flow with
 *    the buyer.
 */
function startProcessingHeartbeat(orderId, claimToken) {
  let stopped = false;
  let interval = null;
  const heartbeat = () => {
    if (stopped) return;
    try {
      const refreshed = orderRepo.touchProcessing(orderId, claimToken);
      if (!refreshed) {
        stopped = true;
        if (interval) clearInterval(interval);
        logger.warn(`Order #${orderId}: processing claim sudah tidak dimiliki worker ini; heartbeat dihentikan.`);
      }
    } catch (err) {
      logger.warn(`Order #${orderId}: heartbeat processing gagal: ${(err && err.message) || err}`);
    }
  };
  interval = setInterval(heartbeat, PROCESSING_HEARTBEAT_INTERVAL_MS);
  if (typeof interval.unref === 'function') interval.unref();
  return () => {
    stopped = true;
    if (interval) clearInterval(interval);
  };
}

async function fulfillOrder(telegram, orderId) {
  const order = refreshOrder(orderId);
  if (!order) return { ok: false, reason: 'not_found' };
  if (order.status === 'fulfilled') return { ok: false, reason: 'already_fulfilled' };
  if (!['awaiting_confirmation', 'paid'].includes(order.status)) {
    return { ok: false, reason: 'invalid_state', order };
  }

  // Atomic compare-and-swap claim. A single order can have only one live
  // processing claim at a time, even when two admin callbacks race.
  const claimToken = orderRepo.claimForProcessing(order.id);
  if (!claimToken) {
    const fresh = orderRepo.findById(order.id);
    return {
      ok: false,
      reason: fresh && fresh.status === 'fulfilled' ? 'already_fulfilled' : fresh && fresh.status === 'expired' ? 'expired' : 'already_processing',
      order: fresh,
    };
  }

  const stopHeartbeat = startProcessingHeartbeat(order.id, claimToken);
  try {
    if (order.category === CATEGORIES.RENEWAL) {
      const renewed = userbotService.renewOwnedUserbot(order, claimToken);
      if (!renewed.ok) {
        orderRepo.releaseProcessingClaim(order.id, claimToken, 'paid'); // release only if this worker still owns the claim
        return { ok: false, reason: renewed.reason, order };
      }
      // DB is committed (extension + audit + order fulfilment in one
      // transaction); now converge the runtime onto it.
      const runtimeResult = await require('./userbotLifecycle.service').restoreRuntime(renewed.userbot.id);
      queueTestimonial(telegram, order.id);
      return { ok: true, type: 'renewal', order, userbot: renewed.userbot, duplicate: renewed.duplicate, runtime: runtimeResult };
    }

    if (order.category === CATEGORIES.JASEB) {
      const leased = userbotService.assignPoolToBuyer(order);
      if (!leased) {
        orderRepo.releaseProcessingClaim(order.id, claimToken, 'paid'); // release only if this worker still owns the claim
        return { ok: false, reason: 'out_of_stock', order };
      }
      const fulfilled = orderRepo.setFulfillment(order.id, leased.id, claimToken);
      if (!fulfilled) {
        const poolRepo = require('../database/repositories/userbotPool.repository');
        poolRepo.returnToPool(leased.id);
        return { ok: false, reason: 'processing_claim_lost', order: orderRepo.findById(order.id) };
      }

      const buyer = await telegram.getChat(order.user_id).catch(() => null);
      const name = (buyer && (buyer.first_name || buyer.username)) || `User ${order.user_id}`;
      await userbotService.sendPinnedActivationMessage(telegram, order.user_id, {
        name,
        id: leased.telegram_userbot_id || null,
        token: leased.token,
        phone: leased.phone || null,
        username: buyer && buyer.username ? buyer.username : null,
        expiresAt: leased.expires_at || null,
        orderId: order.id,
        productName: order.product_name || leased.label || 'Jaseb',
        activatedAt: new Date().toISOString(),
        status: leased.status === 'assigned' ? 'active' : leased.status,
      });
      queueTestimonial(telegram, order.id);
      return { ok: true, type: 'jaseb', order, pool: leased };
    }

    // category === userbot: creating the pending record + kicking off the
    // phone/OTP flow IS this order's fulfilment (mirrors jaseb/renewal,
    // which also mark 'fulfilled' immediately on confirm, not after some
    // later step) — so the order becomes 'fulfilled' right here, right
    // after the pending record is created, instead of staying at 'paid'
    // until the buyer finishes login. userbotService.activateOwned() still
    // calls orderRepo.setFulfillment() again once login succeeds; that is
    // now a harmless idempotent re-write of the same status/ref, kept as-is
    // so nothing about the login-completion path has to change.
    const pending = userbotService.createOwnedPending(order);
    const fulfilled = orderRepo.setFulfillment(order.id, pending.id, claimToken);
    if (!fulfilled) {
      const ownedRepo = require('../database/repositories/ownedUserbot.repository');
      ownedRepo.deleteById(pending.id);
      return { ok: false, reason: 'processing_claim_lost', order: orderRepo.findById(order.id) };
    }
    queueTestimonial(telegram, order.id);
    return { ok: true, type: 'userbot', order, pendingOwnedId: pending.id };
  } catch (err) {
    orderRepo.releaseProcessingClaim(order.id, claimToken, 'paid'); // never leave the order stuck at 'processing' on an unexpected error
    throw err;
  } finally {
    stopHeartbeat();
  }
}

module.exports = {
  QTY_MIN,
  QTY_MAX,
  ORDER_EXPIRATION_HOURS,
  ORDER_EXPIRATION_MINUTES,
  InvalidQuantityError,
  PendingOrderExistsError,
  JasebOutOfStockError,
  parseQtyStrict,
  validateQty,
  createOrder,
  listOpenOrders,
  expireStaleOrders,
  refreshOrder,
  markAwaitingConfirmation,
  requestPaymentProof,
  submitPaymentProof,
  rejectPendingOrder,
  markCancelled,
  cancelOwnOrder,
  cancelAllOwnPendingOrders,
  reclaimStaleProcessingOrders,
  notifyAdminsOfNewOrder,
  fulfillOrder,
  findById: orderRepo.findById,
  listByUser: orderRepo.listByUser,
};
