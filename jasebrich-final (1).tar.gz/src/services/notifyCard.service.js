'use strict';
/**
 * Edit-in-place "card" messages.
 *
 * Every recurring notification is ONE message that is edited when its content
 * changes, instead of a new message each time. The card's message id is stored
 * so it survives restarts. Identical content never triggers an API call.
 */
const crypto = require('crypto');
// Lazy: pure helpers (classification, hashing) stay importable without the DB driver.
function getDb() { return require('../database').getDb(); }

const NOT_MODIFIED_RE = /message is not modified/i;
// The card was deleted or can no longer be edited: create a fresh one once.
const GONE_RE = /message to edit not found|message can't be edited|message is too old|MESSAGE_ID_INVALID|message not found/i;

function errorText(err) {
  return String(err?.description || err?.errorMessage || err?.message || err || '');
}
function isNotModified(err) { return NOT_MODIFIED_RE.test(errorText(err)); }
function isGone(err) { return GONE_RE.test(errorText(err)); }
function hashText(text) { return crypto.createHash('sha256').update(String(text)).digest('hex').slice(0, 32); }

function readCard(key) {
  return getDb().prepare('SELECT * FROM managed_cards WHERE card_key = ?').get(key) || null;
}

function saveCard(key, { chatId, messageId, hash }) {
  getDb().prepare(
    `INSERT INTO managed_cards (card_key, chat_id, message_id, last_hash, updated_at)
     VALUES (?, ?, ?, ?, datetime('now'))
     ON CONFLICT(card_key) DO UPDATE SET
       chat_id = excluded.chat_id, message_id = excluded.message_id,
       last_hash = excluded.last_hash, updated_at = excluded.updated_at`
  ).run(key, String(chatId), messageId == null ? null : Number(messageId), hash);
}

function deleteCard(key) {
  getDb().prepare('DELETE FROM managed_cards WHERE card_key = ?').run(key);
}

/**
 * Transport abstracts where the card lives: a Telegram bot chat or a userbot's
 * Saved Messages. Both expose send(text) -> messageId and edit(messageId, text).
 */
// parseMode: 'HTML' | null (plain text). Plain is used for logs so targets such as @group_name are never parsed as markup.
function botTransport(telegram, chatId, parseMode = 'HTML') {
  const opts = { disable_web_page_preview: true, ...(parseMode ? { parse_mode: parseMode } : {}) };
  return {
    send: async (text) => (await telegram.sendMessage(chatId, text, opts)).message_id,
    edit: (messageId, text) => telegram.editMessageText(chatId, Number(messageId), undefined, text, opts),
  };
}

function userbotTransport(client, peer = 'me', parseMode = 'html') {
  const mode = parseMode ? { parseMode } : {};
  return {
    send: async (text) => (await client.sendMessage(peer, { message: text, ...mode })).id,
    edit: (messageId, text) => client.editMessage(peer, { message: Number(messageId), text, ...mode }),
  };
}

/**
 * Returns 'unchanged' | 'edited' | 'created'. Throws only for real failures
 * (for example a flood wait) so the caller can decide whether to retry.
 */
async function upsertCard({ key, chatId, transport, text }) {
  const hash = hashText(text);
  const row = readCard(key);
  if (row && row.message_id && row.last_hash === hash) return 'unchanged';
  if (row && row.message_id) {
    try {
      await transport.edit(row.message_id, text);
      saveCard(key, { chatId, messageId: row.message_id, hash });
      return 'edited';
    } catch (err) {
      if (isNotModified(err)) {
        saveCard(key, { chatId, messageId: row.message_id, hash });
        return 'unchanged';
      }
      if (!isGone(err)) throw err;
      // Card deleted by someone: fall through and create exactly one new card.
    }
  }
  const messageId = await transport.send(text);
  saveCard(key, { chatId, messageId, hash });
  return 'created';
}

module.exports = {
  isNotModified, isGone, hashText, readCard, saveCard, deleteCard,
  botTransport, userbotTransport, upsertCard,
};
