'use strict';
/**
 * Backup Token — the recovery credential of ONE owned userbot.
 *
 * Single source of truth for everything token-related. "🔥 Cek Token" and
 * "🎫 Klaim Token" (recovery) both go through inspect(), so ownership, expiry,
 * trial/purchased rules and rotation state are evaluated by exactly one piece
 * of code and can never disagree.
 *
 * Canonical sources this builds on (nothing here is a second copy of them):
 *   identity      userbots.id  (+ userbots.telegram_userbot_id: re-login must be
 *                 the SAME Telegram account, as in ubotFlow#finalizeReauth)
 *   ownership     userbots.user_id
 *   entitlement   subscription.getSubscriptionState / isExpiredAt / isTrial
 *                 (userbots.expires_at + status) — the token NEVER carries or
 *                 creates an expiry of its own
 *   session       ownedRepo.replaceSession (the existing re-auth mechanism)
 *   token         userbots.token_hash + token_generation; retired hashes in
 *                 userbot_token_history
 *
 * A token can only ever restore access to the userbot it is bound to. It never
 * creates a userbot, an order, a trial, an entitlement or an expiry.
 *
 * Lifecycle
 *   issue      at activation (trial and purchased)            generation 1
 *   validate   inspect()/checkToken()          read-only, same rules as claim
 *   recover    claimOwned() -> (phone/OTP via the existing re-auth wizard) ->
 *              completeRecovery(): session swapped on the SAME row and the token
 *              CONSUMED (rotated) in ONE transaction — single use
 *   rotate     regenerate() (owner), transferOwnership() (new owner gets a new
 *              token, old owner's is retired, atomically), reactivation
 *   retire     retireOnRemoval() when the userbot row is deleted
 *
 * Concurrency: better-sqlite3 is synchronous and single-writer; every mutation
 * below is ONE db.transaction and every rotation is a compare-and-swap on
 * token_generation, so two racing claims/rotations can produce at most one
 * winner and never a second userbot, session or credential.
 */
const { getDb } = require('../database');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const tokenRepo = require('../database/repositories/userbotToken.repository');
const subscription = require('./subscription.service');
const codec = require('../utils/tokenCodec');
const logger = require('../utils/logger');

const STATE = Object.freeze({
  VALID: 'VALID',
  INVALID: 'INVALID',
  MALFORMED: 'MALFORMED',
  ROTATED: 'ROTATED', // used, regenerated or replaced by an ownership transfer
  REVOKED: 'REVOKED', // withdrawn because its userbot was removed
  EXPIRED: 'EXPIRED', // the userbot's active period (trial or purchased) is over
  OWNERSHIP_MISMATCH: 'OWNERSHIP_MISMATCH',
  NOT_RECOVERABLE: 'NOT_RECOVERABLE',
  RATE_LIMITED: 'RATE_LIMITED',
});

/** What a VALID token would do for its (verified) owner right now. */
const MODE = Object.freeze({
  RECOVER_SESSION: 'recover_session', // session lost/invalid -> re-login the same userbot
  REACTIVATE: 'reactivate', // admin-revoked userbot within its active period (existing Garansi Akses)
  HEALTHY: 'healthy', // nothing to recover
});

const RETIRE_REASON = Object.freeze({
  USED: 'used',
  REGENERATED: 'regenerated',
  TRANSFER: 'transfer',
  EXPIRED: 'expired',
  REVOKED: 'revoked',
});

class TokenError extends Error {
  constructor(code, message) {
    super(message || code);
    this.name = 'TokenError';
    this.code = code;
  }
}

// ------------------------------------------------------------ brute-force guard
// Tokens carry >= 192 bits of entropy so guessing is infeasible; this only
// bounds noisy/abusive attempts per Telegram user. In-memory on purpose (same
// TTL-map pattern as the other state stores): a restart merely resets a window.
const FAIL_LIMIT = 8;
const FAIL_WINDOW_MS = 10 * 60 * 1000;
const MAX_TRACKED_ACTORS = 5000;
const failures = new Map(); // actorId -> number[] (epoch ms)

function recentFailures(actorId, nowMs) {
  const list = (failures.get(actorId) || []).filter((t) => nowMs - t < FAIL_WINDOW_MS);
  if (list.length) failures.set(actorId, list);
  else failures.delete(actorId);
  return list;
}

function isRateLimited(actorId, nowMs = Date.now()) {
  return recentFailures(actorId, nowMs).length >= FAIL_LIMIT;
}

function noteFailure(actorId, nowMs = Date.now()) {
  const list = recentFailures(actorId, nowMs);
  list.push(nowMs);
  failures.set(actorId, list);
  if (failures.size > MAX_TRACKED_ACTORS) failures.delete(failures.keys().next().value);
}

function noteSuccess(actorId) {
  failures.delete(actorId);
}

function resetGuards() {
  failures.clear();
  claims.clear();
}

const FAILING_STATES = new Set([STATE.INVALID, STATE.MALFORMED, STATE.ROTATED, STATE.REVOKED, STATE.OWNERSHIP_MISMATCH]);

// ---------------------------------------------------------------- recovery claims
// A claim is the proof "this user presented a valid, current token for THIS
// userbot at THIS token generation". It bridges the async phone/OTP re-login
// wizard to the atomic completion step. It grants nothing by itself: the
// completion re-verifies ownership, expiry and the token generation inside its
// transaction, so a stale/forged/lost claim can only ever fail closed.
const CLAIM_TTL_MS = 15 * 60 * 1000;
const claims = new Map(); // actorId -> { userbotId, generation, expiresAtMs }

function setClaim(actorId, userbotId, generation, nowMs) {
  claims.set(Number(actorId), { userbotId: Number(userbotId), generation: Number(generation), expiresAtMs: nowMs + CLAIM_TTL_MS });
}

function getClaim(actorId, userbotId, nowMs) {
  const claim = claims.get(Number(actorId));
  if (!claim) return null;
  if (nowMs >= claim.expiresAtMs) {
    claims.delete(Number(actorId));
    return null;
  }
  return claim.userbotId === Number(userbotId) ? claim : null;
}

// ------------------------------------------------------------------- helpers

function prefixFor(row) {
  return subscription.isTrial(row) ? codec.PREFIX.TRIAL : codec.PREFIX.PURCHASE;
}

function retirePrevious(row, reason, nowIso) {
  if (!row || !row.token_hash) return;
  tokenRepo.retire({
    tokenHash: row.token_hash,
    userbotId: row.id,
    generation: row.token_generation,
    reason,
    retiredAt: nowIso,
  });
}

/**
 * Inside a caller's transaction: retire the current hash and install a fresh
 * token with compare-and-swap. Throws (rolling the whole transaction back,
 * including the ledger row) if the row moved on since it was read.
 * @returns {string} the NEW plaintext token — the only time it exists.
 */
function rotateInTx(row, reason, nowIso) {
  const token = codec.generate(prefixFor(row));
  retirePrevious(row, reason, nowIso);
  const swapped = ownedRepo.rotateToken(row.id, {
    expectedGeneration: row.token_generation,
    tokenHash: codec.hashInput(token),
    rotatedAt: nowIso,
  });
  if (!swapped) throw new TokenError('CONFLICT', 'Token berubah saat diproses.');
  return token;
}

function sessionLost(row) {
  return !row.session_string || row.runtime_stop_reason === subscription.RUNTIME_STOP_REASON.SESSION_INVALID;
}

// ------------------------------------------------------------------ validation

/**
 * THE validation. Read-only. Shared by Cek Token and by claim/recovery.
 *
 * Order matters and is deliberate: shape -> existence -> ledger (retired) ->
 * OWNERSHIP -> entitlement/expiry -> session state. Ownership is decided from
 * the database row and the authenticated Telegram id only — never from
 * callback data, a client-supplied id or the token text itself.
 *
 * The returned `row` is for internal callers; it is omitted for every state in
 * which the actor must not learn anything about the userbot.
 */
function inspect({ actorId, rawCode, nowMs = Date.now() }) {
  const hash = codec.hashInput(rawCode);
  if (!hash) return { state: STATE.MALFORMED };

  const row = ownedRepo.findByTokenHash(hash);
  if (!row) {
    const retired = tokenRepo.findRetiredByHash(hash);
    if (!retired) return { state: STATE.INVALID };
    if (retired.reason === RETIRE_REASON.EXPIRED) return { state: STATE.EXPIRED, trial: true };
    if (retired.reason === RETIRE_REASON.REVOKED) return { state: STATE.REVOKED };
    return { state: STATE.ROTATED };
  }

  if (Number(row.user_id) !== Number(actorId)) {
    return { state: STATE.OWNERSHIP_MISMATCH, userbotId: row.id };
  }

  const trial = subscription.isTrial(row);
  // Revoked rows report SUSPENDED regardless of time; their period can still be over.
  if (subscription.isExpiredAt(row.expires_at, nowMs)) return { state: STATE.EXPIRED, row, trial };

  switch (subscription.getSubscriptionState(row, nowMs)) {
    case subscription.STATE.EXPIRED:
      return { state: STATE.EXPIRED, row, trial };
    case subscription.STATE.SUSPENDED:
      return { state: STATE.VALID, mode: MODE.REACTIVATE, row, trial };
    case subscription.STATE.ACTIVE:
      return { state: STATE.VALID, mode: sessionLost(row) ? MODE.RECOVER_SESSION : MODE.HEALTHY, row, trial };
    default:
      return { state: STATE.NOT_RECOVERABLE, row, trial };
  }
}

/** Owner-safe view of an inspection result: never exposes ids, phone, session, order or the token. */
function toPublic(result, nowMs) {
  const out = { state: result.state };
  if (result.state === STATE.VALID || result.state === STATE.EXPIRED || result.state === STATE.NOT_RECOVERABLE) {
    if (result.row) {
      out.label = result.row.label || 'Userbot';
      out.trial = Boolean(result.trial);
      out.expiresAt = result.row.expires_at || null;
      out.remainingMs = result.row.expires_at ? Math.max(0, subscription.parseTimestamp(result.row.expires_at) - nowMs) : null;
    } else if (result.trial) {
      out.trial = true;
    }
    if (result.state === STATE.VALID) out.mode = result.mode;
  }
  return out;
}

/** "🔥 Cek Token": validate a pasted token for this actor. Read-only apart from the attempt counter. */
function checkToken({ actorId, rawCode, nowMs = Date.now() }) {
  if (isRateLimited(actorId, nowMs)) return { state: STATE.RATE_LIMITED };
  const result = inspect({ actorId, rawCode, nowMs });
  if (FAILING_STATES.has(result.state)) {
    noteFailure(actorId, nowMs);
    if (result.state === STATE.OWNERSHIP_MISMATCH) {
      logger.warn(`Cek Token: user ${actorId} mencoba token milik userbot #${result.userbotId} (ditolak)`);
    }
  } else if (result.state === STATE.VALID) {
    noteSuccess(actorId);
  }
  return toPublic(result, nowMs);
}

// -------------------------------------------------------------------- claim

/**
 * "🎫 Klaim Token": start recovery of the userbot this token is bound to.
 *
 * Returns { handled:false } when the token is unknown to the owned-userbot
 * ledger (the caller may then try the leased-pool token path); otherwise
 * { handled:true, ... } with ok/reason. Never creates a userbot, order, trial
 * or expiry, and never modifies subscription data.
 *
 *   ok:true  action:'reauth'       -> caller starts the EXISTING phone/OTP re-auth
 *                                     wizard for userbotId; completeRecovery()
 *                                     finishes it atomically
 *   ok:true  action:'reactivated'  -> admin-revoked userbot restored within its
 *                                     active period; token consumed, newToken issued
 *   ok:false reason: 'rate_limited' | 'rotated' | 'revoked' | 'expired' |
 *                    'not_owner' | 'not_recoverable' | 'already_active'
 */
function claimOwned({ actorId, rawCode, nowMs = Date.now() }) {
  const result = inspect({ actorId, rawCode, nowMs });
  const pub = toPublic(result, nowMs);

  switch (result.state) {
    case STATE.INVALID:
    case STATE.MALFORMED:
      return { handled: false };
    case STATE.ROTATED:
      noteFailure(actorId, nowMs);
      return { handled: true, ok: false, reason: 'rotated' };
    case STATE.REVOKED:
      noteFailure(actorId, nowMs);
      return { handled: true, ok: false, reason: 'revoked' };
    case STATE.OWNERSHIP_MISMATCH:
      noteFailure(actorId, nowMs);
      logger.warn(`Klaim Token: user ${actorId} mencoba token milik userbot #${result.userbotId} (ditolak)`);
      return { handled: true, ok: false, reason: 'not_owner' };
    case STATE.EXPIRED:
      return { handled: true, ok: false, reason: 'expired', trial: Boolean(result.trial) };
    case STATE.NOT_RECOVERABLE:
      return { handled: true, ok: false, reason: 'not_recoverable' };
    default:
      break;
  }

  const row = result.row;
  if (result.mode === MODE.HEALTHY) {
    noteSuccess(actorId);
    return { handled: true, ok: false, reason: 'already_active', label: pub.label };
  }

  if (result.mode === MODE.RECOVER_SESSION) {
    setClaim(actorId, row.id, row.token_generation, nowMs);
    noteSuccess(actorId);
    return { handled: true, ok: true, action: 'reauth', userbotId: row.id, label: pub.label, trial: pub.trial, expiresAt: pub.expiresAt };
  }

  // MODE.REACTIVATE
  const out = reactivateWithRotation({ actorId, userbotId: row.id, expectedGeneration: row.token_generation, nowMs });
  if (!out.ok) return { handled: true, ok: false, reason: out.reason };
  noteSuccess(actorId);
  return { handled: true, ok: true, action: 'reactivated', userbotId: row.id, label: pub.label, newToken: out.token };
}

/**
 * Admin-revoked userbot + its token (existing "Garansi Akses"). One transaction:
 * re-verify owner and active period, flip status back, consume the token.
 * expires_at is NOT touched — the remaining period is exactly what it was.
 */
function reactivateWithRotation({ actorId, userbotId, expectedGeneration, nowMs = Date.now() }) {
  const nowIso = new Date(nowMs).toISOString();
  const run = getDb().transaction(() => {
    const row = ownedRepo.findById(userbotId);
    if (!row) return { ok: false, reason: 'not_recoverable' };
    if (Number(row.user_id) !== Number(actorId)) return { ok: false, reason: 'not_owner' };
    if (row.status !== 'revoked') return { ok: false, reason: 'not_recoverable' };
    if (subscription.isExpiredAt(row.expires_at, nowMs)) return { ok: false, reason: 'expired' };
    if (row.token_generation !== expectedGeneration || !row.token_hash) return { ok: false, reason: 'rotated' };
    ownedRepo.reactivate(row.id);
    return { ok: true, token: rotateInTx(row, RETIRE_REASON.USED, nowIso) };
  });
  try {
    return run();
  } catch (err) {
    if (err instanceof TokenError) return { ok: false, reason: 'rotated' };
    throw err;
  }
}

/**
 * Finishes an owned-userbot re-login (ubotFlow#finalizeReauth) atomically.
 *
 * ONE transaction: verify owner/status/Telegram identity -> (token recovery
 * only) verify active period and that the token generation is still the one
 * that was claimed -> swap the session on the SAME row -> (token recovery only)
 * consume the token by rotating it. If any step fails nothing changes, so a
 * userbot can never end up recovered with its token still reusable, nor
 * with a token consumed and no recovery.
 *
 * With no matching claim this is the pre-existing plain re-auth (Buat Userbot
 * after SESSION_INVALID): same checks and same session swap as before, and no
 * token is touched.
 *
 * Subscription columns (expires_at, status, sub_version) are never written:
 * the remaining period of a trial or a purchase is preserved exactly.
 *
 * @returns {{ok:true,row:object,newToken:string|null}|{ok:false,reason:string}}
 *   reason: 'not_found' | 'not_owner' | 'not_recoverable' | 'identity_mismatch' |
 *           'expired' | 'rotated'
 */
function completeRecovery({ actorId, userbotId, sessionString, telegramUserbotId, nowMs = Date.now() }) {
  const nowIso = new Date(nowMs).toISOString();
  const claim = getClaim(actorId, userbotId, nowMs);

  const run = getDb().transaction(() => {
    const row = ownedRepo.findById(userbotId);
    if (!row) return { ok: false, reason: 'not_found' };
    if (Number(row.user_id) !== Number(actorId)) return { ok: false, reason: 'not_owner' };
    if (!['active', 'expired'].includes(row.status)) return { ok: false, reason: 'not_recoverable' };
    if (row.telegram_userbot_id && Number(row.telegram_userbot_id) !== Number(telegramUserbotId)) {
      return { ok: false, reason: 'identity_mismatch' };
    }
    if (claim) {
      if (subscription.isExpiredAt(row.expires_at, nowMs)) return { ok: false, reason: 'expired' };
      if (!row.token_hash || row.token_generation !== claim.generation) return { ok: false, reason: 'rotated' };
    }

    ownedRepo.replaceSession(row.id, { sessionString, telegramUserbotId });
    const newToken = claim ? rotateInTx(row, RETIRE_REASON.USED, nowIso) : null;
    return { ok: true, row: ownedRepo.findById(row.id), newToken };
  });

  let out;
  try {
    out = run();
  } catch (err) {
    if (!(err instanceof TokenError)) throw err;
    out = { ok: false, reason: 'rotated' };
  }
  claims.delete(Number(actorId)); // a claim is single-use, success or not
  return out;
}

// --------------------------------------------------------- issue / regenerate

/**
 * Activation of a pending userbot: stores ONLY the hash of the new token and
 * returns the plaintext once so it can be shown in the activation receipt.
 * If a token somehow already existed it is retired, never silently overwritten.
 */
function activateWithNewToken(userbotId, { sessionString, telegramUserbotId, expiresAt, prefix }) {
  const nowIso = new Date().toISOString();
  const token = codec.generate(prefix);
  const run = getDb().transaction(() => {
    const existing = ownedRepo.findById(userbotId);
    if (!existing) return null;
    retirePrevious(existing, RETIRE_REASON.REGENERATED, nowIso);
    return ownedRepo.activate(userbotId, {
      sessionString,
      telegramUserbotId,
      tokenHash: codec.hashInput(token),
      expiresAt,
    });
  });
  const row = run();
  return row ? { row, token } : null;
}

/**
 * Owner-initiated new Backup Token ("🪽 Backup Token" -> BUAT). The previous
 * token is retired in the same transaction, so exactly one token is ever valid.
 * Requires the userbot to be ACTIVE now (server-side, not UI): an expired or
 * suspended userbot cannot mint credentials.
 */
function regenerate({ actorId, userbotId, nowMs = Date.now() }) {
  const nowIso = new Date(nowMs).toISOString();
  const run = getDb().transaction(() => {
    const row = ownedRepo.findById(userbotId);
    if (!row) return { ok: false, reason: 'not_found' };
    if (Number(row.user_id) !== Number(actorId)) return { ok: false, reason: 'not_owner' };
    const state = subscription.getSubscriptionState(row, nowMs);
    if (state !== subscription.STATE.ACTIVE) {
      return { ok: false, reason: state === subscription.STATE.EXPIRED ? 'expired' : 'not_active' };
    }
    return { ok: true, token: rotateInTx(row, RETIRE_REASON.REGENERATED, nowIso), label: row.label || 'Userbot' };
  });
  try {
    return run();
  } catch (err) {
    if (err instanceof TokenError) return { ok: false, reason: 'conflict' };
    throw err;
  }
}

/** Owner-verified, token-free status for the "🪽 Backup Token" screen. */
function getStatus({ actorId, userbotId, nowMs = Date.now() }) {
  const row = ownedRepo.findById(userbotId);
  if (!row || Number(row.user_id) !== Number(actorId)) return { ok: false };
  return {
    ok: true,
    hasToken: Boolean(row.token_hash),
    rotatedAt: row.token_rotated_at || null,
    trial: subscription.isTrial(row),
    expiresAt: row.expires_at || null,
    state: subscription.getSubscriptionState(row, nowMs),
  };
}

// ------------------------------------------------------------------- transfer

/**
 * Ownership transfer + token rotation as ONE atomic operation.
 *
 * Inside a single transaction: verify the current owner and that the userbot is
 * ACTIVE, retire the old owner's token, hand the userbot to the new owner and
 * install the NEW owner's token hash. Afterwards the old token is invalid for
 * everyone (including the previous owner) and only the new owner holds a valid
 * one; there is no instant at which both, or neither, is in effect.
 * expires_at / order / session are untouched: the new owner inherits the exact
 * remaining period.
 *
 * @returns {{ok:true,row:object,token:string}|{ok:false,reason:string}}
 *   reason: 'not_found' | 'not_owner' | 'same_owner' | 'not_active' | 'conflict'
 */
function transferOwnership({ userbotId, fromUserId, toUserId, nowMs = Date.now() }) {
  const nowIso = new Date(nowMs).toISOString();
  const run = getDb().transaction(() => {
    const row = ownedRepo.findById(userbotId);
    if (!row) return { ok: false, reason: 'not_found' };
    if (Number(row.user_id) !== Number(fromUserId)) return { ok: false, reason: 'not_owner' };
    if (Number(toUserId) === Number(fromUserId)) return { ok: false, reason: 'same_owner' };
    if (subscription.getSubscriptionState(row, nowMs) !== subscription.STATE.ACTIVE) return { ok: false, reason: 'not_active' };

    const token = codec.generate(prefixFor(row));
    retirePrevious(row, RETIRE_REASON.TRANSFER, nowIso);
    const moved = ownedRepo.transferOwner(row.id, Number(toUserId), {
      expectedOwnerId: Number(fromUserId),
      expectedGeneration: row.token_generation,
      tokenHash: codec.hashInput(token),
      rotatedAt: nowIso,
    });
    if (!moved) throw new TokenError('CONFLICT', 'Kepemilikan berubah saat diproses.');
    return { ok: true, row: ownedRepo.findById(row.id), token };
  });
  try {
    return run();
  } catch (err) {
    if (err instanceof TokenError) return { ok: false, reason: 'conflict' };
    throw err;
  }
}

// -------------------------------------------------------------------- removal

/**
 * Call inside the transaction that deletes a userbot row: records its token as
 * retired so the token then reports "expired"/"revoked" instead of "unknown".
 */
function retireOnRemoval(row, reason) {
  retirePrevious(row, reason, new Date().toISOString());
}

module.exports = {
  STATE,
  MODE,
  RETIRE_REASON,
  TokenError,
  inspect,
  checkToken,
  claimOwned,
  completeRecovery,
  activateWithNewToken,
  regenerate,
  getStatus,
  transferOwnership,
  retireOnRemoval,
  isRateLimited,
  noteFailure,
  noteSuccess,
  resetGuards,
  FAIL_LIMIT,
  FAIL_WINDOW_MS,
};
