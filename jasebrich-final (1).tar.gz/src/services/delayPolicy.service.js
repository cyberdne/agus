'use strict';

const GROUP_DELAY_MIN_SECONDS = 0;
const GROUP_DELAY_MAX_SECONDS = 86400;
const DEFAULT_GROUP_DELAY_SECONDS = 10;
const ROUND_DELAY_MIN_SECONDS = 10;
const ROUND_DELAY_MAX_SECONDS = 604800;
const DEFAULT_ROUND_DELAY_SECONDS = 3600;

function toFiniteInteger(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'string' && value.trim() === '') return null;
  const n = typeof value === 'number' ? value : Number(String(value).trim());
  return Number.isFinite(n) && Number.isInteger(n) ? n : null;
}

function normalizeGroupDelayRange(min, max = min) {
  const lo = toFiniteInteger(min);
  const hi = toFiniteInteger(max);
  if (lo === null || hi === null) return null;
  if (lo < GROUP_DELAY_MIN_SECONDS || hi < GROUP_DELAY_MIN_SECONDS) return null;
  if (lo > GROUP_DELAY_MAX_SECONDS || hi > GROUP_DELAY_MAX_SECONDS) return null;
  if (hi < lo) return null;
  return { min: lo, max: hi };
}

function parseDurationPart(raw, fallbackUnit = 's') {
  const match = String(raw == null ? '' : raw).trim().toLowerCase().match(
    /^(\d+(?:\.\d+)?)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|h|hr|hrs|hour|hours)?$/
  );
  if (!match) return null;
  let seconds = Number(match[1]);
  const unit = match[2] || fallbackUnit;
  if (unit.startsWith('m')) seconds *= 60;
  else if (unit.startsWith('h')) seconds *= 3600;
  if (!Number.isFinite(seconds) || !Number.isInteger(seconds)) return null;
  return seconds;
}

/**
 * Parses either a single delay (legacy-compatible, e.g. `10`, `15s`, `2m`)
 * or an inclusive range (e.g. `1-20`, `1-20s`, `1m-2m`).
 * When one side carries a unit, that unit is applied to both sides so forms
 * such as `1-20m` remain unambiguous. Mixed explicit units are allowed only
 * when they resolve to the same unit, preventing accidental `1m-20s` input.
 */
function parseGroupDelayRangeInput(raw) {
  const value = String(raw == null ? '' : raw).trim().toLowerCase();
  if (!value) return null;
  if (value === '0' || value === 'off' || value === 'none') return { min: 0, max: 0 };

  const rangeMatch = value.match(/^(.+?)\s*[-–]\s*(.+)$/);
  if (!rangeMatch) {
    const single = parseDurationPart(value);
    return single === null ? null : normalizeGroupDelayRange(single, single);
  }

  const leftRaw = rangeMatch[1].trim();
  const rightRaw = rangeMatch[2].trim();
  if (!leftRaw || !rightRaw) return null;

  const unitOf = (rawPart) => {
    const match = String(rawPart).trim().toLowerCase().match(
      /(s|sec|secs|second|seconds|m|min|mins|minute|minutes|h|hr|hrs|hour|hours)$/
    );
    return match ? match[1] : null;
  };
  const leftUnit = unitOf(leftRaw);
  const rightUnit = unitOf(rightRaw);
  if (leftUnit && rightUnit) {
    const leftFamily = leftUnit.startsWith('s') ? 's' : leftUnit.startsWith('m') ? 'm' : 'h';
    const rightFamily = rightUnit.startsWith('s') ? 's' : rightUnit.startsWith('m') ? 'm' : 'h';
    if (leftFamily !== rightFamily) return null;
  }
  const fallbackUnit = leftUnit || rightUnit || 's';
  const left = parseDurationPart(leftRaw, fallbackUnit);
  const right = parseDurationPart(rightRaw, fallbackUnit);
  return normalizeGroupDelayRange(left, right);
}


function normalizeRoundDelaySeconds(value) {
  const n = toFiniteInteger(value);
  if (n === null || n < ROUND_DELAY_MIN_SECONDS || n > ROUND_DELAY_MAX_SECONDS) return null;
  return n;
}

function readRoundDelaySeconds(settings, fallback = DEFAULT_ROUND_DELAY_SECONDS) {
  const normalized = normalizeRoundDelaySeconds(settings && settings.round_delay_seconds);
  if (normalized !== null) return normalized;
  const safeFallback = normalizeRoundDelaySeconds(fallback);
  if (safeFallback === null) throw new Error('Konfigurasi jeda antar putaran tidak valid dan fallback juga tidak valid.');
  return safeFallback;
}

function readGroupDelayRange(settings, fallback = DEFAULT_GROUP_DELAY_SECONDS) {
  const legacy = toFiniteInteger(settings && settings.group_delay_seconds);
  const persistedMax = settings && settings.group_delay_max_seconds;
  const max = persistedMax == null || persistedMax === '' ? legacy : toFiniteInteger(persistedMax);
  const normalized = normalizeGroupDelayRange(legacy, max);
  if (normalized) return normalized;
  const safeFallback = normalizeGroupDelayRange(fallback, fallback);
  if (!safeFallback) throw new Error('Konfigurasi jeda antar grup tidak valid dan fallback juga tidak valid.');
  return safeFallback;
}

function sampleGroupDelay(range, random = Math.random) {
  const normalized = normalizeGroupDelayRange(range && range.min, range && range.max);
  if (!normalized) throw new Error('Range jeda antar grup tidak valid.');
  if (normalized.min === normalized.max) return normalized.min;

  const r = Number(random());
  if (!Number.isFinite(r) || r < 0 || r >= 1) throw new Error('Random source harus menghasilkan nilai pada [0, 1).');
  return normalized.min + Math.floor(r * (normalized.max - normalized.min + 1));
}

function formatGroupDelayRange(range) {
  const normalized = normalizeGroupDelayRange(range && range.min, range && range.max);
  if (!normalized) return '-';
  return normalized.min === normalized.max ? String(normalized.min) : `${normalized.min}-${normalized.max}`;
}

module.exports = {
  GROUP_DELAY_MIN_SECONDS,
  GROUP_DELAY_MAX_SECONDS,
  DEFAULT_GROUP_DELAY_SECONDS,
  ROUND_DELAY_MIN_SECONDS,
  ROUND_DELAY_MAX_SECONDS,
  DEFAULT_ROUND_DELAY_SECONDS,
  normalizeGroupDelayRange,
  parseGroupDelayRangeInput,
  readGroupDelayRange,
  normalizeRoundDelaySeconds,
  readRoundDelaySeconds,
  sampleGroupDelay,
  formatGroupDelayRange,
};
