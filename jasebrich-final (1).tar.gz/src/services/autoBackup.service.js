'use strict';
/**
 * Automatic database backup.
 *
 * Copies the live database with SQLite's online backup API (safe while the bot
 * is writing, unlike copying the .db file). Every copy is verified with
 * PRAGMA integrity_check before it replaces the previous file, so a corrupt
 * backup is never kept and never counted toward retention.
 */
const fs = require('fs');
const path = require('path');
const { config } = require('../config');
const { getDb } = require('../database');
const logger = require('../utils/logger');
const policy = require('./autoBackup.policy');

const BACKUP_DIR = path.join(path.dirname(path.resolve(process.cwd(), config.dbPath)), 'backups');

// Single-process guard: a manual run and the scheduler must never overlap.
let runningJob = false;

const WRITABLE = { enabled: 'enabled', intervalHours: 'interval_hours', retention: 'retention_count', sendToAdmin: 'send_to_admin' };

function getConfig() {
  const row = getDb().prepare('SELECT * FROM auto_backup_settings WHERE id = 1').get() || {};
  return {
    enabled: Boolean(row.enabled),
    intervalHours: policy.normalizeInterval(row.interval_hours),
    retention: policy.normalizeRetention(row.retention_count),
    sendToAdmin: Boolean(row.send_to_admin),
    lastRunAt: row.last_run_at || null,
    lastStatus: row.last_status || null,
    lastError: row.last_error || null,
    lastFile: row.last_file || null,
    raw: row,
  };
}

function updateSettings(patch) {
  const sets = [];
  const vals = [];
  for (const [key, col] of Object.entries(WRITABLE)) {
    if (patch[key] === undefined) continue;
    sets.push(`${col} = ?`);
    if (key === 'intervalHours') vals.push(policy.normalizeInterval(patch[key]));
    else if (key === 'retention') vals.push(policy.normalizeRetention(patch[key]));
    else vals.push(patch[key] ? 1 : 0);
  }
  if (!sets.length) return getConfig();
  getDb().prepare(`UPDATE auto_backup_settings SET ${sets.join(', ')}, updated_at = datetime('now') WHERE id = 1`).run(...vals);
  return getConfig();
}

function recordRun({ status, error = null, file = null }) {
  getDb().prepare(
    `UPDATE auto_backup_settings
        SET last_run_at = datetime('now'), last_status = ?, last_error = ?, last_file = ?, updated_at = datetime('now')
      WHERE id = 1`
  ).run(status, error ? String(error).slice(0, 500) : null, file ? path.basename(file) : null);
}

function safeUnlink(p) {
  try { fs.unlinkSync(p); } catch (_) { /* already gone */ }
}

/** Opens the copy read-only and requires a clean integrity check. */
function verifyBackupFile(filePath, openDb = require('better-sqlite3')) {
  const check = openDb(filePath, { readonly: true, fileMustExist: true });
  try {
    const result = check.pragma('integrity_check', { simple: true });
    if (result !== 'ok') throw new Error(`integrity_check gagal: ${result}`);
  } finally {
    check.close();
  }
}

function pruneBackups(dir = BACKUP_DIR, keep) {
  const entries = fs.readdirSync(dir)
    .filter((name) => policy.isBackupFileName(name))
    .map((name) => ({ name, mtimeMs: fs.statSync(path.join(dir, name)).mtimeMs }));
  const victims = policy.selectPrunable(entries, keep);
  for (const v of victims) safeUnlink(path.join(dir, v.name));
  return victims.length;
}

async function createBackup({ nowMs = Date.now(), dir = BACKUP_DIR, retention } = {}) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, policy.buildBackupFileName(nowMs));
  const tmp = `${file}.tmp`;
  safeUnlink(tmp);
  await getDb().backup(tmp);
  try {
    verifyBackupFile(tmp);
    fs.renameSync(tmp, file);
  } catch (err) {
    safeUnlink(tmp);
    throw err;
  }
  const bytes = fs.statSync(file).size;
  const keep = retention === undefined ? getConfig().retention : retention;
  const pruned = pruneBackups(dir, keep);
  return { file, bytes, pruned };
}

async function deliverToAdmins(telegram, result) {
  const admins = config.adminIds || [];
  if (!telegram || !admins.length) return { delivered: 0, skippedSize: false };
  if (!policy.canSendToTelegram(result.bytes)) return { delivered: 0, skippedSize: true };
  const caption = `🗄️ Backup otomatis database\n📄 ${path.basename(result.file)}\n📦 ${(result.bytes / 1048576).toFixed(2)} MB`;
  let delivered = 0;
  for (const adminId of admins) {
    try {
      await telegram.sendDocument(adminId, { source: fs.createReadStream(result.file), filename: path.basename(result.file) }, { caption });
      delivered += 1;
    } catch (err) {
      logger.warn(`Kirim backup ke admin ${adminId} gagal: ${err.message}`);
    }
  }
  return { delivered, skippedSize: false };
}

async function runNow({ telegram } = {}) {
  if (runningJob) throw new Error('Backup sedang berjalan. Tunggu hingga selesai.');
  runningJob = true;
  try {
    const cfg = getConfig();
    const result = await createBackup({ retention: cfg.retention });
    const delivery = cfg.sendToAdmin ? await deliverToAdmins(telegram, result) : { delivered: 0, skippedSize: false };
    recordRun({ status: 'ok', file: result.file });
    logger.info(`Auto backup selesai: ${path.basename(result.file)} (${result.bytes} bytes), file lama dihapus: ${result.pruned}`);
    return { ...result, delivery };
  } catch (err) {
    // Recording the failure also stamps last_run_at, so a broken disk is retried
    // once per interval rather than on every scheduler tick.
    recordRun({ status: 'error', error: err.message });
    logger.error('Auto backup gagal:', err);
    throw err;
  } finally {
    runningJob = false;
  }
}

/** Called by the scheduler every tick; does nothing unless a backup is due. */
async function runIfDue({ telegram, nowMs = Date.now() } = {}) {
  if (runningJob) return { skipped: 'running' };
  const cfg = getConfig();
  if (!policy.isBackupDue(cfg.raw, nowMs)) return { skipped: 'not_due' };
  try {
    return { ran: true, result: await runNow({ telegram }) };
  } catch (err) {
    return { ran: false, error: err.message };
  }
}

module.exports = {
  BACKUP_DIR, getConfig, updateSettings, verifyBackupFile, pruneBackups,
  createBackup, runNow, runIfDue,
};
