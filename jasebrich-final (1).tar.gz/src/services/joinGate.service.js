const { button } = require('../utils/buttons');
const settingsRepo = require('../database/repositories/settings.repository');
const userRepository = require('../database/repositories/user.repository');
const logger = require('../utils/logger');
const { defineSubmenu, buildReplyOptions } = require('./custom-submenu.service');
const { renderScreen } = require('../utils/render');

const GATE_DEFAULT_TEXT =
  `━━━ 🚫 *Akses Ditolak* 🚫 ━━━\n\n` +
  `🔴 *Status:* Belum Bergabung\n` +
  `💡 *Info:* Anda harus bergabung dengan channel/grup berikut untuk menggunakan bot ini.\n\n` +
  `✏️ *Silakan bergabung lalu tekan tombol Coba Lagi.*`;

const gateSubmenu = defineSubmenu('join_gate', '📢 Pesan Wajib Join', GATE_DEFAULT_TEXT, 'Markdown', { feature: 'Wajib Join' });

const KEYS = {
  ENABLED: 'join_gate_enabled',
  CHANNEL_ID: 'join_gate_channel_id',
  CHANNEL_LINK: 'join_gate_channel_link',
  CHANNEL_TITLE: 'join_gate_channel_title',
  GROUP_ID: 'join_gate_group_id',
  GROUP_LINK: 'join_gate_group_link',
  GROUP_TITLE: 'join_gate_group_title',
};

function getConfig() {
  return {
    enabled: settingsRepo.get(KEYS.ENABLED) === '1',
    channelId: settingsRepo.get(KEYS.CHANNEL_ID) || '',
    channelLink: settingsRepo.get(KEYS.CHANNEL_LINK) || '',
    channelTitle: settingsRepo.get(KEYS.CHANNEL_TITLE) || 'Channel Wajib',
    groupId: settingsRepo.get(KEYS.GROUP_ID) || '',
    groupLink: settingsRepo.get(KEYS.GROUP_LINK) || '',
    groupTitle: settingsRepo.get(KEYS.GROUP_TITLE) || 'Grup (Opsional)',
  };
}

function setConfigValue(key, value) {
  settingsRepo.set(key, value == null ? '' : String(value));
}

function setEnabled(enabled) {
  setConfigValue(KEYS.ENABLED, enabled ? '1' : '0');
}

function clearChannel() {
  Object.values({
    id: KEYS.CHANNEL_ID,
    link: KEYS.CHANNEL_LINK,
    title: KEYS.CHANNEL_TITLE,
  }).forEach((key) => setConfigValue(key, ''));
  setEnabled(false);
}

function clearGroup() {
  [KEYS.GROUP_ID, KEYS.GROUP_LINK, KEYS.GROUP_TITLE].forEach((key) => setConfigValue(key, ''));
}

function normalizeLink(value) {
  const v = String(value || '').trim();
  if (!v) return '';
  if (/^https?:\/\//i.test(v)) return v;
  if (/^t\.me\//i.test(v)) return `https://${v}`;
  if (/^@?[A-Za-z0-9_]{4,}$/.test(v)) return `https://t.me/${v.replace(/^@/, '')}`;
  return v;
}

function parseTargetInput(input) {
  const parts = String(input || '').split('|').map((x) => x.trim()).filter(Boolean);
  if (!parts[0]) throw new Error('Target chat wajib diisi.');

  const target = parts[0];
  const chatId = /^-?\d+$/.test(target) ? target : target.startsWith('@') ? target : `@${target}`;
  const link = normalizeLink(parts[1] || target);

  if (/^-?\d+$/.test(chatId) && !parts[1]) {
    throw new Error('Untuk channel/grup private, sertakan invite link setelah tanda |.');
  }
  if (!link || !/^https?:\/\//i.test(link)) {
    throw new Error('Link join tidak valid. Gunakan https://t.me/...');
  }

  return { chatId, link };
}

async function resolveTitle(telegram, chatId, fallback) {
  try {
    const chat = await telegram.getChat(chatId);
    return chat.title || chat.username || fallback;
  } catch (err) {
    logger.warn(`Tidak dapat mengambil nama chat ${chatId}: ${err.message}`);
    return fallback;
  }
}

async function setChannel(telegram, input) {
  const { chatId, link } = parseTargetInput(input);
  const title = await resolveTitle(telegram, chatId, 'Channel Wajib');
  setConfigValue(KEYS.CHANNEL_ID, chatId);
  setConfigValue(KEYS.CHANNEL_LINK, link);
  setConfigValue(KEYS.CHANNEL_TITLE, title);
  return getConfig();
}

async function setGroup(telegram, input) {
  const { chatId, link } = parseTargetInput(input);
  const title = await resolveTitle(telegram, chatId, 'Grup Opsional');
  setConfigValue(KEYS.GROUP_ID, chatId);
  setConfigValue(KEYS.GROUP_LINK, link);
  setConfigValue(KEYS.GROUP_TITLE, title);
  return getConfig();
}

function isMemberStatus(status) {
  return ['creator', 'administrator', 'member'].includes(status);
}

// Telegram errors that mean "this user is simply not in the chat" (a real
// answer), as opposed to errors that mean the CHECK ITSELF cannot work
// (bot not in the channel / not admin, wrong chat id, network/API outage).
const NOT_A_MEMBER_PATTERN = /user not found|participant_id_invalid|user_not_participant/i;
const ADMIN_ALERT_COOLDOWN_MS = 30 * 60 * 1000;
let lastAdminAlertAt = 0;

async function checkMembershipDetailed(telegram, chatId, userId) {
  if (!chatId) return { joined: false, systemError: false };
  try {
    const member = await telegram.getChatMember(chatId, userId);
    return { joined: isMemberStatus(member.status), systemError: false };
  } catch (err) {
    const message = String((err && (err.description || err.message)) || '');
    if (NOT_A_MEMBER_PATTERN.test(message)) return { joined: false, systemError: false };
    logger.warn(`Gagal cek membership user ${userId} pada ${chatId}: ${message}`);
    return { joined: false, systemError: true, message };
  }
}

async function checkMembership(telegram, chatId, userId) {
  return (await checkMembershipDetailed(telegram, chatId, userId)).joined;
}

async function alertAdminsGateBroken(telegram, chatId, message) {
  const now = Date.now();
  if (now - lastAdminAlertAt < ADMIN_ALERT_COOLDOWN_MS) return;
  lastAdminAlertAt = now;
  const appConfig = require('../config');
  const ids = [...new Set([...(appConfig.paymentNotifyIds || []), ...(appConfig.adminIds || [])])];
  const text =
    '⚠️ Fitur Wajib Join tidak bisa memeriksa keanggotaan.\n\n' +
    `Channel: ${chatId}\nError: ${message}\n\n` +
    'Kemungkinan bot belum ditambahkan sebagai admin di channel tersebut, atau Channel ID salah. ' +
    'User baru tetap DITOLAK sampai konfigurasi/akses bot ke channel diperbaiki.';
  for (const id of ids) {
    try { await telegram.sendMessage(id, text); } catch (e) { logger.warn(`Gagal kirim alert join gate ke ${id}: ${e.message}`); }
  }
}

/**
 * Returns true when the user may use the bot. The gate is intentionally
 * applied only once to newly-created users; once verified, their access is
 * not repeatedly blocked if they later leave the channel.
 */
async function ensureAccess(ctx) {
  if (!ctx.from) return true;
  const config = getConfig();
  if (!config.enabled) return true;
  if (!config.channelId || !config.channelLink) {
    logger.error('Join gate aktif tetapi channel wajib belum lengkap; akses user non-admin ditolak sampai konfigurasi diperbaiki.');
    return false;
  }

  let user = userRepository.findByTelegramId(ctx.from.id);
  if (!user) {
    user = userRepository.upsertFromTelegramUser(ctx.from);
  }
  if (user.join_gate_verified) return true;

  const result = await checkMembershipDetailed(ctx.telegram, config.channelId, ctx.from.id);
  if (result.joined) {
    userRepository.markJoinGateVerified(ctx.from.id);
    return true;
  }

  if (result.systemError) {
    // The verification itself failed. Fail closed for unverified users:
    // otherwise a misconfigured join gate silently becomes an access bypass.
    await alertAdminsGateBroken(ctx.telegram, config.channelId, result.message);
    return false;
  }

  return false;
}

function gateKeyboard(config) {
  const rows = [];
  if (config.channelLink) {
    rows.push([button.successUrl(`🔔 Gabung ${config.channelTitle}`, config.channelLink, { iconKey: '🔔 Gabung Channel Wajib' })]);
  }
  if (config.groupLink) {
    rows.push([button.successUrl(`💬 Gabung ${config.groupTitle} (Opsional)`, config.groupLink, { iconKey: '💬 Gabung Grup Opsional' })]);
  }
  // Generic retry/utility control, not a "fitur" — not customizable.
  rows.push([button.primary('↩️ Coba Lagi / Try Again', 'join_gate:retry', { customizable: false })]);
  return { inline_keyboard: rows };
}

async function sendGateMessage(ctx) {
  const config = getConfig();
  const content = gateSubmenu.getContent(ctx);
  const replyOptions = buildReplyOptions(content);

  if (ctx.callbackQuery && ctx.callbackQuery.message) {
    await renderScreen(ctx, content.text, {
      ...replyOptions,
      reply_markup: gateKeyboard(config),
    }, 'join_gate');
    return;
  }
  await ctx.reply(content.text, {
    ...replyOptions,
    reply_markup: gateKeyboard(config),
  });
}

module.exports = {
  KEYS,
  getConfig,
  setEnabled,
  setChannel,
  setGroup,
  clearChannel,
  clearGroup,
  ensureAccess,
  sendGateMessage,
  checkMembership,
};
