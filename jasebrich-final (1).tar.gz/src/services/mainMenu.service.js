const { renderWithReplyKeyboard } = require('../utils/render');
const { mainKeyboard } = require('../keyboards/main.keyboard');
const { isAdminId } = require('../middlewares/admin.middleware');
const userRepository = require('../database/repositories/user.repository');
const userbotService = require('./userbot.service');
const { defineSubmenu, buildReplyOptions } = require('./custom-submenu.service');
const { getNextMainMenuEffect } = require('./messageEffect.service');

// /start is the canonical custom-submenu identity for the bot's home screen.
// Every route that returns to the main menu renders this same submenu, so the
// text configured under Admin Panel -> Settings -> Custom Submenu -> Pesan
// /start is also the text shown by the normal "Kembali" navigation.
const MAIN_SUBMENU_ID = 'start';

// This is the actual default content of the home screen. It deliberately uses
// the same submenu id as /start so there is only one persisted customization
// for the home screen and therefore no duplicate "main" vs "start" entries.
const MAIN_DEFAULT_TEXT =
  `👋 Halo, {nama}!\n\n` +
  `Selamat datang di *JASEB*.\n` +
  `Jasa Sebar Telegram untuk kebutuhan promosi dan management Telegram kamu.\n\n` +
  `✨ Silakan pilih layanan yang ingin kamu gunakan di bawah ini.`;

const mainSubmenu = defineSubmenu(MAIN_SUBMENU_ID, '👋 Pesan /start', MAIN_DEFAULT_TEXT, 'Markdown', { feature: 'Menu Utama', supportedPlaceholders: ['nama'] });

async function renderMainMenu(ctx, { effect = true } = {}) {
  const telegramId = ctx.from.id;
  const content = mainSubmenu.getContent(ctx);
  const isAdmin = isAdminId(telegramId);
  const hasClaimedTrial = userRepository.hasClaimedTrial(telegramId);
  // Active OR expired: an expired owner must still reach the renewal screen via Kontrol Panel.
  const hasUserbot = userbotService.hasControllablePanelAsset(telegramId);
  const keyboard = mainKeyboard(isAdmin, hasClaimedTrial, hasUserbot);
  const effectId = effect ? getNextMainMenuEffect(telegramId) : null;

  await renderWithReplyKeyboard(
    ctx,
    content.text,
    { ...buildReplyOptions(content), ...keyboard },
    effectId,
    'main'
  );
}

module.exports = { MAIN_SUBMENU_ID, mainSubmenu, MAIN_DEFAULT_TEXT, renderMainMenu };
