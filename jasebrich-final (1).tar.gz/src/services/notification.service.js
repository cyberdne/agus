const crypto = require('crypto');
const { Markup } = require('telegraf');
const settingsRepo = require('../database/repositories/settings.repository');
const userRepo = require('../database/repositories/user.repository');
const orderRepo = require('../database/repositories/order.repository');
const productService = require('./product.service');
const logger = require('../utils/logger');
const { button } = require('../utils/buttons');

const SETTINGS_KEYS = Object.freeze({
  REGISTRATION_CHANNEL_ID: 'notification_registration_channel_id',
  REGISTRATION_CHANNEL_TITLE: 'notification_registration_channel_title',
  TRANSACTION_CHANNEL_ID: 'notification_transaction_channel_id',
  TRANSACTION_CHANNEL_TITLE: 'notification_transaction_channel_title',
  TRANSACTION_DURATION_MINUTES: 'notification_transaction_duration_minutes',
});
const DEFAULT_TRANSACTION_DURATION_MINUTES = 30;
const MIN_DURATION_MINUTES = 1;
const MAX_DURATION_MINUTES = 10080;
const CLAIM_STALE_MINUTES = 10;

function normalizeChannelTarget(input) {
  const value = String(input == null ? '' : input).trim();
  if (!value) throw new Error('Channel wajib diisi.');
  if (!/^@?[A-Za-z0-9_]{5,32}$/.test(value) && !/^-100\d{5,20}$/.test(value)) {
    throw new Error('Channel harus berupa @username channel atau chat ID -100... yang valid.');
  }
  return value;
}

function getChannel(kind) {
  const idKey = kind === 'registration' ? SETTINGS_KEYS.REGISTRATION_CHANNEL_ID : SETTINGS_KEYS.TRANSACTION_CHANNEL_ID;
  const titleKey = kind === 'registration' ? SETTINGS_KEYS.REGISTRATION_CHANNEL_TITLE : SETTINGS_KEYS.TRANSACTION_CHANNEL_TITLE;
  const id = settingsRepo.get(idKey);
  const title = settingsRepo.get(titleKey);
  return id ? { id: String(id), title: title || String(id) } : null;
}

function getTransactionDurationMinutes() {
  const raw = settingsRepo.get(SETTINGS_KEYS.TRANSACTION_DURATION_MINUTES);
  if (raw == null || raw === '') return DEFAULT_TRANSACTION_DURATION_MINUTES;
  const value = Number(raw);
  if (!Number.isInteger(value) || value < MIN_DURATION_MINUTES || value > MAX_DURATION_MINUTES) {
    logger.warn(`Notification setting durasi transaksi invalid (${String(raw)}); memakai default ${DEFAULT_TRANSACTION_DURATION_MINUTES} menit.`);
    return DEFAULT_TRANSACTION_DURATION_MINUTES;
  }
  return value;
}

function assertDuration(raw) {
  const value = Number(String(raw).trim());
  if (!Number.isInteger(value) || value < MIN_DURATION_MINUTES || value > MAX_DURATION_MINUTES) {
    throw new Error(`Durasi harus bilangan bulat ${MIN_DURATION_MINUTES}-${MAX_DURATION_MINUTES} menit.`);
  }
  return value;
}

async function validateChannel(telegram, input) {
  const target = normalizeChannelTarget(input);
  const chat = await telegram.getChat(target);
  if (!chat || chat.type !== 'channel') throw new Error('Target harus benar-benar berupa Telegram channel.');
  const me = await telegram.getMe();
  const member = await telegram.getChatMember(chat.id, me.id);
  if (!member || !['creator', 'administrator'].includes(member.status) || (member.status === 'administrator' && member.can_post_messages === false)) {
    throw new Error('Bot harus menjadi admin channel dan memiliki izin mengirim pesan.');
  }
  return { id: String(chat.id), title: chat.title || String(chat.id), username: chat.username || null };
}

function setChannel(kind, chat) {
  const idKey = kind === 'registration' ? SETTINGS_KEYS.REGISTRATION_CHANNEL_ID : SETTINGS_KEYS.TRANSACTION_CHANNEL_ID;
  const titleKey = kind === 'registration' ? SETTINGS_KEYS.REGISTRATION_CHANNEL_TITLE : SETTINGS_KEYS.TRANSACTION_CHANNEL_TITLE;
  settingsRepo.set(idKey, String(chat.id));
  settingsRepo.set(titleKey, String(chat.title || chat.id));
  return getChannel(kind);
}

function resetChannel(kind) {
  const idKey = kind === 'registration' ? SETTINGS_KEYS.REGISTRATION_CHANNEL_ID : SETTINGS_KEYS.TRANSACTION_CHANNEL_ID;
  const titleKey = kind === 'registration' ? SETTINGS_KEYS.REGISTRATION_CHANNEL_TITLE : SETTINGS_KEYS.TRANSACTION_CHANNEL_TITLE;
  settingsRepo.set(idKey, null);
  settingsRepo.set(titleKey, null);
  return true;
}

function setTransactionDuration(raw) {
  const value = assertDuration(raw);
  settingsRepo.set(SETTINGS_KEYS.TRANSACTION_DURATION_MINUTES, String(value));
  return value;
}

function replyKeyboard(orderId) {
  return Markup.inlineKeyboard([[
    button.success('✅ Approve', `adminorder:confirm:${orderId}`),
    button.danger('❌ Reject', `adminorder:reject:${orderId}`),
  ]]);
}

function safeEntities(raw) {
  if (!raw) return [];
  try {
    const value = JSON.parse(raw);
    return Array.isArray(value) ? value : [];
  } catch (_) {
    return [];
  }
}

function utf16Length(text) {
  return Buffer.byteLength(String(text || ''), 'utf16le') / 2;
}

function shiftEntities(entities, offset) {
  return (Array.isArray(entities) ? entities : []).map((entity) => ({
    ...entity,
    offset: Number(entity.offset || 0) + offset,
  })).filter((entity) => Number.isInteger(entity.offset) && Number.isInteger(entity.length) && entity.length > 0);
}

function truncateTelegramCaption(text, entities, maxUtf16Units = 1024) {
  const value = String(text || '');
  if (utf16Length(value) <= maxUtf16Units) return { text: value, entities };
  let cut = 0;
  let units = 0;
  for (const char of value) {
    const charUnits = utf16Length(char);
    if (units + charUnits > maxUtf16Units) break;
    units += charUnits;
    cut += char.length;
  }
  const outText = value.slice(0, cut);
  const outEntities = (Array.isArray(entities) ? entities : []).filter((entity) => {
    const start = Number(entity.offset || 0);
    const length = Number(entity.length || 0);
    return Number.isInteger(start) && Number.isInteger(length) && length > 0 && start + length <= utf16Length(outText);
  });
  return { text: outText, entities: outEntities };
}

function buildTransactionCaption(order, terminalStatus = null) {
  const productName = order.product_name || 'Produk';
  const proofCaption = typeof order.payment_proof_caption === 'string' ? order.payment_proof_caption : '';
  const header =
    `💳 TRANSAKSI #${order.id}\n` +
    `👤 User: ${order.user_id}\n` +
    `📦 Produk: ${productName}\n` +
    `🔢 Qty: ${order.qty}\n` +
    `💰 Total: ${productService.formatRupiah(order.total_price)}\n` +
    `🕒 Dibuat: ${order.created_at}\n` +
    `⏳ Proof diterima: ${order.payment_proof_received_at || '-'}\n` +
    `⌛ Aktif sampai: ${order.transaction_notification_expires_at || '-'}\n` +
    `📌 Status: ${terminalStatus || order.status}\n` +
    `${order.notification_actor_id ? `👮 Diproses admin: ${order.notification_actor_id}\n` : ''}`;
  const separator = proofCaption ? `\n🧾 Keterangan bukti:\n` : '';
  const text = header + separator + proofCaption;
  const entities = proofCaption ? shiftEntities(safeEntities(order.payment_proof_entities), utf16Length(header + separator)) : [];
  return truncateTelegramCaption(text, entities, 1024);
}

function buildRegistrationText(user) {
  const name = [user.first_name, user.last_name].filter(Boolean).join(' ') || '-';
  const username = user.username ? `@${user.username}` : '-';
  return (
    `🆕 <b>User Baru Terdaftar</b>\n\n` +
    `👤 Nama: ${escapeHtml(name)}\n` +
    `🔗 Username: ${escapeHtml(username)}\n` +
    `🆔 Telegram ID: <code>${Number(user.telegram_id)}</code>\n` +
    `🕒 Waktu: ${escapeHtml(user.created_at || '-')}`
  );
}

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function sendRegistrationNotification(telegram, user) {
  const channel = getChannel('registration');
  if (!channel || !user || !user.telegram_id) return { ok: false, reason: 'disabled' };
  const claimToken = crypto.randomUUID();
  if (!userRepo.claimRegistrationNotification(user.telegram_id, claimToken, CLAIM_STALE_MINUTES)) {
    return { ok: false, reason: 'already_sent_or_claimed' };
  }
  try {
    const message = await telegram.sendMessage(channel.id, buildRegistrationText(user), { parse_mode: 'HTML' });
    if (!userRepo.completeRegistrationNotification(user.telegram_id, claimToken, message.message_id)) {
      logger.warn(`Registration notification #${user.telegram_id} terkirim tetapi claim DB tidak dapat diselesaikan.`);
      return { ok: false, reason: 'claim_completion_failed', messageId: message.message_id };
    }
    return { ok: true, messageId: message.message_id };
  } catch (err) {
    userRepo.releaseRegistrationNotificationClaim(user.telegram_id, claimToken);
    logger.warn(`Registration notification gagal untuk user ${user.telegram_id}: ${(err && err.message) || err}`);
    return { ok: false, reason: 'telegram_error', error: err };
  }
}

function mediaSender(telegram, order, extra) {
  const fileId = order.payment_proof_file_id;
  if (order.payment_proof_type === 'photo') return telegram.sendPhoto(extra.chatId, fileId, extra.options);
  if (order.payment_proof_type === 'document') return telegram.sendDocument(extra.chatId, fileId, extra.options);
  if (order.payment_proof_type === 'video') return telegram.sendVideo(extra.chatId, fileId, extra.options);
  throw new Error(`Tipe bukti pembayaran tidak didukung: ${String(order.payment_proof_type)}`);
}

async function ensureTransactionNotification(telegram, orderOrId) {
  const supplied = typeof orderOrId === 'object' ? orderOrId : null;
  if (supplied && supplied.id) orderRepo.expireOrderIfDue(supplied.id);
  const order = supplied ? orderRepo.findById(supplied.id) : orderRepo.findById(orderOrId);
  const channel = getChannel('transaction');
  if (!order || !channel) return { ok: false, reason: order ? 'disabled' : 'not_found' };
  if (order.status === 'expired') return { ok: false, reason: 'expired', order };
  if (order.status !== 'awaiting_confirmation' || !order.payment_proof_file_id) return { ok: false, reason: 'invalid_state' };
  if (order.transaction_notification_message_id) return { ok: true, reason: 'already_sent', messageId: order.transaction_notification_message_id };
  if (order.transaction_notification_expires_at && Date.now() >= new Date(order.transaction_notification_expires_at).getTime()) {
    await expireTransactionNotification(telegram, order);
    return { ok: false, reason: 'expired' };
  }
  const claimToken = crypto.randomUUID();
  if (!orderRepo.claimTransactionNotification(order.id, claimToken, CLAIM_STALE_MINUTES)) {
    return { ok: false, reason: 'already_claimed' };
  }
  try {
    const built = buildTransactionCaption(order, 'awaiting_confirmation');
    const sent = await mediaSender(telegram, order, {
      chatId: channel.id,
      options: {
        caption: built.text,
        caption_entities: built.entities,
        ...replyKeyboard(order.id),
      },
    });
    const ok = orderRepo.recordTransactionNotification({
      id: order.id,
      claimToken,
      chatId: channel.id,
      messageId: sent.message_id,
      mediaType: order.payment_proof_type,
    });
    if (!ok) {
      logger.warn(`Transaction notification #${order.id} terkirim tetapi claim DB tidak terselesaikan.`);
      return { ok: false, reason: 'claim_completion_failed', messageId: sent.message_id };
    }
    return { ok: true, messageId: sent.message_id };
  } catch (err) {
    orderRepo.releaseTransactionNotificationClaim(order.id, claimToken, 'pending');
    logger.warn(`Transaction notification #${order.id} gagal: ${(err && err.message) || err}`);
    return { ok: false, reason: 'telegram_error', error: err };
  }
}

async function editProjection(telegram, order, captionStatus, replyMarkup, projectionStatus, actorId = null) {
  if (!order.transaction_notification_chat_id || !order.transaction_notification_message_id) return false;
  const built = buildTransactionCaption(order, captionStatus);
  try {
    await telegram.callApi('editMessageCaption', {
      chat_id: order.transaction_notification_chat_id,
      message_id: order.transaction_notification_message_id,
      caption: built.text,
      caption_entities: built.entities,
      reply_markup: replyMarkup || { inline_keyboard: [] },
    });
    orderRepo.setTransactionNotificationProjectionStatus(order.id, projectionStatus, actorId);
    return true;
  } catch (err) {
    orderRepo.setTransactionNotificationProjectionStatus(order.id, 'final_pending', actorId);
    logger.warn(`Gagal update transaction notification #${order.id}: ${(err && err.message) || err}`);
    return false;
  }
}

async function updateTransactionNotification(telegram, orderOrId, { status, actorId = null } = {}) {
  const order = typeof orderOrId === 'object' ? orderOrId : orderRepo.findById(orderOrId);
  if (!order || !order.transaction_notification_message_id) return { ok: false, reason: 'not_sent' };
  const label = status || order.status;
  const ok = await editProjection(telegram, order, label, { inline_keyboard: [] }, 'sent_final', actorId);
  return { ok, status: label };
}

async function expireTransactionNotification(telegram, orderOrId) {
  const order = typeof orderOrId === 'object' ? orderOrId : orderRepo.findById(orderOrId);
  if (!order) return { ok: false, reason: 'not_found' };
  if (!order.transaction_notification_message_id) {
    orderRepo.setTransactionNotificationProjectionStatus(order.id, 'expired');
    return { ok: true, reason: 'no_message' };
  }
  const ok = await editProjection(telegram, order, 'EXPIRED', { inline_keyboard: [] }, 'expired');
  return { ok };
}

async function validateChannelOrderCallback(telegram, ctx, order) {
  if (order && order.id) orderRepo.expireOrderIfDue(order.id);
  order = order && order.id ? orderRepo.findById(order.id) : order;
  const message = ctx && ctx.callbackQuery && ctx.callbackQuery.message;
  if (!message || message.chat.type !== 'channel') return { channelCallback: false };
  const channel = getChannel('transaction');
  if (!channel || String(message.chat.id) !== String(channel.id)) throw new Error('Callback channel sudah tidak aktif.');
  if (!order || String(order.transaction_notification_chat_id) !== String(message.chat.id) || Number(order.transaction_notification_message_id) !== Number(message.message_id)) {
    throw new Error('Callback tidak terikat ke notification transaksi yang valid.');
  }
  const member = await telegram.getChatMember(message.chat.id, ctx.from.id);
  if (!member || !['creator', 'administrator'].includes(member.status)) throw new Error('Actor bukan admin channel yang berwenang.');
  if (order.status !== 'awaiting_confirmation') throw new Error('Transaksi sudah diproses atau tidak berada pada status pending.');
  if (order.transaction_notification_expires_at && Date.now() >= new Date(order.transaction_notification_expires_at).getTime()) {
    await expireTransactionNotification(telegram, order);
    throw new Error('Notification transaksi sudah expired.');
  }
  return { channelCallback: true };
}

async function sweepTransactionNotifications(telegram, limit = 100) {
  let touched = 0;
  // Order expiry is a separate lifecycle boundary from the notification TTL.
  // Once an order is expired, its channel action must be projected as expired
  // rather than left approve/reject-capable.
  for (const order of orderRepo.listExpiredWithTransactionNotifications(limit)) {
    await expireTransactionNotification(telegram, order);
    touched++;
  }
  const rows = orderRepo.listAwaitingWithTransactionNotifications(limit);
  for (const order of rows) {
    if (order.transaction_notification_expires_at && Date.now() >= new Date(order.transaction_notification_expires_at).getTime()) {
      await expireTransactionNotification(telegram, order);
      touched++;
      continue;
    }
    if (!order.transaction_notification_message_id) {
      await ensureTransactionNotification(telegram, order);
      touched++;
    }
  }
  for (const order of orderRepo.listTransactionNotificationsFinalPending(limit)) {
    const current = orderRepo.findById(order.id);
    if (current && ['fulfilled', 'cancelled', 'rejected'].includes(current.status)) {
      await updateTransactionNotification(telegram, current, { status: current.status, actorId: current.notification_actor_id });
      touched++;
    }
  }
  return touched;
}

module.exports = {
  SETTINGS_KEYS,
  DEFAULT_TRANSACTION_DURATION_MINUTES,
  MIN_DURATION_MINUTES,
  MAX_DURATION_MINUTES,
  normalizeChannelTarget,
  getChannel,
  getTransactionDurationMinutes,
  validateChannel,
  setChannel,
  resetChannel,
  setTransactionDuration,
  sendRegistrationNotification,
  ensureTransactionNotification,
  updateTransactionNotification,
  expireTransactionNotification,
  validateChannelOrderCallback,
  sweepTransactionNotifications,
};
