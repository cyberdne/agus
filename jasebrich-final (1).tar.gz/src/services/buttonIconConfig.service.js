const crypto = require('crypto');
const repo = require('../database/repositories/settings.repository');
const { validateSingleEmoji } = require('../utils/emojiValidation');

const KEY = 'button_icons_v1';
const KNOWN_KEY = 'button_icons_known_v1';
const KNOWN_BUTTONS_KEY = 'button_icons_buttons_v2';
const MAX_ICONS = 500;
const MAX_KNOWN_BUTTONS = 2000;

// In-memory cache of every button label ever seen across the whole bot
// (persisted to `settings`), so the "pilih tombol" picker always shows
// every button that exists right now — including ones added by future
// features — without any manual registry file to maintain.
let knownCache = null;
let knownButtonCache = null;

function loadKnown() {
  if (knownCache) return knownCache;
  try {
    const raw = repo.get(KNOWN_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    knownCache = new Set(Array.isArray(arr) ? arr : []);
  } catch (_) {
    knownCache = new Set();
  }
  return knownCache;
}

function loadKnownButtons() {
  if (knownButtonCache) return knownButtonCache;
  try {
    const raw = repo.get(KNOWN_BUTTONS_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    knownButtonCache = new Map();
    if (Array.isArray(arr)) {
      for (const item of arr) {
        if (!item || typeof item !== 'object') continue;
        const label = String(item.label || '').trim();
        if (!label) continue;
        knownButtonCache.set(label, String(item.iconKey || label));
      }
    }
  } catch (_) {
    knownButtonCache = new Map();
  }
  return knownButtonCache;
}
// Whether the last attempt to persist the known-labels set to the DB
// succeeded. Starts false so the very first successful write (once the
// database is actually initialized) is never skipped.
let knownPersisted = false;

/**
 * Registry for labels that must NEVER be evicted, no matter how many
 * one-off dynamic labels (product names, group names, order text,
 * per-user data, ...) the bot generates over its lifetime. Populated
 * once at boot via registerStaticLabels() with every constant menu
 * label (MENU, PANEL_FEATURE, CATEGORY_LABEL) — see src/index.js.
 *
 * ROOT CAUSE this exists to fix: every button, static or dynamic,
 * used to share ONE capped registry (KNOWN_BUTTONS_KEY, see
 * MAX_KNOWN_BUTTONS below) that evicts its OLDEST entry once full.
 * Static navigation buttons ("Hapus Reply", "Atur Timer WTB", ...)
 * are registered the moment the bot boots — i.e. they are always the
 * FIRST, oldest entries. As a long-running/busy bot accumulates more
 * and more dynamic labels (each also written into that same
 * registry), it eventually evicts those old static entries first.
 * Once evicted, a customized static button can never be routed back
 * from its rendered (icon-prefixed) text to the constant the handler
 * is registered under — the bot replies "Perintah tidak dikenali" to
 * a perfectly normal button tap. This can happen to ANY static
 * button, anywhere in the bot, purely as a function of uptime/usage —
 * not tied to any specific screen. Keeping static labels in this
 * separate, unbounded, in-memory-only map removes them from the
 * evictable pool entirely.
 */
const staticButtons = new Map(); // rawLabel -> iconKey

function registerStaticLabels(labels) {
  for (const raw of labels || []) {
    const label = String(raw || '').trim();
    if (!label) continue;
    staticButtons.set(label, label);
    // Also seed the normalized picker set so it shows up in Admin
    // Panel -> Settings -> Custom Icon Tombol even before the button
    // has ever actually been rendered to a user.
    const key = normalizeLabel(label);
    if (key) loadKnown().add(key);
  }
}

function saveKnown() {
  try {
    repo.set(KNOWN_KEY, JSON.stringify(Array.from(knownCache)));
    repo.set(KNOWN_BUTTONS_KEY, JSON.stringify(Array.from(loadKnownButtons(), ([label, iconKey]) => ({ label, iconKey }))));
    knownPersisted = true;
  } catch (_) {
    // Database may not be initialized yet (this can be triggered by a
    // keyboard being built at module-require time, before
    // initDatabase() runs in src/index.js). Never let that crash the
    // bot — keep the label in memory and retry persisting on the next
    // registerButton() call, which will happen naturally as soon as
    // real traffic starts flowing through the bot.
    knownPersisted = false;
  }
}

/**
 * Called by src/utils/buttons.js for EVERY button created through the
 * `button.*`/`replyButton.*` helpers — main features, pagination,
 * per-row user/product listings, generic Kembali/Batal/Tutup
 * navigation, admin CRUD actions (Ban, Hapus, Edit, dst.), all of it —
 * so every button that exists anywhere in the bot ends up pickable in
 * Admin Panel -> Settings -> Custom Icon Tombol, no exceptions. Cheap
 * no-op once a label is already known AND already durably saved — only
 * writes to the DB when there's something new, or when an earlier
 * write attempt failed (e.g. it ran before the database was ready) and
 * needs retrying.
 */
function registerLabel(rawLabel, lookupLabel = rawLabel) {
  const raw = String(rawLabel || '').trim();
  const key = normalizeLabel(lookupLabel);
  if (!key && !raw) return;

  const set = loadKnown();
  const isNew = key ? !set.has(key) : false;
  if (key && isNew) set.add(key);

  const buttons = loadKnownButtons();
  const existingIconKey = buttons.get(raw);
  const buttonChanged = raw && existingIconKey !== String(lookupLabel || raw);
  if (raw && (!existingIconKey || buttonChanged)) {
    buttons.set(raw, String(lookupLabel || raw));
    // Keep the DYNAMIC registry bounded — static labels (see
    // staticButtons above) live outside this map entirely and are
    // never at risk here, no matter how full this one gets. Guarded
    // with a hard iteration cap: if every single entry were somehow
    // static (impossible in practice — the static set is a few dozen
    // constants against a 2000 cap — but never trust a while(true)),
    // this stops instead of spinning forever.
    let guard = 0;
    while (buttons.size > MAX_KNOWN_BUTTONS && guard < MAX_KNOWN_BUTTONS + 1) {
      guard += 1;
      const oldestKey = buttons.keys().next().value;
      if (staticButtons.has(oldestKey)) {
        // Never evict a static button — move it to the end of
        // insertion order instead, so eviction keeps progressing
        // through genuinely dynamic labels behind it.
        const v = buttons.get(oldestKey);
        buttons.delete(oldestKey);
        buttons.set(oldestKey, v);
        continue;
      }
      buttons.delete(oldestKey);
    }
  }

  if (isNew || buttonChanged || !knownPersisted) saveKnown();
}

/**
 * Registers the exact text used by a button before Custom Icon Tombol
 * transforms it. `iconKey` is the stable lookup identity and may differ
 * from the visible label for dynamic buttons. Keeping the original label
 * is essential for reply keyboards because Telegram sends the button's
 * rendered text back as a normal message — it has no callback_data.
 */
function registerButtonLabel(rawLabel, iconKey = rawLabel) {
  registerLabel(rawLabel, iconKey);
}

/**
 * Full list of every button label known to the system: auto-discovered
 * labels plus (defensively) any label that already has a custom icon
 * saved, sorted alphabetically for a stable, browsable picker.
 */
function getKnownLabels() {
  const set = loadKnown();
  Object.keys(load()).forEach((k) => set.add(k));
  return Array.from(set).sort((a, b) => a.localeCompare(b, 'id'));
}

/**
 * Stable identifier for a known button label, used by the Custom Icon
 * Tombol picker's inline-keyboard callback_data INSTEAD OF a positional
 * array index.
 *
 * ROOT CAUSE this exists to fix: getKnownLabels() returns a live,
 * alphabetically-sorted view of an ever-growing registry. Any button
 * rendered anywhere in the bot between the admin loading a picker page
 * and tapping a row on it (or between tapping "Pilih" and tapping
 * "Set/Ganti Icon") inserts a new label into that registry, which can
 * shift every index after the insertion point. On a busy bot this is
 * not a rare edge case — it can happen within the same second. The
 * admin taps what they see on screen, but by the time the callback
 * fires, `labels[idx]` may already refer to a completely different
 * button, so the emoji they picked gets silently saved onto the wrong
 * label. Deriving the callback token from the label's own content
 * (a short deterministic hash) instead of its position makes the
 * picker immune to registry growth: the token a button was rendered
 * with always resolves back to that exact same label, no matter how
 * many other labels are registered in between.
 */
function labelToken(label) {
  return crypto.createHash('sha1').update(String(label || '')).digest('hex').slice(0, 10);
}

/**
 * Resolves a labelToken() back to the original label text by scanning
 * the CURRENT known-labels registry. Returns null if no known label
 * hashes to this token (e.g. stale callback_data from a message sent
 * before a `reset()`, which cannot happen today since reset() only
 * clears icons, not the known-labels registry — kept defensive
 * regardless).
 */
function findLabelByToken(token) {
  const t = String(token || '').trim();
  if (!t) return null;
  for (const label of getKnownLabels()) {
    if (labelToken(label) === t) return label;
  }
  return null;
}

function load() {
  try {
    const raw = repo.get(KEY);
    const obj = raw ? JSON.parse(raw) : {};
    return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {};
  } catch (_) { return {}; }
}
function save(obj) {
  try { repo.set(KEY, JSON.stringify(obj)); } catch (_) { /* DB not ready yet; safe to ignore, see saveKnown() */ }
}
function normalizeLabel(label) {
  let value = String(label || '').trim();
  // Remove a leading run of emoji/ZWJ/variation-selector characters while
  // keeping the semantic button label. This is intentionally tolerant of
  // labels such as `🔔 Gabung Channel Wajib` and `💎 Premium`.
  value = value.replace(/^[\p{Extended_Pictographic}\uFE0F\u200D\s]+/u, '').trim();
  return value;
}
function getIcon(label) {
  const key = normalizeLabel(label);
  return load()[key] || null;
}
function setIcon(label, icon, meta = {}) {
  const key = normalizeLabel(label);
  if (!key) throw new Error('Nama tombol tidak valid.');
  // Grapheme-aware check (see utils/emojiValidation.js) — the old raw
  // `.length > 32` cap here was loose enough to rarely bite, but it's
  // the same kind of check that silently rejected valid multi-codepoint
  // emoji (flags, ZWJ sequences, skin tones) in the Emoji Premium
  // feature. Unified here so both features behave identically.
  const check = validateSingleEmoji(icon);
  if (!check.ok) throw new Error(check.reason);
  const value = check.value;
  const all = load();
  if (!all[key] && Object.keys(all).length >= MAX_ICONS) throw new Error('Batas custom icon tercapai.');
  all[key] = { icon: value, customEmojiId: meta.customEmojiId || null, updatedAt: new Date().toISOString() };
  save(all);
  return all[key];
}
function removeIcon(label) { const all=load(); delete all[normalizeLabel(label)]; save(all); }
function reset() {
  try { repo.set(KEY, '{}'); } catch (_) { /* DB not ready yet; safe to ignore */ }
}
function list() { return Object.entries(load()).map(([label,v])=>({label,...v})); }
/**
 * Two different cases, handled differently on purpose:
 *
 * 1. Admin picked a REGULAR unicode emoji (no `entry.customEmojiId`):
 *    there is no native icon to attach for that, so the only way to
 *    show it at all is to bake it into the button text, e.g.
 *    "⭐ Label". This always renders, on every account.
 *
 * 2. Admin picked an actual Telegram Premium/custom emoji (so
 *    `entry.customEmojiId` IS known): this is shown via the button's
 *    native `icon_custom_emoji_id` field (Bot API 9.4+) so the real
 *    animated Premium emoji renders — the whole point of picking a
 *    custom emoji in the first place. The text is left as the PLAIN
 *    label with no fallback character prefixed.
 *
 *    Why no prefix here: if the text also started with the fallback
 *    character (e.g. "⭐ Label") while `icon_custom_emoji_id` is set,
 *    Telegram draws the native icon to the left of the button AND the
 *    text still starts with its own character — showing the icon
 *    TWICE ("emoji terduplikat setelah emoji diset"). Leaving the text
 *    plain avoids that duplication while still actually applying the
 *    real custom emoji via the native field.
 *
 *    On accounts where the native field is silently ignored by
 *    Telegram (bot has no Fragment username and its owner has no
 *    Telegram Premium), the button simply shows the plain label with
 *    no icon at all — Bot API gives no way to fall back to a plain
 *    glyph in that case without risking the duplication above, so a
 *    bot owner who wants icons to show for 100% of accounts should
 *    pick a regular emoji (case 1) rather than a Premium one here.
 */
function stripTrailingDecorativeEmoji(label) {
  let value = normalizeLabel(label);
  // Pagination and navigation labels historically carried a trailing emoji
  // (for example `Berikutnya ▶️`) while Custom Icon Tombol is configured by
  // the semantic label (`Berikutnya`). Only use the stripped form as an
  // additional lookup candidate; never rewrite the saved key itself.
  value = value.replace(/(?:[\s\uFE0F\u200D]*[\p{Extended_Pictographic}])+(?:\uFE0F)?$/u, '').trim();
  return value;
}

function getButtonConfig(label, lookupLabel = label) {
  const candidates = [];
  for (const value of [lookupLabel, label, stripTrailingDecorativeEmoji(lookupLabel), stripTrailingDecorativeEmoji(label)]) {
    const key = normalizeLabel(value);
    if (key && !candidates.includes(key)) candidates.push(key);
  }

  let entry = null;
  let matchedKey = null;
  const all = load();
  for (const key of candidates) {
    if (all[key]) {
      entry = all[key];
      matchedKey = key;
      break;
    }
  }
  if (!entry) return { text: label, iconCustomEmojiId: null };
  if (entry.customEmojiId) {
    // When a semantic icon key such as `Berikutnya` matched a legacy visible
    // label such as `Berikutnya ▶️`, the trailing arrow is the old default
    // decoration, not part of the configured semantic button text. Native
    // Premium/custom-emoji buttons must not render that fallback glyph twice;
    // preserve the configured custom emoji as the sole presentation icon.
    const normalizedLabel = normalizeLabel(label);
    const semanticLabel = matchedKey || normalizedLabel;
    const strippedLabel = stripTrailingDecorativeEmoji(normalizedLabel);
    const outputText = semanticLabel === strippedLabel ? strippedLabel : normalizedLabel;
    return { text: outputText, iconCustomEmojiId: entry.customEmojiId, matchedKey };
  }
  return { text: `${entry.icon} ${normalizeLabel(label)}`, iconCustomEmojiId: null, matchedKey };
}
function renderLabel(label) {
  return getIcon(label) ? getButtonConfig(label).text : label;
}
function findDefaultLabel(customLabel, knownLabels) {
  const incoming = String(customLabel || '').trim();
  if (!incoming) return null;

  // First prefer an exact rendered-label match. This preserves labels whose
  // leading emoji is meaningful and avoids changing ordinary user text.
  for (const label of knownLabels) if (renderLabel(label) === incoming) return label;

  // Native `icon_custom_emoji_id` is visual-only on a reply keyboard, so the
  // client can return the semantic/plain label without the icon. Resolve that
  // form as well. Keep this as a fallback after exact matching to preserve
  // existing behavior when two labels only differ by their leading emoji.
  const semantic = normalizeLabel(incoming);
  if (!semantic) return null;
  for (const label of knownLabels) {
    if (normalizeLabel(label) === semantic) return label;
  }
  return null;
}

/**
 * Resolves a Telegram reply-keyboard message back to the exact original
 * button label that the handler registered. This handles BOTH custom-icon
 * modes:
 *   - regular Unicode custom icon: `⭐ Batalkan` -> `❌ Batalkan`
 *   - native Premium custom emoji: `Batalkan` -> `❌ Batalkan`
 *
 * Matching is exact on the rendered button text and therefore does not
 * rewrite ordinary user input unless it is actually a registered button.
 */
function resolveIncomingButtonLabel(incomingText) {
  const incoming = String(incomingText || '').trim();
  if (!incoming) return null;

  // Reply keyboards have no callback_data. Telegram sends the button
  // `text` back as a normal message. With Bot API native
  // `icon_custom_emoji_id`, the icon is visual-only and Telegram sends the
  // PLAIN label (e.g. `Tambah Produk Userbot`) even though the button shown
  // to the user has a custom emoji in front of it. Therefore exact matching
  // against the rendered label is necessary for regular emoji icons, but is
  // NOT sufficient for native custom-emoji icons.
  //
  // Checked in two passes — the capped/evictable dynamic registry first
  // (buttons), then the never-evicted static registry (staticButtons, see
  // registerStaticLabels above) — so a static button ALWAYS resolves
  // correctly even if it has fallen out of the dynamic registry.
  const buttons = loadKnownButtons();
  for (const [rawLabel, iconKey] of buttons.entries()) {
    if (getButtonConfig(rawLabel, iconKey).text === incoming) return rawLabel;
  }
  for (const [rawLabel, iconKey] of staticButtons.entries()) {
    if (getButtonConfig(rawLabel, iconKey).text === incoming) return rawLabel;
  }

  // Compatibility/failsafe path: match by the semantic label after removing
  // the leading presentation emoji. This also handles Telegram clients that
  // normalize the visual custom icon away before returning the button text.
  //
  // IMPORTANT: both loops below return the RAW label from a registry
  // (buttons/staticButtons) — never a bare normalized string. Returning a
  // normalized (emoji-stripped) label here would silently break routing:
  // it would no longer match the original MENU/PANEL_FEATURE constant the
  // handler is registered under, and would fall straight through to the
  // "Perintah tidak dikenali" catch-all — which is exactly the bug this
  // function exists to prevent.
  const incomingSemantic = normalizeLabel(incoming);
  if (incomingSemantic) {
    for (const rawLabel of buttons.keys()) {
      if (normalizeLabel(rawLabel) === incomingSemantic) return rawLabel;
    }
    for (const rawLabel of staticButtons.keys()) {
      if (normalizeLabel(rawLabel) === incomingSemantic) return rawLabel;
    }

    // Telegram reply keyboards are normally exact-text, but users can also
    // type the semantic button label themselves. The catch-all handler must
    // not treat a registered menu action such as `Status Promosi` as an
    // unknown command merely because the user typed `status promosi`. Keep
    // this case-insensitive fallback strictly scoped to labels already
    // registered as real buttons; never normalize arbitrary user text. If
    // multiple registered labels differ only by case, do not guess.
    const folded = incomingSemantic.toLocaleLowerCase('id-ID');
    const matches = [];
    for (const rawLabel of buttons.keys()) {
      if (normalizeLabel(rawLabel).toLocaleLowerCase('id-ID') === folded && !matches.includes(rawLabel)) matches.push(rawLabel);
    }
    for (const rawLabel of staticButtons.keys()) {
      if (normalizeLabel(rawLabel).toLocaleLowerCase('id-ID') === folded && !matches.includes(rawLabel)) matches.push(rawLabel);
    }
    if (matches.length === 1) return matches[0];
  }

  return null;
}

module.exports = { normalizeLabel, getIcon, setIcon, removeIcon, reset, list, renderLabel, getButtonConfig, findDefaultLabel, registerLabel, registerButtonLabel, registerStaticLabels, resolveIncomingButtonLabel, getKnownLabels, labelToken, findLabelByToken, KEY };
