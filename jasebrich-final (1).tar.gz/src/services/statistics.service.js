const fs = require('fs');
const os = require('os');
const path = require('path');
const { config } = require('../config');
const { getDb } = require('../database');
const userbotRuntime = require('./userbotRuntime.service');
const { getStatus: getSchedulerStatus } = require('../scheduler');
const packageInfo = require('../../package.json');

function round(value, digits = 1) {
  const n = Number(value);
  return Number.isFinite(n) ? Number(n.toFixed(digits)) : null;
}

function formatDuration(totalSeconds) {
  const total = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  const parts = [];
  if (days) parts.push(`${days} hari`);
  if (hours) parts.push(`${hours}j`);
  if (minutes) parts.push(`${minutes}m`);
  if (!parts.length || seconds) parts.push(`${seconds}d`);
  return parts.join(' ');
}

function nowIso() {
  return new Date().toISOString();
}

function collectUserStats(db, now) {
  const counts = db.prepare(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN updated_at >= datetime('now', '-30 days') THEN 1 ELSE 0 END) AS active_30d,
      SUM(CASE WHEN updated_at >= datetime('now', '-1 day') THEN 1 ELSE 0 END) AS active_24h,
      SUM(CASE WHEN COALESCE(is_banned, 0) = 1 THEN 1 ELSE 0 END) AS banned,
      SUM(CASE WHEN trial_claimed_at IS NOT NULL THEN 1 ELSE 0 END) AS trial_claimed
    FROM users
  `).get();
  const admins = db.prepare('SELECT COUNT(*) AS c FROM users WHERE telegram_id IN (' + (config.adminIds.length ? config.adminIds.map(() => '?').join(',') : 'NULL') + ')').get(...config.adminIds).c;
  return {
    total: Number(counts.total || 0),
    active30d: Number(counts.active_30d || 0),
    inactive30d: Math.max(0, Number(counts.total || 0) - Number(counts.active_30d || 0)),
    recentlyActive24h: Number(counts.active_24h || 0),
    admins: Number(admins || 0),
    banned: Number(counts.banned || 0),
    trialClaimed: Number(counts.trial_claimed || 0),
  };
}

function collectUserbotStats(db, now) {
  const rows = db.prepare(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status='active' AND (expires_at IS NULL OR datetime(expires_at) > datetime(?) ) THEN 1 ELSE 0 END) AS active,
      SUM(CASE WHEN status='inactive' THEN 1 ELSE 0 END) AS inactive,
      SUM(CASE WHEN status='pending_otp' THEN 1 ELSE 0 END) AS pending_otp,
      SUM(CASE WHEN status='expired' OR (expires_at IS NOT NULL AND datetime(expires_at) <= datetime(?) AND status='active') THEN 1 ELSE 0 END) AS expired,
      SUM(CASE WHEN status='revoked' THEN 1 ELSE 0 END) AS revoked,
      SUM(CASE WHEN label='🎁 Trial Userbot' AND status IN ('pending_otp','active') AND expires_at IS NOT NULL AND datetime(expires_at) > datetime(?) THEN 1 ELSE 0 END) AS trial_active
    FROM userbots
  `).get(now, now, now);
  return {
    total: Number(rows.total || 0),
    active: Number(rows.active || 0),
    inactive: Number(rows.inactive || 0),
    pendingOtp: Number(rows.pending_otp || 0),
    expired: Number(rows.expired || 0),
    revoked: Number(rows.revoked || 0),
    trialActive: Number(rows.trial_active || 0),
  };
}

function collectPoolStats(db, now) {
  const row = db.prepare(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) AS available,
      SUM(CASE WHEN status='assigned' THEN 1 ELSE 0 END) AS assigned,
      SUM(CASE WHEN status='disabled' THEN 1 ELSE 0 END) AS disabled,
      SUM(CASE WHEN status='assigned' AND expires_at IS NOT NULL AND datetime(expires_at) <= datetime(?) THEN 1 ELSE 0 END) AS assignedExpired
    FROM userbot_pool
  `).get(now);
  return {
    total: Number(row.total || 0),
    available: Number(row.available || 0),
    assigned: Number(row.assigned || 0),
    disabled: Number(row.disabled || 0),
    assignedExpired: Number(row.assignedExpired || 0),
  };
}

function collectOrderStats(db) {
  const rows = db.prepare('SELECT status, COUNT(*) AS c FROM orders GROUP BY status').all();
  const byStatus = Object.fromEntries(rows.map((row) => [String(row.status), Number(row.c || 0)]));
  const total = rows.reduce((sum, row) => sum + Number(row.c || 0), 0);
  return {
    total,
    pending: byStatus.pending || 0,
    awaitingConfirmation: byStatus.awaiting_confirmation || 0,
    processing: byStatus.processing || 0,
    paid: byStatus.paid || 0,
    fulfilled: byStatus.fulfilled || 0,
    rejected: byStatus.rejected || 0,
    cancelled: byStatus.cancelled || 0,
    expired: byStatus.expired || 0,
    successful: (byStatus.paid || 0) + (byStatus.fulfilled || 0),
    byStatus,
  };
}

function collectPaymentStats(db) {
  const row = db.prepare(`
    SELECT
      SUM(CASE WHEN status IN ('pending','awaiting_confirmation') AND expires_at IS NOT NULL AND datetime(expires_at) > datetime('now') THEN 1 ELSE 0 END) AS pending,
      SUM(CASE WHEN status='pending' AND expires_at IS NOT NULL AND datetime(expires_at) > datetime('now') AND payment_proof_requested_at IS NOT NULL AND payment_proof_file_id IS NULL THEN 1 ELSE 0 END) AS waiting_proof,
      SUM(CASE WHEN payment_proof_file_id IS NOT NULL THEN 1 ELSE 0 END) AS proof_submitted,
      SUM(CASE WHEN status IN ('paid','fulfilled') THEN 1 ELSE 0 END) AS verified,
      SUM(CASE WHEN status='rejected' THEN 1 ELSE 0 END) AS rejected
    FROM orders
  `).get();
  return {
    pending: Number(row.pending || 0),
    waitingProof: Number(row.waiting_proof || 0),
    proofSubmitted: Number(row.proof_submitted || 0),
    verified: Number(row.verified || 0),
    rejected: Number(row.rejected || 0),
  };
}

function collectSubscriptionStats(db, now) {
  const future7 = new Date(Date.now() + 7 * 86400000).toISOString();
  const row = db.prepare(`
    SELECT
      SUM(CASE WHEN status='active' AND (expires_at IS NULL OR datetime(expires_at) > datetime(?)) THEN 1 ELSE 0 END) AS active,
      SUM(CASE WHEN (status='expired' OR (expires_at IS NOT NULL AND datetime(expires_at) <= datetime(?) AND status='active')) THEN 1 ELSE 0 END) AS expired,
      SUM(CASE WHEN status='active' AND expires_at IS NOT NULL AND datetime(expires_at) > datetime(?) AND datetime(expires_at) <= datetime(?) THEN 1 ELSE 0 END) AS expiring_soon,
      SUM(CASE WHEN label='🎁 Trial Userbot' AND status IN ('pending_otp','active') AND expires_at IS NOT NULL AND datetime(expires_at) > datetime(?) THEN 1 ELSE 0 END) AS trial_active
    FROM userbots
  `).get(now, now, now, future7, now);
  const claimed = Number(db.prepare('SELECT COUNT(*) AS c FROM users WHERE trial_claimed_at IS NOT NULL').get().c || 0);
  const trialActive = Number(row.trial_active || 0);
  return {
    active: Number(row.active || 0),
    expired: Number(row.expired || 0),
    expiringSoon: Number(row.expiring_soon || 0),
    trialActive,
    trialClaimed: claimed,
    // The current schema records trial claims and currently-live trial rows,
    // but not a durable trial-expiry event. This derived count therefore means
    // "claimed but not currently active", not a fabricated historical expiry.
    trialInactive: Math.max(0, claimed - trialActive),
  };
}

function getDatabaseHealth(db) {
  const started = process.hrtime.bigint();
  let status = 'unavailable';
  let latency = null;
  let journalMode = null;
  let foreignKeys = null;
  let integrity = null;
  let sizeBytes = null;
  try {
    db.prepare('SELECT 1').get();
    latency = Number(process.hrtime.bigint() - started) / 1e6;
    status = 'ok';
    journalMode = String(db.pragma('journal_mode', { simple: true }) || '');
    foreignKeys = Number(db.pragma('foreign_keys', { simple: true })) === 1;
    integrity = String(db.pragma('quick_check', { simple: true }) || '') || null;
    const filePath = path.resolve(process.cwd(), config.dbPath);
    if (config.dbPath !== ':memory:' && fs.existsSync(filePath)) {
      sizeBytes = fs.statSync(filePath).size;
    }
  } catch (_) {
    status = 'unavailable';
  }
  return { status, latencyMs: round(latency, 2), journalMode, foreignKeys, integrity, sizeBytes };
}


function getSystemSnapshot() {
  const memory = process.memoryUsage();
  const systemTotal = os.totalmem();
  const systemFree = os.freemem();
  const cpuCount = Math.max(1, os.cpus().length);
  const load1 = os.loadavg()[0];
  const processUptimeSeconds = process.uptime();
  return {
    appVersion: packageInfo.version || null,
    uptimeSeconds: processUptimeSeconds,
    uptime: formatDuration(processUptimeSeconds),
    serverTime: nowIso(),
    pid: process.pid,
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    processMemoryMb: round(memory.rss / 1048576, 1),
    heapUsedMb: round(memory.heapUsed / 1048576, 1),
    heapTotalMb: round(memory.heapTotal / 1048576, 1),
    externalMb: round(memory.external / 1048576, 1),
    systemMemoryMb: round(systemTotal / 1048576, 1),
    systemFreeMb: round(systemFree / 1048576, 1),
    cpuLoadPercent: round((load1 / cpuCount) * 100, 1),
    cpuLoad1: round(load1, 2),
    cpuCount,
  };
}

function getStatisticsSnapshot() {
  const db = getDb();
  const now = nowIso();
  const users = collectUserStats(db, now);
  const userbots = collectUserbotStats(db, now);
  const pool = collectPoolStats(db, now);
  const orders = collectOrderStats(db);
  const payments = collectPaymentStats(db);
  const subscriptions = collectSubscriptionStats(db, now);
  const runtime = userbotRuntime.getRuntimeStats();
  const scheduler = getSchedulerStatus();
  const system = getSystemSnapshot();
  const dbHealth = getDatabaseHealth(db);

  return {
    generatedAt: now,
    users,
    userbots: {
      ...userbots,
      running: runtime.running,
      runtimeRecords: runtime.runtimeRecords,
      promotionRunning: runtime.promotionRunning,
      promotionStopped: Math.max(0, runtime.runtimeRecords - runtime.promotionRunning),
      stopped: Math.max(0, runtime.runtimeRecords - runtime.running),
    },
    pool,
    orders,
    payments,
    subscriptions,
    promotion: {
      running: runtime.promotionRunning,
      stopped: Math.max(0, runtime.runtimeRecords - runtime.promotionRunning),
      runtimeRecords: runtime.runtimeRecords,
    },
    system,
    database: dbHealth,
    scheduler,
  };
}

module.exports = { getStatisticsSnapshot, getSystemSnapshot, getDatabaseHealth, formatDuration };
