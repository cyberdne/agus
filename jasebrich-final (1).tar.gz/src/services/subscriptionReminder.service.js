const crypto = require('crypto');
const { Markup } = require('telegraf');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const reminderRepo = require('../database/repositories/subscriptionReminder.repository');
const userRepo = require('../database/repositories/user.repository');
const subscription = require('./subscription.service');
const logger = require('../utils/logger');
const { button } = require('../utils/buttons');
const { formatIndonesiaDate, formatRemainingDuration } = require('../utils/placeholders');
const { CALLBACK } = require('../constants/menu');
const { escapeHtml } = require('../utils/telegramFormatting');
const subscriptionNotice = require('./subscriptionNotice.service');
const reminderPolicy = require('./subscriptionReminder.policy');
const { classifyReminderDeliveryError, chooseCurrentThreshold } = reminderPolicy;

const DEFAULT_THRESHOLDS = [7 * 24 * 60, 3 * 24 * 60, 24 * 60];
const MAX_THRESHOLDS = 6;
const MAX_AUTOMATIC_SENDS_PER_TICK = 100;
const MAX_AUTOMATIC_ATTEMPTS_PER_EVENT = 3;
const DEFAULT_TEMPLATE = `⚠️ <b>Langganan Userbot Akan Segera Berakhir</b>\n\n` +
  `📦 Paket: {package_name}\n` +
  `⏳ Sisa waktu: {remaining}\n` +
  `📅 Berakhir: {expires_at}\n\n` +
  `Perpanjang sekarang agar layanan tetap aktif.`;

function getConfig() {
  const row = reminderRepo.getConfig();
  let thresholds = DEFAULT_THRESHOLDS;
  try {
    const parsed = JSON.parse(row.thresholds_minutes || '[]');
    if (Array.isArray(parsed) && parsed.length) thresholds = normalizeThresholds(parsed);
  } catch (_) {}
  return { enabled: Boolean(row.enabled), thresholds, template: row.template || DEFAULT_TEMPLATE, updatedAt: row.updated_at };
}

function normalizeThresholds(values) {
  const uniq = [...new Set(values.map(Number).filter((n) => Number.isInteger(n) && n > 0 && n <= 43200))];
  if (!uniq.length) throw new Error('Minimal satu threshold reminder harus valid.');
  if (uniq.length > MAX_THRESHOLDS) throw new Error(`Maksimal ${MAX_THRESHOLDS} threshold reminder.`);
  return uniq.sort((a,b) => b-a);
}

function parseThresholds(input) {
  const parts = String(input || '').split(',').map((x) => x.trim()).filter(Boolean);
  if (!parts.length) throw new Error('Threshold wajib diisi. Contoh: 7d,3d,1d atau 168h,72h,24h.');
  const minutes = parts.map((part) => {
    const m = part.match(/^(\d+)\s*(d|h|m)$/i);
    if (!m) throw new Error(`Threshold "${part}" tidak valid. Gunakan d/h/m.`);
    const n = Number(m[1]);
    if (!Number.isSafeInteger(n) || n <= 0) throw new Error(`Threshold "${part}" tidak valid.`);
    const multiplier = m[2].toLowerCase() === 'd' ? 1440 : m[2].toLowerCase() === 'h' ? 60 : 1;
    return n * multiplier;
  });
  return normalizeThresholds(minutes);
}

function setThresholds(input) {
  const thresholds = Array.isArray(input) ? normalizeThresholds(input) : parseThresholds(input);
  reminderRepo.setThresholds(thresholds);
  return getConfig();
}

function setEnabled(enabled) {
  reminderRepo.setEnabled(Boolean(enabled));
  return getConfig();
}

function renderTemplate(template, user, row, remaining) {
  const owner = user || userRepo.findByTelegramId(row.user_id) || {};
  const replacements = {
    '{package_name}': escapeHtml(String(row.label || 'Userbot')),
    '{remaining}': escapeHtml(String(remaining)),
    '{expires_at}': escapeHtml(String(formatIndonesiaDate(row.expires_at))),
    '{nama}': escapeHtml([owner.first_name, owner.last_name].filter(Boolean).join(' ') || owner.username || 'Pengguna'),
    '{username}': escapeHtml(owner.username ? `@${owner.username}` : '-'),
    '{telegram_id}': escapeHtml(String(row.user_id)),
  };
  let text = String(template || DEFAULT_TEMPLATE);
  for (const [token, value] of Object.entries(replacements)) text = text.split(token).join(value);
  if (/[{][A-Za-z0-9_]+[}]/.test(text)) throw new Error('Template reminder mengandung placeholder yang tidak didukung.');
  return text.slice(0, 4096);
}

function eligibleRows(nowMs = Date.now()) {
  const cfg = getConfig();
  const max = Math.max(...cfg.thresholds, 0);
  if (!max) return [];
  const nowIso = new Date(nowMs).toISOString();
  const maxIso = new Date(nowMs + max * 60 * 1000).toISOString();
  return ownedRepo.listActiveExpiringByMaxThreshold(nowIso, maxIso, 5000).filter((row) => subscription.isActiveNow(row, nowMs));
}


async function sendReminder(telegram, row, thresholdMinutes, eventKey, eventType = 'automatic', nonce = null) {
  const fresh = ownedRepo.findById(row.id);
  if (!fresh || !subscription.isActiveNow(fresh)) return { ok: false, reason: 'subscription_changed' };
  if (String(fresh.expires_at) !== String(row.expires_at)) return { ok: false, reason: 'expiry_changed' };
  if (eventType === 'automatic' && Number(fresh.sub_version || 0) !== Number(row.sub_version || 0)) return { ok: false, reason: 'subscription_version_changed' };
  const token = crypto.randomUUID();
  if (!reminderRepo.claimEvent(eventKey, token)) return { ok: false, reason: 'already_claimed', claimed: false };
  try {
    // Re-read after claiming but immediately before the network send. A renewal
    // can race the first read; this second compare prevents a stale reminder
    // from being sent when the subscription instance already changed.
    const beforeSend = ownedRepo.findById(row.id);
    if (!beforeSend || !subscription.isActiveNow(beforeSend) || String(beforeSend.expires_at) !== String(row.expires_at) || (eventType === 'automatic' && Number(beforeSend.sub_version || 0) !== Number(row.sub_version || 0))) {
      reminderRepo.markSkipped(eventKey, token, 'Subscription berubah sebelum reminder dikirim.');
      return { ok: false, reason: 'subscription_changed', claimed: true };
    }
    const user = userRepo.findByTelegramId(beforeSend.user_id);
    const text = renderTemplate(getConfig().template, user, beforeSend, formatRemainingDuration(beforeSend.expires_at));
    await telegram.sendMessage(fresh.user_id, text, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[button.success('🔄 Perpanjang', CALLBACK.SUBSCRIPTION_RENEW(fresh.id))]]),
    });
    reminderRepo.markSent(eventKey, token);
    return { ok: true, claimed: true };
  } catch (err) {
    const classification = classifyReminderDeliveryError(err);
    if (classification === 'permanent') reminderRepo.markSkipped(eventKey, token, 'Pengiriman reminder gagal permanen: ' + String(err?.message || err));
    else reminderRepo.markFailed(eventKey, token, String(err?.message || err));
    return { ok: false, reason: classification === 'permanent' ? 'permanent_error' : 'telegram_error', error: err, claimed: true };
  }
}

async function ensureExpiredReminderEvent(row) {
  if (!row || !row.id || !row.expires_at) return null;
  const key = `expiry:${row.id}:${row.sub_version || 0}:${row.expires_at}`;
  reminderRepo.ensureEvent(key, { eventType: 'expiry', row, threshold: 0 });
  return key;
}

async function sendExpiredReminder(telegram, row, eventKey) {
  const fresh = ownedRepo.findById(row.id);
  if (!fresh || fresh.status !== 'expired' || String(fresh.expires_at) !== String(row.expires_at) || Number(fresh.sub_version || 0) !== Number(row.sub_version || 0)) {
    return { ok:false, reason:'subscription_changed' };
  }
  const token = crypto.randomUUID();
  if (!reminderRepo.claimEvent(eventKey, token)) return { ok:false, reason:'already_claimed', claimed:false };
  try {
    const current = ownedRepo.findById(row.id);
    if (!current || current.status !== 'expired' || String(current.expires_at) !== String(row.expires_at) || Number(current.sub_version || 0) !== Number(row.sub_version || 0)) {
      reminderRepo.markSkipped(eventKey, token, 'Subscription berubah sebelum reminder kadaluarsa dikirim.');
      return { ok:false, reason:'subscription_changed', claimed:true };
    }
    const notice = subscriptionNotice.buildExpiredNotice(subscriptionNotice.ctxLikeFor(current.user_id), current);
    await telegram.sendMessage(current.user_id, notice.text, notice.options);
    reminderRepo.markSent(eventKey, token);
    return { ok:true, claimed:true };
  } catch (err) {
    const classification = classifyReminderDeliveryError(err);
    if (classification === 'permanent') reminderRepo.markSkipped(eventKey, token, 'Pengiriman reminder kadaluarsa gagal permanen: ' + String(err?.message || err));
    else reminderRepo.markFailed(eventKey, token, String(err?.message || err));
    return { ok:false, reason:classification === 'permanent' ? 'permanent_error' : 'telegram_error', claimed:true, error:err };
  }
}

async function sweepExpiredReminders(telegram) {
  reminderRepo.quarantineStaleSending();
  let sent=0, skipped=0, failed=0, attempted=0;
  for (const row of reminderRepo.listPendingExpiry(100)) {
    if (Number(row.attempts || 0) >= MAX_AUTOMATIC_ATTEMPTS_PER_EVENT) {
      reminderRepo.markExhausted(row.event_key, 'Batas percobaan reminder kadaluarsa tercapai setelah kegagalan sementara.');
      skipped++;
      continue;
    }
    try {
      const result=await sendExpiredReminder(telegram,row,row.event_key);
      if(result.claimed) attempted++;
      if(result.ok) sent++;
      else if(['already_claimed','subscription_changed','permanent_error'].includes(result.reason)) skipped++;
      else failed++;
    } catch(err) {
      failed++;
      logger.error(`Reminder kadaluarsa userbot #${row.id} gagal: ${err.message}`);
    }
    if(attempted>=MAX_AUTOMATIC_SENDS_PER_TICK) break;
  }
  return {sent,skipped,failed,attempted};
}

async function sweepAutomaticReminders(telegram, nowMs = Date.now()) {
  const cfg = getConfig();
  if (!cfg.enabled || !cfg.thresholds.length) return { sent: 0, skipped: 0, failed: 0 };
  let sent = 0; let skipped = 0; let failed = 0; let attempted = 0;
  reminderRepo.quarantineStaleSending();
  const rows = eligibleRows(nowMs);
  for (const row of rows) {
    const remainingMs = new Date(row.expires_at).getTime() - nowMs;
    if (!Number.isFinite(remainingMs) || remainingMs <= 0) continue;
    // Send only the most imminent threshold currently crossed. This avoids
    // sending all missed 7d/3d/1d reminders at once after downtime.
    const threshold = chooseCurrentThreshold(remainingMs, cfg.thresholds);
    if (!Number.isFinite(threshold) || threshold <= 0 || remainingMs > threshold * 60 * 1000) continue;
    const key = `auto:${row.id}:${row.sub_version || 0}:${row.expires_at}:${threshold}`;
    const existing = reminderRepo.getEvent(key);
    if (existing && ['sent', 'skipped', 'sending'].includes(existing.status)) {
      skipped += 1;
      continue;
    }
    if (existing && existing.status === 'failed' && Number(existing.attempts || 0) >= MAX_AUTOMATIC_ATTEMPTS_PER_EVENT) {
      reminderRepo.markExhausted(key, 'Batas percobaan reminder tercapai setelah kegagalan sementara.');
      skipped += 1;
      continue;
    }
    reminderRepo.ensureEvent(key, { eventType: 'automatic', row, threshold });
    try {
      const result = await sendReminder(telegram, row, threshold, key, 'automatic');
      if (result.claimed) attempted += 1;
      if (result.ok) sent += 1;
      else if (['already_claimed','subscription_changed','expiry_changed','subscription_version_changed'].includes(result.reason)) skipped += 1;
      else if (['permanent_error','blocked'].includes(result.reason)) skipped += 1;
      else failed += 1;
    } catch (err) {
      // One malformed row/template or unexpected Telegram failure must never
      // terminate the sweep for every other subscriber.
      failed += 1;
      logger.error(`Reminder userbot #${row.id} gagal: ${err.message}`);
    }
    if (attempted >= MAX_AUTOMATIC_SENDS_PER_TICK) break;
  }
  return { sent, skipped, failed, attempted };
}


async function sendManualReminder(telegram, userbotId, adminId, nonce) {
  const row = ownedRepo.findById(Number(userbotId));
  if (!row || Number(row.user_id) <= 0) return { ok: false, reason: 'not_found' };
  const now = Date.now();
  if (!subscription.isActiveNow(row, now)) return { ok: false, reason: 'not_active' };
  const cfg = getConfig();
  const remainingMs = new Date(row.expires_at).getTime() - now;
  const threshold = chooseCurrentThreshold(remainingMs, cfg.thresholds);
  const key = `manual:${adminId}:${row.id}:${row.sub_version || 0}:${nonce}`;
  reminderRepo.ensureEvent(key, { eventType: 'manual', row, threshold });
  return sendReminder(telegram, row, threshold, key, 'manual', nonce);
}

function manualCandidates(limit = 20) {
  const rows = eligibleRows(Date.now());
  return rows.sort((a,b) => new Date(a.expires_at).getTime() - new Date(b.expires_at).getTime()).slice(0, Math.max(1, Math.min(50, Number(limit) || 20)));
}

function formatThresholds(thresholds) {
  return thresholds.map((m) => {
    if (m % 1440 === 0) return `${m / 1440} hari`;
    if (m % 60 === 0) return `${m / 60} jam`;
    return `${m} menit`;
  }).join(', ');
}

function homeSummary() {
  const cfg = getConfig();
  const candidates = eligibleRows();
  const next = candidates[0];
  return { ...cfg, eligibleCount: candidates.length, next, thresholdsLabel: formatThresholds(cfg.thresholds) };
}

module.exports = {
  DEFAULT_TEMPLATE, getConfig, setThresholds, setEnabled, parseThresholds,
  renderTemplate, eligibleRows, sweepAutomaticReminders, manualCandidates,
  sendManualReminder, homeSummary, formatThresholds, ensureExpiredReminderEvent, sendExpiredReminder, sweepExpiredReminders,
};

/**
 * One complete reminder cycle: automatic threshold reminders first, then
 * expiry notices. The two are isolated so a failure in one never blocks the
 * other, and every cycle is recorded so the admin panel can show its outcome.
 */
async function runSweep(telegram) {
  const startedAt = Date.now();
  let automatic = null;
  let expired = null;
  const errors = [];
  try { automatic = await sweepAutomaticReminders(telegram); }
  catch (err) { errors.push('otomatis: ' + err.message); logger.error('Reminder sweep otomatis gagal:', err); }
  try { expired = await sweepExpiredReminders(telegram); }
  catch (err) { errors.push('kadaluarsa: ' + err.message); logger.error('Reminder sweep kadaluarsa gagal:', err); }
  const totals = reminderPolicy.summarizeSweep(automatic, expired);
  const error = errors.length ? errors.join('; ').slice(0, 500) : null;
  const status = reminderPolicy.classifyRunStatus({ error, failed: totals.failed });
  reminderRepo.insertRun({ status, ...totals, durationMs: Date.now() - startedAt, error });
  return { status, ...totals, error };
}

function lastRunSummary() {
  return reminderRepo.lastRun() || null;
}

Object.assign(module.exports, { runSweep, lastRunSummary });
