/**
 * Decides WHICH owned userbot a buyer is renewing. Never guesses when a
 * buyer owns several: it asks (status 'pick') instead of silently picking
 * the newest one, so renewing one userbot can never affect another.
 */
const subscription = require('./subscription.service');
const renewalState = require('../state/renewalState');

/** @returns {{status:'none'}|{status:'ok',asset:object}|{status:'pick',rows:object[]}} */
function resolve(telegramId) {
  const rows = subscription.listRenewable(telegramId);
  if (!rows.length) return { status: 'none' };
  const chosen = renewalState.get(telegramId);
  if (chosen) {
    const row = rows.find((r) => r.id === Number(chosen.userbotId));
    if (row) return { status: 'ok', asset: row };
  }
  if (rows.length === 1) return { status: 'ok', asset: rows[0] };
  return { status: 'pick', rows };
}

function choose(telegramId, userbotId) {
  renewalState.set(telegramId, { userbotId: Number(userbotId) });
}

function clear(telegramId) {
  renewalState.clear(telegramId);
}

module.exports = { resolve, choose, clear };
