'use strict';
/**
 * Pure health evaluation. Each check returns ok / warn / critical with a plain
 * detail string. Overall status is the worst check. Card actions are decided
 * here so the "when do we touch the admin's message" rule is testable.
 */
const { escapeHtml } = require('../utils/telegramFormatting');
const { parseDbTimestamp } = require('./autoBackup.policy');

const LEVELS = ['ok', 'warn', 'critical'];
const ICON = { ok: '🟢', warn: '🟡', critical: '🔴' };
const HOUR = 3600 * 1000;

function rank(status) { return LEVELS.indexOf(status); }

function overallStatus(checks) {
  return checks.reduce((worst, c) => (rank(c.status) > rank(worst) ? c.status : worst), 'ok');
}

function evaluateChecks(input) {
  const out = [];
  const nowMs = input.nowMs;
  const s = input.scheduler || {};
  const interval = (Number(s.intervalSeconds) || 300) * 1000;
  // Before the first tick finishes there is no completed timestamp yet; fall
  // back to the start time so the check does not fire during the first tick.
  const ref = s.lastTickCompletedAt ? Date.parse(s.lastTickCompletedAt) : (s.lastTickStartedAt ? Date.parse(s.lastTickStartedAt) : NaN);
  if (!s.running) {
    out.push({ id: 'scheduler', label: 'Scheduler', status: 'critical', detail: 'Berhenti' });
  } else if (!Number.isFinite(ref) || nowMs - ref > 3 * interval) {
    out.push({ id: 'scheduler', label: 'Scheduler', status: 'critical', detail: 'Tidak menyelesaikan tick lebih dari 3x interval' });
  } else if (s.lastTickError) {
    out.push({ id: 'scheduler', label: 'Scheduler', status: 'warn', detail: `Tick terakhir error: ${String(s.lastTickError).slice(0, 120)}` });
  } else {
    out.push({ id: 'scheduler', label: 'Scheduler', status: 'ok', detail: 'Berjalan normal' });
  }

  out.push(input.db && input.db.ok === false
    ? { id: 'database', label: 'Database', status: 'critical', detail: `Tidak bisa dibaca: ${String(input.db.error || '').slice(0, 120)}` }
    : { id: 'database', label: 'Database', status: 'ok', detail: 'Terhubung' });

  const free = Number(input.disk && input.disk.freeRatio);
  const pct = Number.isFinite(free) ? `${(free * 100).toFixed(1)}% bebas` : 'tidak diketahui';
  if (Number.isFinite(free) && free < 0.05) out.push({ id: 'disk', label: 'Disk', status: 'critical', detail: `Hampir penuh (${pct})` });
  else if (Number.isFinite(free) && free < 0.10) out.push({ id: 'disk', label: 'Disk', status: 'warn', detail: `Ruang menipis (${pct})` });
  else out.push({ id: 'disk', label: 'Disk', status: 'ok', detail: pct });

  const lastReminder = input.reminder && input.reminder.lastRun;
  if (!lastReminder) out.push({ id: 'reminder', label: 'Pengingat masa aktif', status: 'ok', detail: 'Belum ada siklus' });
  else if (lastReminder.status === 'error') out.push({ id: 'reminder', label: 'Pengingat masa aktif', status: 'warn', detail: `Siklus terakhir error: ${String(lastReminder.error || '').slice(0, 120)}` });
  else out.push({ id: 'reminder', label: 'Pengingat masa aktif', status: 'ok', detail: `Siklus terakhir: ${lastReminder.status}` });

  const b = input.backup || {};
  if (!b.enabled) out.push({ id: 'backup', label: 'Backup otomatis', status: 'ok', detail: 'Nonaktif' });
  else {
    const last = parseDbTimestamp(b.lastRunAt);
    const bInterval = (Number(b.intervalHours) || 24) * HOUR;
    if (!b.lastRunAt) out.push({ id: 'backup', label: 'Backup otomatis', status: 'warn', detail: 'Belum pernah berjalan' });
    else if (b.lastStatus === 'error') out.push({ id: 'backup', label: 'Backup otomatis', status: 'warn', detail: 'Backup terakhir gagal' });
    else if (Number.isFinite(last) && nowMs - last > 2 * bInterval) out.push({ id: 'backup', label: 'Backup otomatis', status: 'warn', detail: 'Terlambat dari jadwal' });
    else out.push({ id: 'backup', label: 'Backup otomatis', status: 'ok', detail: 'Berjalan sesuai jadwal' });
  }

  const u = input.ubot || { success: 0, failed: 0 };
  const total = u.success + u.failed;
  if (total >= 10 && u.failed / total > 0.5) {
    out.push({ id: 'ubot', label: 'Pengiriman userbot', status: 'warn', detail: `Gagal ${u.failed} dari ${total} pengiriman` });
  } else {
    out.push({ id: 'ubot', label: 'Pengiriman userbot', status: 'ok', detail: `Berhasil ${u.success}, gagal ${u.failed}` });
  }
  return out;
}

function signatureOf(checks) {
  return JSON.stringify(checks.map((c) => [c.id, c.status]));
}

/**
 * Card policy: create once, edit when the set of statuses changes, and send
 * a heartbeat edit while a problem remains open. Nothing else touches the
 * admin's chat, so a stable system produces zero messages.
 */
function decideCardAction({ prevSignature, nextSignature, lastEditMs, nowMs, heartbeatMs, overall }) {
  if (!prevSignature) return 'create';
  if (prevSignature !== nextSignature) return 'edit';
  if (overall !== 'ok' && (!Number.isFinite(lastEditMs) || nowMs - lastEditMs >= heartbeatMs)) return 'edit';
  return 'none';
}

function formatCard({ checks, overall, incidentStartedAt, nowLabel }) {
  const header = `🩺 <b>Kesehatan Sistem</b>\nStatus: ${ICON[overall]} <b>${overall === 'ok' ? 'Normal' : overall === 'warn' ? 'Perlu perhatian' : 'Kritis'}</b>`;
  const lines = checks.map((c) => `${ICON[c.status]} ${escapeHtml(c.label)} — ${escapeHtml(c.detail)}`).join('\n');
  const incident = incidentStartedAt && overall !== 'ok'
    ? `\n\n⏱️ Masalah sejak: ${escapeHtml(incidentStartedAt.slice(0, 16).replace('T', ' '))} UTC`
    : '';
  return `${header}\n\n${lines}${incident}\n\n<i>Diperbarui ${escapeHtml(nowLabel || '-')} UTC. Pesan ini diedit, bukan dikirim ulang.</i>`;
}

module.exports = { LEVELS, overallStatus, evaluateChecks, signatureOf, decideCardAction, formatCard };
