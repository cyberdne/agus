const repo = require('../database/repositories/settings.repository');

const KEYS = {
  AUTO_PROMOSI_TEXT: 'automation_auto_promosi_text',
  AUTO_PROMOSI_INTERVAL_MINUTES: 'automation_auto_promosi_interval_minutes',
  WTB_KEYWORDS: 'automation_wtb_keywords',
  WTB_REPLY_TEXT: 'automation_wtb_reply_text',
  PM_PERMIT_WARNING_TEXT: 'automation_pm_permit_warning_text',
};

const DEFAULTS = {
  [KEYS.AUTO_PROMOSI_TEXT]:
    '🔥 Promo spesial hari ini! Cek produk & layanan terbaru kami. Info & order langsung chat admin ya 🙏',
  [KEYS.AUTO_PROMOSI_INTERVAL_MINUTES]: '60',
  [KEYS.WTB_KEYWORDS]: 'wtb,want to buy,cari barang,dicari,looking for',
  [KEYS.WTB_REPLY_TEXT]:
    '👋 Halo! Sepertinya Anda sedang mencari sesuatu. Silakan hubungi saya lewat PM untuk info lebih lanjut, terima kasih 🙏',
  [KEYS.PM_PERMIT_WARNING_TEXT]:
    '🚫 *PM Permit aktif*\n\nAkun ini hanya menerima pesan pribadi dari kontak tersimpan. Pesan Anda tidak akan dibalas. Jika ini keliru, hubungi admin dari channel/grup resmi.',
};

function getRaw(key) {
  const value = repo.get(key);
  return value === null || value === undefined || value === '' ? DEFAULTS[key] : value;
}

function getAutoPromosiText() {
  return getRaw(KEYS.AUTO_PROMOSI_TEXT);
}

function setAutoPromosiText(text) {
  repo.set(KEYS.AUTO_PROMOSI_TEXT, text);
}

function getAutoPromosiIntervalMinutes() {
  const raw = getRaw(KEYS.AUTO_PROMOSI_INTERVAL_MINUTES);
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed >= 5 ? parsed : 60;
}

function setAutoPromosiIntervalMinutes(minutes) {
  const parsed = Number(minutes);
  if (!Number.isFinite(parsed) || parsed < 5) {
    throw new Error('Interval minimal 5 menit.');
  }
  repo.set(KEYS.AUTO_PROMOSI_INTERVAL_MINUTES, String(Math.round(parsed)));
}

function getWtbKeywords() {
  return getRaw(KEYS.WTB_KEYWORDS)
    .split(',')
    .map((k) => k.trim().toLowerCase())
    .filter(Boolean);
}

function setWtbKeywords(text) {
  repo.set(KEYS.WTB_KEYWORDS, text);
}

function getWtbReplyText() {
  return getRaw(KEYS.WTB_REPLY_TEXT);
}

function setWtbReplyText(text) {
  repo.set(KEYS.WTB_REPLY_TEXT, text);
}

function getPmPermitWarningText() {
  return getRaw(KEYS.PM_PERMIT_WARNING_TEXT);
}

function setPmPermitWarningText(text) {
  repo.set(KEYS.PM_PERMIT_WARNING_TEXT, text);
}

module.exports = {
  KEYS,
  getAutoPromosiText,
  setAutoPromosiText,
  getAutoPromosiIntervalMinutes,
  setAutoPromosiIntervalMinutes,
  getWtbKeywords,
  setWtbKeywords,
  getWtbReplyText,
  setWtbReplyText,
  getPmPermitWarningText,
  setPmPermitWarningText,
};
