/**
 * Centralized authorization for Userbot CONTROL actions.
 *
 * Every path that lets someone control an owned userbot (all Kontrol Panel
 * reply-keyboard handlers, wizard steps, media/forward inputs, old inline
 * callbacks such as panelgrp:*, Admin Panel "Kontrol Panel Ubot") funnels
 * through checkUserbotControlAccess() — the check is NOT per-button and NOT
 * UI-driven, it is evaluated server-side on every single action against a
 * fresh database read.
 *
 * It answers, in order:
 *   1. does the userbot exist?
 *   2. does the actor own it (admins acting through Admin Panel excepted)?
 *   3. is the subscription still valid *right now*  (now < expires_at)?
 *      -> derived from the timestamp, so an expired userbot is locked
 *         immediately even if the scheduler has not ticked yet; when it
 *         notices a lapsed-but-still-'active' row it also triggers the
 *         persisted EXPIRED transition + runtime stop right away.
 *
 * Root cause this fixes: previously only `status === 'active'` and ownership
 * were checked, and nothing but the (trial-only) sweeper ever consulted
 * expires_at, so an expired userbot kept status 'active' forever.
 */
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const poolRepo = require('../database/repositories/userbotPool.repository');
const subscription = require('./subscription.service');
const logger = require('../utils/logger');

const CODE = Object.freeze({
  OK: 'OK',
  NOT_FOUND: 'NOT_FOUND',
  NOT_OWNER: 'NOT_OWNER',
  EXPIRED: 'EXPIRED',
  SUSPENDED: 'SUSPENDED',
  NOT_ACTIVE: 'NOT_ACTIVE',
});

class UserbotAccessError extends Error {
  constructor(code, asset) {
    super(`Akses kontrol userbot ditolak: ${code}`);
    this.name = 'UserbotAccessError';
    this.code = code;
    this.asset = asset || null;
  }
}

const enforcing = new Set();

/** Fire-and-forget persisted EXPIRED transition + runtime stop for a lapsed row (deduplicated). */
function enforceExpiryAsync(asset) {
  if (asset.status !== 'active' || subscription.isTrial(asset)) return;
  if (enforcing.has(asset.id)) return;
  enforcing.add(asset.id);
  try {
    require('./userbotLifecycle.service')
      .expireAndStop(asset.id, { notify: false })
      .catch((err) => logger.error(`Lazy expiry enforcement userbot #${asset.id} gagal: ${err.message}`))
      .finally(() => enforcing.delete(asset.id));
  } catch (err) {
    enforcing.delete(asset.id);
    logger.error(`Lazy expiry enforcement userbot #${asset.id} gagal: ${err.message}`);
  }
}

/**
 * @param {object} p
 * @param {number} p.userbotId  stable internal userbots.id
 * @param {number} p.actorId    Telegram id of whoever is acting
 * @param {boolean} [p.adminMode] actor is an admin controlling someone else's userbot via Admin Panel
 * @returns {{ok:true, asset:object}|{ok:false, code:string, asset:object|null}}
 */
function checkUserbotControlAccess({ userbotId, actorId, adminMode = false, kind = 'owned', nowMs = Date.now() }) {
  if (kind === 'pool') {
    const asset = userbotId ? poolRepo.findById(userbotId) : null;
    if (!asset) return { ok: false, code: CODE.NOT_FOUND, asset: null };
    if (!adminMode && Number(asset.assigned_user_id) !== Number(actorId)) return { ok: false, code: CODE.NOT_OWNER, asset };
    if (asset.status === 'disabled' || asset.status === 'reserved' || asset.status === 'available' && !adminMode) return { ok: false, code: CODE.NOT_ACTIVE, asset };
    // A missing session means runtime is unavailable; it must not erase a
    // valid ownership/lease from the control panel. Runtime operations call
    // userbotRuntime.withClient(), which re-checks the session and fails safely.
    if (asset.expires_at) {
      const t = new Date(asset.expires_at).getTime();
      if (!Number.isFinite(t) || t <= nowMs) return { ok: false, code: CODE.EXPIRED, asset };
    } else if (!adminMode) {
      return { ok: false, code: CODE.NOT_ACTIVE, asset };
    }
    return { ok: true, asset };
  }

  const asset = userbotId ? ownedRepo.findById(userbotId) : null;
  if (!asset) return { ok: false, code: CODE.NOT_FOUND, asset: null };
  if (!adminMode && Number(asset.user_id) !== Number(actorId)) return { ok: false, code: CODE.NOT_OWNER, asset };
  const state = subscription.getSubscriptionState(asset, nowMs);
  if (state === subscription.STATE.EXPIRED) {
    enforceExpiryAsync(asset);
    return { ok: false, code: CODE.EXPIRED, asset };
  }
  if (state === subscription.STATE.SUSPENDED) return { ok: false, code: CODE.SUSPENDED, asset };
  if (state !== subscription.STATE.ACTIVE) return { ok: false, code: CODE.NOT_ACTIVE, asset };
  return { ok: true, asset };
}

/** Throwing variant for service-layer callers. */
function assertUserbotControlAccess(params) {
  const res = checkUserbotControlAccess(params);
  if (!res.ok) throw new UserbotAccessError(res.code, res.asset);
  return res.asset;
}

module.exports = { CODE, UserbotAccessError, checkUserbotControlAccess, assertUserbotControlAccess };
