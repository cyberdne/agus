const repo = require('../database/repositories/settings.repository');

const KEYS = {
  START_STICKER_FILE_ID: 'start_sticker_file_id',
};

function getStartStickerFileId() {
  return repo.get(KEYS.START_STICKER_FILE_ID);
}

function setStartStickerFileId(fileId) {
  repo.set(KEYS.START_STICKER_FILE_ID, fileId);
}

function removeStartSticker() {
  repo.set(KEYS.START_STICKER_FILE_ID, '');
}

module.exports = { getStartStickerFileId, setStartStickerFileId, removeStartSticker };
