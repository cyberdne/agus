const { MESSAGE_EFFECT } = require('../constants/effects');

// Effects are rotated per user instead of always firing the same FIRE effect.
// This keeps the home screen lively while remaining deterministic for each
// process: every fresh home render advances to the next valid Bot API effect.
const MAIN_MENU_EFFECTS = MESSAGE_EFFECT.MAIN_MENU;

const positions = new Map();

function getNextMainMenuEffect(userId) {
  const key = String(userId);
  const current = positions.get(key) || 0;
  const effect = MAIN_MENU_EFFECTS[current % MAIN_MENU_EFFECTS.length];
  positions.set(key, (current + 1) % MAIN_MENU_EFFECTS.length);
  return effect;
}

module.exports = { MAIN_MENU_EFFECTS, getNextMainMenuEffect };
