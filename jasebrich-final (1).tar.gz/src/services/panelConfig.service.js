const fs = require('fs');
const path = require('path');
const { getDb } = require('../database');
const pmPermitState = require('../database/repositories/pmPermitState.repository');
const baseReplyCooldown = require('../database/repositories/baseReplyCooldown.repository');
const delayPolicy = require('./delayPolicy.service');

// Safe, widely-used defaults for userbot group broadcasting: fast enough to
// finish a round of groups in reasonable time, slow enough to stay well
// clear of Telegram's flood limits for MTProto userbot accounts. Used both
// as the schema-level default for brand-new panel_settings rows (see
// database/schema.js) AND as the "reset to recommended" target from the
// ⏱️ Atur Jeda wizards (panel.handler.js), so a user who never touches this
// screen at all still gets a safe cadence, and one who wants to go back to
// it later never has to remember the exact numbers.
const RECOMMENDED_GROUP_DELAY_SECONDS = delayPolicy.DEFAULT_GROUP_DELAY_SECONDS;
const DEFAULT_WTB_COOLDOWN_MINUTES = 3;
const MAX_WTB_COOLDOWN_MINUTES = 10080;
const RECOMMENDED_ROUND_DELAY_SECONDS = delayPolicy.DEFAULT_ROUND_DELAY_SECONDS;

function normalizeCooldownMinutes(value, fallback = DEFAULT_WTB_COOLDOWN_MINUTES) {
  const raw = String(value ?? '').trim();
  if (!/^\d+$/.test(raw)) return fallback;
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 1 || n > MAX_WTB_COOLDOWN_MINUTES) return fallback;
  return n;
}

function normalizeDelay(value, fallback, min, max) {
  const n=Number(value);
  if(!Number.isFinite(n) || !Number.isInteger(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function ensureSettings(userbotId) {
  getDb().prepare(`INSERT OR IGNORE INTO panel_settings (userbot_id) VALUES (?)`).run(userbotId);
  return getDb().prepare('SELECT * FROM panel_settings WHERE userbot_id = ?').get(userbotId);
}

function getSettings(userbotId) { return ensureSettings(userbotId); }

function updateSettings(userbotId, fields) {
  const cur = ensureSettings(userbotId);
  const currentGroupRange = delayPolicy.readGroupDelayRange(cur, RECOMMENDED_GROUP_DELAY_SECONDS);
  let nextGroupRange = currentGroupRange;

  if (fields.group_delay_range !== undefined) {
    const range = delayPolicy.normalizeGroupDelayRange(fields.group_delay_range?.min, fields.group_delay_range?.max);
    if (!range) throw new Error('Range jeda antar grup tidak valid.');
    nextGroupRange = range;
  } else if (fields.group_delay_min_seconds !== undefined || fields.group_delay_max_seconds !== undefined) {
    const min = fields.group_delay_min_seconds !== undefined ? fields.group_delay_min_seconds : currentGroupRange.min;
    const max = fields.group_delay_max_seconds !== undefined ? fields.group_delay_max_seconds : currentGroupRange.max;
    const range = delayPolicy.normalizeGroupDelayRange(min, max);
    if (!range) throw new Error('Range jeda antar grup tidak valid.');
    nextGroupRange = range;
  } else if (fields.group_delay_seconds !== undefined) {
    // Backward-compatible legacy callers: a single configured delay remains a
    // fixed range (min=max), never an accidental random range.
    const single = normalizeDelay(fields.group_delay_seconds, null, 0, delayPolicy.GROUP_DELAY_MAX_SECONDS);
    if (single === null) throw new Error('Jeda antar grup tidak valid.');
    nextGroupRange = { min: single, max: single };
  }

  const roundDelayValue = fields.round_delay_seconds !== undefined
    ? delayPolicy.normalizeRoundDelaySeconds(fields.round_delay_seconds)
    : delayPolicy.readRoundDelaySeconds(cur, RECOMMENDED_ROUND_DELAY_SECONDS);
  if (roundDelayValue === null) throw new Error('Jeda antar putaran tidak valid.');

  let cooldown = normalizeCooldownMinutes(cur.wtb_auto_reset_minutes, DEFAULT_WTB_COOLDOWN_MINUTES);
  if (fields.wtb_auto_reset_minutes !== undefined) {
    const raw = String(fields.wtb_auto_reset_minutes ?? '').trim();
    if (!/^\d+$/.test(raw)) throw new Error('Cooldown Base Reply harus bilangan bulat positif.');
    const parsed = Number(raw);
    if (!Number.isSafeInteger(parsed) || parsed < 1 || parsed > MAX_WTB_COOLDOWN_MINUTES) throw new Error(`Cooldown Base Reply harus 1-${MAX_WTB_COOLDOWN_MINUTES} menit.`);
    cooldown = parsed;
  }
  const next = {
    wtb_timer: fields.wtb_timer !== undefined ? fields.wtb_timer : cur.wtb_timer,
    wtb_auto_reset_minutes: cooldown,
    channel_disabled: fields.channel_disabled !== undefined ? (fields.channel_disabled ? 1 : 0) : cur.channel_disabled,
    wtb_target_channel: fields.wtb_target_channel !== undefined ? fields.wtb_target_channel : cur.wtb_target_channel,
    wtb_banned_words: fields.wtb_banned_words !== undefined ? String(fields.wtb_banned_words || '') : cur.wtb_banned_words,
    wtb_max_chars: fields.wtb_max_chars !== undefined ? Math.max(0, Number(fields.wtb_max_chars) || 0) : cur.wtb_max_chars,
    wtb_filter_links: fields.wtb_filter_links !== undefined ? (fields.wtb_filter_links ? 1 : 0) : cur.wtb_filter_links,
    wtb_filter_usernames: fields.wtb_filter_usernames !== undefined ? (fields.wtb_filter_usernames ? 1 : 0) : cur.wtb_filter_usernames,
    auto_react: fields.auto_react !== undefined ? (fields.auto_react ? 1 : 0) : cur.auto_react,
    auto_react_emoji: fields.auto_react_emoji !== undefined ? String(fields.auto_react_emoji || '❤️') : (cur.auto_react_emoji || '❤️'),
    group_delay_seconds: nextGroupRange.min,
    group_delay_max_seconds: nextGroupRange.max,
    round_delay_seconds: roundDelayValue,
  };
  getDb().prepare(`UPDATE panel_settings SET wtb_timer=?, wtb_auto_reset_minutes=?, channel_disabled=?, wtb_target_channel=?, wtb_banned_words=?, wtb_max_chars=?, wtb_filter_links=?, wtb_filter_usernames=?, auto_react=?, auto_react_emoji=?, group_delay_seconds=?, group_delay_max_seconds=?, round_delay_seconds=? WHERE userbot_id=?`)
    .run(next.wtb_timer, next.wtb_auto_reset_minutes, next.channel_disabled, next.wtb_target_channel, next.wtb_banned_words, next.wtb_max_chars, next.wtb_filter_links, next.wtb_filter_usernames, next.auto_react, next.auto_react_emoji, next.group_delay_seconds, next.group_delay_max_seconds, next.round_delay_seconds, userbotId);
  return ensureSettings(userbotId);
}

function getGroupDelayRange(userbotId) {
  return delayPolicy.readGroupDelayRange(ensureSettings(userbotId), RECOMMENDED_GROUP_DELAY_SECONDS);
}

function getRoundDelaySeconds(userbotId) {
  return delayPolicy.readRoundDelaySeconds(ensureSettings(userbotId), RECOMMENDED_ROUND_DELAY_SECONDS);
}

function listGroups(userbotId) {
  return getDb().prepare('SELECT * FROM panel_groups WHERE userbot_id = ? ORDER BY id ASC').all(userbotId);
}

// Paged read for large group configurations. Keep the existing listGroups()
// contract for callers that genuinely need the complete configuration, while
// UI list rendering uses bounded SQL reads so a large target set can never be
// materialized into one Telegram message.
function countGroups(userbotId) {
  return Number(getDb().prepare('SELECT COUNT(*) AS count FROM panel_groups WHERE userbot_id = ?').get(userbotId)?.count || 0);
}
function listGroupsPage(userbotId, offset, limit) {
  const safeOffset = Math.max(0, Number.isInteger(Number(offset)) ? Number(offset) : 0);
  const safeLimit = Math.max(1, Math.min(100, Number.isInteger(Number(limit)) ? Number(limit) : 10));
  return getDb().prepare('SELECT * FROM panel_groups WHERE userbot_id = ? ORDER BY id ASC LIMIT ? OFFSET ?').all(userbotId, safeLimit, safeOffset);
}
function addGroup(userbotId, target, title = null, topicId = null) {
  const normalized = String(target || '').trim();
  if (!normalized) throw new Error('Target grup kosong.');
  getDb().prepare(`INSERT INTO panel_groups (userbot_id,target,title,topic_id,enabled) VALUES (?,?,?,?,1)
    ON CONFLICT(userbot_id,target) DO UPDATE SET title=excluded.title, topic_id=excluded.topic_id, enabled=1`)
    .run(userbotId, normalized, title, topicId === null || topicId === '' ? null : Number(topicId));
  // Re-adding a target is an explicit user action: clear only that target's
  // previous health verdict so a formerly unusable chat is validated again.
  getDb().prepare('DELETE FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target=?')
    .run('owned', userbotId, normalized);
  return getDb().prepare('SELECT * FROM panel_groups WHERE userbot_id=? AND target=?').get(userbotId, normalized);
}
function deleteGroup(userbotId, targetOrId) {
  let target = null;
  if (/^\d+$/.test(String(targetOrId))) target = getDb().prepare('SELECT target FROM panel_groups WHERE userbot_id=? AND id=?').get(userbotId, Number(targetOrId))?.target || null;
  else target = String(targetOrId).trim();
  const changes = /^\d+$/.test(String(targetOrId))
    ? getDb().prepare('DELETE FROM panel_groups WHERE userbot_id=? AND id=?').run(userbotId, Number(targetOrId)).changes
    : getDb().prepare('DELETE FROM panel_groups WHERE userbot_id=? AND target=?').run(userbotId, String(targetOrId).trim()).changes;
  if (changes && target) getDb().prepare('DELETE FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target=?').run('owned', userbotId, String(target));
  return changes;
}
function updateGroupTopic(userbotId, target, topicId) {
  return getDb().prepare('UPDATE panel_groups SET topic_id=? WHERE userbot_id=? AND target=?').run(topicId === null ? null : Number(topicId), userbotId, String(target).trim()).changes;
}
// "🗑️ Hapus Semua" in Atur Grup -> Hapus Grup: deletes only this userbot's
// target-group rows. Scoped strictly to panel_groups so it never touches
// the userbot itself, its message/reply/settings config, or other assets.
function deleteAllGroups(userbotId) {
  return getDb().prepare('DELETE FROM panel_groups WHERE userbot_id=?').run(userbotId).changes;
}

function normalizeEntities(entities) {
  return Array.isArray(entities) ? entities.map((e) => ({ ...e })) : [];
}
function normalizeMessageKind(rawKind) {
  const value = String(rawKind || '').trim().toLowerCase();
  // `kind='forward'` is the canonical persisted identifier used by the
  // current setter. Case/whitespace normalization is intentionally the only
  // compatibility coercion here; text/media rows are never inferred from
  // Telegram metadata and unknown kinds remain unknown instead of being
  // silently converted into a different message type.
  if (value === 'forward') return 'forward';
  if (value === 'media') return 'media';
  if (value === 'text') return 'text';
  return value || null;
}

function parseStoredMessage(row) {
  if (!row) return null;
  return { ...row, kind: normalizeMessageKind(row.kind) };
}

function getMessage(userbotId) {
  const row = getDb().prepare('SELECT * FROM panel_messages WHERE userbot_id=?').get(userbotId);
  return parseStoredMessage(row);
}
function cleanupOldMediaIfUnreferenced(mediaPath) {
  if (!mediaPath) return;
  const row = getDb().prepare(`
    SELECT 1 FROM panel_messages WHERE media_path = ?
    UNION ALL
    SELECT 1 FROM broadcast_pm_messages WHERE media_path = ?
    LIMIT 1
  `).get(mediaPath, mediaPath);
  if (row) return;
  safeDeleteMedia(mediaPath);
}
function setTextMessage(userbotId, text, entities = []) {
  const previous = getMessage(userbotId);
  const json = JSON.stringify(normalizeEntities(entities));
  getDb().prepare(`INSERT INTO panel_messages (userbot_id,kind,text,media_path,media_type,source_chat_id,source_message_id,entities,caption_entities,file_name,updated_at)
    VALUES (?,'text',?,NULL,NULL,NULL,NULL,?,'[]',NULL,datetime('now'))
    ON CONFLICT(userbot_id) DO UPDATE SET kind='text',text=excluded.text,media_path=NULL,media_type=NULL,source_chat_id=NULL,source_message_id=NULL,entities=excluded.entities,caption_entities='[]',file_name=NULL,updated_at=datetime('now')`)
    .run(userbotId, text, json);
  getDb().prepare('UPDATE userbots SET broadcast_text=? WHERE id=?').run(String(text || ''), userbotId);
  cleanupOldMediaIfUnreferenced(previous?.media_path);
}
function setMediaMessage(userbotId, mediaPath, mediaType, caption = '', captionEntities = [], fileName = null) {
  const previous = getMessage(userbotId);
  const json = JSON.stringify(normalizeEntities(captionEntities));
  getDb().prepare(`INSERT INTO panel_messages (userbot_id,kind,text,media_path,media_type,source_chat_id,source_message_id,entities,caption_entities,file_name,updated_at)
    VALUES (?,'media',?, ?, ?, NULL,NULL,'[]',?,?,datetime('now'))
    ON CONFLICT(userbot_id) DO UPDATE SET kind='media',text=excluded.text,media_path=excluded.media_path,media_type=excluded.media_type,source_chat_id=NULL,source_message_id=NULL,entities='[]',caption_entities=excluded.caption_entities,file_name=excluded.file_name,updated_at=datetime('now')`)
    .run(userbotId, caption || '', mediaPath, mediaType, json, fileName);
  getDb().prepare('UPDATE userbots SET broadcast_text=NULL WHERE id=?').run(userbotId);
  if (previous?.media_path && previous.media_path !== mediaPath) cleanupOldMediaIfUnreferenced(previous.media_path);
}
function setForwardMessage(userbotId, sourceChatId, sourceMessageId, forwardKind = 'forward') {
  const previous = getMessage(userbotId);
  getDb().prepare(`INSERT INTO panel_messages (userbot_id,kind,text,media_path,media_type,source_chat_id,source_message_id,entities,caption_entities,file_name,updated_at)
    VALUES (?,'forward',NULL,NULL,NULL,?,?, '[]','[]',NULL,datetime('now'))
    ON CONFLICT(userbot_id) DO UPDATE SET kind='forward',text=NULL,media_path=NULL,media_type=NULL,source_chat_id=excluded.source_chat_id,source_message_id=excluded.source_message_id,entities='[]',caption_entities='[]',file_name=NULL,updated_at=datetime('now')`)
    .run(userbotId, String(sourceChatId), Number(sourceMessageId));
  cleanupOldMediaIfUnreferenced(previous?.media_path);
}
function clearMessage(userbotId) {
  const previous = getMessage(userbotId);
  getDb().prepare('DELETE FROM panel_messages WHERE userbot_id=?').run(userbotId);
  getDb().prepare('UPDATE userbots SET broadcast_text=NULL WHERE id=?').run(userbotId);
  cleanupOldMediaIfUnreferenced(previous?.media_path);
}


function setPmPermitMessage(userbotId, text, entities = []) {
  if (!String(text || '').trim()) throw new Error('Teks PM Permit tidak boleh kosong.');
  getDb().prepare(`INSERT INTO pm_permit_messages (userbot_id,text,entities,updated_at) VALUES (?,?,?,datetime('now'))
    ON CONFLICT(userbot_id) DO UPDATE SET text=excluded.text,entities=excluded.entities,updated_at=datetime('now')`)
    .run(userbotId, String(text), JSON.stringify(normalizeEntities(entities)));
}
function getPmPermitMessage(userbotId) {
  return getDb().prepare('SELECT * FROM pm_permit_messages WHERE userbot_id=?').get(userbotId);
}
function clearPmPermitMessage(userbotId) { getDb().prepare('DELETE FROM pm_permit_messages WHERE userbot_id=?').run(userbotId); }

function setBroadcastPmMessage(userbotId, data) {
  const previous = getBroadcastPmMessage(userbotId);
  const d={kind:data.kind||'text',text:data.text||null,entities:JSON.stringify(normalizeEntities(data.entities)),media_path:data.media_path||null,media_type:data.media_type||null,source_chat_id:data.source_chat_id==null?null:String(data.source_chat_id),source_message_id:data.source_message_id==null?null:Number(data.source_message_id),caption_entities:JSON.stringify(normalizeEntities(data.caption_entities)),file_name:data.file_name||null};
  getDb().prepare(`INSERT INTO broadcast_pm_messages (userbot_id,kind,text,entities,media_path,media_type,source_chat_id,source_message_id,caption_entities,file_name,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'))
    ON CONFLICT(userbot_id) DO UPDATE SET kind=excluded.kind,text=excluded.text,entities=excluded.entities,media_path=excluded.media_path,media_type=excluded.media_type,source_chat_id=excluded.source_chat_id,source_message_id=excluded.source_message_id,caption_entities=excluded.caption_entities,file_name=excluded.file_name,updated_at=datetime('now')`).run(userbotId,d.kind,d.text,d.entities,d.media_path,d.media_type,d.source_chat_id,d.source_message_id,d.caption_entities,d.file_name);
  if (previous?.media_path && previous.media_path !== d.media_path) cleanupOldMediaIfUnreferenced(previous.media_path);
}
function getBroadcastPmMessage(userbotId) { return getDb().prepare('SELECT * FROM broadcast_pm_messages WHERE userbot_id=?').get(userbotId); }
function clearBroadcastPmMessage(userbotId) {
  const previous = getBroadcastPmMessage(userbotId);
  getDb().prepare('DELETE FROM broadcast_pm_messages WHERE userbot_id=?').run(userbotId);
  cleanupOldMediaIfUnreferenced(previous?.media_path);
}

function listReplies(userbotId) { return getDb().prepare('SELECT * FROM panel_wtb_replies WHERE userbot_id=? ORDER BY id ASC').all(userbotId); }
// `entities` preserves whatever Telegram formatting/custom-emoji entities
// the admin's reply text carried (bold/italic/.../MessageEntityCustomEmoji),
// stored the same way panel_messages/pm_permit_messages already do. Optional
// and defaulted to '[]' so every existing call site that never passed
// entities keeps producing byte-identical rows/behavior.
function addReply(userbotId, keywords, response, entities = []) {
  const k = String(keywords || '').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean).join(',');
  if (!k || !response) throw new Error('Keyword dan balasan wajib diisi.');
  const json = JSON.stringify(normalizeEntities(entities));
  const r = getDb().prepare('INSERT INTO panel_wtb_replies (userbot_id,keywords,response,entities,enabled) VALUES (?,?,?,?,1)').run(userbotId,k,response,json);
  return getDb().prepare('SELECT * FROM panel_wtb_replies WHERE id=?').get(r.lastInsertRowid);
}
function deleteReply(userbotId, id) { return getDb().prepare('DELETE FROM panel_wtb_replies WHERE userbot_id=? AND id=?').run(userbotId,Number(id)).changes; }
function setReplyEnabled(userbotId, enabled) { getDb().prepare('UPDATE panel_wtb_replies SET enabled=? WHERE userbot_id=?').run(enabled?1:0,userbotId); }
function hasEnabledReply(userbotId) { return getDb().prepare('SELECT 1 FROM panel_wtb_replies WHERE userbot_id=? AND enabled=1 LIMIT 1').get(userbotId) !== undefined; }
function resetAll(userbotId) {
  const db=getDb();
  const previousMedia = [
    getMessage(userbotId)?.media_path,
    getBroadcastPmMessage(userbotId)?.media_path,
  ].filter(Boolean);
  const tx=db.transaction(()=>{
    db.prepare('DELETE FROM panel_groups WHERE userbot_id=?').run(userbotId);
    db.prepare('DELETE FROM panel_messages WHERE userbot_id=?').run(userbotId);
    db.prepare('DELETE FROM panel_wtb_replies WHERE userbot_id=?').run(userbotId);
    db.prepare('DELETE FROM pm_permit_messages WHERE userbot_id=?').run(userbotId);
    db.prepare('DELETE FROM base_reply_cooldowns WHERE owner_id=?').run(userbotId);
    db.prepare('DELETE FROM userbot_promotion_target_health WHERE owner_id=?').run(userbotId);
    db.prepare('DELETE FROM userbot_runtime_jobs WHERE owner_id=?').run(userbotId);
    db.prepare('DELETE FROM broadcast_pm_messages WHERE userbot_id=?').run(userbotId);
    db.prepare('DELETE FROM panel_settings WHERE userbot_id=?').run(userbotId);
  });
  tx();
  // resetAll() is called with just a userbotId (no kind), and the row id
  // space for 'owned' userbots and 'pool' userbots is independent, so
  // clear PM Permit interaction state for both — a no-op for whichever
  // kind this id doesn't actually belong to.
  pmPermitState.clearForOwner('owned', userbotId);
  pmPermitState.clearForOwner('pool', userbotId);
  baseReplyCooldown.clearForOwner('owned', userbotId);
  baseReplyCooldown.clearForOwner('pool', userbotId);
  for (const mediaPath of previousMedia) cleanupOldMediaIfUnreferenced(mediaPath);
}

function safeDeleteMedia(mediaPath) {
  if (!mediaPath) return;
  try {
    const root = path.resolve(process.cwd(), 'data', 'panel_media');
    const resolved = path.resolve(String(mediaPath));
    if (resolved !== root && !resolved.startsWith(`${root}${path.sep}`)) return;
    if (fs.existsSync(resolved)) fs.unlinkSync(resolved);
  } catch (_) {}
}

function cleanupOrphanMedia() {
  const root = path.resolve(process.cwd(), 'data', 'panel_media');
  if (!fs.existsSync(root)) return 0;
  const referenced = new Set();
  for (const row of getDb().prepare('SELECT media_path FROM panel_messages WHERE media_path IS NOT NULL').all()) {
    if (row.media_path) referenced.add(path.resolve(String(row.media_path)));
  }
  for (const row of getDb().prepare('SELECT media_path FROM broadcast_pm_messages WHERE media_path IS NOT NULL').all()) {
    if (row.media_path) referenced.add(path.resolve(String(row.media_path)));
  }
  let removed = 0;
  for (const name of fs.readdirSync(root)) {
    const resolved = path.resolve(root, name);
    if (resolved === root || !resolved.startsWith(`${root}${path.sep}`)) continue;
    try {
      const stat = fs.statSync(resolved);
      if (!stat.isFile()) continue;
      if (!referenced.has(resolved)) { fs.unlinkSync(resolved); removed += 1; }
    } catch (_) {}
  }
  return removed;
}

module.exports = { getSettings, updateSettings, listGroups, countGroups, listGroupsPage, addGroup, deleteGroup, deleteAllGroups, updateGroupTopic,
  RECOMMENDED_GROUP_DELAY_SECONDS, RECOMMENDED_ROUND_DELAY_SECONDS, DEFAULT_WTB_COOLDOWN_MINUTES, MAX_WTB_COOLDOWN_MINUTES, getGroupDelayRange, getRoundDelaySeconds, delayPolicy,
  getMessage, setTextMessage, setMediaMessage, setForwardMessage, clearMessage, cleanupOrphanMedia,
  listReplies, addReply, deleteReply, setReplyEnabled, hasEnabledReply, resetAll, safeDeleteMedia,
  setPmPermitMessage, getPmPermitMessage, clearPmPermitMessage, setBroadcastPmMessage, getBroadcastPmMessage, clearBroadcastPmMessage };
