const poolRepo = require('../database/repositories/userbotPool.repository');
const ownedRepo = require('../database/repositories/ownedUserbot.repository');
const orderRepo = require('../database/repositories/order.repository');
const userbotRuntime = require('./userbotRuntime.service');
const logger = require('../utils/logger');
const userRepository = require('../database/repositories/user.repository');
const orderRepository = require('../database/repositories/order.repository');
const subscription = require('./subscription.service');
const backupToken = require('./backupToken.service');
const codec = require('../utils/tokenCodec');
const { getDb } = require('../database');
const { defineSubmenu, buildReplyOptions } = require('./custom-submenu.service');

const activationSubmenu = defineSubmenu(
  'userbot_activation_success',
  '🎉 Userbot Berhasil Diaktifkan',
  '🎉 <b>Userbot Berhasil Diaktifkan!</b>\n\n' +
    '👤 <b>Akun:</b> {akun}\n' +
    '🔗 <b>Username:</b> {userbot_username}\n' +
    '🆔 <b>ID Userbot:</b> <code>{telegram_userbot_id}</code>\n' +
    '📱 <b>Nomor:</b> {userbot_nomor}\n' +
    '📦 <b>Produk:</b> {userbot_produk}\n' +
    '🧾 <b>Order:</b> {userbot_order}\n' +
    '📌 <b>Status:</b> AKTIF\n' +
    '⏳ <b>Berlaku sampai:</b> {expired_at}\n' +
    '⏱️ <b>Sisa masa aktif:</b> {expired}\n\n' +
    '🔑 <b>Token Garansi Anda:</b>\n<code>{token_garansi}</code>\n\n' +
    '📌 Pesan ini disematkan sebagai bukti aktivasi. Simpan token ini baik-baik.\n' +
    'Ketik /start untuk kembali ke menu utama.',
  'HTML',
  { feature: 'Userbot', supportedPlaceholders: ['akun', 'userbot_username', 'telegram_userbot_id', 'userbot_nomor', 'userbot_produk', 'userbot_order', 'expired_at', 'expired', 'token_garansi'] }
);

/**
 * Generates a token string (crypto.randomBytes, see utils/tokenCodec.js).
 * Owned-userbot Backup Tokens are issued/rotated ONLY through
 * services/backupToken.service.js (hash stored, plaintext shown once). This
 * plaintext generator remains for leased pool userbots (userbot_pool.token).
 */
function generateToken(prefix = 'JASEB') {
  return codec.generate(prefix);
}

function addDays(days) {
  const d = new Date();
  d.setDate(d.getDate() + Number(days || 0));
  return d.toISOString();
}

function addHours(hours) {
  const d = new Date();
  d.setTime(d.getTime() + Number(hours || 0) * 60 * 60 * 1000);
  return d.toISOString();
}

/** "Beli Jaseb": lease one available pool userbot to the buyer for the order's duration. */
function assignPoolToBuyer(order) {
  const expiresAt = addDays(order.duration_days);
  const reserved = poolRepo.findReservedByOrder(order.id);
  if (reserved) {
    const token = generateToken('JASEB');
    return poolRepo.assignReservedToBuyer(order.id, { userId: order.user_id, expiresAt, token });
  }
  // Legacy orders created before reservation support: retain the existing
  // atomic CAS assignment path. New orders never use this fallback.
  for (const pick of poolRepo.listAvailableForPurchase()) {
    const token = generateToken('JASEB');
    const assigned = poolRepo.assign(pick.id, { userId: order.user_id, orderId: order.id, expiresAt, token });
    if (assigned) return assigned;
  }
  return null;
}

/** "Beli Userbot": create the pending record before the phone/OTP login flow starts. */
function createOwnedPending(order) {
  const expiresAt = order.duration_days ? addDays(order.duration_days) : null;
  return ownedRepo.create({ userId: order.user_id, label: order.product_name, phone: null, orderId: order.id, expiresAt });
}

function updateOwnedUserbotPhone(userbotId, phone) {
  const updated = ownedRepo.updatePhone(userbotId, phone);
  if (!updated) throw new Error(`Userbot #${userbotId} tidak ditemukan saat memperbarui nomor telepon.`);
  return updated;
}

/**
 * "🔄 Perpanjang Langganan" fulfilment: extends the owned userbot the buyer
 * chose (orders.target_userbot_id) through the single subscription service,
 * so it gets the same guarantees as an admin extension:
 *   - still valid  -> new expiry = current expiry + paid duration
 *   - already over -> new expiry = now + paid duration (no double time)
 *   - one atomic DB transaction (expiry + status + audit + order fulfilment)
 *   - idempotent per order (operation id `order:<id>`): confirming the same
 *     order twice can never extend twice.
 * Works for EXPIRED userbots too (renewal is how they come back), and never
 * guesses: with several userbots and no recorded target it refuses instead
 * of picking one.
 *
 * Returns { ok: true, userbot, duplicate } or { ok: false, reason } where
 * reason is 'no_active_userbot' | 'target_not_renewable' | 'ambiguous_target'.
 */
function renewOwnedUserbot(order, processingClaimToken = null) {
  const rows = subscription.listRenewable(order.user_id);
  let target = null;
  if (order.target_userbot_id) {
    target = rows.find((r) => r.id === Number(order.target_userbot_id)) || null;
    if (!target) return { ok: false, reason: 'target_not_renewable' };
  } else if (rows.length === 1) {
    target = rows[0];
  } else if (rows.length === 0) {
    return { ok: false, reason: 'no_active_userbot' };
  } else {
    return { ok: false, reason: 'ambiguous_target' };
  }

  const run = getDb().transaction(() => {
    const result = subscription.extend({
      userbotId: target.id,
      days: Number(order.duration_days),
      operationId: `order:${order.id}`,
      action: 'order_renewal',
      orderId: order.id,
      ownerUserId: order.user_id,
    });
    const fulfilled = orderRepo.setFulfillment(order.id, target.id, processingClaimToken);
    if (processingClaimToken && !fulfilled) {
      throw new Error(`Order #${order.id} processing claim lost before renewal commit`);
    }
    return result;
  });
  const result = run();
  return { ok: true, userbot: result.row, duplicate: result.duplicate };
}

/** "Claim Trial": same shape as createOwnedPending, but free (no order) and one-time per user. */
function createTrialOwned({ userId, durationHours }) {
  // The reference flow activates the trial immediately after the first
  // agreement, so its duration is counted from that point.
  const expiresAt = addHours(durationHours);
  return ownedRepo.create({ userId, label: '🎁 Trial Userbot', phone: null, orderId: null, expiresAt });
}

/**
 * A trial row this user already started (pending_otp = agreed but hasn't
 * finished phone/OTP login yet; active = already usable) that is not yet
 * expired. Used to make re-tapping "⭐ Setuju Trial" resume the SAME row
 * instead of creating a second one, now that trial_claimed_at is only set
 * on successful activation (see activateOwned()) rather than at the first
 * tap — see audit.txt finding #6 for why that changed.
 */
function findOwnTrialInProgress(userId) {
  return ownedRepo
    .listByUser(userId)
    .find((row) => subscription.isTrial(row) && ['pending_otp', 'active'].includes(row.status) && !subscription.isExpiredAt(row.expires_at))
    || null;
}

/**
 * Activates a pending owned userbot and issues its Backup Token. Only the hash
 * is persisted; the returned object carries the plaintext `token` ONE time, for
 * the activation receipt (it is not readable from the database afterwards).
 */
function activateOwned(id, { sessionString, telegramUserbotId, expiresAt, tokenPrefix = 'JASEB' }) {
  const issued = backupToken.activateWithNewToken(id, { sessionString, telegramUserbotId, expiresAt, prefix: tokenPrefix });
  if (!issued) return null;
  const { row, token } = issued;
  if (row && row.order_id) orderRepo.setFulfillment(row.order_id, row.id);
  // Free trial's "used 1x seumur hidup" flag is set HERE — on confirmed,
  // successful activation — and nowhere earlier. Previously it was set the
  // moment the user tapped "Setuju Trial", before they had even entered a
  // phone number; if phone/OTP/2FA then failed or was abandoned within the
  // pending window, the user permanently lost their one-time trial without
  // ever receiving a working userbot (audit.txt finding #6). Marking it
  // only on success means an incomplete attempt can always be retried from
  // "🎁 Coba Gratis" with no manual admin intervention needed.
  if (row && subscription.isTrial(row)) userRepository.markTrialClaimed(row.user_id);
  return { ...row, token };
}

function getTrialExpiresAt(durationHours) {
  return addHours(durationHours);
}

/**
 * Scheduler sweep: stop the old Telegram runtime FIRST, then conditionally
 * return the exact expired lease to stock. Returning stock before teardown
 * creates a real reuse race: another buyer can be assigned the row while the
 * previous GramJS client is still alive and can still send messages.
 */
async function sweepExpiredPool() {
  const expired = poolRepo.listExpired(new Date().toISOString());
  const returned = [];
  for (const row of expired) {
    const notifyUserId = row.assigned_user_id;
    try {
      await userbotRuntime.teardownAsset('pool', row.id);
    } catch (err) {
      logger.error(`Gagal hentikan runtime pool #${row.id}: ${err.message}`);
      continue; // keep the lease assigned so a later tick can retry safely
    }

    const fresh = poolRepo.findById(row.id);
    if (!fresh || fresh.status !== 'assigned' || !fresh.expires_at) continue;
    const nowIso = new Date().toISOString();
    const stillExpired = new Date(fresh.expires_at).getTime() <= Date.now();
    if (!stillExpired) continue;

    const released = poolRepo.returnExpiredToPool(row.id, fresh.expires_at, nowIso);
    if (!released) continue; // lease changed/reclaimed while teardown was running

    returned.push({ label: fresh.label, notifyUserId });
    logger.info(`Userbot pool #${row.id} (${fresh.label}) expired, returned to stock`);
  }
  return returned;
}

/**
 * Trials are deleted on expiry, but the running Telegram client must be torn
 * down before the row disappears. Otherwise a stale client can survive long
 * enough to send into a newly-created asset that reuses the same logical
 * userbot slot. The DB delete remains atomic with token retirement and only
 * happens after teardown succeeds.
 */
async function sweepExpiredTrials() {
  const expired = ownedRepo.listExpiredTrials(new Date().toISOString());
  const results = [];

  for (const row of expired) {
    try {
      await userbotRuntime.teardownAsset('owned', row.id);
    } catch (err) {
      logger.error(`Gagal hentikan runtime trial #${row.id}: ${err.message}`);
      continue;
    }

    const fresh = ownedRepo.findById(row.id);
    if (!fresh || !subscription.isTrial(fresh) || !subscription.isExpiredAt(fresh.expires_at)) continue;

    // Same transaction: the trial's Backup Token is retired as "expired" so it
    // keeps reporting the true reason after the row is gone.
    getDb().transaction(() => {
      backupToken.retireOnRemoval(fresh, backupToken.RETIRE_REASON.EXPIRED);
      ownedRepo.deleteById(fresh.id);
    })();

    results.push({
      id: fresh.id,
      userId: fresh.user_id,
      wasActive: fresh.status === 'active',
      label: fresh.label || '🎁 Trial Userbot',
    });
    logger.info(`Trial userbot #${fresh.id} expired for user ${fresh.user_id}`);
  }

  return results;
}

function hasControllablePanelAsset(telegramId, nowMs = Date.now()) {
  // Visibility/access to the control panel is determined by persisted
  // ownership/entitlement, not by runtime liveness. Runtime operations that
  // need GramJS still require a live session in userbotRuntime.withClient().
  const renewableOwned = subscription.listRenewable(telegramId);
  const ownedEligible = renewableOwned.some((row) => {
    // Control access requires a currently valid entitlement. Expired rows
    // remain in storage for renewal/history, but must never make the control
    // panel appear or grant runtime control.
    return subscription.getSubscriptionState(row, nowMs) === subscription.STATE.ACTIVE;
  });
  const leasedEligible = poolRepo.listAssignedToUser(telegramId).some((row) => {
    if (row.status !== 'assigned' || !row.expires_at) return false;
    const t = new Date(row.expires_at).getTime();
    return Number.isFinite(t) && t > nowMs;
  });
  return ownedEligible || leasedEligible;
}
function getAvailableJasebStockCount() {
  return Number(poolRepo.countAvailableForPurchase() || 0);
}

function normalizePackageLabel(value, fallback) {
  let label = String(value || '').trim();
  // Remove decorative leading emoji/symbols only; the actual configured/package
  // name remains the source of truth and is never replaced by a hardcoded plan.
  label = label.replace(/^(?:[\p{Extended_Pictographic}\uFE0F\u200D]|[•·|:/\-])+\s*/u, '').trim();
  label = label.replace(/^🎁\s*/u, '');
  if (/^trial(?:\s+userbot)?$/iu.test(label)) return 'Trial';
  return label || fallback;
}

function packageLabelForAsset(kind, row) {
  if (!row) return kind === 'pool' ? 'Jaseb' : 'Userbot';
  if (String(row.label || '').trim().replace(/^[^A-Za-z0-9]+/u, '').toLowerCase() === 'trial userbot') return 'Trial';
  const orderId = kind === 'owned' ? row.order_id : row.assigned_order_id;
  if (orderId != null) {
    try {
      const order = orderRepository.findById(orderId);
      if (order && order.product_name) return normalizePackageLabel(order.product_name, kind === 'pool' ? 'Jaseb' : 'Userbot');
    } catch (err) {
      logger.warn(`Gagal membaca nama paket order #${orderId} untuk userbot #${row.id}: ${err.message}`);
    }
  }
  return normalizePackageLabel(row.label, kind === 'pool' ? 'Jaseb' : 'Userbot');
}

function withPackageLabel(kind, row) {
  return row ? { ...row, package_name: packageLabelForAsset(kind, row) } : row;
}

function getUserAssets(telegramId) {
  const owned = ownedRepo.listByUser(telegramId).filter((r) => r.status !== 'revoked').map((r) => withPackageLabel('owned', r));
  const leased = poolRepo.listAssignedToUser(telegramId).map((r) => withPackageLabel('pool', r));
  return { owned, leased };
}

/** Every plaintext Token Garansi still readable for the user. Owned-userbot Backup Tokens are hash-only, so this yields leased pool tokens only. */
function getUserTokens(telegramId) {
  const assets = getUserAssets(telegramId);
  const owned = assets.owned
    .filter((a) => a.status === 'active' && a.token)
    .map((a) => ({ kind: 'owned', id: a.id, label: a.label || 'Userbot', token: a.token }));
  const leased = assets.leased
    .filter((a) => a.token)
    .map((a) => ({ kind: 'pool', id: a.id, label: a.label || 'Jaseb', token: a.token }));
  return [...owned, ...leased];
}

/**
 * "🎫 Klaim Token" -> Klaim Akses via Token: recovers the userbot a token is
 * bound to. Owned-userbot tokens are handled entirely by the canonical
 * services/backupToken.service.js (ownership, entitlement/expiry, trial vs
 * purchased, rotation) — this function only adds the leased-pool fallback and
 * the runtime reconciliation.
 *
 * Owned userbot outcomes:
 *   { ok:true, kind:'owned', action:'reauth', userbotId, label }
 *        session lost -> caller starts the EXISTING phone/OTP re-auth wizard
 *        for that same userbot; nothing is created here
 *   { ok:true, kind:'owned', action:'reactivated', label, newToken }
 *        admin-revoked userbot restored within its active period (existing
 *        Garansi Akses); the used token is replaced by `newToken`
 * Leased pool userbot (unchanged): { ok:true, kind:'pool', label }
 *
 * Failure: { ok:false, reason } with reason one of
 *   'not_found' | 'not_owner' | 'already_active' | 'rotated' | 'revoked' |
 *   'expired' | 'not_recoverable' | 'rate_limited'
 */
function claimToken(telegramId, rawCode) {
  const code = String(rawCode || '').trim();
  if (!code) return { ok: false, reason: 'not_found' };
  if (backupToken.isRateLimited(telegramId)) return { ok: false, reason: 'rate_limited' };

  const owned = backupToken.claimOwned({ actorId: telegramId, rawCode: code });
  if (owned.handled) {
    if (!owned.ok) return { ok: false, reason: owned.reason, ...(owned.trial ? { trial: true } : {}) };
    if (owned.action === 'reactivated') {
      userbotRuntime.syncAsset('owned', owned.userbotId).catch((err) =>
        logger.error(`Gagal sinkronisasi runtime setelah klaim token owned #${owned.userbotId}: ${err.message}`)
      );
      return { ok: true, kind: 'owned', action: 'reactivated', label: owned.label, newToken: owned.newToken };
    }
    return { ok: true, kind: 'owned', action: 'reauth', userbotId: owned.userbotId, label: owned.label, trial: owned.trial, expiresAt: owned.expiresAt };
  }

  const leased = poolRepo.findByToken(code);
  if (leased) {
    if (leased.assigned_user_id !== telegramId) {
      backupToken.noteFailure(telegramId);
      return { ok: false, reason: 'not_owner' };
    }
    if (leased.status !== 'disabled') return { ok: false, reason: 'already_active' };
    if (!leased.expires_at || new Date(leased.expires_at).getTime() <= Date.now()) {
      backupToken.noteFailure(telegramId);
      return { ok: false, reason: 'expired' };
    }
    poolRepo.reactivate(leased.id);
    userbotRuntime.syncAsset('pool', leased.id).catch((err) =>
      logger.error(`Gagal sinkronisasi runtime setelah klaim token pool #${leased.id}: ${err.message}`)
    );
    return { ok: true, kind: 'pool', label: leased.label || 'Jaseb' };
  }

  backupToken.noteFailure(telegramId);
  return { ok: false, reason: 'not_found' };
}

async function sendPinnedActivationMessage(telegram, chatId, {
  name,
  id,
  token,
  phone = null,
  username = null,
  expiresAt = null,
  orderId = null,
  productName = null,
  activatedAt = null,
  status = 'active',
}) {
  const storedUser = userRepository.findByTelegramId(chatId) || {};
  const userCtx = {
    from: {
      id: chatId,
      first_name: storedUser.first_name || undefined,
      last_name: storedUser.last_name || undefined,
      username: storedUser.username || undefined,
    },
    chat: { id: chatId },
  };
  const activationData = {
    userbot: {
      id: null,
      telegram_userbot_id: id,
      account_name: name || 'Akun Telegram',
      username: username || null,
      phone: phone || null,
      label: productName || 'Userbot',
      product_name: productName || 'Userbot',
      order_id: orderId || null,
      status,
      expires_at: expiresAt || null,
      activated_at: activatedAt || new Date().toISOString(),
      token: token || '-',
    },
  };
  const content = activationSubmenu.getContent(userCtx, activationData);
  const sent = await telegram.sendMessage(chatId, content.text, buildReplyOptions(content));
  try {
    await telegram.pinChatMessage(chatId, sent.message_id, { disable_notification: true });
  } catch (err) {
    logger.warn(`Failed to pin activation message in chat ${chatId}: ${(err && err.message) || err}`);
  }
  return sent;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatIndonesiaDate(value) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    dateStyle: 'long',
    timeStyle: 'short',
  }).format(d) + ' WIB';
}

module.exports = {
  generateToken,
  assignPoolToBuyer,
  createOwnedPending,
  updateOwnedUserbotPhone,
  renewOwnedUserbot,
  createTrialOwned,
  findOwnTrialInProgress,
  activateOwned,
  getTrialExpiresAt,
  sweepExpiredPool,
  sweepExpiredTrials,
  getUserAssets,
  hasControllablePanelAsset,
  getAvailableJasebStockCount,
  getUserTokens,
  claimToken,
  sendPinnedActivationMessage,
  activationSubmenu,
};
