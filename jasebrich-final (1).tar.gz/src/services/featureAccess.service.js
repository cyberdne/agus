/**
 * Feature entitlement — shared abstraction for BOTH product-based
 * (purchased userbot) and trial-based (free trial userbot) access.
 *
 * PRODUCT entitlement source of truth: products.feature_access (JSON array
 * of feature ids from FEATURE_REGISTRY below, see database/schema.js). An
 * owned userbot's entitlement is resolved live from the product that its
 * originating order points at (userbots.order_id -> orders.product_id ->
 * products.id) — NOT a snapshot taken at purchase time — so editing a
 * product's checklist in Product Management takes effect immediately for
 * every buyer of that product, per the "Perubahan harus langsung
 * tersinkron" requirement.
 *
 * TRIAL entitlement source of truth: settings row `trial_feature_access`
 * (same settings key/value repository trialConfig.service.js already uses
 * for `trial_duration_hours`), storing the SAME JSON-array-of-registry-id
 * shape as a product's feature_access — there is deliberately only ONE
 * feature registry and ONE parse/serialize/validate implementation for
 * both. See getTrialFeatureAccess/setTrialFeatureAccess/
 * resetTrialFeatureAccess below.
 *
 * Backward compatibility (do not reduce existing functionality): a product
 * whose feature_access is NULL — i.e. every product that existed before
 * this feature shipped, and any new product an admin never opened the
 * checklist for — is UNRESTRICTED (every feature allowed). Restriction only
 * ever starts once an admin explicitly saves a checklist for that product.
 * The exact same NULL-is-unrestricted semantics apply to
 * `trial_feature_access`: every trial userbot created before this feature
 * shipped (and any trial created while the admin has never opened/saved
 * Akses Fitur Trial) stays unrestricted. Restriction only ever starts once
 * an admin explicitly saves a checklist — an explicit empty checklist ([])
 * is a deliberate "no feature" choice and is never conflated with NULL.
 *
 * Legacy rows with no order relationship retain the unrestricted fallback.
 * An asset that claims to be purchase-backed but cannot resolve its
 * order/product chain fails CLOSED instead of becoming an implicit grant.
 * Product removal is implemented as a soft retirement so normal catalog
 * maintenance never severs the entitlement chain.
 */
const orderRepo = require('../database/repositories/order.repository');
const productService = require('./product.service');
const settingsRepo = require('../database/repositories/settings.repository');
const subscriptionService = require('./subscription.service');
const poolRepo = require('../database/repositories/userbotPool.repository');

const TRIAL_FEATURE_ACCESS_KEY = 'trial_feature_access';

// Stable feature identifiers. These map 1:1 onto real Kontrol Panel
// capability groups in handlers/panel.handler.js — not UI labels, so
// renaming a button never breaks a saved entitlement. Add new entries
// here (and gate the corresponding handler with requireFeature) whenever
// a new real capability is added; never invent one that has no handler.
const FEATURE_REGISTRY = [
  { id: 'auto_promosi', label: '🚀 Auto Promosi (Mulai/Stop)' },
  { id: 'base_reply', label: '💬 Base Reply (WTB Reply & Auto Balas)' },
  { id: 'message_settings', label: '📝 Atur Pesan' },
  { id: 'group_settings', label: '👥 Atur Grup' },
  { id: 'delay_settings', label: '⏱️ Atur Jeda' },
  { id: 'broadcast_pm', label: '📄 Broadcast PM' },
  { id: 'pm_permit', label: '🛡️ PM Permit' },
  { id: 'custom_wm', label: '⭐ Custom Watermark' },
  { id: 'timer', label: '⏰ Timer Jam Aktif' },
  { id: 'transfer_ubot', label: '🔄 Transfer Userbot' },
  { id: 'reset_data', label: '🗑️ Reset Data' },
];

const FEATURE_IDS = new Set(FEATURE_REGISTRY.map((f) => f.id));
const FEATURE_LABEL = Object.fromEntries(FEATURE_REGISTRY.map((f) => [f.id, f.label]));

function listFeatures() {
  return FEATURE_REGISTRY;
}

function isValidFeatureId(id) {
  return FEATURE_IDS.has(id);
}

/**
 * Parse a raw stored feature-access value (a products.feature_access column
 * value, or the `trial_feature_access` settings value) into null (= not
 * configured / explicitly reset -> unrestricted) or a clean array of valid
 * FEATURE_REGISTRY ids. Never trusts anything but FEATURE_REGISTRY ids —
 * unknown/stale ids from an old registry shape are silently dropped instead
 * of being treated as grantable. Malformed/invalid JSON fails CLOSED to an
 * empty checklist (`[]`) rather than granting unrestricted access. This makes
 * corrupted entitlement data fail safely and predictably.
 */
function parseFeatureAccessValue(raw) {
  if (raw === null || raw === undefined || raw === '') return null;
  let arr;
  try {
    arr = JSON.parse(raw);
  } catch (_) {
    return [];
  }
  if (arr === null) return null;
  if (!Array.isArray(arr)) return [];
  const clean = arr.filter((id) => isValidFeatureId(id));
  return clean;
}

/** Parse a product row's feature_access column. See parseFeatureAccessValue. */
function parseFeatureAccess(product) {
  if (!product) return null;
  return parseFeatureAccessValue(product.feature_access);
}

/** Serialize a checklist (array of feature ids) for storage. Invalid ids are
 * dropped defensively — the UI only ever offers valid ids, but this is the
 * real backend boundary so a manipulated/forged value can't smuggle one in. */
function serializeFeatureAccess(featureIds) {
  if (!Array.isArray(featureIds)) return null;
  const clean = featureIds.filter((id) => isValidFeatureId(id));
  return JSON.stringify(clean);
}

/**
 * Resolve the product that entitles a given OWNED userbot row, following
 * the real purchase chain: userbots.order_id -> orders.product_id ->
 * products.id. Returns null if unresolvable (trial, legacy row with no
 * order_id, or a corrupted/missing order/product chain).
 */
function resolveProductForOwnedAsset(asset) {
  if (!asset || !asset.order_id) return null;
  const order = orderRepo.findById(asset.order_id);
  if (!order || !order.product_id) return null;
  return productService.getById(order.product_id);
}

/**
 * Trial identification — reuses the SAME real identifier subscription.service
 * already uses to tell a free-trial userbot apart from anything else
 * (label === '🎁 Trial Userbot' AND no order_id). Deliberately NOT
 * `product === null` alone (see module doc: a legacy row or a row whose
 * order's product was deleted also resolves to a null product and must
 * keep the pre-existing unrestricted fallback, not trial rules).
 */
function isTrialAsset(asset) {
  return subscriptionService.isTrial(asset);
}

/** Read the persisted Trial Feature Access checklist. null = unrestricted. */
function getTrialFeatureAccess() {
  return parseFeatureAccessValue(settingsRepo.get(TRIAL_FEATURE_ACCESS_KEY));
}

/**
 * Persist the Trial Feature Access checklist. Never trusts the caller:
 * invalid/unknown feature ids are dropped, exactly like product checklists.
 * An empty array is stored as an explicit "no feature" ([]), never coerced
 * into "unrestricted" — see resetTrialFeatureAccess() for that.
 */
function setTrialFeatureAccess(featureIds) {
  const json = serializeFeatureAccess(Array.isArray(featureIds) ? featureIds : []);
  settingsRepo.set(TRIAL_FEATURE_ACCESS_KEY, json);
  return parseFeatureAccessValue(json);
}

/** Explicitly restore "🔓 Semua fitur" (NULL), distinct from an empty checklist. */
function resetTrialFeatureAccess() {
  settingsRepo.set(TRIAL_FEATURE_ACCESS_KEY, JSON.stringify(null));
  return null;
}

/**
 * @returns {{allowed:boolean, restricted:boolean, product:object|null}}
 *   restricted=false means the effective config (product, trial, or lack of
 *   either) is unrestricted — allowed is always true in that case.
 *   restricted=true means a checklist IS configured and allowed reflects
 *   whether featureId is in it. `product` is always null for a trial asset.
 *
 * Resolution order (see module doc for the full rationale):
 *   1. TRIAL asset       -> live Trial Feature Access config
 *   2. resolvable PRODUCT -> that product's Feature Access config
 *   3. legacy row with no order_id -> unrestricted
 *   4. purchase-backed row with an unresolved entitlement -> fail closed
 */
function resolveProductForPoolAsset(asset) {
  if (!asset || !asset.assigned_order_id) return null;
  const order = orderRepo.findById(asset.assigned_order_id);
  if (!order || !order.product_id) return null;
  return productService.getById(order.product_id);
}

function checkAssetFeature(asset, featureId, kind = 'owned') {
  if (kind === 'pool') {
    const live = asset && asset.id ? poolRepo.findById(asset.id) : null;
    if (!live) return { allowed:false, restricted:false, product:null, reason:'not_found' };
    if (!live.assigned_order_id) return { allowed:true, restricted:false, product:null };
    const product = resolveProductForPoolAsset(live);
    if (!product) return { allowed:false, restricted:true, product:null, reason:'entitlement_unresolved' };
    const configured = parseFeatureAccess(product);
    if (configured === null) return { allowed:true, restricted:false, product };
    return { allowed:configured.includes(featureId), restricted:true, product };
  }
  return checkOwnedAssetFeature(asset, featureId);
}

function checkOwnedAssetFeature(asset, featureId) {
  if (isTrialAsset(asset)) {
    const configured = getTrialFeatureAccess();
    if (configured === null) return { allowed: true, restricted: false, product: null };
    return { allowed: configured.includes(featureId), restricted: true, product: null };
  }
  const product = resolveProductForOwnedAsset(asset);
  if (asset && asset.order_id && !product) {
    return { allowed:false, restricted:true, product:null, reason:'entitlement_unresolved' };
  }
  const configured = parseFeatureAccess(product);
  if (configured === null) return { allowed: true, restricted: false, product };
  return { allowed: configured.includes(featureId), restricted: true, product };
}

module.exports = {
  FEATURE_REGISTRY,
  FEATURE_LABEL,
  listFeatures,
  isValidFeatureId,
  parseFeatureAccess,
  parseFeatureAccessValue,
  serializeFeatureAccess,
  resolveProductForOwnedAsset,
  checkOwnedAssetFeature,
  checkAssetFeature,
  resolveProductForPoolAsset,
  isTrialAsset,
  getTrialFeatureAccess,
  setTrialFeatureAccess,
  resetTrialFeatureAccess,
};
