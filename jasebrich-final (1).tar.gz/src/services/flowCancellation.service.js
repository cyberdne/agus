/**
 * Centralized cancellation for every interactive input flow.
 *
 * A Telegram user can only be in one interactive flow at a time. When a
 * navigation button is pressed, the previous flow must be discarded before
 * the destination handler runs; otherwise the old middleware can consume the
 * next message as stale input (phone/OTP/token/admin/panel wizard/etc.).
 */
const buyerState = require('../state/buyerState');
const tokenClaimState = require('../state/tokenClaimState');
const adminState = require('../state/adminState');
const panelState = require('../state/panelState');
const gramjsService = require('./gramjs.service');

function hasActiveFlow(telegramId) {
  return Boolean(
    buyerState.get(telegramId) ||
    tokenClaimState.get(telegramId) ||
    adminState.get(telegramId) ||
    panelState.get(telegramId)?.step
  );
}

/**
 * Cancel all input/wizard state and any pending GramJS phone login.
 * Returns true when something was actually active.
 */
function cancelAll(telegramId) {
  const active = hasActiveFlow(telegramId);

  // Important: cancel the actual GramJS auth attempt, not just its UI state.
  // This prevents a late OTP/2FA result from completing an abandoned login.
  if (buyerState.get(telegramId)) {
    try { gramjsService.cancelLogin(telegramId); } catch (_) {}
  }

  buyerState.clear(telegramId);
  tokenClaimState.clear(telegramId);
  adminState.clear(telegramId);
  panelState.clear(telegramId);
  return active;
}

/** Cancel only the current wizard step while keeping the selected userbot. */
function cancelPanelStep(telegramId) {
  const active = Boolean(panelState.get(telegramId)?.step);
  panelState.clearStep(telegramId);
  return active;
}

/**
 * Cancel every flow except the currently selected Kontrol Panel session.
 * Used when moving between panel sub-features so the selected userbot is
 * preserved while stale phone/OTP/token/admin flows are discarded.
 */
function cancelOutsidePanel(telegramId) {
  const panel = panelState.get(telegramId);
  const active = Boolean(
    buyerState.get(telegramId) ||
    tokenClaimState.get(telegramId) ||
    adminState.get(telegramId) ||
    panel?.step
  );

  if (buyerState.get(telegramId)) {
    try { gramjsService.cancelLogin(telegramId); } catch (_) {}
  }
  buyerState.clear(telegramId);
  tokenClaimState.clear(telegramId);
  adminState.clear(telegramId);
  if (panel) panelState.clearStep(telegramId);
  return active;
}

module.exports = { hasActiveFlow, cancelAll, cancelPanelStep, cancelOutsidePanel };
