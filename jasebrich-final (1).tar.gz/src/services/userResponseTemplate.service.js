/**
 * Canonical registry for user-facing operational responses that previously
 * escaped the Custom Submenu system. Feature screens already use
 * defineTemplate()/defineSubmenu(); this module closes the remaining gaps for
 * errors, callback alerts, fallback responses, and flow prompts.
 *
 * These are deliberately NOT used for cancellation notices whose wording is
 * explicitly fixed by the product requirement (see cancelNotice.service.js).
 */
const { defineTemplate } = require('./custom-submenu.service');

const userResponseTpl = {
  paymentProofFailed: defineTemplate('system.payment_proof_failed', 'System', 'Bukti Pembayaran Gagal Diproses', '❌ Bukti pembayaran gagal diproses.'),
  mediaProcessFailed: defineTemplate('system.media_process_failed', 'System', 'Media Tidak Dapat Diproses', '❌ Media tidak dapat diproses. Silakan coba lagi.'),
  unknownCommand: defineTemplate('system.unknown_command', 'System', 'Perintah Tidak Dikenali', 'Perintah tidak dikenali. Silakan gunakan menu di bawah ini.'),
  joinGateError: defineTemplate('system.join_gate_error', 'System', 'Verifikasi Sistem Bermasalah', '❌ Sistem verifikasi sedang bermasalah. Silakan coba lagi beberapa saat lagi.'),
  banCallback: defineTemplate('system.ban_callback', 'System', 'Akun Diblokir (Alert)', '🚫 Akun Anda diblokir.', { messageType: 'callback_alert', maxLength: 200 }),
  banMessage: defineTemplate('system.ban_message', 'System', 'Akun Diblokir', '🚫 Akun Anda diblokir dan tidak dapat menggunakan bot ini. Hubungi admin jika ini keliru.'),
  joinNotDetected: defineTemplate('system.join_not_detected', 'System', 'Keanggotaan Belum Terdeteksi (Alert)', 'Belum terdeteksi bergabung.', { messageType: 'callback_alert', maxLength: 200 }),
  joinVerified: defineTemplate('system.join_verified', 'System', 'Verifikasi Berhasil (Alert)', 'Berhasil diverifikasi!', { messageType: 'callback_alert', maxLength: 200 }),
  rateLimited: defineTemplate('system.rate_limited', 'System', 'Terlalu Banyak Permintaan', '⏳ Terlalu banyak permintaan. Coba lagi sebentar lagi.'),
  rateLimitedCallback: defineTemplate('system.rate_limited_callback', 'System', 'Rate Limit (Alert)', '⏳ Terlalu banyak permintaan. Coba lagi sebentar lagi.', { messageType: 'callback_alert', maxLength: 200 }),

  ubotGenericError: defineTemplate('system.ubot_generic_error', 'Userbot', 'Kesalahan Flow Userbot', '❌ Terjadi kesalahan. Silakan coba lagi.'),
  customInputInvalid: defineTemplate('system.custom_input_invalid', 'System', 'Input Custom Tidak Valid', '❌ {reason}\n\nKirim ulang pesan custom yang valid.', { supportedPlaceholders: ['reason'] }),
  contactNotNeeded: defineTemplate('userbot.activation_contact_not_needed', 'Userbot', 'Kontak Tidak Diperlukan', '❌ Kontak tidak diperlukan pada langkah ini. Kirim kode/password yang diminta.'),
  contactOwnRequired: defineTemplate('userbot.activation_contact_own_required', 'Userbot', 'Kontak Akun Sendiri Diperlukan', '❌ Silakan tekan tombol *Kontak Saya* dan bagikan kontak akun Telegram kamu sendiri.'),
  contactPrompt: defineTemplate('userbot.activation_contact_prompt', 'Userbot', 'Prompt Verifikasi Kontak', '💬 *Verifikasi Kontak*\n\nSilakan tekan tombol *Kontak Saya* untuk melanjutkan.'),
  contactWrongAccount: defineTemplate('userbot.activation_contact_wrong_account', 'Userbot', 'Kontak Bukan Akun Sendiri', '❌ Kontak yang dibagikan harus berasal dari akun Telegram yang akan dijadikan userbot. Tekan tombol *Kontak Saya* untuk membagikan kontak akunmu sendiri.'),

  tokenProcessError: defineTemplate('token.process_error', 'Backup Token', 'Kesalahan Proses Token', '❌ Terjadi kesalahan saat memproses token. Silakan coba lagi.'),
  panelPickerPrompt: defineTemplate('panel.userbot_picker_prompt', 'Userbot', 'Pilih Userbot', 'Pilih salah satu userbot dari daftar di bawah ini.'),
  panelForwardProcessError: defineTemplate('panel.forward_process_error', 'Message Settings', 'Forward Tidak Dapat Diproses', '❌ Pesan forward tidak dapat diproses. Silakan coba lagi.'),
  panelForwardSourceMissing: defineTemplate('panel.forward_source_missing', 'Message Settings', 'Source Forward Tidak Tersedia', '❌ Pesan forward ini tidak menyediakan source message ID. Forward ulang dari channel/grup yang dapat direferensikan.'),
  panelForwardSaveError: defineTemplate('panel.forward_save_error', 'Message Settings', 'Forward Tidak Dapat Disimpan', '❌ Pesan forward tidak dapat disimpan. Silakan coba lagi.'),
  panelBroadcastCopyResult: defineTemplate('panel.broadcast_copy_result', 'Broadcast PM', 'Broadcast Copy Selesai', '📄 Forward tidak memiliki source ID yang dapat dire-forward; konten dikirim sebagai copy.\nBroadcast selesai: {hasil}.', { supportedPlaceholders: ['hasil'] }),
  panelBroadcastResult: defineTemplate('panel.broadcast_result_fallback', 'Broadcast PM', 'Broadcast Selesai', '📄 Broadcast PM selesai: {hasil}.', { supportedPlaceholders: ['hasil'] }),
  panelForwardSaved: defineTemplate('panel.forward_saved', 'Message Settings', 'Forward Disimpan', '✅ Pesan forward disimpan.', { supportedPlaceholders: [] }),
  panelForwardSavedAndJoined: defineTemplate('panel.forward_saved_joined', 'Message Settings', 'Forward Disimpan + Auto Join', '✅ Pesan forward disimpan. Userbot otomatis bergabung ke {hasil} agar pesan ini bisa dikirim ke semua target.', { supportedPlaceholders: ['hasil'] }),
  panelForwardPreviewText: defineTemplate('panel.forward_preview_text', 'Message Settings', 'Preview Forward Teks', '↪️ *Pesan forward aktif*\n\n{pesan}{media}\n\nAsal: {asal}\nMessage ID: {message_id}', { supportedPlaceholders: ['pesan','media','asal','message_id'] }),
  panelForwardPreviewMedia: defineTemplate('panel.forward_preview_media', 'Message Settings', 'Preview Forward Media', '↪️ *Pesan forward aktif*\n\n📎 Pesan media\nAsal: {asal}\nMessage ID: {message_id}', { supportedPlaceholders: ['asal','message_id'] }),
  panelForwardPreviewUnavailable: defineTemplate('panel.forward_preview_unavailable', 'Message Settings', 'Preview Forward Tidak Tersedia', '↪️ *Pesan forward aktif*\n\nAsal: {asal}\nMessage ID: {message_id}\n\n⚠️ Preview membutuhkan userbot yang aktif dan akses ke pesan asal.', { supportedPlaceholders: ['asal','message_id'] }),
};

function get(template, ctx, extra = {}) {
  const content = template.getContent(ctx, extra);
  return content;
}

module.exports = { userResponseTpl, get };
