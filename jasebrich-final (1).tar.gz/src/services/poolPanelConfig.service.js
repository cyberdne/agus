const poolRepo = require('../database/repositories/userbotPool.repository');
const DEFAULT_WTB_COOLDOWN_MINUTES = 3;
const MAX_WTB_COOLDOWN_MINUTES = 10080;
const delayPolicy = require('./delayPolicy.service');
const automationConfig = require('./automationConfig.service');

const RECOMMENDED_GROUP_DELAY_SECONDS = delayPolicy.DEFAULT_GROUP_DELAY_SECONDS;
const RECOMMENDED_ROUND_DELAY_SECONDS = delayPolicy.DEFAULT_ROUND_DELAY_SECONDS;

function row(id) { return poolRepo.findById(id); }
function ensure(id) {
  const r = row(id);
  if (!r) throw new Error('Userbot Jaseb tidak ditemukan.');
  return r;
}

function getSettings(id) {
  const r = ensure(id);
  return {
    wtb_timer: r.wtb_timer || null,
    wtb_auto_reset_minutes: Number(r.wtb_auto_reset_minutes || DEFAULT_WTB_COOLDOWN_MINUTES),
    channel_disabled: Number(r.channel_disabled || 0),
    wtb_target_channel: r.wtb_target_channel || null,
    wtb_banned_words: r.wtb_banned_words || '',
    wtb_max_chars: Number(r.wtb_max_chars || 0),
    wtb_filter_links: Number(r.wtb_filter_links || 0),
    wtb_filter_usernames: Number(r.wtb_filter_usernames || 0),
    auto_react: Number(r.auto_react || 0),
    auto_react_emoji: r.auto_react_emoji || '❤️',
    group_delay_seconds: Number(r.delay_seconds || RECOMMENDED_GROUP_DELAY_SECONDS),
    group_delay_max_seconds: Number(r.delay_max_seconds || r.delay_seconds || RECOMMENDED_GROUP_DELAY_SECONDS),
    round_delay_seconds: Number(r.round_delay_seconds || RECOMMENDED_ROUND_DELAY_SECONDS),
  };
}

function updateSettings(id, fields) {
  const cur = getSettings(id);
  let groupMin = cur.group_delay_seconds;
  let groupMax = cur.group_delay_max_seconds;
  if (fields.group_delay_range) {
    const range = delayPolicy.normalizeGroupDelayRange(fields.group_delay_range.min, fields.group_delay_range.max);
    if (!range) throw new Error('Range jeda antar grup tidak valid.');
    groupMin = range.min; groupMax = range.max;
  } else if (fields.group_delay_seconds !== undefined) {
    const n = Number(fields.group_delay_seconds);
    if (!Number.isInteger(n) || n < 0 || n > delayPolicy.GROUP_DELAY_MAX_SECONDS) throw new Error('Jeda antar grup tidak valid.');
    groupMin = n; groupMax = n;
  }
  let cooldown = cur.wtb_auto_reset_minutes;
  if (fields.wtb_auto_reset_minutes !== undefined) {
    const raw = String(fields.wtb_auto_reset_minutes ?? '').trim();
    if (!/^\d+$/.test(raw)) throw new Error('Cooldown Base Reply harus bilangan bulat positif.');
    const parsed = Number(raw);
    if (!Number.isSafeInteger(parsed) || parsed < 1 || parsed > MAX_WTB_COOLDOWN_MINUTES) throw new Error(`Cooldown Base Reply harus 1-${MAX_WTB_COOLDOWN_MINUTES} menit.`);
    cooldown = parsed;
  }
  const round = fields.round_delay_seconds === undefined
    ? cur.round_delay_seconds
    : delayPolicy.normalizeRoundDelaySeconds(fields.round_delay_seconds);
  if (round === null) throw new Error('Jeda antar putaran tidak valid.');
  const db = require('../database').getDb();
  db.prepare(`UPDATE userbot_pool SET
    wtb_timer=?, wtb_auto_reset_minutes=?, channel_disabled=?, wtb_target_channel=?,
    wtb_banned_words=?, wtb_max_chars=?, wtb_filter_links=?, wtb_filter_usernames=?,
    auto_react=?, auto_react_emoji=?, delay_seconds=?, delay_max_seconds=?, round_delay_seconds=?,
    updated_at=datetime('now') WHERE id=?`).run(
    fields.wtb_timer !== undefined ? fields.wtb_timer : cur.wtb_timer,
    cooldown,
    fields.channel_disabled !== undefined ? (fields.channel_disabled ? 1 : 0) : cur.channel_disabled,
    fields.wtb_target_channel !== undefined ? fields.wtb_target_channel : cur.wtb_target_channel,
    fields.wtb_banned_words !== undefined ? String(fields.wtb_banned_words || '') : cur.wtb_banned_words,
    fields.wtb_max_chars !== undefined ? Math.max(0, Number(fields.wtb_max_chars) || 0) : cur.wtb_max_chars,
    fields.wtb_filter_links !== undefined ? (fields.wtb_filter_links ? 1 : 0) : cur.wtb_filter_links,
    fields.wtb_filter_usernames !== undefined ? (fields.wtb_filter_usernames ? 1 : 0) : cur.wtb_filter_usernames,
    fields.auto_react !== undefined ? (fields.auto_react ? 1 : 0) : cur.auto_react,
    fields.auto_react_emoji !== undefined ? String(fields.auto_react_emoji || '❤️') : cur.auto_react_emoji,
    groupMin, groupMax, round, id
  );
  return getSettings(id);
}

function listGroups(id) {
  const r = ensure(id);
  const targets = String(r.target || '').split(/\n+/).map((x) => x.trim()).filter(Boolean);
  return targets.map((target, index) => ({ id: index + 1, target, title: null, topic_id: r.topic_grup || null, enabled: 1 }));
}
function countGroups(id) {
  return listGroups(id).length;
}
function listGroupsPage(id, offset, limit) {
  const all = listGroups(id);
  const safeOffset = Math.max(0, Number.isInteger(Number(offset)) ? Number(offset) : 0);
  const safeLimit = Math.max(1, Math.min(100, Number.isInteger(Number(limit)) ? Number(limit) : 10));
  return all.slice(safeOffset, safeOffset + safeLimit);
}
function addGroup(id, target, title = null, topicId = null) {
  const normalized = String(target || '').trim(); if (!normalized) throw new Error('Target grup kosong.');
  const values = listGroups(id).map((g) => g.target);
  if (!values.includes(normalized)) values.push(normalized);
  poolRepo.updateConfig(id, { target: values.join('\n'), topic_grup: topicId == null ? undefined : String(topicId) });
  require('../database').getDb().prepare('DELETE FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target=?')
    .run('pool', id, normalized);
  return listGroups(id).find((g) => g.target === normalized) || null;
}
function deleteGroup(id, targetOrId) {
  const groups = listGroups(id);
  const n = Number(targetOrId);
  let target = Number.isInteger(n) && n > 0 ? groups.find((g) => g.id === n)?.target : String(targetOrId || '').trim();
  if (!target) return 0;
  const next = groups.filter((g) => g.target !== target).map((g) => g.target);
  const changed = next.length === groups.length ? 0 : 1;
  poolRepo.updateConfig(id, { target: next.length ? next.join('\n') : null });
  if (changed) require('../database').getDb().prepare('DELETE FROM userbot_promotion_target_health WHERE owner_kind=? AND owner_id=? AND target=?').run('pool', id, String(target));
  return changed;
}
function deleteAllGroups(id) {
  const changed = listGroups(id).length ? 1 : 0;
  poolRepo.updateConfig(id, { target: null, topic_grup: null });
  return changed;
}
function updateGroupTopic(id, target, topicId) {
  const g = listGroups(id).find((x) => x.target === String(target).trim());
  if (!g) return 0;
  poolRepo.updateConfig(id, { topic_grup: topicId == null ? null : String(topicId) });
  return 1;
}

function parseJsonArray(raw, fallback = []) {
  if (Array.isArray(raw)) return raw;
  try {
    const parsed = JSON.parse(raw || '[]');
    return Array.isArray(parsed) ? parsed : fallback;
  } catch (_) {
    return fallback;
  }
}

function normalizeEntities(entities) {
  return Array.isArray(entities) ? entities.map((e) => ({ ...e })) : [];
}

function getMessage(id) {
  const r = ensure(id);
  const kind = String(r.broadcast_kind || 'text').toLowerCase();
  if (kind === 'forward') {
    if (r.broadcast_source_chat_id == null || r.broadcast_source_message_id == null) return null;
    return {
      kind: 'forward',
      text: null,
      entities: '[]',
      caption_entities: '[]',
      source_chat_id: String(r.broadcast_source_chat_id),
      source_message_id: Number(r.broadcast_source_message_id),
    };
  }
  if (!r.broadcast_text) return null;
  return { kind: 'text', text: r.broadcast_text, entities: r.broadcast_text_entities || '[]', caption_entities: '[]' };
}
function setTextMessage(id, text, entities = []) {
  const normalized = normalizeEntities(entities);
  poolRepo.updateConfig(id, {
    broadcast_text: String(text || ''),
    broadcast_text_entities: JSON.stringify(normalized),
    broadcast_kind: 'text',
    broadcast_source_chat_id: null,
    broadcast_source_message_id: null,
  });
}
function setMediaMessage() {
  const e = new Error('Fitur media pesan promosi belum tersedia untuk konfigurasi stok Jaseb karena storage media pool belum didukung.');
  e.code='POOL_PANEL_UNSUPPORTED';
  throw e;
}
function setForwardMessage(id, sourceChatId, sourceMessageId) {
  const chatId = String(sourceChatId ?? '').trim();
  const messageId = Number(sourceMessageId);
  if (!chatId || !Number.isSafeInteger(messageId) || messageId <= 0) {
    throw new Error('Sumber pesan forward tidak valid.');
  }
  // Keep the existing broadcast_text as the optional plain-text fallback.
  // Forward remains the primary configured mode; this does not introduce a
  // second message configuration store.
  poolRepo.updateConfig(id, {
    broadcast_kind: 'forward',
    broadcast_source_chat_id: chatId,
    broadcast_source_message_id: messageId,
  });
}
function clearMessage(id) {
  poolRepo.updateConfig(id, {
    broadcast_text: null,
    broadcast_text_entities: '[]',
    broadcast_kind: 'text',
    broadcast_source_chat_id: null,
    broadcast_source_message_id: null,
  });
}
function safeDeleteMedia() {}

function listReplies(id) {
  const r = ensure(id);
  return parseJsonArray(r.wtb_replies).map((reply) => ({
    id: Number(reply.id),
    keywords: String(reply.keywords || ''),
    response: String(reply.response || ''),
    entities: typeof reply.entities === 'string' ? reply.entities : JSON.stringify(normalizeEntities(reply.entities)),
    enabled: Boolean(reply.enabled),
    created_at: reply.created_at || null,
  })).filter((reply) => Number.isSafeInteger(reply.id) && reply.id > 0);
}
function addReply(id, keywords, response, entities = []) {
  const k = String(keywords || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean).join(',');
  if (!k || !response) throw new Error('Keyword dan balasan wajib diisi.');
  const rows = listReplies(id);
  const nextId = rows.reduce((max, row) => Math.max(max, row.id), 0) + 1;
  const row = { id: nextId, keywords: k, response: String(response), entities: JSON.stringify(normalizeEntities(entities)), enabled: true, created_at: new Date().toISOString() };
  const raw = parseJsonArray(ensure(id).wtb_replies);
  raw.push(row);
  poolRepo.updateConfig(id, { wtb_replies: JSON.stringify(raw) });
  return row;
}
function deleteReply(id, replyId) {
  const numericId = Number(replyId);
  if (!Number.isSafeInteger(numericId) || numericId <= 0) return 0;
  const raw = parseJsonArray(ensure(id).wtb_replies);
  const next = raw.filter((reply) => Number(reply?.id) !== numericId);
  if (next.length === raw.length) return 0;
  poolRepo.updateConfig(id, { wtb_replies: JSON.stringify(next) });
  return 1;
}
function setReplyEnabled(id, enabled) {
  const raw = parseJsonArray(ensure(id).wtb_replies);
  const next = raw.map((reply) => ({ ...reply, enabled: enabled ? true : false }));
  poolRepo.updateConfig(id, { wtb_replies: JSON.stringify(next) });
}
function hasEnabledReply(id) {
  return listReplies(id).some((reply) => reply.enabled);
}

function setPmPermitMessage(id, text) { poolRepo.updateConfig(id, { pm_permit_text: String(text || '') }); }
function getPmPermitMessage(id) { const r=ensure(id); return r.pm_permit_text ? { userbot_id:id, text:r.pm_permit_text, entities:'[]' } : null; }
function clearPmPermitMessage(id) { poolRepo.updateConfig(id, { pm_permit_text:null }); }
function setBroadcastPmMessage() { const e = new Error('Broadcast PM khusus belum tersedia untuk stok Jaseb.'); e.code='POOL_PANEL_UNSUPPORTED'; throw e; }
function getBroadcastPmMessage() { return null; }
function clearBroadcastPmMessage() {}

function resetAll(id) {
  poolRepo.resetConfig(id);
  return true;
}

module.exports = {
  getSettings, updateSettings, listGroups, countGroups, listGroupsPage, addGroup, deleteGroup, deleteAllGroups, updateGroupTopic,
  RECOMMENDED_GROUP_DELAY_SECONDS, RECOMMENDED_ROUND_DELAY_SECONDS, DEFAULT_WTB_COOLDOWN_MINUTES, MAX_WTB_COOLDOWN_MINUTES,
  getGroupDelayRange: (id) => delayPolicy.readGroupDelayRange(getSettings(id), RECOMMENDED_GROUP_DELAY_SECONDS),
  getRoundDelaySeconds: (id) => delayPolicy.readRoundDelaySeconds(getSettings(id), RECOMMENDED_ROUND_DELAY_SECONDS),
  delayPolicy,
  getMessage, setTextMessage, setMediaMessage, setForwardMessage, clearMessage, safeDeleteMedia,
  listReplies, addReply, deleteReply, setReplyEnabled, hasEnabledReply, resetAll,
  setPmPermitMessage, getPmPermitMessage, clearPmPermitMessage,
  setBroadcastPmMessage, getBroadcastPmMessage, clearBroadcastPmMessage,
};
